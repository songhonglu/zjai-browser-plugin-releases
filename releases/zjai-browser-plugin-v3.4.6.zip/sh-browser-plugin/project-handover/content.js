(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else api.bootstrap();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const FAB_ID = 'project-handover-fab';
  const PANEL_ID = 'project-handover-panel';
  const FAB_POS_KEY = 'project-handover:fab-pos';
  const PANEL_POS_KEY = 'project-handover:panel-pos';
  const TEMPLATE_PATH = 'project-handover/assets/项目交接会议纪要模板.docx';
  const WORD_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  const LABEL_ALIASES = Object.freeze({
    '大区': '大区名称',
    '区域': '大区名称',
    '合同号': '合同编号',
    '客户名称': '签约单位',
    '签约客户': '签约单位',
    '合同客户': '签约单位',
    '客户单位': '签约单位',
    '最终用户': '实际用户',
    '项目客户': '实际用户',
    '是否招标': '是否招标项目',
    '是否有合同': '是否签订合同',
    '是否提前入场': '是否提前进场',
    '合同时间': '合同签订时间',
    '产品': '交付产品',
    '插件': '交付插件',
    '实施人天': '实施合同人天',
    '客开人天': '客开合同人天',
    '客户环境': '客户IT环境',
    '项目范围': '实施范围',
    '合同交付内容': '交付内容',
    '核心需求': '最核心需求',
    '开发内容': '需要开发内容',
    '特殊条款': '特殊的条款',
    '口头承诺': '客户要求和口头承诺',
    '项目风险': '风险和其他说明',
    '风险说明': '风险和其他说明',
    '进场日期': '进场时间',
    '实施评估人天': '实施进场评估人天',
    '客开评估人天': '客开进场评估人天',
    '计划安排': '项目安排'
  });

  let currentSnapshot = null;
  let monitorTimer = 0;
  let launcherButton = null;

  function normalizeText(value) {
    return String(value == null ? '' : value).replace(/[\u200b-\u200f\ufeff]/g, '').replace(/\s+/g, ' ').trim();
  }

  function normalizeLabel(value) {
    return normalizeText(value).replace(/[：:*＊\s]+$/g, '').replace(/\s+/g, '');
  }

  function parseHandoverTitle(text) {
    const normalized = normalizeText(text);
    const match = normalized.match(/\(自动发起\)\s*【([^】]+)】\s*-\s*\{([^{}]+?)-([^{}]+)\}\s*-\s*([\d,]+(?:\.\d+)?)\s*项目移交/);
    if (!match) return null;
    return {
      region: normalizeText(match[1]),
      contractNo: normalizeText(match[2]),
      company: normalizeText(match[3]),
      amount: normalizeText(match[4]).replace(/,/g, ''),
      rawTitle: normalizeText(match[0])
    };
  }

  function sanitizeFilePart(value) {
    const cleaned = normalizeText(value)
      .replace(/[\p{Cc}\p{Cf}]/gu, '')
      .replace(/[\\/:*?"<>|]/g, '_')
      .replace(/[.\s]+$/g, '');
    const source = cleaned || '未命名单位';
    const encoder = new TextEncoder();
    let result = '';
    let bytes = 0;
    for (const char of source) {
      const size = encoder.encode(char).length;
      if (bytes + size > 160) break;
      result += char;
      bytes += size;
    }
    return result || '未命名单位';
  }

  function buildOutputFileName(company, date) {
    const value = date instanceof Date ? date : new Date(date);
    const yyyy = value.getFullYear();
    const mm = String(value.getMonth() + 1).padStart(2, '0');
    const dd = String(value.getDate()).padStart(2, '0');
    return `项目交接会议纪要-${sanitizeFilePart(company)}-${yyyy}-${mm}-${dd}.docx`;
  }

  function templateLabelFor(label) {
    const normalized = normalizeLabel(label);
    return LABEL_ALIASES[normalized] || normalized;
  }

  function isVisible(node) {
    if (!node || !node.ownerDocument || !node.getBoundingClientRect) return true;
    try {
      const style = node.ownerDocument.defaultView.getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden') return false;
      const rect = node.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    } catch (_) {
      return true;
    }
  }

  function allDocs() {
    const docs = [];
    const seen = new Set();
    const visit = (doc) => {
      if (!doc || seen.has(doc)) return;
      seen.add(doc);
      docs.push(doc);
      try {
        doc.querySelectorAll('iframe').forEach((frame) => {
          try { visit(frame.contentDocument); } catch (_) {}
        });
      } catch (_) {}
    };
    visit(document);
    try { if (window.top && window.top.document !== document) visit(window.top.document); } catch (_) {}
    return docs;
  }

  function controlValue(control) {
    if (!control || control.disabled || !isVisible(control)) return '';
    const tag = String(control.tagName || '').toLowerCase();
    const type = String(control.type || '').toLowerCase();
    if ((type === 'checkbox' || type === 'radio')) return control.checked ? normalizeText(control.value || '是') : '';
    if (tag === 'select') {
      const option = control.options && control.options[control.selectedIndex];
      return normalizeText(option ? option.textContent : control.value);
    }
    return normalizeText(control.value != null ? control.value : control.getAttribute('value'));
  }

  function cellValue(cell) {
    if (!cell) return '';
    const controls = Array.from(cell.querySelectorAll('input,select,textarea'));
    const values = controls.map(controlValue).filter(Boolean);
    if (controls.length) return Array.from(new Set(values)).join('、');
    return normalizeText(cell.innerText || cell.textContent);
  }

  function labelForControl(control) {
    const explicit = normalizeText(control.getAttribute('aria-label') || control.getAttribute('data-label') || control.placeholder);
    if (explicit && explicit.length <= 40) return explicit;
    const id = control.id;
    if (id) {
      try {
        const label = control.ownerDocument.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (label) return normalizeText(label.textContent);
      } catch (_) {}
    }
    const cell = control.closest('td,th');
    if (cell) {
      let previous = cell.previousElementSibling;
      while (previous) {
        const value = normalizeText(previous.innerText || previous.textContent);
        if (value && value.length <= 40) return value;
        previous = previous.previousElementSibling;
      }
    }
    const group = control.closest('.cap4-field,.form-group,.el-form-item,[class*="field"]');
    if (group) {
      const label = group.querySelector('label,.cap4-label,.el-form-item__label,[class*="label"]');
      if (label) return normalizeText(label.textContent);
    }
    return '';
  }

  function looksLikeLabel(text) {
    const value = normalizeLabel(text);
    return value.length > 0 && value.length <= 24 && !/^[-+]?\d+(?:\.\d+)?%?$/.test(value) && !/^https?:\/\//i.test(value);
  }

  function collectPageFields() {
    const fields = new Map();
    const put = (label, value, source) => {
      const cleanLabel = normalizeLabel(label);
      const cleanValue = normalizeText(value);
      if (!cleanLabel || cleanLabel.length > 40) return;
      const key = templateLabelFor(cleanLabel);
      const existing = fields.get(key);
      const priority = source === 'control' ? 2 : 1;
      const existingPriority = existing && existing.source === 'control' ? 2 : 1;
      if (!existing || priority > existingPriority || (!existing.value && cleanValue)) {
        fields.set(key, { label: key, originalLabel: cleanLabel, value: cleanValue, source });
      }
    };

    allDocs().forEach((doc) => {
      doc.querySelectorAll('input,select,textarea').forEach((control) => {
        if (control.closest(`#${FAB_ID},#${PANEL_ID}`)) return;
        put(labelForControl(control), controlValue(control), 'control');
      });
      doc.querySelectorAll('tr').forEach((row) => {
        if (!isVisible(row) || row.closest(`#${FAB_ID},#${PANEL_ID}`)) return;
        const cells = Array.from(row.children).filter((node) => /^(TD|TH)$/.test(node.tagName));
        for (let index = 0; index < cells.length - 1; index += 2) {
          const label = normalizeText(cells[index].innerText || cells[index].textContent);
          if (!looksLikeLabel(label)) continue;
          put(label, cellValue(cells[index + 1]), 'row');
        }
      });
    });
    return Array.from(fields.values()).sort((a, b) => a.label.localeCompare(b.label, 'zh-CN'));
  }

  function findPageTitle() {
    for (const doc of allDocs()) {
      const candidates = [];
      const subject = doc.getElementById && doc.getElementById('subject');
      if (subject) candidates.push(subject.value, subject.textContent);
      candidates.push(doc.title);
      try {
        const text = normalizeText(doc.body && (doc.body.innerText || doc.body.textContent));
        const direct = parseHandoverTitle(text);
        if (direct) return direct;
      } catch (_) {}
      for (const candidate of candidates) {
        const parsed = parseHandoverTitle(candidate);
        if (parsed) return parsed;
      }
    }
    return null;
  }

  function readSnapshot() {
    const title = findPageTitle();
    if (!title) return null;
    const fields = collectPageFields();
    const values = new Map(fields.map((field) => [field.label, field.value]));
    const titleFields = [
      ['大区名称', title.region],
      ['合同编号', title.contractNo],
      ['签约单位', title.company],
      ['合同金额', title.amount]
    ];
    titleFields.forEach(([label, value]) => {
      values.set(label, value);
      const existing = fields.find((field) => field.label === label);
      if (existing) existing.value = value;
      else fields.unshift({ label, originalLabel: label, value, source: 'title' });
    });
    return { title, fields, values, readAt: new Date() };
  }

  function bindDrag(handle, target, storageKey) {
    if (!handle || !target || handle.dataset.dragBound === '1') return;
    handle.dataset.dragBound = '1';
    let active = false;
    let moved = false;
    let startX = 0;
    let startY = 0;
    let offsetX = 0;
    let offsetY = 0;
    const moveTo = (left, top) => {
      const maxLeft = Math.max(0, window.innerWidth - target.offsetWidth);
      const maxTop = Math.max(0, window.innerHeight - target.offsetHeight);
      target.style.left = `${Math.max(0, Math.min(maxLeft, left))}px`;
      target.style.top = `${Math.max(0, Math.min(maxTop, top))}px`;
      target.style.right = 'auto';
    };
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
      if (saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) moveTo(saved.left, saved.top);
    } catch (_) {}
    handle.addEventListener('pointerdown', (event) => {
      if (event.target !== handle && event.target && event.target.closest && event.target.closest('button')) return;
      const rect = target.getBoundingClientRect();
      active = true;
      moved = false;
      startX = event.clientX;
      startY = event.clientY;
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      try { handle.setPointerCapture(event.pointerId); } catch (_) {}
    });
    handle.addEventListener('pointermove', (event) => {
      if (!active) return;
      if (!moved && Math.hypot(event.clientX - startX, event.clientY - startY) > 5) moved = true;
      if (moved) moveTo(event.clientX - offsetX, event.clientY - offsetY);
    });
    const stop = (event) => {
      if (!active) return;
      active = false;
      try { handle.releasePointerCapture(event.pointerId); } catch (_) {}
      if (!moved) return;
      target.dataset.draggedAt = String(Date.now());
      const rect = target.getBoundingClientRect();
      try { localStorage.setItem(storageKey, JSON.stringify({ left: rect.left, top: rect.top })); } catch (_) {}
    };
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
    window.addEventListener('resize', () => {
      const rect = target.getBoundingClientRect();
      moveTo(rect.left, rect.top);
    });
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function ensurePanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;
    panel = document.createElement('section');
    panel.id = PANEL_ID;
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'false');
    panel.setAttribute('aria-label', '项目移交会议纪要');
    panel.style.cssText = 'position:fixed;top:72px;right:16px;width:480px;max-width:calc(100vw - 32px);max-height:80vh;display:none;flex-direction:column;background:#fff;border:1px solid #bfdbfe;border-radius:12px;box-shadow:0 12px 40px rgba(30,64,175,.24);z-index:2147483647;font:13px/1.5 system-ui,-apple-system,"Microsoft YaHei",sans-serif;color:#1f2937;overflow:hidden';
    panel.innerHTML = `
      <style>
        #${PANEL_ID} button:hover:not(:disabled){filter:brightness(.94)}
        #${PANEL_ID} button:focus-visible{outline:2px solid #f59e0b;outline-offset:2px}
      </style>
      <header id="ph-header" style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#1d4ed8;color:#fff;cursor:move;user-select:none">
        <b style="font-size:14px">项目移交会议纪要</b>
        <button id="ph-close" type="button" aria-label="关闭" style="width:28px;height:28px;border:0;border-radius:8px;background:rgba(255,255,255,.18);color:#fff;font-size:18px;cursor:pointer">×</button>
      </header>
      <div style="padding:12px 16px;overflow:auto">
        <div id="ph-status" role="status" style="padding:8px 12px;border:1px solid #bfdbfe;border-radius:8px;background:#eff6ff;color:#1d4ed8;font-weight:600"></div>
        <div id="ph-fields" style="margin-top:12px"></div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px">
          <button id="ph-reread" type="button" aria-label="重新读取网页字段" style="padding:8px 14px;border:0;border-radius:8px;background:#0f766e;color:#fff;cursor:pointer">重新读取</button>
          <button id="ph-generate" type="button" aria-label="写入并下载会议纪要" style="padding:8px 14px;border:0;border-radius:8px;background:#2563eb;color:#fff;cursor:pointer">写入会议纪要</button>
        </div>
      </div>`;
    document.documentElement.appendChild(panel);
    bindDrag(panel.querySelector('#ph-header'), panel, PANEL_POS_KEY);
    panel.querySelector('#ph-close').addEventListener('click', () => {
      panel.style.display = 'none';
      if (launcherButton) launcherButton.focus();
    });
    panel.querySelector('#ph-reread').addEventListener('click', () => renderPanel(readSnapshot()));
    panel.querySelector('#ph-generate').addEventListener('click', async () => {
      const button = panel.querySelector('#ph-generate');
      const status = panel.querySelector('#ph-status');
      button.disabled = true;
      button.style.opacity = '.65';
      status.textContent = '正在生成会议纪要…';
      try {
        currentSnapshot = readSnapshot() || currentSnapshot;
        if (!currentSnapshot) throw new Error('未识别到项目移交流程标题');
        const result = await generateMinutes(currentSnapshot);
        status.textContent = '已生成会议纪要，文件已开始下载。';
        status.title = result.fileName;
      } catch (error) {
        status.textContent = `生成失败：${error && error.message ? error.message : error}`;
        status.style.color = '#b91c1c';
      } finally {
        button.disabled = false;
        button.style.opacity = '1';
      }
    });
    return panel;
  }

  function renderPanel(snapshot) {
    const panel = ensurePanel();
    currentSnapshot = snapshot;
    panel.style.display = 'flex';
    const status = panel.querySelector('#ph-status');
    const fieldsHost = panel.querySelector('#ph-fields');
    status.style.color = '#1d4ed8';
    if (!snapshot) {
      status.textContent = '未识别到项目移交流程，请确认当前页面标题。';
      fieldsHost.innerHTML = '';
      return;
    }
    status.textContent = `已读取 ${snapshot.fields.length} 个字段；网页修改后可点击“重新读取”。`;
    fieldsHost.innerHTML = `<table style="width:100%;table-layout:fixed;border-collapse:collapse;font-size:12px"><tbody>${snapshot.fields.map((field) => `<tr>
      <th scope="row" style="width:34%;padding:7px 8px;border:1px solid #dbeafe;background:#f8fafc;text-align:left;vertical-align:top;word-break:break-word">${escapeHtml(field.label)}</th>
      <td style="padding:7px 8px;border:1px solid #dbeafe;vertical-align:top;white-space:pre-wrap;word-break:break-word">${escapeHtml(field.value || '(空)')}</td>
    </tr>`).join('')}</tbody></table>`;
  }

  function ensureLauncher() {
    let host = document.getElementById(FAB_ID);
    if (host) return host;
    host = document.createElement('div');
    host.id = FAB_ID;
    host.style.cssText = 'position:fixed;right:18px;top:55%;z-index:2147483646;font-family:system-ui,-apple-system,"Microsoft YaHei",sans-serif';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>
      button{font:inherit}#ball{width:42px;height:42px;border:2px solid #fff;border-radius:50%;background:#1d4ed8;color:#fff;font-weight:700;cursor:grab;box-shadow:0 4px 14px rgba(37,99,235,.38)}
      #menu{position:absolute;right:54px;top:0;width:220px;display:none;padding:6px;background:#fff;border:1px solid #bfdbfe;border-radius:10px;box-shadow:0 10px 30px rgba(30,64,175,.2)}
      #menu.open{display:block}#open{width:100%;padding:10px 12px;border:0;border-radius:8px;background:#fff;color:#1f2937;text-align:left;cursor:pointer}#open:hover,#open:focus-visible{background:#eff6ff;outline:2px solid #2563eb;outline-offset:1px}
      #ball:focus-visible{outline:2px solid #f59e0b;outline-offset:3px}
      #open b{display:block;font-size:13px}#open span{display:block;margin-top:2px;font-size:11px;color:#64748b}
      @media (prefers-reduced-motion:no-preference){#ball{transition:transform .15s ease}#ball:hover{transform:scale(1.05)}}
    </style><div id="menu"><button id="open" type="button"><b>项目移交会议纪要</b><span>读取网页并生成 DOCX</span></button></div><button id="ball" type="button" aria-label="打开项目移交工具">移</button>`;
    document.documentElement.appendChild(host);
    const ball = shadow.getElementById('ball');
    launcherButton = ball;
    const menu = shadow.getElementById('menu');
    bindDrag(ball, host, FAB_POS_KEY);
    ball.setAttribute('aria-expanded', 'false');
    ball.addEventListener('click', () => {
      if (Date.now() - Number(host.dataset.draggedAt || 0) < 250) return;
      menu.classList.toggle('open');
      ball.setAttribute('aria-expanded', menu.classList.contains('open') ? 'true' : 'false');
    });
    shadow.getElementById('open').addEventListener('click', () => {
      menu.classList.remove('open');
      ball.setAttribute('aria-expanded', 'false');
      renderPanel(readSnapshot());
      const closeButton = document.querySelector(`#${PANEL_ID} #ph-close`);
      if (closeButton) closeButton.focus();
    });
    return host;
  }

  function replaceCellText(cell, value) {
    const oldParagraph = cell.getElementsByTagNameNS(WORD_NS, 'p')[0];
    const oldRun = cell.getElementsByTagNameNS(WORD_NS, 'r')[0];
    const cellProperties = cell.getElementsByTagNameNS(WORD_NS, 'tcPr')[0];
    Array.from(cell.childNodes).forEach((node) => { if (node !== cellProperties) cell.removeChild(node); });
    const paragraph = cell.ownerDocument.createElementNS(WORD_NS, 'w:p');
    const paragraphProperties = oldParagraph && oldParagraph.getElementsByTagNameNS(WORD_NS, 'pPr')[0];
    if (paragraphProperties) paragraph.appendChild(paragraphProperties.cloneNode(true));
    const run = cell.ownerDocument.createElementNS(WORD_NS, 'w:r');
    const runProperties = oldRun && oldRun.getElementsByTagNameNS(WORD_NS, 'rPr')[0];
    if (runProperties) run.appendChild(runProperties.cloneNode(true));
    const text = cell.ownerDocument.createElementNS(WORD_NS, 'w:t');
    text.setAttribute('xml:space', 'preserve');
    text.textContent = String(value || '');
    run.appendChild(text);
    paragraph.appendChild(run);
    cell.appendChild(paragraph);
  }

  function cellText(cell) {
    return normalizeText(Array.from(cell.getElementsByTagNameNS(WORD_NS, 't')).map((node) => node.textContent).join(''));
  }

  function fillDocumentXml(xml, snapshot) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xml, 'application/xml');
    if (doc.getElementsByTagName('parsererror').length) throw new Error('会议纪要模板 XML 无法解析');
    const values = snapshot.values || new Map(snapshot.fields.map((field) => [field.label, field.value]));
    const rows = Array.from(doc.getElementsByTagNameNS(WORD_NS, 'tr'));
    rows.forEach((row) => {
      const cells = Array.from(row.getElementsByTagNameNS(WORD_NS, 'tc')).filter((cell) => cell.parentNode === row);
      cells.forEach((cell, index) => {
        const label = normalizeLabel(cellText(cell));
        if (label.includes('项目交接会议纪要')) {
          replaceCellText(cell, `${snapshot.title.company}项目交接会议纪要`);
          return;
        }
        const targetLabel = templateLabelFor(label);
        const value = values.get(targetLabel);
        if (!value || index + 1 >= cells.length) return;
        replaceCellText(cells[index + 1], value);
      });
    });
    return new XMLSerializer().serializeToString(doc);
  }

  async function generateMinutes(snapshot) {
    if (typeof JSZip === 'undefined') throw new Error('JSZip 未加载');
    const templateUrl = chrome.runtime.getURL('project-handover/assets/项目交接会议纪要模板.docx');
    const response = await fetch(templateUrl);
    if (!response.ok) throw new Error(`模板加载失败：HTTP ${response.status}`);
    const zip = await JSZip.loadAsync(await response.arrayBuffer());
    const documentFile = zip.file('word/document.xml');
    if (!documentFile) throw new Error('模板缺少 word/document.xml');
    zip.file('word/document.xml', fillDocumentXml(await documentFile.async('string'), snapshot));
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
    const fileName = buildOutputFileName(snapshot.title.company, new Date());
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.style.display = 'none';
    document.documentElement.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    return { blob, fileName };
  }

  function removeUi() {
    const fab = document.getElementById(FAB_ID);
    const panel = document.getElementById(PANEL_ID);
    if (fab) fab.remove();
    if (panel) panel.remove();
  }

  function isTopWindow() {
    try { return window.top === window; } catch (_) { return true; }
  }

  function refreshUi() {
    if (!isTopWindow() || !findPageTitle()) {
      removeUi();
      return;
    }
    ensureLauncher();
  }

  function bootstrap() {
    if (typeof document === 'undefined' || !document.documentElement) return;
    refreshUi();
    if (monitorTimer) clearInterval(monitorTimer);
    monitorTimer = setInterval(refreshUi, 1500);
  }

  return {
    parseHandoverTitle,
    sanitizeFilePart,
    buildOutputFileName,
    templateLabelFor,
    collectPageFields,
    fillDocumentXml,
    bootstrap
  };
});
