// =============================================================================
// shared/launcher.js —— 统一悬浮球 + 菜单（方案 B：单球 + 菜单分流）
// =============================================================================
// 在 xt.seeyon.com 工单页注入，作为 ②冲突雷达 与 ③工单速配 的统一入口：
//   1. 隐藏 ②③ 各自的自带悬浮球（#v5cs-fab、#seeyon-bug-flow-host）；
//      ② 的结果面板 #v5cs-panel 保留，由菜单触发的 conflict-open 事件打开。
//   2. 轮询 <html> 上的 data-* 属性（由 ②③ 写入），据此显示菜单项：
//        data-seeyon-conflict = "1"           → 「🔧 代码冲突检测」
//        data-seeyon-engineer = "张三"(非空)   → 「👤 推荐工程师：张三」
//      至少有一项可用才显示统一球；菜单项按可用性动态显隐。
//   3. 菜单点击：
//        冲突检测 → dispatch CustomEvent('seeyon-helper:conflict-open')（②监听→打开面板）
//        推荐工程师 → 复制姓名到剪切板；附带「查看工单」链接（data-seeyon-engineer-affair）
//   4. 球可拖动，位置记忆（chrome.storage.local）。
//
// 用 <html> 上的 data 属性作 IPC，规避多脚本注入的时序问题（launcher 不必早于 ②③）。
// =============================================================================
(function () {
  if (window.__seeyon_launcher) return;              // 防重复注入（每框架独立 window）
  window.__seeyon_launcher = true;

  // ---- 隐藏 ②③ 自带球（保留 ② 面板 #v5cs-panel，由事件触发显示）----
  const hideStyle = document.createElement('style');
  hideStyle.textContent =
    '#v5cs-fab{display:none!important}' +
    '#seeyon-bug-flow-host{display:none!important}';
  (document.head || document.documentElement).appendChild(hideStyle);

  // ---- 日志（统一前缀 [kk-helper:launcher]，便于按模块排查）----
  const LOG = {
    info: (...a) => console.log('[kk-helper:launcher]', ...a),
    warn: (...a) => console.warn('[kk-helper:launcher]', ...a),
    debug: (...a) => console.debug('[kk-helper:launcher]', ...a),
  };
  LOG.info('loaded @ ' + location.href);

  function showLauncherUpdateDot(shadowRoot) {
    const dot = shadowRoot.getElementById('update-dot');
    if (!dot) return;
    const refresh = () => {
      try {
        chrome.runtime.sendMessage({ action: 'checkPluginUpdate' }, (resp) => {
          const info = resp && resp.success ? resp.data : null;
          if (!info || !info.update || !info.url) {
            dot.hidden = true;
            return;
          }
          dot.href = info.url;
          dot.target = '_blank';
          dot.rel = 'noopener noreferrer';
          dot.hidden = false;
          dot.title = '已有新版本 ' + info.version + '，查看更新说明';
          dot.dataset.version = info.version;
        });
      } catch (_) {}
    };
    if (dot.dataset.bound !== '1') {
      dot.dataset.bound = '1';
      dot.addEventListener('pointerdown', (event) => { event.stopPropagation(); });
      dot.addEventListener('click', (event) => {
        event.stopPropagation();
        dot.hidden = true;
        chrome.runtime.sendMessage({ action: 'dismissPluginUpdate', params: { version: dot.dataset.version } });
      });
      setInterval(refresh, 30 * 60 * 1000);
    }
    refresh();
  }

  // ---- 宿主 + Shadow DOM（样式隔离）----
  const host = document.createElement('div');
  host.id = 'seeyon-helper-launcher';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;';
  const shadow = host.attachShadow({ mode: 'open' });
  shadow.innerHTML = `
    <style>
      #ball {
        width:42px;height:42px;border-radius:50%;
        background:#fff;
        color:#fff;font-size:11px;font-weight:700;letter-spacing:.5px;line-height:1.15;
        display:flex;align-items:center;justify-content:center;text-align:center;
        cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;
        box-shadow:0 4px 14px rgba(56,189,248,.45);
        border:2px solid #fff;font-family:"Microsoft YaHei",sans-serif;
        overflow:hidden;
        transition:transform .15s ease;
      }
      #ball img { width:42px;height:42px;display:block;object-fit:cover;pointer-events:none; }
      #ball { position:relative; z-index:5; }
      #ball:hover { transform:scale(1.06); }
      #ball:active { cursor:grabbing; }
      #ball.has-conflict { box-shadow:0 4px 14px rgba(14,165,233,.55); }
      #update-dot{position:absolute;top:0;right:0;z-index:6;width:12px;height:12px;border-radius:50%;background:#ef4444;border:2px solid #fff;box-shadow:0 0 0 1px rgba(239,68,68,.25);cursor:pointer}
      #update-dot[hidden]{display:none}
      .menu {
        position:absolute;right:50px;top:50%;z-index:1;
        display:flex;flex-direction:column;align-items:flex-end;gap:8px;
        opacity:0;pointer-events:none;transform:translate(6px,-50%);
        transition:opacity .16s ease,transform .16s ease;
        font-family:"Microsoft YaHei",sans-serif;
      }
      .menu.show { opacity:1;pointer-events:auto;transform:translate(0,-50%); }
      .menu.to-right { right:auto;left:50px;align-items:flex-start;transform:translate(-6px,-50%); }
      .menu.to-right.show { transform:translate(0,-50%); }
      .item {
        height:40px;border:0;border-radius:20px;padding:0 14px;
        display:none;align-items:center;gap:6px;cursor:pointer;
        font-size:13px;font-weight:650;white-space:nowrap;
      }
      #i-conflict { background:rgba(8,145,178,.30);color:#0891b2; }
      #i-conflict:hover,#i-conflict:focus-visible { background:rgba(8,145,178,.48); }
      #i-engineer { background:rgba(124,58,237,.30);color:#7c3aed; }
      #i-engineer:hover,#i-engineer:focus-visible { background:rgba(124,58,237,.48); }
      .item .ico { font-size:14px;flex:none; }
      .item .main { display:flex;align-items:center;gap:6px; }
      .item .main b { font-weight:650;font-size:13px; }
      .item .sub { display:none; }
      .item .main span { font-size:13px;font-weight:650;color:inherit; }
      .link {
        height:32px;padding:0 12px;border-radius:16px;background:rgba(37,99,235,.16);
        color:#2563eb;font-size:12px;font-weight:650;text-decoration:none;
        display:none;align-items:center;
      }
      .link:hover { background:rgba(37,99,235,.30); }
      .lab { display:flex; align-items:center; gap:6px; }
      .menu.is-fan, .menu.is-fan.show, .menu.is-fan.to-right, .menu.is-fan.to-right.show {
        left:21px; top:21px; right:auto; width:0; height:0; gap:0; transform:none;
      }
      .menu.is-fan .item, .menu.is-fan .link,
      .menu.is-fan #i-conflict, .menu.is-fan #i-engineer, .menu.is-fan #i-engineer-link {
        position:absolute; left:-130px; top:-130px; width:260px; height:260px;
        border-radius:0; padding:0; margin:0;
        background:var(--fan-bg, rgba(5,150,105,.30));
        color:var(--fan-color, #059669);
      }
      .menu.is-fan .item:hover, .menu.is-fan .link:hover,
      .menu.is-fan .item:focus-visible, .menu.is-fan .link:focus-visible,
      .menu.is-fan #i-conflict:hover, .menu.is-fan #i-engineer:hover, .menu.is-fan #i-engineer-link:hover,
      .menu.is-fan #i-conflict:focus-visible, .menu.is-fan #i-engineer:focus-visible, .menu.is-fan #i-engineer-link:focus-visible {
        background:var(--fan-hot, rgba(5,150,105,.48));
        color:var(--fan-color, #059669);
      }
      .menu.is-fan .lab {
        position:absolute; flex-direction:column; align-items:center; gap:2px;
        transform:translate(-50%,-50%); pointer-events:none; text-align:center;
      }
      .menu.is-fan .sub { display:none; }
      .menu.is-fan .main { flex-direction:column; gap:1px; }
      .menu.is-fan .main b, .menu.is-fan .main span { font-size:12px; line-height:1.1; font-weight:650; color:inherit; }
      .menu.is-fan .is-wait { opacity:1; }
      .menu.is-fan .is-wait .lab { opacity:.72; }
      .is-wait { opacity:.45; }
    </style>
    <div class="menu" id="menu">
      <button class="item" id="i-conflict" style="display:none" title="比对源码补丁与客开 V5 仓库">
        <span class="lab"><span class="ico">🔧</span><span class="main"><b>冲突检测</b><span class="sub">比对源码补丁与客开 V5 仓库</span></span></span>
      </button>
      <button class="item" id="i-engineer" style="display:none" title="点击复制推荐工程师">
        <span class="lab"><span class="ico">👤</span><span class="main"><b>推荐工程师</b><span id="eng-name">—</span></span></span>
      </button>
      <a class="link" id="i-engineer-link" style="display:none" target="_blank" rel="noopener noreferrer" title="查看该历史工单">
        <span class="lab"><span class="main"><b>历史工单</b></span></span>
      </a>
    </div>
    <button id="ball" title="随事 3.4.28" aria-label="随事 3.4.28"><img id="ball-logo" alt=""></button>
    <a id="update-dot" hidden title="已有新版本，查看更新说明" aria-label="已有新版本，查看更新说明"></a>
  `;
  document.documentElement.appendChild(host);

  const ball = shadow.getElementById('ball');
  const ballLogo = shadow.getElementById('ball-logo');
  try { SeeyonIcon.applyToImage(ballLogo, 'icons/fab-84.png'); } catch (_) {}
  const menu = shadow.getElementById('menu');
  const iConflict = shadow.getElementById('i-conflict');
  const iEngineer = shadow.getElementById('i-engineer');
  const engName = shadow.getElementById('eng-name');
  const iEngLink = shadow.getElementById('i-engineer-link');
  showLauncherUpdateDot(shadow);

  // ---- 位置记忆 ----
  const POS_KEY = 'seeyonhelper:fabpos';
  const SIZE = 42;
  function setPos(left, top) {
    left = Math.max(0, Math.min(window.innerWidth - SIZE, left));
    top = Math.max(0, Math.min(window.innerHeight - SIZE, top));
    host.style.left = left + 'px';
    host.style.top = top + 'px';
  }
  function savePos() {
    try {
      chrome.storage.local.set({ [POS_KEY]: { left: parseFloat(host.style.left) || 0, top: parseFloat(host.style.top) || 0 } });
    } catch (_) {}
  }
  function initPos() {
    try {
      chrome.storage.local.get(POS_KEY, (res) => {
        const p = res && res[POS_KEY];
        if (p && typeof p.left === 'number') setPos(p.left, p.top);
        else setPos(window.innerWidth - SIZE - 24, window.innerHeight / 2 - SIZE / 2);
      });
    } catch (_) {
      setPos(window.innerWidth - SIZE - 24, window.innerHeight / 2 - SIZE / 2);
    }
  }
  window.addEventListener('resize', () => setPos(parseFloat(host.style.left) || 0, parseFloat(host.style.top) || 0));

  // ---- 拖动 + 点击（区分）----
  let pressing = false, moved = false, sx = 0, sy = 0, offX = 0, offY = 0;
  ball.addEventListener('pointerdown', (e) => {
    pressing = true; moved = false; sx = e.clientX; sy = e.clientY;
    const r = host.getBoundingClientRect();
    offX = e.clientX - r.left; offY = e.clientY - r.top;
    try { ball.setPointerCapture(e.pointerId); } catch (_) {}
  });
  ball.addEventListener('pointermove', (e) => {
    if (!pressing) return;
    if (!moved && Math.hypot(e.clientX - sx, e.clientY - sy) > 5) moved = true;
    if (moved) {
      host.dataset.dragging = '1';
      delete host.dataset.fanShift;
      menu.classList.remove('show');
      setPos(e.clientX - offX, e.clientY - offY);
    }
  });
  const end = (e) => {
    if (!pressing) return;
    pressing = false;
    try { ball.releasePointerCapture(e.pointerId); } catch (_) {}
    if (moved) savePos();
    host.dataset.dragging = '0';

  };
  ball.addEventListener('pointerup', end);
  ball.addEventListener('pointercancel', end);

  function placeMenu() {
    const rect = host.getBoundingClientRect();
    menu.classList.toggle('to-right', rect.left < 180);
  }
  function openMenu() {
    if (host.dataset.dragging === '1') return;
    window.clearTimeout(menuTimer);
    placeMenu();
    if (menu.classList.contains('is-fan')) shiftLauncherFan();
    menu.classList.add('show');
  }
  function closeMenuSoon() {
    window.clearTimeout(menuTimer);
    menuTimer = window.setTimeout(() => {
      if (ball.matches(':hover') || menu.matches(':hover')) return;
      menu.classList.remove('show');
      restoreLauncherFan();
    }, 220);
  }
  let menuTimer = 0;
  ball.addEventListener('pointerenter', openMenu);
  menu.addEventListener('pointerenter', openMenu);
  ball.addEventListener('pointerleave', closeMenuSoon);
  menu.addEventListener('pointerleave', closeMenuSoon);

  // 点击页面空白处关闭菜单（shadow 内点击的 e.target 会 retarget 到 host）
  const isInsideLauncher = function (e) {
    if (!e) return false;
    const path = typeof e.composedPath === 'function' ? e.composedPath() : [];
    if (path && path.length) {
      return path.indexOf(host) >= 0 || path.indexOf(shadow) >= 0 || path.indexOf(menu) >= 0;
    }
    return e.target === host || host.contains(e.target) || host === e.target.getRootNode().host;
  };

  const stopClose = function (e) {
    e.stopPropagation();
  };
  ball.addEventListener('pointerdown', stopClose);
  menu.addEventListener('pointerdown', stopClose);
  iConflict.addEventListener('pointerdown', stopClose);
  iEngineer.addEventListener('pointerdown', stopClose);
  iEngLink.addEventListener('pointerdown', stopClose);

  document.addEventListener('pointerdown', (e) => {
    if (!menu.classList.contains('show')) return;
    if (isInsideLauncher(e)) return;
    menu.classList.remove('show');
  });

  // ---- 菜单项交互 ----
  iConflict.addEventListener('click', () => {
    menu.classList.remove('show');
    document.dispatchEvent(new CustomEvent('seeyon-helper:conflict-open'));
  });
  iEngineer.addEventListener('click', async () => {
    const name = document.documentElement.getAttribute('data-seeyon-engineer') || '';
    if (!name) {
      flash('暂无推荐工程师');
      return;
    }
    menu.classList.remove('show');
    const ok = await copyText(name);
    flash(ok ? '已复制' : '复制失败');
  });
  iEngLink.addEventListener('click', (event) => {
    const affairId = document.documentElement.getAttribute('data-seeyon-engineer-affair') || '';
    const engineerName = document.documentElement.getAttribute('data-seeyon-engineer') || '';
    if (!engineerName || !affairId) {
      event.preventDefault();
      flash('暂无历史工单');
    }
  });

  async function copyText(t) {
    try { await navigator.clipboard.writeText(t); return true; } catch (_) {}
    try {
      const ta = document.createElement('textarea');
      ta.value = t; ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
      document.body.appendChild(ta); ta.focus(); ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (_) { return false; }
  }

  // 球上临时反馈
  let flashTimer = null;
  function flash(msg) {
    ballLogo.style.display = 'none';
    ball.textContent = msg;
    if (flashTimer) clearTimeout(flashTimer);
    flashTimer = setTimeout(() => { ballLogo.style.display = ''; ball.textContent = ''; ball.appendChild(ballLogo); }, 1500);
  }

  // ---- 读取 BUG 工单标题 subject ----
  // 1) 当前/同源 parent/top 文档的 #subject
  // 2) window.subject / window.top.subject
  // 3) 文档标题（新页面 subject 未落到 #subject 时）
  function readSubject() {
    const norm = (v) => String(v || '').replace(/^﻿+/, '').trim();
    const docs = [];
    const seen = new Set();
    const collectFrom = (doc) => {
      if (!doc || seen.has(doc)) return;
      seen.add(doc);
      docs.push(doc);

      let frames = [];
      try {
        frames = Array.from(doc.querySelectorAll('iframe')).map((iframe) => {
          try { return iframe.contentDocument; } catch (_) { return null; }
        }).filter(Boolean);
      } catch (_) {
        frames = [];
      }
      for (const f of frames) collectFrom(f);
    };

    // 先收集当前文档，再收集顶部文档（若同源且未重复）
    collectFrom(document);
    try {
      if (window.top && window.top.document && window.top.document !== document) {
        collectFrom(window.top.document);
      }
    } catch (_) {}

    for (const doc of docs) {
      try {
        const el = doc.querySelector('#subject');
        if (el) {
          const val = el.value != null ? el.value : (el.getAttribute('value') || '');
          const s = norm(val);
          if (s) return s;
        }
      } catch (_) {}
    }

    for (const doc of docs) {
      try {
        const win = doc.defaultView;
        if (win && typeof win.subject === 'string') {
          const s = norm(win.subject);
          if (s) return s;
        }
      } catch (_) {}
    }

    for (const doc of docs) {
      try {
        const s = norm(doc.title);
        if (s) return s;
      } catch (_) {}
    }

    return '';
  }


  function launcherSector(index, count) {
    const spread = Math.PI * 2;
    const center = Math.PI / 4;
    const slice = spread / count;
    const pad = -0.012;
    const start = center - spread / 2 + slice * index + pad;
    const end = center - spread / 2 + slice * (index + 1) - pad;
    const outer = 108;
    const inner = 24;
    const cx = 130;
    const cy = 130;
    const steps = 48;
    const points = [];
    for (let i = 0; i <= steps; i += 1) {
      const angle = start + (end - start) * (i / steps);
      points.push(launcherPoint(cx, cy, outer, angle));
    }
    for (let i = steps; i >= 0; i -= 1) {
      const angle = start + (end - start) * (i / steps);
      points.push(launcherPoint(cx, cy, inner, angle));
    }
    return { clip: 'polygon(' + points.join(',') + ')', mid: (start + end) / 2 };
  }

  function launcherPoint(cx, cy, radius, angle) {
    const x = cx + Math.cos(angle) * radius;
    const y = cy + Math.sin(angle) * radius;
    return x.toFixed(2) + 'px ' + y.toFixed(2) + 'px';
  }

  function launcherColor(hex, alpha) {
    const value = hex.replace('#', '');
    const red = parseInt(value.slice(0, 2), 16);
    const green = parseInt(value.slice(2, 4), 16);
    const blue = parseInt(value.slice(4, 6), 16);
    return 'rgba(' + red + ',' + green + ',' + blue + ',' + alpha + ')';
  }

  function clearLauncherEntry(entry) {
    entry.style.clipPath = '';
    entry.style.removeProperty('--fan-color');
    entry.style.removeProperty('--fan-bg');
    entry.style.removeProperty('--fan-hot');
    const lab = entry.querySelector('.lab');
    if (!lab) return;
    lab.style.left = '';
    lab.style.top = '';
  }

  function paintLauncherEntries(entries) {
    const colors = ['#059669', '#d97706', '#dc2626', '#2563eb', '#7c3aed'];
    const useFan = entries.length >= 3;
    menu.classList.toggle('is-fan', useFan);
    [iConflict, iEngineer, iEngLink].forEach(clearLauncherEntry);
    if (!useFan) return;
    entries.forEach((entry, index) => {
      const sector = launcherSector(index, entries.length);
      const color = colors[index % colors.length];
      const lab = entry.querySelector('.lab');
      entry.style.clipPath = sector.clip;
      entry.style.setProperty('--fan-color', color);
      entry.style.setProperty('--fan-bg', launcherColor(color, 0.30));
      entry.style.setProperty('--fan-hot', launcherColor(color, 0.48));
      if (!lab) return;
      lab.style.left = (130 + Math.cos(sector.mid) * 68).toFixed(1) + 'px';
      lab.style.top = (130 + Math.sin(sector.mid) * 68).toFixed(1) + 'px';
    });
  }

  function shiftLauncherFan() {
    const outer = 116;
    const margin = 8;
    const rect = host.getBoundingClientRect();
    const minLeft = margin + outer - SIZE / 2;
    const maxLeft = Math.max(minLeft, window.innerWidth - margin - outer - SIZE / 2);
    const minTop = margin + outer - SIZE / 2;
    const maxTop = Math.max(minTop, window.innerHeight - margin - outer - SIZE / 2);
    const left = Math.min(Math.max(rect.left, minLeft), maxLeft);
    const top = Math.min(Math.max(rect.top, minTop), maxTop);
    if (Math.abs(left - rect.left) < 1 && Math.abs(top - rect.top) < 1) return;
    if (!host.dataset.fanShift) host.dataset.fanShift = JSON.stringify({ left: host.style.left, top: host.style.top });
    host.style.left = left + 'px';
    host.style.top = top + 'px';
  }

  function restoreLauncherFan() {
    const raw = host.dataset.fanShift;
    if (!raw) return;
    delete host.dataset.fanShift;
    const saved = JSON.parse(raw);
    host.style.left = saved.left;
    host.style.top = saved.top;
  }


  function hasTopLauncherHost() {
    let current = window;
    try {
      while (current.parent && current.parent !== current) {
        const parentDoc = current.parent.document;
        if (parentDoc.getElementById('seeyon-helper-launcher')) return true;
        current = current.parent;
      }
    } catch (_) {
      return false;
    }
    return false;
  }

  // ---- 同一标签页只留一个工单入口 ----
  const launcherOwnerId = Date.now().toString(36) + Math.random().toString(36).slice(2);
  let launcherLeaderId = launcherOwnerId;
  let launcherClaimAt = 0;
  let launcherChannel = null;
  try {
    launcherChannel = new BroadcastChannel('seeyon-helper-launcher-owner');
    launcherChannel.onmessage = (event) => {
      const data = event.data || {};
      if (data.type !== 'claim' || !data.id || data.id === launcherOwnerId) return;
      if (data.id < launcherLeaderId) launcherLeaderId = data.id;
    };
  } catch (_) {}

  function claimLauncherOwner() {
    if (!launcherClaimAt) launcherClaimAt = Date.now();
    if (!launcherChannel) return;
    launcherChannel.postMessage({ type: 'claim', id: launcherOwnerId });
  }

  function isLauncherOwner() {
    if (!launcherChannel) return true;
    if (!launcherClaimAt || Date.now() - launcherClaimAt < 400) return false;
    return launcherLeaderId === launcherOwnerId;
  }

  // ---- 轮询 ②③ 状态（DOM 属性 IPC）----
  let lastVisible = null;
  let lastHiddenReason = '';
  function poll() {
    // 工单入口只留在最外层页面。内嵌页面一律不显示，避免出现两个随事。
    let topFrame = false;
    try { topFrame = window.top === window; } catch (_) { topFrame = false; }
    if (!topFrame) {
      host.style.display = 'none';
      menu.classList.remove('show');
      return;
    }

    const conflict = document.documentElement.getAttribute('data-seeyon-conflict') === '1';
    const engineer = document.documentElement.getAttribute('data-seeyon-engineer') || '';
    const affair = document.documentElement.getAttribute('data-seeyon-engineer-affair') || '';
    // ★ 仅 BUG 工单页（subject 含 _BUG20）才显示统一球
    const subject = readSubject();
    const subjectContainsBug20 = subject.indexOf('_BUG20') >= 0;
    const isBugPage = subjectContainsBug20;
    const hasConflictMenu = Boolean(conflict);
    const hasEngineerMenu = Boolean(engineer);
    const hasAnyMenuItem = hasConflictMenu || hasEngineerMenu;

    const historyReady = Boolean(engineer && affair);
    if (isBugPage) {
      iConflict.style.display = 'flex';
      iEngineer.style.display = 'flex';
      iEngLink.style.display = 'flex';
      iConflict.classList.toggle('is-wait', !conflict);
      iEngineer.classList.toggle('is-wait', !engineer);
      iEngLink.classList.toggle('is-wait', !historyReady);
      engName.textContent = engineer || '暂无';
      if (historyReady) {
        iEngLink.href = 'https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=listDone&affairId=' + encodeURIComponent(affair) + '&showTab=true';
      } else {
        iEngLink.removeAttribute('href');
      }
    } else {
      iConflict.style.display = 'none';
      iEngineer.style.display = 'none';
      iEngLink.style.display = 'none';
    }
    const visibleEntries = [iConflict, iEngineer, iEngLink].filter((entry) => entry.style.display !== 'none');
    paintLauncherEntries(visibleEntries);

    // 球的显隐：BUG 工单页固定显示三项，不再等数据到齐后才出现
    if (isBugPage) {
      if (lastVisible !== true) LOG.info('[入口] 统一悬浮球显示', { conflict, engineer: engineer || '(无)', subject });
      lastVisible = true;
      lastHiddenReason = '';
      claimLauncherOwner();
      if (!isLauncherOwner()) {
        host.style.display = 'none';
        menu.classList.remove('show');
        return;
      }
      host.style.display = '';
      ball.classList.toggle('has-conflict', conflict && !engineer);
    } else {
      const reason = !isBugPage ? '非 BUG 工单页或未读取到 _BUG20 标题' : '没有可用菜单项（冲突检测/推荐工程师均未就绪）';
      const key = reason + '|subject=' + subject + '|conflict=' + conflict + '|engineer=' + Boolean(engineer);
      if (lastVisible !== false || lastHiddenReason !== key) {
        LOG.info('[入口] 统一悬浮球不显示：目标页/菜单条件未满足', {
          reason,
          url: location.href,
          bugPageRule: {
            subject: subject || '(空)',
            expectedSubjectContains: '_BUG20',
            subjectContainsBug20,
            isBugPage
          },
          menuRule: {
            conflictAttribute: document.documentElement.getAttribute('data-seeyon-conflict') || '(空)',
            hasConflictMenu,
            engineer: engineer || '(空)',
            hasEngineerMenu,
            hasAnyMenuItem
          }
        });
      }
      lastVisible = false;
      lastHiddenReason = key;
      host.style.display = 'none';
      menu.classList.remove('show');
    }
  }

  initPos();
  poll();
  setInterval(poll, 600);
})();
