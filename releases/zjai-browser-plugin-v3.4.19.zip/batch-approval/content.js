(function () {
  const DEFAULT_PHRASES = [
    '收到，谢谢。',
    'OK，全力支持',
    '同意，按规定办理',
    '按流程办理',
    '交相关部门处理',
    '按单位相关规章制度办理',
    '保留意见'
  ];

  const TYPE_RULES = [
    { type: '周计划', pattern: /^交付序列周计划-.+-.+-\d{4}年-\d{1,2}月-第\d+周(?:\(由.+原发\))?$/ },
    { type: '项目周报', pattern: /^【[^】]+】.+-\d{4}(?:-\d{1,2}-\d{1,2}|年\d{1,2}月(?:\d{1,2}日(?:第\d+周)?|第\d+周))项目周报$/ },
    { type: '绩效考核', pattern: /^(?:\(自动发起\))?交付月度绩效考核-.+-.+-\d{4}(?:年度-\d{1,2}月度|年-\d{1,2}月|-\d{1,2})$/ },
    { type: '前置评估', pattern: /^交付报价前置评估(?:变更)?_.+$/ },
    { type: '客开作业单', pattern: /^【[^】]+】交付作业申请：【.+-.+】\([^)]+\)_[^_]+_\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/ },
    { type: '工时单', pattern: /^顾问工时登记-.+-.+-\d{4}-\d{2}-\d{2}(?:\(由.+原发\))?$/ },
    { type: '工时单', pattern: /^【补录】顾问工时登记-.+-.+-\d{4}-\d{2}-\d{2}(?:\(由.+原发\))?$/ },
    { type: '工时单', pattern: /^运维顾问工时登记-.+-.+-\d{4}-\d{2}-\d{2}$/ },
    { type: '工时单', pattern: /^【流程】运维顾问工时补录\(.+\s.+\)$/ }
  ];

  const SENT_PAGE_SIZE_OPTIONS = [10, 20, 50, 100];
  const DEFAULT_SENT_PAGE_SIZE = 20;

  function normalizeSentPageSize(value) {
    const size = Number(value);
    if (SENT_PAGE_SIZE_OPTIONS.indexOf(size) !== -1) return size;
    return DEFAULT_SENT_PAGE_SIZE;
  }

  function buildSentPageItems(current, pageCount, openEnded) {
    const page = Math.max(1, Math.floor(Number(current) || 1));
    if (openEnded) {
      const start = Math.max(1, page - 2);
      const end = page + 2;
      const pages = [];
      if (start > 1) pages.push(1);
      if (start > 2) pages.push('...');
      for (let index = start; index <= end; index += 1) pages.push(index);
      pages.push('...');
      return pages;
    }
    const last = Math.max(1, Math.floor(Number(pageCount) || 1));
    if (last <= 7) {
      const pages = [];
      for (let index = 1; index <= last; index += 1) pages.push(index);
      return pages;
    }
    let start = 2;
    let end = 5;
    const nearEnd = page >= last - 3;
    if (page > 4 && !nearEnd) {
      start = page - 2;
      end = page + 2;
    } else if (nearEnd) {
      start = last - 4;
      end = last - 1;
    }
    const pages = [1];
    if (start > 2) pages.push('...');
    for (let index = start; index <= end; index += 1) pages.push(index);
    if (end < last - 1) pages.push('...');
    pages.push(last);
    return pages;
  }

  function resolveSentPage(page, pageCount, openEnded) {
    const requested = Math.floor(Number(page));
    if (!Number.isFinite(requested) || requested < 1) return 0;
    if (openEnded) return requested;
    const last = Math.max(1, Math.floor(Number(pageCount) || 1));
    if (requested > last) return last;
    return requested;
  }

  function buildSentPagerHtml(state) {
    const pageSize = normalizeSentPageSize(state && state.pageSize);
    const exactTotal = !state || state.exactTotal !== false;
    const total = Math.max(0, Math.floor(Number(state && state.total) || 0));
    const requestedPage = Math.max(1, Math.floor(Number(state && state.page) || 1));
    let pageCount = Math.floor(Number(state && state.pageCount) || 0);
    if (pageCount < 1) {
      pageCount = exactTotal ? Math.max(1, Math.ceil(total / pageSize) || 1) : requestedPage;
    }
    const page = exactTotal ? Math.min(requestedPage, pageCount) : requestedPage;
    const openEnded = !exactTotal;
    const pageItems = buildSentPageItems(page, pageCount, openEnded);
    const pageHtml = pageItems.map((item) => {
      if (item === '...') return '<span class="sent-ellipsis">···</span>';
      const current = item === page;
      const currentClass = current ? ' is-current' : '';
      const currentAttr = current ? ' aria-current="page"' : '';
      return '<button type="button" class="sent-page' + currentClass + '" data-page="' + item + '"' + currentAttr + '>' + item + '</button>';
    }).join('');
    const sizeHtml = SENT_PAGE_SIZE_OPTIONS.map((size) => {
      const selected = size === pageSize ? ' selected' : '';
      return '<option value="' + size + '"' + selected + '>' + size + '条/页</option>';
    }).join('');
    const totalText = openEnded ? ('共' + total + '+条记录') : ('共' + total + '条记录');
    const prevDisabled = page <= 1 ? ' disabled' : '';
    const nextDisabled = !openEnded && page >= pageCount ? ' disabled' : '';
    const prefix = (state && state.idPrefix) || 'sent';
    return '<span class="sent-total">' + totalText + '</span>'
      + '<button type="button" class="sent-nav" id="' + prefix + '-prev" aria-label="上一页" title="上一页"' + prevDisabled + '>&lt;</button>'
      + pageHtml
      + '<button type="button" class="sent-nav" id="' + prefix + '-next" aria-label="下一页" title="下一页"' + nextDisabled + '>&gt;</button>'
      + '<select id="' + prefix + '-page-size" aria-label="每页条数">' + sizeHtml + '</select>'
      + '<label class="sent-jump">跳至<input id="' + prefix + '-jump-page" inputmode="numeric" aria-label="跳转页码" value="' + page + '">页</label>';
  }

  const api = {
    DEFAULT_PHRASES,
    normalizeText,
    matchApprovalType,
    filterApprovalItems,
    buildDetailUrl,
    SENT_PAGE_SIZE_OPTIONS,
    normalizeSentPageSize,
    buildSentPageItems,
    resolveSentPage,
    buildSentPagerHtml
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
    return;
  }

  if (window.__seeyon_batch_approval__) return;
  window.__seeyon_batch_approval__ = true;

  const HOST_ID = 'seeyon-batch-approval-host';
  const PANEL_ID = 'seeyon-batch-approval-panel';
  const SENT_PANEL_ID = 'seeyon-sent-query-panel';
  const DONE_PANEL_ID = 'seeyon-done-query-panel';
  const STORAGE_PHRASES = 'seeyon-batch-approval-phrases';
  const STORAGE_RUN = 'seeyon-batch-approval-run';
  const STORAGE_POS = 'seeyon-batch-approval-pos';
  const STORAGE_PAGE_SIZE = 'seeyon-batch-approval-page-size';
  const RUNNER_ID = 'seeyon-batch-approval-runner';
  const RUN_TIMEOUT_MS = 30000;
  const RUN_HANDOFF_DELAY_MS = 5000;
  const LOG_PREFIX = '[kk-helper:batch-approval]';
  const REQUIREMENT_PAGE_URL = runtimeUrl('requirement/request.html');
  let detailAutoSubmitStarted = false;

  const Log = {
    info: (...args) => console.log(LOG_PREFIX, ...args),
    warn: (...args) => console.warn(LOG_PREFIX, ...args)
  };

  function normalizeText(value) {
    return String(value || '')
      .replace(/[\u200b-\u200d\ufeff]/g, '')
      .replace(/[‐‑‒–—―－]/g, '-')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .replace(/\s*-\s*/g, '-')
      .trim();
  }

  function matchApprovalType(subject, expectedType) {
    const text = normalizeText(subject);
    const rule = TYPE_RULES.find((item) => (!expectedType || item.type === expectedType) && item.pattern.test(text));
    return rule ? rule.type : '';
  }

  function itemId(item) {
    return String((item && (item.affairId || item.id || item.summaryId)) || '');
  }

  function itemTime(item) {
    return String((item && (item.receiveTime || item.startDate || item.createDate || item.createTime || item.updateDate)) || '');
  }

  function filterApprovalItems(items) {
    const seen = new Set();
    return (Array.isArray(items) ? items : []).map((item) => {
      const subject = normalizeText(item && item.subject);
      const sourceType = String((item && item.sourceType) || '');
      const type = sourceType ? matchApprovalType(subject, sourceType) : matchApprovalType(subject);
      const affairId = itemId(item);
      if (!type || !affairId || seen.has(affairId)) return null;
      seen.add(affairId);
      return {
        affairId,
        subject,
        type,
        time: itemTime(item),
        status: '待处理'
      };
    }).filter(Boolean);
  }

  function buildDetailUrl(affairId) {
    return 'https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=listPending&affairId=' + encodeURIComponent(affairId) + '&showTab=true';
  }

  function chromeGet(key, fallback) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(key, (res) => resolve((res && res[key]) || fallback));
      } catch (_) {
        resolve(fallback);
      }
    });
  }

  function chromeSet(values) {
    return new Promise((resolve) => {
      try { chrome.storage.local.set(values, resolve); } catch (_) { resolve(); }
    });
  }

  function send(action, params) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action, params: params || {} }, (resp) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || '消息发送失败'));
          return;
        }
        if (!resp || !resp.success) {
          reject(new Error((resp && resp.error) || '后台处理失败'));
          return;
        }
        resolve(resp.data);
      });
    });
  }

  function runtimeUrl(path) {
    try {
      return chrome.runtime.getURL(path);
    } catch (_) {
      return '';
    }
  }

  function openRequirementPage() {
    if (!REQUIREMENT_PAGE_URL) {
      window.alert('插件刚刚更新，请刷新 OA 页面后再点击提需求');
      return;
    }
    const link = document.createElement('a');
    link.href = REQUIREMENT_PAGE_URL;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.documentElement.appendChild(link);
    link.click();
    link.remove();
  }

  function isTopWindow() {
    return window.top === window;
  }

  function isHomePage() {
    if (!isTopWindow()) return false;
    const path = location.pathname || '';
    if (/\/seeyon\/main\.do$/.test(path)) return true;
    return /\/seeyon\/index\.jsp$|\/seeyon\/portal/.test(location.href);
  }

  function isLoginFormVisible() {
    const selector = '#login_username, input[name="login_username"], #login_password, .login_area, #login_area';
    if (document.querySelector(selector)) return true;
    const frames = Array.from(document.querySelectorAll('iframe'));
    return frames.some((frame) => {
      try { return !!(frame.contentDocument && frame.contentDocument.querySelector(selector)); } catch (_) { return false; }
    });
  }

  function hasCurrentUser() {
    try {
      const portal = window.vPortal || {};
      const user = portal.CurrentUser || portal.currentUser;
      if (user && (user.id || user.name || user.userName || user.loginName)) return true;
    } catch (_) {}
    try {
      const ctxUser = window.$ && window.$.ctx && window.$.ctx.CurrentUser;
      if (ctxUser && (ctxUser.id || ctxUser.name || ctxUser.userName)) return true;
    } catch (_) {}
    return false;
  }

  function isLoggedInPortal() {
    if (isLoginFormVisible()) return false;
    if (/method=login|\/login\.do|ssoLogin/i.test(location.href)) return false;
    if (hasCurrentUser()) return true;
    if (document.querySelector('#accountShortName, .account4in1, #portalHeader, #portalTop, .portal-header, #top-center-nav, #spaceMenuNav')) return true;
    if (/\/seeyon\/index\.jsp$/i.test(location.pathname || '')) return false;
    return /\/seeyon\/main\.do$/i.test(location.pathname || '') || /\/seeyon\/portal/i.test(location.href);
  }

  function removeHost() {
    const existing = document.getElementById(HOST_ID);
    if (existing) existing.remove();
  }

  function ensureHost() {
    if (!document.body || !isHomePage() || !isLoggedInPortal()) {
      removeHost();
      return null;
    }
    let host = document.getElementById(HOST_ID);
    if (host) return host;

    host = document.createElement('div');
    host.id = HOST_ID;
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        :host{font-family:"Microsoft YaHei",Arial,sans-serif;color:#111827}
        button,input,textarea{font-family:inherit}
        #ball{position:relative;z-index:5;width:54px;height:54px;border-radius:50%;background:#fff;border:3px solid #fff;box-shadow:0 4px 14px rgba(15,23,42,.16);cursor:grab;touch-action:none;user-select:none;display:flex;align-items:center;justify-content:center;overflow:hidden}
        #update-dot{position:absolute;top:0;right:0;z-index:6;width:12px;height:12px;border-radius:50%;background:#ef4444;border:2px solid #fff;box-shadow:0 0 0 1px rgba(239,68,68,.25);cursor:pointer}
        #update-dot[hidden]{display:none}
        #ball:active{cursor:grabbing}
        #ball img{width:54px;height:54px;display:block;object-fit:cover}
        #fan{position:absolute;left:27px;top:27px;width:0;height:0;z-index:3;pointer-events:none}
        #fan-shape{position:absolute;left:0;top:0;width:0;height:0}
        #fan.open #fan-shape{filter:drop-shadow(0 8px 16px rgba(15,23,42,.22))}
        .fan-item{position:absolute;left:-130px;top:-130px;width:260px;height:260px;border:none;background:var(--fan-bg,#f3f4f6);color:var(--fan-color,#6b7280);padding:0;margin:0;cursor:pointer;clip-path:polygon(130px 130px,130px 130px,130px 130px);transform:scale(.12);transform-origin:130px 130px;opacity:0;pointer-events:none;transition:transform .2s ease,opacity .16s ease,background .12s ease,color .12s ease}
        #fan.open .fan-item{transform:scale(1);opacity:1;pointer-events:auto}
        .fan-label{position:absolute;z-index:6;display:flex;flex-direction:column;align-items:center;gap:3px;transform:translate(-50%,-50%);text-align:center;pointer-events:none;white-space:nowrap;color:var(--fan-color,#6b7280);opacity:0;transition:opacity .16s ease,color .12s ease}
        #fan.open .fan-label{opacity:1}
        .fan-ico{width:18px;height:18px;display:block}
        .fan-ico svg{width:18px;height:18px;display:block}
        .fan-label b{display:block;font-size:12px;line-height:1.1;font-weight:650;color:inherit;white-space:nowrap}
        .fan-item:hover,.fan-item:focus-visible{background:var(--fan-hot-bg,#dbeafe);z-index:4}
        .fan-label.hot,.fan-label.hot b{color:var(--fan-color,#2563eb)}
        #${PANEL_ID}{position:fixed;right:72px;top:48px;width:860px;max-width:calc(100vw - 96px);box-sizing:border-box;height:min(675px, calc(100vh - 64px));max-height:calc(100vh - 64px);background:#fff;border:1px solid #d1d5db;border-radius:8px;box-shadow:0 18px 50px rgba(15,23,42,.22);display:none;overflow:hidden;flex-direction:column}
        #${PANEL_ID}.show{display:flex}
        #${SENT_PANEL_ID}{position:fixed;right:72px;top:48px;width:860px;max-width:calc(100vw - 96px);max-height:calc(100vh - 64px);background:#fff;border:1px solid #d1d5db;border-radius:8px;box-shadow:0 18px 50px rgba(15,23,42,.22);display:none;overflow:hidden}
        #${SENT_PANEL_ID}.show{display:block}
        #${DONE_PANEL_ID}{position:fixed;right:72px;top:48px;width:860px;max-width:calc(100vw - 96px);max-height:calc(100vh - 64px);background:#fff;border:1px solid #d1d5db;border-radius:8px;box-shadow:0 18px 50px rgba(15,23,42,.22);display:none;overflow:hidden}
        #${DONE_PANEL_ID}.show{display:block}
        #sent-keyword{height:30px;width:280px;border:1px solid #cbd5e1;border-radius:6px;padding:0 8px;font-size:12px}
        #done-keyword{height:30px;width:280px;border:1px solid #cbd5e1;border-radius:6px;padding:0 8px;font-size:12px}
        #${SENT_PANEL_ID} th:nth-child(1),#${SENT_PANEL_ID} td:nth-child(1){width:auto;text-align:left}
        #${SENT_PANEL_ID} th:nth-child(2),#${SENT_PANEL_ID} td:nth-child(2){width:120px;text-align:left}
        #${SENT_PANEL_ID} th:nth-child(3),#${SENT_PANEL_ID} td:nth-child(3){width:148px;text-align:left}
        #${DONE_PANEL_ID} th:nth-child(1),#${DONE_PANEL_ID} td:nth-child(1){width:auto;text-align:left}
        #${DONE_PANEL_ID} th:nth-child(2),#${DONE_PANEL_ID} td:nth-child(2){width:120px;text-align:left}
        #${DONE_PANEL_ID} th:nth-child(3),#${DONE_PANEL_ID} td:nth-child(3){width:148px;text-align:left}
        .hd{height:42px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;background:#f8fafc;border-bottom:1px solid #e5e7eb;cursor:move}
        .hd b{font-size:14px}.hd span{font-size:12px;color:#64748b}
        .close{border:none;background:transparent;font-size:18px;line-height:1;cursor:pointer;color:#475569}
        .body{padding:12px;max-height:calc(100vh - 116px);overflow:auto}
        #${PANEL_ID} .body{flex:1;min-height:0;display:flex;flex-direction:column;max-height:none;overflow:hidden}
        #${PANEL_ID} .list{flex:1;min-height:0;max-height:none}
        #${PANEL_ID} .bar,#${PANEL_ID} .pager,#${PANEL_ID} .approval{flex:none}
        .bar{display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap}
        .bar button,.actions button{height:30px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:0 10px;font-size:12px;cursor:pointer}
        .bar button.primary,.actions button.primary{background:#2563eb;border-color:#2563eb;color:#fff}
        .bar label{font-size:12px;color:#334155;display:flex;gap:4px;align-items:center}
        .list{border:1px solid #e5e7eb;border-radius:6px;max-height:520px;overflow:auto}
        table{width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed}
        th,td{border-bottom:1px solid #eef2f7;padding:5px 8px;text-align:left;vertical-align:top;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        th{background:#f8fafc;color:#475569;position:sticky;top:0}
        th:nth-child(1),td:nth-child(1){width:32px;text-align:center}
        th:nth-child(2),td:nth-child(2){width:48px}
        th:nth-child(4),td:nth-child(4){width:116px}
        th:nth-child(5),td:nth-child(5){width:112px}
        td.subject{max-width:none;word-break:normal}
        .detail-link{color:inherit;text-decoration:none}
        .detail-link:hover{color:#2563eb;text-decoration:underline}
        .empty{padding:26px;text-align:center;color:#64748b;font-size:13px}
        .approval{position:relative;margin-top:10px}
        .approval-line{display:flex;align-items:center;gap:8px}
        textarea{flex:1;box-sizing:border-box;height:34px;min-height:34px;border:1px solid #cbd5e1;border-radius:6px;padding:7px 8px;font-size:13px;resize:none}
        .phrase-panel{position:absolute;right:72px;bottom:42px;width:360px;max-width:calc(100% - 84px);background:#fff;border:1px solid #cbd5e1;border-radius:8px;box-shadow:0 10px 28px rgba(15,23,42,.18);padding:8px;display:none;z-index:1}
        .phrase-panel.show{display:block}
        .phrase-title{font-weight:700;font-size:13px;margin-bottom:6px}
        .phrase-list{max-height:88px;overflow:auto;border-top:1px solid #eef2f7;padding-top:4px}
        .phrase-item{display:block;width:100%;border:none;background:#fff;text-align:left;padding:2px 4px;font-size:12px;line-height:1.45;cursor:pointer;color:#111827}
        .phrase-item:hover{background:#eff6ff;color:#2563eb}
        .approval button:not(.phrase-item),.custom button{height:32px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:0 10px;font-size:12px;cursor:pointer;white-space:nowrap}
        .approval button.primary{background:#2563eb;border-color:#2563eb;color:#fff}
        .custom{display:flex;gap:6px;margin-top:6px}
        .custom input{flex:1;height:30px;border:1px solid #cbd5e1;border-radius:6px;padding:0 8px;font-size:12px}
        .pager{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin:8px 0 10px;color:#64748b;font-size:12px}
        .pager button{height:28px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:0 9px;font-size:12px;cursor:pointer}
        .pager select{height:28px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:0 6px;font-size:12px}
        .pager button:disabled{opacity:.45;cursor:not-allowed}
        #sent-pager,#done-pager,#pager{justify-content:flex-end;flex-wrap:wrap;gap:6px;margin-top:10px}
        #sent-pager .sent-total,#done-pager .sent-total,#pager .sent-total{margin-right:6px;color:#6b7280;white-space:nowrap}
        #sent-pager button,#done-pager button,#pager button{min-width:28px;height:28px;padding:0 6px;border:1px solid transparent;border-radius:4px;background:#fff;color:#374151}
        #sent-pager button:hover:not(:disabled),#done-pager button:hover:not(:disabled),#pager button:hover:not(:disabled){color:#1677ff}
        #sent-pager .sent-page.is-current,#done-pager .sent-page.is-current,#pager .sent-page.is-current{border-color:#1677ff;color:#1677ff;font-weight:600;opacity:1;cursor:default}
        #sent-pager .sent-ellipsis,#done-pager .sent-ellipsis,#pager .sent-ellipsis{min-width:28px;text-align:center;color:#9ca3af;letter-spacing:1px}
        #sent-pager select,#done-pager select,#pager select{height:28px;border:1px solid #d9d9d9;border-radius:4px;padding:0 6px;color:#374151;background:#fff}
        #sent-pager .sent-jump,#done-pager .sent-jump,#pager .sent-jump{display:inline-flex;align-items:center;gap:4px;color:#6b7280;white-space:nowrap}
        #sent-pager .sent-jump input,#done-pager .sent-jump input,#pager .sent-jump input{width:46px;height:28px;box-sizing:border-box;border:1px solid #d9d9d9;border-radius:4px;text-align:center;color:#374151;font-size:12px}
        .actions{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:6px}
        .msg{font-size:12px;color:#dc2626}
      </style>
      <div id="fan" aria-hidden="true">
        <div id="fan-shape">
          <button class="fan-item" id="open-batch" type="button" title="批量处理周计划、工时单、项目周报、绩效考核、前置评估、客开作业单"></button>
          <button class="fan-item" id="open-work-hours" type="button" title="工时签卡：查看本人最近30天工时、签卡情况"></button>
          <button class="fan-item" id="open-request" type="button" title="提需求：描述需求、联系人和在线文档"></button>
          <button class="fan-item" id="open-sent" type="button" title="已发查询：按标题关键词查询当前账号已发协同"></button>
          <button class="fan-item" id="open-done" type="button" title="已办查询：按标题关键词查询当前账号已办协同"></button>
        </div>
        <span class="fan-label" data-label="open-batch"><i class="fan-ico"></i><b>批量处理</b></span>
        <span class="fan-label" data-label="open-work-hours"><i class="fan-ico"></i><b>工时签卡</b></span>
        <span class="fan-label" data-label="open-request"><i class="fan-ico"></i><b>提需求</b></span>
        <span class="fan-label" data-label="open-sent"><i class="fan-ico"></i><b>已发查询</b></span>
        <span class="fan-label" data-label="open-done"><i class="fan-ico"></i><b>已办查询</b></span>
      </div>
      <button id="ball" title="随事" aria-label="随事"><img id="logo" alt=""></button>
      <a id="update-dot" hidden title="已有新版本，查看更新说明" aria-label="已有新版本，查看更新说明"></a>
      <section id="${PANEL_ID}" aria-label="待办批量处理">
        <div class="hd" id="drag"><div><b>待办批量处理</b> <span id="count">0 条</span></div><button class="close" id="close" title="关闭">x</button></div>
        <div class="body">
          <div class="bar">
            <button id="refresh" class="primary">刷新待办</button>
            <label><input type="checkbox" data-type="周计划" checked>周计划</label>
            <label><input type="checkbox" data-type="工时单" checked>工时单</label>
            <label><input type="checkbox" data-type="项目周报" checked>项目周报</label>
            <label><input type="checkbox" data-type="绩效考核" checked>绩效考核</label>
            <label><input type="checkbox" data-type="前置评估" checked>前置评估</label>
            <label><input type="checkbox" data-type="客开作业单" checked>客开作业单</label>
          </div>
          <div class="list" id="list"><div class="empty">点击“刷新待办”读取当前用户待办</div></div>
          <div class="pager" id="pager"></div>
          <div class="approval">
            <div class="phrase-panel" id="phrase-panel"><div class="phrase-title">常用语</div><div class="phrase-list" id="phrase-list"></div><div class="custom" id="custom-box"><input id="custom-text" placeholder="新增或修改常用语"><button id="add-phrase">新增/编辑</button><button id="delete-phrase">删除当前意见</button></div></div>
            <div class="approval-line"><textarea id="opinion" placeholder="请输入审批意见，不能为空"></textarea><button id="phrase-toggle">常用语</button><button id="start" class="primary">开始批量处理</button></div>
            <div class="actions"><span class="msg" id="msg"></span></div>
          </div>
        </div>
      </section>
      <section id="${SENT_PANEL_ID}" aria-label="已发查询">
        <div class="hd" id="sent-drag"><div><b>已发查询</b> <span id="sent-count">0 条</span></div><button class="close" id="sent-close" title="关闭">x</button></div>
        <div class="body">
          <div class="bar">
            <input id="sent-keyword" type="text" placeholder="标题关键词，留空查最近已发">
            <button id="sent-search" class="primary">查询</button>
          </div>
          <div class="list" id="sent-list"><div class="empty">输入关键词后查询，留空则查最近已发</div></div>
          <div class="pager" id="sent-pager"></div>
        </div>
      </section>
      <section id="${DONE_PANEL_ID}" aria-label="已办查询">
        <div class="hd" id="done-drag"><div><b>已办查询</b> <span id="done-count">0 条</span></div><button class="close" id="done-close" title="关闭">x</button></div>
        <div class="body">
          <div class="bar">
            <input id="done-keyword" type="text" placeholder="标题关键词，留空查最近已办">
            <button id="done-search" class="primary">查询</button>
          </div>
          <div class="list" id="done-list"><div class="empty">输入关键词后查询，留空则查最近已办</div></div>
          <div class="pager" id="done-pager"></div>
        </div>
      </section>
    `;
    document.documentElement.appendChild(host);
    const logo = shadow.getElementById('logo');
    try {
      SeeyonIcon.applyToImage(logo, 'icons/fab-84.png');
      logo.draggable = false;
    } catch (_) {}
    bindPanel(host, shadow);
    return host;
  }

  async function bindPanel(host, shadow) {
    const panel = shadow.getElementById(PANEL_ID);
    const ball = shadow.getElementById('ball');
    const fan = shadow.getElementById('fan');
    const sentPanel = shadow.getElementById(SENT_PANEL_ID);
    const donePanel = shadow.getElementById(DONE_PANEL_ID);
    const openBatch = shadow.getElementById('open-batch');
    const openWorkHours = shadow.getElementById('open-work-hours');
    const openRequest = shadow.getElementById('open-request');
    const openSent = shadow.getElementById('open-sent');
    const openDone = shadow.getElementById('open-done');
    const sentList = shadow.getElementById('sent-list');
    const sentCount = shadow.getElementById('sent-count');
    const sentKeyword = shadow.getElementById('sent-keyword');
    const sentPager = shadow.getElementById('sent-pager');
    const doneList = shadow.getElementById('done-list');
    const doneCount = shadow.getElementById('done-count');
    const doneKeyword = shadow.getElementById('done-keyword');
    const donePager = shadow.getElementById('done-pager');
    const list = shadow.getElementById('list');
    const count = shadow.getElementById('count');
    const msg = shadow.getElementById('msg');
    const opinion = shadow.getElementById('opinion');
    const pager = shadow.getElementById('pager');
    const phrasePanel = shadow.getElementById('phrase-panel');
    const phraseList = shadow.getElementById('phrase-list');
    const customBox = shadow.getElementById('custom-box');
    let items = [];
    let phraseSource = DEFAULT_PHRASES.slice();
    let pageIndex = 0;
    let pageSize = DEFAULT_SENT_PAGE_SIZE;
    let batchPageCount = 1;
    let batchPagerRendering = false;
    let selectedIds = new Set();
    let sentPage = 1;
    let sentPageSize = DEFAULT_SENT_PAGE_SIZE;
    let sentPageCount = 1;
    let sentOpenEnded = false;
    let sentRequestId = 0;
    let sentPagerRendering = false;
    let donePage = 1;
    let donePageSize = DEFAULT_SENT_PAGE_SIZE;
    let donePageCount = 1;
    let doneOpenEnded = false;
    let doneRequestId = 0;
    let donePagerRendering = false;

    const setMsg = (text) => { msg.textContent = text || ''; };
    const selectedTypes = () => Array.from(shadow.querySelectorAll('input[data-type]:checked')).map((el) => el.dataset.type);
    const visibleItems = () => {
      const types = selectedTypes();
      return items.filter((item) => types.includes(item.type));
    };
    const syncSelectedWithTypes = () => {
      const types = selectedTypes();
      items.forEach((item) => {
        if (!types.includes(item.type)) selectedIds.delete(item.affairId);
      });
    };
    const closePanel = () => {
      panel.classList.remove('show');
      setMsg('');
    };
    const closeFan = () => {
      hideFan(host, fan);
    };
    const sentDetailUrl = (affairId) => {
      return 'https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=listSent&affairId=' + encodeURIComponent(affairId) + '&showTab=true';
    };

    async function refreshSent() {
      const requestId = ++sentRequestId;
      sentList.innerHTML = '<div class="empty">正在查询已发...</div>';
      try {
        const keyword = sentKeyword.value.trim();
        const data = await send('sentQueryGetList', { subject: keyword, page: sentPage, size: sentPageSize });
        if (requestId !== sentRequestId) return;
        const items = data && Array.isArray(data.items) ? data.items : [];
        const reportedTotal = data ? data.total : null;
        const totalNumber = Number(reportedTotal);
        const exactTotal = reportedTotal != null && Number.isFinite(totalNumber) && totalNumber >= 0;
        const total = exactTotal ? Math.floor(totalNumber) : (sentPage - 1) * sentPageSize + items.length;
        sentOpenEnded = !exactTotal && items.length >= sentPageSize;
        sentPageCount = exactTotal ? Math.max(1, Math.ceil(total / sentPageSize) || 1) : Math.max(1, sentPage);
        if (exactTotal && sentPage > sentPageCount) {
          sentPage = sentPageCount;
          refreshSent();
          return;
        }
        const countLabel = sentOpenEnded ? (total + '+') : String(total);
        sentCount.textContent = countLabel + ' 条';
        if (!items.length) {
          sentList.innerHTML = '<div class="empty">没有查到已发协同</div>';
        } else {
          const rows = items.map((item) => {
            const href = escapeHtml(sentDetailUrl(item.affairId));
            const title = escapeHtml(item.subject);
            const handler = escapeHtml(item.handler || '-');
            const time = escapeHtml(item.time || '-');
            return '<tr><td class="subject" title="' + title + '"><a class="detail-link" href="' + href + '" target="_blank" rel="noopener noreferrer">' + title + '</a></td><td title="' + handler + '">' + handler + '</td><td title="' + time + '">' + time + '</td></tr>';
          }).join('');
          sentList.innerHTML = '<table><thead><tr><th>标题</th><th>当前待办人</th><th>发起时间</th></tr></thead><tbody>' + rows + '</tbody></table>';
          sentList.scrollTop = 0;
        }
        sentPagerRendering = true;
        try {
          sentPager.innerHTML = buildSentPagerHtml({
            page: sentPage,
            pageSize: sentPageSize,
            total: total,
            pageCount: sentPageCount,
            exactTotal: !sentOpenEnded
          });
        } finally {
          sentPagerRendering = false;
        }
      } catch (error) {
        if (requestId !== sentRequestId) return;
        sentCount.textContent = '0 条';
        sentPagerRendering = true;
        try {
          sentPager.innerHTML = '';
        } finally {
          sentPagerRendering = false;
        }
        sentList.innerHTML = '<div class="empty">' + escapeHtml(error.message || '查询失败') + '</div>';
      }
    }

    function gotoSentPage(value) {
      const nextPage = resolveSentPage(value, sentPageCount, sentOpenEnded);
      if (!nextPage || nextPage === sentPage) return;
      sentPage = nextPage;
      refreshSent();
    }

    async function refreshDone() {
      const requestId = ++doneRequestId;
      doneList.innerHTML = '<div class="empty">正在查询已办...</div>';
      try {
        const keyword = doneKeyword.value.trim();
        const data = await send('doneQueryGetList', { subject: keyword, page: donePage, size: donePageSize });
        if (requestId !== doneRequestId) return;
        const rows = data && Array.isArray(data.items) ? data.items : [];
        const reportedTotal = data ? data.total : null;
        const totalNumber = Number(reportedTotal);
        const exactTotal = reportedTotal != null && Number.isFinite(totalNumber) && totalNumber >= 0;
        const total = exactTotal ? Math.floor(totalNumber) : (donePage - 1) * donePageSize + rows.length;
        doneOpenEnded = !exactTotal && rows.length >= donePageSize;
        donePageCount = exactTotal ? Math.max(1, Math.ceil(total / donePageSize) || 1) : Math.max(1, donePage);
        if (exactTotal && donePage > donePageCount) {
          donePage = donePageCount;
          refreshDone();
          return;
        }
        const countLabel = doneOpenEnded ? (total + '+') : String(total);
        doneCount.textContent = countLabel + ' 条';
        if (!rows.length) {
          doneList.innerHTML = '<div class="empty">没有查到已办协同</div>';
        } else {
          const html = rows.map((item) => {
            const href = escapeHtml('https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=listDone&affairId=' + encodeURIComponent(item.affairId) + '&showTab=true');
            const title = escapeHtml(item.subject);
            const handler = escapeHtml(item.handler || '-');
            const time = escapeHtml(item.time || '-');
            return '<tr><td class="subject" title="' + title + '"><a class="detail-link" href="' + href + '" target="_blank" rel="noopener noreferrer">' + title + '</a></td><td title="' + handler + '">' + handler + '</td><td title="' + time + '">' + time + '</td></tr>';
          }).join('');
          doneList.innerHTML = '<table><thead><tr><th>标题</th><th>当前待办人</th><th>处理时间</th></tr></thead><tbody>' + html + '</tbody></table>';
          doneList.scrollTop = 0;
        }
        donePagerRendering = true;
        try {
          donePager.innerHTML = buildSentPagerHtml({
            page: donePage,
            pageSize: donePageSize,
            total: total,
            pageCount: donePageCount,
            exactTotal: !doneOpenEnded,
            idPrefix: 'done'
          });
        } finally {
          donePagerRendering = false;
        }
      } catch (error) {
        if (requestId !== doneRequestId) return;
        doneCount.textContent = '0 条';
        donePagerRendering = true;
        try {
          donePager.innerHTML = '';
        } finally {
          donePagerRendering = false;
        }
        doneList.innerHTML = '<div class="empty">' + escapeHtml(error.message || '查询失败') + '</div>';
      }
    }

    function gotoDonePage(value) {
      const nextPage = resolveSentPage(value, donePageCount, doneOpenEnded);
      if (!nextPage || nextPage === donePage) return;
      donePage = nextPage;
      refreshDone();
    }

    const renderList = () => {
      const allRows = visibleItems();
      const pageCount = Math.max(1, Math.ceil(allRows.length / pageSize));
      if (pageIndex >= pageCount) pageIndex = pageCount - 1;
      const rows = allRows.slice(pageIndex * pageSize, pageIndex * pageSize + pageSize);
      const selectedCount = allRows.filter((item) => selectedIds.has(item.affairId)).length;
      count.textContent = allRows.length + ' 条，已选 ' + selectedCount + ' 条';
      if (!allRows.length) {
        list.innerHTML = '<div class="empty">未读取到符合条件的周计划、工时单待办</div>';
        renderPager(0, 1);
        return;
      }
      list.innerHTML = '<table><thead><tr><th><input id="all-box" type="checkbox"></th><th>类型</th><th>标题</th><th>时间</th><th>状态</th></tr></thead><tbody>' +
        rows.map((item) => '<tr><td><input class="row-box" type="checkbox" data-id="' + escapeHtml(item.affairId) + '"></td><td>' + escapeHtml(item.type) + '</td><td class="subject" title="' + escapeHtml(item.subject) + '"><a class="detail-link" href="' + buildDetailUrl(item.affairId) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(item.subject) + '</a></td><td title="' + escapeHtml(item.time || '-') + '">' + escapeHtml(item.time || '-') + '</td><td data-status="' + escapeHtml(item.affairId) + '" title="' + escapeHtml(item.status || '待处理') + '">' + escapeHtml(item.status || '待处理') + '</td></tr>').join('') +
        '</tbody></table>';
      const allBox = shadow.getElementById('all-box');
      if (allBox) {
        const pageSelectedCount = rows.filter((item) => selectedIds.has(item.affairId)).length;
        allBox.checked = pageSelectedCount === rows.length;
        allBox.indeterminate = pageSelectedCount > 0 && pageSelectedCount < rows.length;
        allBox.addEventListener('change', () => setPageSelected(rows, allBox.checked));
      }
      shadow.querySelectorAll('.row-box').forEach((box) => {
        box.checked = selectedIds.has(box.dataset.id);
        box.addEventListener('change', () => {
          if (box.checked) selectedIds.add(box.dataset.id);
          else selectedIds.delete(box.dataset.id);
          renderList();
        });
      });
      renderPager(allRows.length, pageCount);
    };

    const renderPhrases = async () => {
      phraseSource = await chromeGet(STORAGE_PHRASES, DEFAULT_PHRASES);
      if (!Array.isArray(phraseSource) || !phraseSource.length) phraseSource = DEFAULT_PHRASES.slice();
      phraseList.innerHTML = phraseSource.map((text, index) => '<button class="phrase-item" data-index="' + index + '">' + (index + 1) + '：' + escapeHtml(text) + '</button>').join('');
      phraseList.querySelectorAll('.phrase-item').forEach((button) => {
        button.addEventListener('click', () => {
          opinion.value = phraseSource[Number(button.dataset.index)] || '';
          shadow.getElementById('custom-text').value = opinion.value;
          phrasePanel.classList.remove('show');
          setMsg('');
        });
      });
    };

    const setPageSelected = (rows, checked) => {
      rows.forEach((item) => {
        if (checked) selectedIds.add(item.affairId);
        else selectedIds.delete(item.affairId);
      });
      renderList();
    };

    const renderPager = (total, pageCount) => {
      batchPageCount = pageCount;
      batchPagerRendering = true;
      try {
        pager.innerHTML = buildSentPagerHtml({
          page: pageIndex + 1,
          pageSize,
          total,
          pageCount,
          exactTotal: true,
          idPrefix: 'batch'
        });
      } finally {
        batchPagerRendering = false;
      }
    };

    function gotoBatchPage(value) {
      const nextPage = resolveSentPage(value, batchPageCount, false);
      if (!nextPage || nextPage === pageIndex + 1) return;
      pageIndex = nextPage - 1;
      renderList();
    }

    pager.addEventListener('click', (event) => {
      const target = event.target;
      if (!target || !target.closest) return;
      const pageButton = target.closest('.sent-page');
      if (pageButton) {
        gotoBatchPage(pageButton.dataset.page);
        return;
      }
      if (target.id === 'batch-prev') gotoBatchPage(pageIndex);
      if (target.id === 'batch-next') gotoBatchPage(pageIndex + 2);
    });
    pager.addEventListener('change', async (event) => {
      const target = event.target;
      if (!target || target.id !== 'batch-page-size') return;
      const nextSize = normalizeSentPageSize(target.value);
      if (nextSize === pageSize) return;
      pageSize = nextSize;
      pageIndex = 0;
      await chromeSet({ [STORAGE_PAGE_SIZE]: pageSize });
      renderList();
    });
    pager.addEventListener('keydown', (event) => {
      const target = event.target;
      if (!target || target.id !== 'batch-jump-page' || event.key !== 'Enter') return;
      event.preventDefault();
      gotoBatchPage(target.value);
    });
    pager.addEventListener('focusout', (event) => {
      const target = event.target;
      if (batchPagerRendering || !target || target.id !== 'batch-jump-page') return;
      gotoBatchPage(target.value);
    });

    bindBallDrag(host, ball, fan);
    bindFanHover(host, ball, fan);
    showPluginUpdateDot(shadow);
    openBatch.addEventListener('click', async () => {
      closeFan();
      sentPanel.classList.remove('show');
      donePanel.classList.remove('show');
      panel.classList.toggle('show');
      if (panel.classList.contains('show')) {
        await loadPageSize();
        renderPhrases();
        refreshItems();
      }
    });
    openWorkHours.addEventListener('click', () => {
      closeFan();
      document.dispatchEvent(new CustomEvent('seeyon-helper:work-hours-open'));
    });
    openRequest.addEventListener('click', () => {
      closeFan();
      openRequirementPage();
    });
    openSent.addEventListener('click', () => {
      closeFan();
      panel.classList.remove('show');
      donePanel.classList.remove('show');
      sentPanel.classList.add('show');
      refreshSent();
    });
    openDone.addEventListener('click', () => {
      closeFan();
      panel.classList.remove('show');
      sentPanel.classList.remove('show');
      donePanel.classList.add('show');
      refreshDone();
    });
    sentKeyword.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      sentPage = 1;
      refreshSent();
    });
    shadow.getElementById('sent-search').addEventListener('click', () => {
      sentPage = 1;
      refreshSent();
    });
    sentPager.addEventListener('click', (event) => {
      const target = event.target;
      if (!target || !target.closest) return;
      const pageButton = target.closest('.sent-page');
      if (pageButton) {
        gotoSentPage(pageButton.dataset.page);
        return;
      }
      if (target.id === 'sent-prev') gotoSentPage(sentPage - 1);
      if (target.id === 'sent-next') gotoSentPage(sentPage + 1);
    });
    sentPager.addEventListener('change', (event) => {
      const target = event.target;
      if (!target || target.id !== 'sent-page-size') return;
      const nextSize = normalizeSentPageSize(target.value);
      if (nextSize === sentPageSize) return;
      sentPageSize = nextSize;
      sentPage = 1;
      refreshSent();
    });
    sentPager.addEventListener('keydown', (event) => {
      const target = event.target;
      if (!target || target.id !== 'sent-jump-page' || event.key !== 'Enter') return;
      event.preventDefault();
      gotoSentPage(target.value);
    });
    sentPager.addEventListener('focusout', (event) => {
      const target = event.target;
      if (sentPagerRendering || !target || target.id !== 'sent-jump-page') return;
      gotoSentPage(target.value);
    });
    shadow.getElementById('sent-close').addEventListener('pointerdown', (event) => {
      event.stopPropagation();
      sentPanel.classList.remove('show');
    });
    shadow.getElementById('sent-close').addEventListener('click', () => {
      sentPanel.classList.remove('show');
    });
    bindDrag(sentPanel, shadow.getElementById('sent-drag'));
    doneKeyword.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      donePage = 1;
      refreshDone();
    });
    shadow.getElementById('done-search').addEventListener('click', () => {
      donePage = 1;
      refreshDone();
    });
    donePager.addEventListener('click', (event) => {
      const target = event.target;
      if (!target || !target.closest) return;
      const pageButton = target.closest('.sent-page');
      if (pageButton) {
        gotoDonePage(pageButton.dataset.page);
        return;
      }
      if (target.id === 'done-prev') gotoDonePage(donePage - 1);
      if (target.id === 'done-next') gotoDonePage(donePage + 1);
    });
    donePager.addEventListener('change', (event) => {
      const target = event.target;
      if (!target || target.id !== 'done-page-size') return;
      const nextSize = normalizeSentPageSize(target.value);
      if (nextSize === donePageSize) return;
      donePageSize = nextSize;
      donePage = 1;
      refreshDone();
    });
    donePager.addEventListener('keydown', (event) => {
      const target = event.target;
      if (!target || target.id !== 'done-jump-page' || event.key !== 'Enter') return;
      event.preventDefault();
      gotoDonePage(target.value);
    });
    donePager.addEventListener('focusout', (event) => {
      const target = event.target;
      if (donePagerRendering || !target || target.id !== 'done-jump-page') return;
      gotoDonePage(target.value);
    });
    shadow.getElementById('done-close').addEventListener('pointerdown', (event) => {
      event.stopPropagation();
      donePanel.classList.remove('show');
    });
    shadow.getElementById('done-close').addEventListener('click', () => {
      donePanel.classList.remove('show');
    });
    bindDrag(donePanel, shadow.getElementById('done-drag'));
    shadow.getElementById('close').addEventListener('pointerdown', (event) => {
      event.stopPropagation();
      closePanel();
    });
    shadow.getElementById('close').addEventListener('click', closePanel);
    shadow.getElementById('refresh').addEventListener('click', refreshItems);
    shadow.querySelectorAll('input[data-type]').forEach((el) => el.addEventListener('change', () => {
      syncSelectedWithTypes();
      pageIndex = 0;
      renderList();
    }));
    shadow.getElementById('phrase-toggle').addEventListener('click', async () => {
      await renderPhrases();
      phrasePanel.classList.toggle('show');
      shadow.getElementById('custom-text').value = opinion.value || '';
    });
    shadow.getElementById('add-phrase').addEventListener('click', async () => {
      const text = normalizeText(shadow.getElementById('custom-text').value || opinion.value);
      if (!text) return setMsg('常用语不能为空');
      phraseSource = phraseSource.filter((item) => item !== text).concat(text);
      await chromeSet({ [STORAGE_PHRASES]: phraseSource });
      await renderPhrases();
      opinion.value = text;
      setMsg('');
    });
    shadow.getElementById('delete-phrase').addEventListener('click', async () => {
      const text = normalizeText(opinion.value || shadow.getElementById('custom-text').value);
      if (!text) return setMsg('请选择要删除的常用语');
      phraseSource = phraseSource.filter((item) => item !== text);
      await chromeSet({ [STORAGE_PHRASES]: phraseSource });
      await renderPhrases();
      opinion.value = '';
      setMsg('');
    });
    shadow.getElementById('start').addEventListener('click', startBatch);
    bindDrag(panel, shadow.getElementById('drag'));
    setInterval(syncRunStatus, 1500);

    async function loadPageSize() {
      const saved = Number(await chromeGet(STORAGE_PAGE_SIZE, pageSize));
      pageSize = normalizeSentPageSize(saved);
    }

    async function refreshItems() {
      setMsg('正在读取待办...');
      try {
        const raw = await send('batchApprovalGetPending');
        items = filterApprovalItems(raw);
        selectedIds = new Set();
        const run = await chromeGet(STORAGE_RUN, null);
        if (!run || !run.active) await chromeSet({ [STORAGE_RUN]: null });
        pageIndex = 0;
        renderList();
        setMsg('');
      } catch (error) {
        items = [];
        renderList();
        setMsg(error.message || '读取待办失败');
      }
    }

    async function startBatch() {
      const text = normalizeText(opinion.value);
      if (!text) return setMsg('审批意见不能为空');
      const selected = visibleItems().filter((item) => selectedIds.has(item.affairId));
      if (!selected.length) return setMsg('请先选择待办');
      selected.forEach((item, index) => { item.status = index === 0 ? '处理中' : '排队中'; });
      renderList();
      await chromeSet({ [STORAGE_RUN]: { active: true, opinion: text, queue: selected, index: 0, updatedAt: Date.now() } });
      startSilentRunner(selected[0].affairId);
      setMsg('已启动静默批量处理，列表状态会实时更新');
    }

    async function syncRunStatus() {
      if (!panel.classList.contains('show') || !items.length) return;
      const run = await chromeGet(STORAGE_RUN, null);
      if (!run || !Array.isArray(run.queue)) return;
      if (run.active && Date.now() - Number(run.updatedAt || 0) > RUN_TIMEOUT_MS) {
        run.active = false;
        run.updatedAt = Date.now();
        run.queue.forEach((runItem) => {
          const oldReviewStatus = '已触发提交，' + '待复核';
          if (/^(处理中|排队中|已提交)$/.test(runItem.status || '') || runItem.status === oldReviewStatus) runItem.status = '处理超时，仍在待办';
        });
        await chromeSet({ [STORAGE_RUN]: run });
        const frame = document.getElementById(RUNNER_ID);
        if (frame) frame.remove();
        setMsg('静默处理超时，已停止，请刷新待办后重试');
      } else {
        resumeProcessingItem(run);
      }
      let changed = false;
      run.queue.forEach((runItem) => {
        const item = items.find((candidate) => candidate.affairId === runItem.affairId);
        const oldClickedStatus = '已' + '点击提交';
        const oldReviewStatus = '已触发提交，' + '待复核';
        const status = runItem.status === oldClickedStatus ? '仍在待办' : (runItem.status === oldReviewStatus ? '已提交' : runItem.status);
        if (item && status && item.status !== status) {
          item.status = status;
          changed = true;
        }
      });
      if (changed) renderList();
    }

    function resumeProcessingItem(run) {
      if (!run.active || Date.now() - Number(run.updatedAt || 0) < RUN_HANDOFF_DELAY_MS) return;
      const current = run.queue.find((runItem) => runItem.status === '处理中');
      if (!current) return;
      const frame = document.getElementById(RUNNER_ID);
      const targetUrl = buildDetailUrl(current.affairId);
      if (frame && frame.src === targetUrl) return;
      startSilentRunner(current.affairId);
    }
  }

  function startSilentRunner(affairId) {
    let frame = document.getElementById(RUNNER_ID);
    if (!frame) {
      frame = document.createElement('iframe');
      frame.id = RUNNER_ID;
      frame.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;border:0;opacity:0;pointer-events:none;';
      document.documentElement.appendChild(frame);
    }
    frame.src = buildDetailUrl(affairId);
  }

  function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }

  function bindDrag(panel, handle) {
    let active = false, sx = 0, sy = 0, left = 0, top = 0;
    handle.addEventListener('pointerdown', (e) => {
      active = true;
      sx = e.clientX;
      sy = e.clientY;
      const rect = panel.getBoundingClientRect();
      left = rect.left;
      top = rect.top;
      panel.style.left = left + 'px';
      panel.style.top = top + 'px';
      panel.style.right = 'auto';
      try { handle.setPointerCapture(e.pointerId); } catch (_) {}
    });
    handle.addEventListener('pointermove', (e) => {
      if (!active) return;
      panel.style.left = Math.max(8, Math.min(window.innerWidth - 80, left + e.clientX - sx)) + 'px';
      panel.style.top = Math.max(8, Math.min(window.innerHeight - 60, top + e.clientY - sy)) + 'px';
    });
    handle.addEventListener('pointerup', () => { active = false; });
    handle.addEventListener('pointercancel', () => { active = false; });
  }

  async function bindBallDrag(host, ball, fan) {
    const size = 54;
    const setPos = (left, top) => {
      host.style.left = Math.max(0, Math.min(window.innerWidth - size, left)) + 'px';
      host.style.top = Math.max(0, Math.min(window.innerHeight - size, top)) + 'px';
      host.style.right = 'auto';
    };
    const saved = await chromeGet(STORAGE_POS, null);
    if (saved && typeof saved.left === 'number' && typeof saved.top === 'number') {
      setPos(saved.left, saved.top);
    } else {
      setPos(window.innerWidth - size - 18, Math.round(window.innerHeight * 0.62));
    }
    window.addEventListener('resize', () => setPos(parseFloat(host.style.left) || 0, parseFloat(host.style.top) || 0));

    let pressing = false, moved = false, sx = 0, sy = 0, offX = 0, offY = 0, pointerId = null;
    ball.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      event.stopPropagation();
      pressing = true;
      moved = false;
      pointerId = event.pointerId;
      sx = event.clientX;
      sy = event.clientY;
      const rect = host.getBoundingClientRect();
      offX = event.clientX - rect.left;
      offY = event.clientY - rect.top;
      document.addEventListener('pointermove', move, true);
      document.addEventListener('pointerup', end, true);
      document.addEventListener('pointercancel', end, true);
    });
    const move = (event) => {
      if (!pressing) return;
      if (pointerId != null && event.pointerId !== pointerId) return;
      event.preventDefault();
      if (!moved && Math.hypot(event.clientX - sx, event.clientY - sy) > 5) moved = true;
      if (moved) {
        host.dataset.dragging = '1';
        delete host.dataset.fanShift;
        fan.classList.remove('open');
        setPos(event.clientX - offX, event.clientY - offY);
      }
    };
    const end = async (event) => {
      if (!pressing) return;
      if (pointerId != null && event.pointerId !== pointerId) return;
      event.preventDefault();
      event.stopPropagation();
      pressing = false;
      document.removeEventListener('pointermove', move, true);
      document.removeEventListener('pointerup', end, true);
      document.removeEventListener('pointercancel', end, true);
      if (moved) {
        await chromeSet({ [STORAGE_POS]: { left: parseFloat(host.style.left) || 0, top: parseFloat(host.style.top) || 0 } });
      }
      host.dataset.dragging = '0';
      pointerId = null;
    };
  }

  function sectorClip(center, spread, index, count, outer) {
    const slice = spread / count;
    const pad = 0.016;
    const start = center - spread / 2 + slice * index + pad;
    const end = center - spread / 2 + slice * (index + 1) - pad;
    const inner = 28;
    const cx = 130;
    const cy = 130;
    const steps = 12;
    const points = [];
    for (let i = 0; i <= steps; i += 1) {
      const angle = start + (end - start) * (i / steps);
      const x = cx + Math.cos(angle) * outer;
      const y = cy + Math.sin(angle) * outer;
      points.push(x.toFixed(1) + 'px ' + y.toFixed(1) + 'px');
    }
    for (let i = steps; i >= 0; i -= 1) {
      const angle = start + (end - start) * (i / steps);
      const x = cx + Math.cos(angle) * inner;
      const y = cy + Math.sin(angle) * inner;
      points.push(x.toFixed(1) + 'px ' + y.toFixed(1) + 'px');
    }
    return {
      clip: 'polygon(' + points.join(',') + ')',
      mid: (start + end) / 2
    };
  }

  function layoutFan(host, fan) {
    const spread = Math.PI * 2;
    const centerAngle = Math.PI / 4;
    const outer = 120;
    const inner = 28;
    const items = Array.from(fan.querySelectorAll('.fan-item'));
    if (!items.length) return;
    items.forEach((item, index) => {
      const sector = sectorClip(centerAngle, spread, index, items.length, outer);
      const label = fan.querySelector('.fan-label[data-label="' + item.id + '"]');
      const labelRadius = 78;
      item.style.clipPath = sector.clip;
      if (!label) return;
      label.style.left = (Math.cos(sector.mid) * labelRadius).toFixed(1) + 'px';
      label.style.top = (Math.sin(sector.mid) * labelRadius).toFixed(1) + 'px';
    });
  }

  function fanColor(index) {
    const palette = ['#059669', '#d97706', '#dc2626', '#2563eb', '#7c3aed'];
    return palette[index % palette.length];
  }

  function hexToRgba(hex, alpha) {
    const value = String(hex || '').replace('#', '');
    const red = parseInt(value.slice(0, 2), 16);
    const green = parseInt(value.slice(2, 4), 16);
    const blue = parseInt(value.slice(4, 6), 16);
    return 'rgba(' + red + ',' + green + ',' + blue + ',' + alpha + ')';
  }

  function fanIcon(icon, label) {
    const common = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
    if (icon === 'grid') return '<svg ' + common + '><rect x="4" y="4" width="6.5" height="6.5" rx="1.2"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.2"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.2"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.2"/></svg>';
    if (icon === 'clock') return '<svg ' + common + '><circle cx="12" cy="12" r="7.5"/><path d="M12 8.2V12l2.6 1.8"/></svg>';
    if (icon === 'plus') return '<svg ' + common + '><circle cx="12" cy="12" r="7.5"/><path d="M12 8.5v7M8.5 12h7"/></svg>';
    if (icon === 'search') return '<svg ' + common + '><circle cx="11" cy="11" r="5.5"/><path d="M15.5 15.5L20 20"/></svg>';
    if (icon === 'check') return '<svg ' + common + '><circle cx="12" cy="12" r="7.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/></svg>';
    const mark = String(label || '').slice(0, 1) || '·';
    return '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.8"/><text x="12" y="16" text-anchor="middle" font-size="11" fill="currentColor" stroke="none">' + mark + '</text></svg>';
  }

  function paintFanEntries(fan) {
    const entries = [
      { id: 'open-batch', label: '批量处理', icon: 'grid' },
      { id: 'open-work-hours', label: '工时签卡', icon: 'clock' },
      { id: 'open-request', label: '提需求', icon: 'plus' },
      { id: 'open-sent', label: '已发查询', icon: 'search' },
      { id: 'open-done', label: '已办查询', icon: 'check' }
    ];
    entries.forEach((entry, index) => {
      const color = fanColor(index);
      const item = fan.querySelector('#' + entry.id);
      const label = fan.querySelector('.fan-label[data-label="' + entry.id + '"]');
      const baseBg = hexToRgba(color, 0.30);
      const hotBg = hexToRgba(color, 0.48);
      if (item) {
        item.style.setProperty('--fan-color', color);
        item.style.setProperty('--fan-bg', baseBg);
        item.style.setProperty('--fan-hot-bg', hotBg);
      }
      if (!label) return;
      label.style.setProperty('--fan-color', color);
      const holder = label.querySelector('.fan-ico');
      if (holder) holder.innerHTML = fanIcon(entry.icon, entry.label);
    });
  }

  function ensureFanRoom(host) {
    const outer = 128;
    const margin = 8;
    const ball = 54;
    const rect = host.getBoundingClientRect();
    const minLeft = margin + outer - ball / 2;
    const maxLeft = window.innerWidth - margin - outer - ball / 2;
    const minTop = margin + outer - ball / 2;
    const maxTop = window.innerHeight - margin - outer - ball / 2;
    let left = rect.left;
    let top = rect.top;
    if (maxLeft >= minLeft) left = Math.min(Math.max(left, minLeft), maxLeft);
    if (maxTop >= minTop) top = Math.min(Math.max(top, minTop), maxTop);
    const moved = Math.abs(left - rect.left) > 0.5 || Math.abs(top - rect.top) > 0.5;
    if (!moved) return;
    if (!host.dataset.fanShift) host.dataset.fanShift = JSON.stringify({ left: rect.left, top: rect.top });
    host.style.left = left + 'px';
    host.style.top = top + 'px';
    host.style.right = 'auto';
  }

  function restoreFanShift(host) {
    const raw = host.dataset.fanShift;
    if (!raw) return;
    delete host.dataset.fanShift;
    const saved = JSON.parse(raw);
    host.style.left = saved.left + 'px';
    host.style.top = saved.top + 'px';
  }

  function hideFan(host, fan) {
    fan.classList.remove('open');
    fan.setAttribute('aria-hidden', 'true');
    fan.querySelectorAll('.fan-label.hot').forEach((label) => label.classList.remove('hot'));
    restoreFanShift(host);
  }

  async function showPluginUpdateDot(shadow) {
    const dot = shadow.getElementById('update-dot');
    if (!dot) return;
    const refresh = async () => {
      try {
        const info = await send('checkPluginUpdate');
        if (!info || !info.update || !info.url) {
          dot.hidden = true;
          return;
        }
        dot.href = info.url;
        dot.target = '_blank';
        dot.rel = 'noopener noreferrer';
        dot.hidden = false;
        dot.title = '已有新版本 ' + info.version + '，查看更新说明';
        dot.dataset.version = info.version;
      } catch (_) {}
    };
    if (dot.dataset.bound !== '1') {
      dot.dataset.bound = '1';
      dot.addEventListener('pointerdown', (event) => { event.stopPropagation(); });
      dot.addEventListener('click', (event) => {
        event.stopPropagation();
        dot.hidden = true;
        send('dismissPluginUpdate', { version: dot.dataset.version }).catch(() => {});
      });
      setInterval(refresh, 30 * 60 * 1000);
    }
    await refresh();
  }

  function bindFanHover(host, ball, fan) {
    paintFanEntries(fan);
    let closeTimer = 0;
    const open = () => {
      if (host.dataset.dragging === '1') return;
      window.clearTimeout(closeTimer);
      ensureFanRoom(host);
      layoutFan(host, fan);
      fan.classList.add('open');
      fan.setAttribute('aria-hidden', 'false');
    };
    const closeSoon = () => {
      window.clearTimeout(closeTimer);
      closeTimer = window.setTimeout(() => {
        hideFan(host, fan);
      }, 220);
    };
    fan.querySelectorAll('.fan-item').forEach((item) => {
      const label = fan.querySelector('.fan-label[data-label="' + item.id + '"]');
      item.addEventListener('pointerenter', () => {
        if (label) label.classList.add('hot');
      });
      item.addEventListener('pointerleave', () => {
        if (label) label.classList.remove('hot');
      });
    });
    ball.addEventListener('pointerenter', open);
    fan.addEventListener('pointerenter', open);
    ball.addEventListener('pointerleave', closeSoon);
    fan.addEventListener('pointerleave', closeSoon);
  }

  async function maybeAutoSubmitDetail() {
    if (!/collaboration\.do/.test(location.href) || !/method=summary/.test(location.href)) return;
    const affairId = new URLSearchParams(location.search).get('affairId') || '';
    if (!affairId) return;
    const run = await chromeGet(STORAGE_RUN, null);
    if (!run || !run.active || !Array.isArray(run.queue)) return;
    const index = run.queue.findIndex((item) => item.affairId === affairId);
    if (index < 0) return;
    const opinion = normalizeText(run.opinion);
    if (!opinion) return;
    if (detailAutoSubmitStarted) return;
    detailAutoSubmitStarted = true;
    Log.info('详情页自动处理:', affairId);
    await dismissRecoveryPrompt();
    const filled = await waitAndFillOpinion(opinion);
    const clicked = filled ? clickSubmit() : false;
    run.queue[index].status = filled ? (clicked ? '已提交' : '未找到提交按钮') : '未找到意见框';
    run.index = index + 1;
    run.updatedAt = Date.now();
    if (clicked) setTimeout(clickConfirmButtons, 900);
    const next = run.queue.find((item) => item.status === '排队中');
    if (next) {
      next.status = '处理中';
      await chromeSet({ [STORAGE_RUN]: run });
      setTimeout(() => { location.href = buildDetailUrl(next.affairId); }, 1800);
    } else {
      run.active = false;
      await chromeSet({ [STORAGE_RUN]: run });
      await wait(1800);
      await verifyQueueStatus(run);
    }
  }

  async function verifyQueueStatus(run) {
    try {
      const raw = await send('batchApprovalGetPending');
      const pendingIds = new Set(filterApprovalItems(raw).map((item) => item.affairId));
      run.queue.forEach((item) => {
        if (/^未找到/.test(item.status || '')) return;
        item.status = pendingIds.has(item.affairId) ? '仍在待办' : '已办结';
      });
      run.verifiedAt = Date.now();
      await chromeSet({ [STORAGE_RUN]: run });
    } catch (error) {
      run.queue.forEach((item) => {
        const oldReviewStatus = '已触发提交，' + '待复核';
        if (item.status === '已提交' || item.status === oldReviewStatus) item.status = '回查失败，请刷新待办';
      });
      run.verifyError = error.message || '复核失败';
      await chromeSet({ [STORAGE_RUN]: run });
    }
  }

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function accessibleDocs() {
    const docs = [document];
    try {
      if (window.top && window.top.document && window.top.document !== document) docs.push(window.top.document);
    } catch (_) {}
    return docs;
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  async function dismissRecoveryPrompt() {
    for (let i = 0; i < 20; i++) {
      for (const doc of accessibleDocs()) {
        const text = normalizeText(doc.body && doc.body.innerText);
        if (!/有未保存数据|是否恢复/.test(text)) continue;
        const buttons = Array.from(doc.querySelectorAll('button,input[type="button"],a,span,div'));
        const target = buttons.find((el) => normalizeText(el.innerText || el.textContent || el.value) === '不恢复' && isVisible(el));
        if (target) {
          (target.closest('button,a') || target).click();
          await wait(500);
          return true;
        }
      }
      await wait(250);
    }
    return false;
  }

  async function waitAndFillOpinion(opinion) {
    for (let i = 0; i < 20; i++) {
      const field = document.querySelector('textarea[placeholder*="请输入处理意见"], textarea');
      if (field) {
        field.value = opinion;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        field.dispatchEvent(new Event('blur', { bubbles: true }));
        return true;
      }
      await wait(300);
    }
    return false;
  }

  function clickableText(el) {
    return normalizeText(el && (el.innerText || el.textContent || el.value || el.title));
  }

  function clickSubmit() {
    const nodes = Array.from(document.querySelectorAll('button,input[type="button"],input[type="submit"],a,span,div'));
    const target = nodes.find((el) => clickableText(el) === '提交' && el.offsetParent !== null);
    if (!target) return false;
    const clickable = target.closest('button,a') || target;
    clickable.click();
    return true;
  }

  function clickConfirmButtons() {
    const target = Array.from(document.querySelectorAll('button,input[type="button"],a,span'))
      .find((el) => /^(确定|继续提交)$/.test(clickableText(el)) && el.offsetParent !== null);
    if (!target) return;
    try { (target.closest('button,a') || target).click(); } catch (_) {}
  }

  function bootstrap() {
    ensureHost();
    maybeAutoSubmitDetail();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
  } else {
    bootstrap();
  }
  window.addEventListener('load', bootstrap, { once: true });
  [800, 2000, 4000].forEach((delay) => setTimeout(ensureHost, delay));
})();
