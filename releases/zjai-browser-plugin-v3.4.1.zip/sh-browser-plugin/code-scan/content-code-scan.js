/**
 * CTP-Studio 代码检测模块 - 内容脚本
 * 负责悬浮按钮、弹窗展示和交互
 * 仅在 http://studio.kk.seeyon.com/index 页面生效
 */

(function () {
    'use strict';

    const LOG_PREFIX = '[kk-helper:code-scan]';
    const DEBUG = true;

    const Logger = {
        info: (...args) => DEBUG && console.log(LOG_PREFIX + '[INFO]', ...args),
        warn: (...args) => DEBUG && console.warn(LOG_PREFIX + '[WARN]', ...args),
        error: (...args) => DEBUG && console.error(LOG_PREFIX + '[ERROR]', ...args),
        debug: (...args) => DEBUG && console.debug(LOG_PREFIX + '[DEBUG]', ...args)
    };

    // ========== 页面判断 ==========

    function isTargetPage() {
        const href = window.location.href;
        // 匹配 http://studio.kk.seeyon.com/index 或带参数的情况
        const startsWithIndex = href.startsWith('http://studio.kk.seeyon.com/index');
        const isStudioRootWithSlash = href === 'http://studio.kk.seeyon.com/';
        const isStudioRoot = href === 'http://studio.kk.seeyon.com';
        const isMatch = startsWithIndex || isStudioRootWithSlash || isStudioRoot;
        Logger.debug('isTargetPage:', isMatch, 'url:', href);
        if (!isMatch) {
            Logger.info('[入口] 代码检测悬浮球不显示：目标页条件均未满足', {
                href,
                rules: {
                    startsWithIndex: {
                        expectedPrefix: 'http://studio.kk.seeyon.com/index',
                        matched: startsWithIndex
                    },
                    isStudioRootWithSlash: {
                        expected: 'http://studio.kk.seeyon.com/',
                        matched: isStudioRootWithSlash
                    },
                    isStudioRoot: {
                        expected: 'http://studio.kk.seeyon.com',
                        matched: isStudioRoot
                    }
                }
            });
        }
        return isMatch;
    }

    // ========== FAB（悬浮按钮） ==========

    function createFAB() {
        if (document.getElementById('code-scan-fab')) {
            Logger.warn('FAB 已存在');
            return;
        }
        if (!document.body) {
            Logger.warn('[入口] 代码检测悬浮球不显示：document.body 尚未就绪');
            return;
        }

        var fab = document.createElement('div');
        fab.id = 'code-scan-fab';
        fab.className = 'code-scan-fab';
        fab.innerHTML = '<span>C</span>';
        fab.title = 'CTP-Studio 代码检测';

        // 拖动相关变量
        var isDragging = false;
        var hasMoved = false;
        var startX, startY;
        var startLeft, startBottom;
        var DRAG_THRESHOLD = 5; // 拖动阈值，小于此值视为点击

        fab.onmousedown = function (e) {
            e.preventDefault();

            isDragging = true;
            hasMoved = false;
            startX = e.clientX;
            startY = e.clientY;

            // 获取当前位置
            var rect = fab.getBoundingClientRect();
            startLeft = rect.left;
            startBottom = window.innerHeight - rect.bottom;

            fab.style.transition = 'none'; // 拖动时禁用过渡动画
        };

        document.addEventListener('mousemove', function (e) {
            if (!isDragging) return;

            var deltaX = e.clientX - startX;
            var deltaY = e.clientY - startY;

            // 检查是否超过拖动阈值
            if (Math.abs(deltaX) > DRAG_THRESHOLD || Math.abs(deltaY) > DRAG_THRESHOLD) {
                hasMoved = true;
            }

            if (hasMoved) {
                var newLeft = startLeft + deltaX;
                var newBottom = startBottom - deltaY;

                // 边界限制
                newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - fab.offsetWidth));
                newBottom = Math.max(0, Math.min(newBottom, window.innerHeight - fab.offsetHeight));

                fab.style.left = newLeft + 'px';
                fab.style.bottom = newBottom + 'px';
                fab.style.right = 'auto'; // 清除right定位
            }
        });

        document.addEventListener('mouseup', function () {
            if (isDragging) {
                isDragging = false;
                fab.style.transition = ''; // 恢复过渡动画
            }
        });

        fab.onclick = function (e) {
            e.stopPropagation();
            e.preventDefault();

            // 只有在没有拖动时才触发点击
            if (!hasMoved) {
                Logger.info('FAB 点击');
                onFABClick();
            }
        };

        document.body.appendChild(fab);
        Logger.info('FAB 已创建');
    }

    // ========== 弹窗管理 ==========

    var pollTimer = null;

    function getOverlay() {
        return document.getElementById('code-scan-overlay');
    }

    function getModal() {
        return document.getElementById('code-scan-modal');
    }

    function getBody() {
        return document.getElementById('code-scan-body');
    }

    function createModal() {
        if (getOverlay()) return;

        var overlay = document.createElement('div');
        overlay.id = 'code-scan-overlay';
        overlay.className = 'code-scan-overlay';

        var modal = document.createElement('div');
        modal.id = 'code-scan-modal';
        modal.className = 'code-scan-modal';

        modal.innerHTML =
            '<div class="code-scan-modal-header">' +
                '<h3 class="code-scan-modal-title">CTP-Studio 代码检测结果</h3>' +
                '<div style="display:flex;align-items:center;gap:8px;">' +
                    '<button class="code-scan-refresh-btn" id="code-scan-refresh-btn" title="拉取最新的扫描结果（每次检测结果会保留24小时）">🔄 强刷</button>' +
                    '<button class="code-scan-close-btn" id="code-scan-close-btn">X</button>' +
                '</div>' +
            '</div>' +
            '<div class="code-scan-modal-body" id="code-scan-body">' +
                '<div class="code-scan-progress-container">' +
                    '<div class="code-scan-progress-icon">⚙️</div>' +
                    '<div class="code-scan-progress-text">正在准备...</div>' +
                '</div>' +
            '</div>';

        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        // 关闭按钮 - 必须点击才能关闭
        document.getElementById('code-scan-close-btn').onclick = function (e) {
            e.stopPropagation();
            e.preventDefault();
            hideModal();
        };

        // 强刷按钮
        document.getElementById('code-scan-refresh-btn').onclick = function (e) {
            e.stopPropagation();
            e.preventDefault();
            forceRefresh();
        };

        // 不响应遮罩层点击（需求：必须点击关闭按钮才能关闭）
        // overlay.onclick 故意不设置
    }

    function showModal() {
        createModal();
        var overlay = getOverlay();
        if (overlay) {
            overlay.classList.add('active');
            Logger.info('弹窗已显示');
        }
    }

    function hideModal() {
        var overlay = getOverlay();
        if (overlay) {
            overlay.classList.remove('active');
            Logger.info('弹窗已隐藏');
        }
        // 停止轮询（但后台检测继续）
        stopPolling();
    }

    // ========== 进度展示 ==========

    function showProgress(progress) {
        var body = getBody();
        if (!body) return;

        var percent = progress ? (progress.percent || 0) : 0;
        var currentProject = progress ? (progress.currentProject || '准备中...') : '准备中...';
        var current = progress ? (progress.current || 0) : 0;
        var total = progress ? (progress.total || 0) : 0;

        var detailText = '';
        if (total > 0) {
            detailText = '正在扫描第 ' + current + ' / ' + total + ' 个项目';
        }

        body.innerHTML =
            '<div class="code-scan-progress-container">' +
                '<div class="code-scan-progress-icon">⚙️</div>' +
                '<div class="code-scan-progress-percent">' + percent + '%</div>' +
                '<div class="code-scan-progress-bar-wrapper">' +
                    '<div class="code-scan-progress-bar" style="width: ' + percent + '%;"></div>' +
                '</div>' +
                '<div class="code-scan-progress-text">' + escapeHtml(currentProject) + '</div>' +
                (detailText ? '<div class="code-scan-progress-detail">' + detailText + '</div>' : '') +
                '<div class="code-scan-progress-hint">' +
                    '💡 扫描太慢了？可以关闭窗口等5分钟再来看看<br>' +
                    '如果长时间没有进度，可以关闭窗口重新进来看看' +
                '</div>' +
            '</div>';
    }

    // ========== 错误展示 ==========

    function showError(errorMsg) {
        var body = getBody();
        if (!body) return;

        body.innerHTML =
            '<div class="code-scan-error-container">' +
                '<div class="code-scan-error-icon">❌</div>' +
                '<div class="code-scan-progress-text">检测失败</div>' +
                '<div class="code-scan-error-text">' + escapeHtml(errorMsg || '未知错误') + '</div>' +
            '</div>';
    }

    // ========== 结果展示 ==========

    function showResult(result, currentUser, currentUserCodes, currentUserNonCompliant, scanDurationMs) {
        var body = getBody();
        if (!body) return;

        if (!result || !result.rows || result.rows.length === 0) {
            body.innerHTML = '<div class="code-scan-error-container">' +
                '<div class="code-scan-error-icon">📭</div>' +
                '<div class="code-scan-progress-text">未检测到任何代码记录</div>' +
            '</div>';
            return;
        }

        // 计算耗时描述
        var durationText = '';
        if (scanDurationMs) {
            var totalSec = Math.round(scanDurationMs / 1000);
            if (totalSec >= 60) {
                durationText = Math.floor(totalSec / 60) + ' 分 ' + (totalSec % 60) + ' 秒';
            } else {
                durationText = totalSec + ' 秒';
            }
        }

        var projectsWithCode = result.rows.length;
        var totalScanned = result.totalProjectsScanned || projectsWithCode;
        var failedProjects = result.failedProjects || [];
        var skippedProjects = result.skippedProjects || [];

        var html = '<div class="code-scan-result">';

        // 扫描信息摘要（一行文字提示）
        if (durationText) {
            var startTimeText = '';
            if (result.scanStartTime) {
                startTimeText = new Date(result.scanStartTime).toLocaleString('zh-CN');
            }
            html += '<div class="code-scan-scan-info">';
            if (startTimeText) {
                html += '🕐 本次扫描时间：<strong>' + startTimeText + '</strong><br>';
            }
            html += '⏱️ 本次扫描耗时：<strong>' + durationText + '</strong>' +
                '，共 <strong>' + totalScanned + '</strong> 个目标项目' +
                '，扫描到 <strong>' + projectsWithCode + '</strong> 个项目有代码记录';
            var issueCount = failedProjects.length + skippedProjects.length;
            if (issueCount > 0) {
                var issueParts = [];
                if (failedProjects.length > 0) issueParts.push(failedProjects.length + '个失败');
                if (skippedProjects.length > 0) issueParts.push(skippedProjects.length + '个跳过');
                html += '（<span style="color:#e67e22;">' + issueParts.join('，') + '</span>）';
            }
            html += '</div>';
        }

        // 异常项目独立汇总区域（仅展示跳过或失败的项目）
        if (skippedProjects.length > 0 || failedProjects.length > 0) {
            html += '<div class="code-scan-scan-info" style="background:#fff8f0;border-left-color:#e67e22;margin-top:8px;">';
            html += '<strong>📋 异常项目汇总</strong>';
            if (skippedProjects.length > 0) {
                html += '<div style="margin-top:6px;"><span style="color:#e67e22;">⚠️ 跳过（' + skippedProjects.length + ' 个）</span>：' +
                    skippedProjects.map(function (sp) { return escapeHtml(sp.projectAlias) + '<span style="color:#999;font-size:11px;">(' + escapeHtml(sp.reason) + ')</span>'; }).join('、') +
                    '</div>';
            }
            if (failedProjects.length > 0) {
                html += '<div style="margin-top:4px;"><span style="color:#e74c3c;">❌ 扫描失败（' + failedProjects.length + ' 个）</span>：' +
                    failedProjects.map(function (fp) { return escapeHtml(fp.projectAlias) + '<span style="color:#999;font-size:11px;">(' + escapeHtml(fp.error) + ')</span>'; }).join('、') +
                    '</div>';
            }
            html += '</div>';
        }

        // 区域一：当前用户不合规代码（置顶显示）
        if (currentUser && currentUserNonCompliant && currentUserNonCompliant.length > 0) {
            html += '<div class="code-scan-user-alert">';
            html += '<h4>⚠️ 我的不合规代码</h4>';
            html += '<div class="code-scan-user-info">';
            html += '当前登录人：<strong>' + escapeHtml(currentUser) + '</strong>';
            html += '</div>';
            html += buildUserNonCompliantTable(currentUserNonCompliant);
            html += '</div>';
        } else if (currentUser) {
            html += '<div class="code-scan-user-ok">';
            html += '<div>✅ 当前登录人：<strong>' + escapeHtml(currentUser) + '</strong></div>';
            html += '</div>';
        }


        // 按申请人统计
        html += '<h4>👥 按代码申请人统计</h4>';
        html += buildApplicantTable(result.rows, currentUser);

        // 按项目统计
        html += '<h4>📁 按项目统计</h4>';
        html += buildProjectTable(result.rows, currentUser);

        // 原始数据（可折叠）
        html += '<h4>📄 原始数据</h4>';
        html += buildRawDataCollapse(result);

        // 底部 - 使用实际扫描完成时间
        var scanEndTime = '';
        if (result.scanStartTime && scanDurationMs) {
            scanEndTime = new Date(result.scanStartTime + scanDurationMs).toLocaleString('zh-CN');
        } else if (result.scanStartTime) {
            scanEndTime = new Date(result.scanStartTime).toLocaleString('zh-CN');
        }
        html += '<div class="code-scan-result-footer">';
        if (scanEndTime) {
            html += '检测完成时间：' + scanEndTime;
        }
        html += ' | 每次检测结果会保留 24 小时</div>';

        html += '</div>';

        body.innerHTML = html;

        // 绑定折叠事件
        bindCollapseEvents();
    }

    /**
     * 构建当前用户不合规代码明细表
     */
    function buildUserNonCompliantTable(items) {
        if (!items || items.length === 0) return '';

        var html = '<table class="code-scan-table">';
        html += '<tr><th>项目名称</th><th>代码路径</th><th>提交时间</th><th>申请人</th></tr>';

        items.forEach(function (item) {
            html += '<tr>' +
                '<td>' + escapeHtml(item.projectAlias) + '</td>' +
                '<td style="font-size:11px;word-break:break-all;">' + escapeHtml(item.filePath) + '</td>' +
                '<td>' + escapeHtml(item.applicationDate || '-') + '</td>' +
                '<td>' + escapeHtml(item.applicant || '-') + '</td>' +
                '</tr>';
        });

        html += '</table>';
        return html;
    }

    /**
     * 构建按申请人统计表
     */
    function buildApplicantTable(rows, currentUser) {
        var applicantStats = {};

        rows.forEach(function (entry) {
            var applicants = {};
            entry.projectCode.forEach(function (code) {
                var applicant = code.applicant || '-';
                if (applicant === '-') return;
                if (!applicants[applicant]) {
                    applicants[applicant] = true;
                    if (!applicantStats[applicant]) {
                        applicantStats[applicant] = { projects: 0, totalCode: 0 };
                    }
                    applicantStats[applicant].projects++;
                }
                applicantStats[applicant].totalCode++;
            });
        });

        var entries = Object.entries(applicantStats);
        if (entries.length === 0) {
            return '<p style="color:#999;">暂无代码申请人数据</p>';
        }

        // 按代码数量降序排列
        entries.sort(function (a, b) { return b[1].totalCode - a[1].totalCode; });

        var html = '<table class="code-scan-table">';
        html += '<tr><th>代码申请人</th><th>项目数量</th><th>代码数量</th></tr>';

        entries.forEach(function (item) {
            var applicant = item[0];
            var data = item[1];
            var isCurrentUser = currentUser && applicant === currentUser;
            var nameStyle = isCurrentUser ? ' style="color:#e74c3c;font-weight:bold;"' : ' class="highlight"';
            var badge = isCurrentUser ? ' <span style="color:#e74c3c;font-size:11px;">(我)</span>' : '';
            html += '<tr>' +
                '<td' + nameStyle + '>' + escapeHtml(applicant) + badge + '</td>' +
                '<td>' + data.projects + '</td>' +
                '<td>' + data.totalCode + '</td>' +
                '</tr>';
        });

        html += '</table>';
        return html;
    }

    /**
     * 构建按项目统计表
     */
    function buildProjectTable(rows, currentUser) {
        if (rows.length === 0) {
            return '<p style="color:#999;">暂无项目数据</p>';
        }

        var html = '<table class="code-scan-table">';
        html += '<tr><th>项目名称</th><th>创建人</th><th>代码文件数量</th><th>代码申请人</th></tr>';

        // 按代码数量降序
        var sorted = rows.slice().sort(function (a, b) {
            return b.projectCode.length - a.projectCode.length;
        });

        sorted.forEach(function (entry) {
            var applicantSet = {};
            entry.projectCode.forEach(function (code) {
                var applicant = code.applicant || '-';
                applicantSet[applicant] = true;
            });
            // 移除 '-'
            delete applicantSet['-'];
            var applicants = Object.keys(applicantSet);
            var applicantStr = applicants.length > 0
                ? applicants.map(function (a) {
                    if (currentUser && a === currentUser) {
                        return '<strong style="color:#e74c3c;">' + escapeHtml(a) + '(我)</strong>';
                    }
                    return '<strong>' + escapeHtml(a) + '</strong>';
                }).join('、')
                : '-';

            html += '<tr>' +
                '<td>' + escapeHtml(entry.projectAlias) + '</td>' +
                '<td style="font-weight:bold;">' + escapeHtml(entry.creator) + '</td>' +
                '<td>' + entry.projectCode.length + '</td>' +
                '<td style="color:#4a90e2;">' + applicantStr + '</td>' +
                '</tr>';
        });

        html += '</table>';
        return html;
    }

    /**
     * 构建原始数据折叠区
     */
    function buildRawDataCollapse(result) {
        var jsonData = JSON.stringify(result, null, 2);
        var html = '<div class="code-scan-collapse">';
        html += '<div style="display:flex;align-items:center;gap:8px;">';
        html += '<button class="code-scan-collapse-toggle" id="code-scan-raw-toggle">' +
            '<span>点击展开原始 JSON 数据</span>' +
            '<span class="arrow">▶</span>' +
            '</button>';
        html += '<button id="code-scan-copy-btn" style="padding:4px 12px;font-size:12px;cursor:pointer;border:1px solid #4a90e2;background:#fff;color:#4a90e2;border-radius:3px;white-space:nowrap;">📋 复制数据</button>';
        html += '</div>';
        html += '<div class="code-scan-collapse-content" id="code-scan-raw-content">' +
            '<pre>' + escapeHtml(jsonData) + '</pre>' +
            '</div>';
        html += '</div>';
        return html;
    }

    /**
     * 绑定折叠区事件
     */
    function bindCollapseEvents() {
        var toggleBtn = document.getElementById('code-scan-raw-toggle');
        var content = document.getElementById('code-scan-raw-content');
        if (toggleBtn && content) {
            toggleBtn.onclick = function () {
                var isOpen = content.classList.contains('open');
                if (isOpen) {
                    content.classList.remove('open');
                    toggleBtn.classList.remove('open');
                    toggleBtn.querySelector('span:first-child').textContent = '点击展开原始 JSON 数据';
                } else {
                    content.classList.add('open');
                    toggleBtn.classList.add('open');
                    toggleBtn.querySelector('span:first-child').textContent = '点击收起原始 JSON 数据';
                }
            };
        }

        var copyBtn = document.getElementById('code-scan-copy-btn');
        if (copyBtn) {
            copyBtn.onclick = function () {
                // 从已渲染的 pre 标签中获取文本（确保与页面显示一致）
                var pre = document.querySelector('#code-scan-raw-content pre');
                var textToCopy = pre ? pre.textContent : '';
                navigator.clipboard.writeText(textToCopy).then(function () {
                    copyBtn.textContent = '✅ 已复制';
                    copyBtn.style.borderColor = '#4caf50';
                    copyBtn.style.color = '#4caf50';
                    setTimeout(function () {
                        copyBtn.textContent = '📋 复制数据';
                        copyBtn.style.borderColor = '#4a90e2';
                        copyBtn.style.color = '#4a90e2';
                    }, 2000);
                }).catch(function (err) {
                    Logger.error('复制失败:', err);
                    copyBtn.textContent = '❌ 复制失败';
                    setTimeout(function () {
                        copyBtn.textContent = '📋 复制数据';
                    }, 2000);
                });
            };
        }
    }

    // ========== 轮询进度 ==========

    function startPolling() {
        stopPolling();
        pollTimer = setInterval(function () {
            chrome.runtime.sendMessage({ action: 'getCodeScanProgress' }, function (resp) {
                if (!resp || !resp.success) return;
                var data = resp.data;
                Logger.debug('轮询进度:', data);

                if (data.status === 'scanning' && data.progress) {
                    showProgress(data.progress);
                } else if (data.status === 'completed' && data.result) {
                    stopPolling();
                    isScanning = false;
                    updateRefreshBtnState();
                    // 通过 getCodeScanResult 获取完整的用户数据
                    chrome.runtime.sendMessage({ action: 'getCodeScanResult' }, function (fullResp) {
                        if (fullResp && fullResp.success && fullResp.data.status === 'completed') {
                            var fd = fullResp.data;
                            showResult(fd.result, fd.currentUser, fd.currentUserCodes, fd.currentUserNonCompliant, fd.scanDurationMs);
                        } else {
                            showResult(data.result);
                        }
                    });
                } else if (data.status === 'error') {
                    stopPolling();
                    isScanning = false;
                    updateRefreshBtnState();
                    showError(data.error);
                }
            });
        }, 1500);
    }

    function stopPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
    }

    // ========== 缓存的完整数据（用于强制刷新和展示） ==========
    var cachedFullData = null;
    var isScanning = false;

    /**
     * 更新强刷按钮状态
     */
    function updateRefreshBtnState() {
        var btn = document.getElementById('code-scan-refresh-btn');
        if (!btn) return;

        if (isScanning) {
            btn.disabled = true;
            btn.style.opacity = '0.4';
            btn.style.cursor = 'not-allowed';
            btn.title = '当前有检测任务正在执行，请等待完成后再强刷';
        } else {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
            btn.title = '拉取最新的扫描结果（每次检测结果会保留24小时）';
        }
    }

    // ========== FAB 点击处理 ==========

    function onFABClick() {
        Logger.info('开始处理 FAB 点击');

        // 先查询缓存
        chrome.runtime.sendMessage({ action: 'getCodeScanResult' }, function (resp) {
            if (!resp || !resp.success) {
                Logger.error('查询失败:', resp);
                showModal();
                showError('与后台通信失败');
                return;
            }

            var data = resp.data;
            Logger.info('缓存查询结果:', data);

            switch (data.status) {
                case 'completed':
                    // 有有效缓存，直接展示
                    Logger.info('使用缓存结果');
                    cachedFullData = data;
                    isScanning = false;
                    showModal();
                    updateRefreshBtnState();
                    showResult(data.result, data.currentUser, data.currentUserCodes, data.currentUserNonCompliant, data.scanDurationMs);
                    break;

                case 'expired':
                    // 缓存过期，重新检测
                    Logger.info('缓存已过期，重新启动检测');
                    cachedFullData = null;
                    showModal();
                    showProgress({ percent: 0, currentProject: '正在启动检测...', current: 0, total: 0 });
                    startCodeScan();
                    break;

                case 'scanning':
                    // 正在扫描中，展示进度
                    Logger.info('检测正在进行中，展示进度');
                    isScanning = true;
                    showModal();
                    updateRefreshBtnState();
                    showProgress(data.progress || { percent: 0, currentProject: '正在扫描...' });
                    startPolling();
                    break;

                case 'error':
                    // 上次出错，重新检测
                    Logger.info('上次检测出错，重新启动');
                    cachedFullData = null;
                    showModal();
                    showProgress({ percent: 0, currentProject: '正在重新启动检测...', current: 0, total: 0 });
                    startCodeScan();
                    break;

                case 'idle':
                default:
                    // 未检测过，启动检测
                    Logger.info('首次检测，启动');
                    cachedFullData = null;
                    showModal();
                    showProgress({ percent: 0, currentProject: '正在启动检测...', current: 0, total: 0 });
                    startCodeScan();
                    break;
            }
        });
    }

    /**
     * 强制刷新：忽略缓存，重新执行检测（仅在非扫描状态可用）
     */
    function forceRefresh() {
        if (isScanning) {
            Logger.info('当前有检测任务正在执行，强刷被忽略');
            return;
        }
        Logger.info('强制刷新：重新执行检测');
        cachedFullData = null;
        showProgress({ percent: 0, currentProject: '正在拉取最新扫描结果...', current: 0, total: 0 });
        startCodeScan();
    }

    /**
     * 发起代码检测请求
     */
    function startCodeScan() {
        isScanning = true;
        updateRefreshBtnState();
        chrome.runtime.sendMessage({ action: 'startCodeScan' }, function (resp) {
            if (resp && resp.success) {
                Logger.info('检测启动成功:', resp.data);
                // 开始轮询进度
                startPolling();
            } else {
                Logger.error('检测启动失败:', resp);
                showError('启动检测失败：' + (resp ? resp.error : '通信失败'));
            }
        });
    }

    // ========== 工具函数 ==========

    function escapeHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    // ========== 初始化 ==========

    function init() {
        Logger.info('init', window.location.href);
        if (isTargetPage()) {
            Logger.info('目标页面，创建 UI');
            createFAB();
        } else {
            Logger.info('[入口] 代码检测悬浮球不显示：非目标页面');
        }
    }

    // 启动
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // SPA 路由监听（studio 可能是单页应用）
    var lastHref = location.href;
    setInterval(function () {
        if (location.href !== lastHref) {
            lastHref = location.href;
            Logger.info('URL 变化:', location.href);
            if (isTargetPage()) {
                if (!document.getElementById('code-scan-fab')) {
                    createFAB();
                }
            } else {
                Logger.info('[入口] URL变化后仍非目标页，代码检测悬浮球不显示');
            }
        }
    }, 1000);

    Logger.info('代码检测内容脚本加载完成');
})();