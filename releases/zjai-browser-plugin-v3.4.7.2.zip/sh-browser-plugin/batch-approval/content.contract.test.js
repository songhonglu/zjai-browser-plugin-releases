const assert = require('assert');
const fs = require('fs');
const path = require('path');

const modulePath = path.join(__dirname, 'content.js');
const manifestPath = path.join(__dirname, '..', 'manifest.json');
const backgroundPath = path.join(__dirname, '..', 'background.js');

const api = require(modulePath);
const source = fs.readFileSync(modulePath, 'utf8');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const backgroundSource = fs.readFileSync(backgroundPath, 'utf8');

assert.strictEqual(api.matchApprovalType('交付序列周计划-浙江项目交付三部-黄米-2026年-8月-第1周'), '周计划');
assert.strictEqual(api.matchApprovalType('交付序列周计划-浙江客开二部-宋汉望-2026年-8月-第1周'), '周计划');
assert.strictEqual(api.matchApprovalType('交付序列周计划-浙江客开二部-陈培托-2026年-8月-第1周(由陈培托原发)'), '周计划');
assert.strictEqual(api.matchApprovalType('【浙江大区】SAP集成项目-2026-08-03项目周报'), '项目周报');
assert.strictEqual(api.matchApprovalType('【浙江军团】预算管理项目-2026年8月3日项目周报'), '项目周报');
assert.strictEqual(api.matchApprovalType('【其他区域】预算管理项目-2026-08-03项目周报'), '');
assert.strictEqual(api.matchApprovalType('交付月度绩效考核-宋汉望-浙江客开二部-2026年度-8月度'), '绩效考核');
assert.strictEqual(api.matchApprovalType('交付月度绩效考核-宋汉望-浙江客开二部-2026年-8月'), '绩效考核');
assert.strictEqual(api.matchApprovalType('交付月度绩效考核-戴恩法-浙江客开二部-2026-7'), '绩效考核');
assert.strictEqual(api.matchApprovalType('(自动发起)交付月度绩效考核-宋汉望-浙江客开一部-2026-08'), '绩效考核');
assert.strictEqual(api.matchApprovalType('月度绩效考核-宋汉望-浙江客开二部-2026-8'), '');
assert.strictEqual(api.matchApprovalType('顾问工时登记-浙江大区-宋汉望-2026-07-30'), '工时单');
assert.strictEqual(api.matchApprovalType('顾问工时登记-浙江军团-宋汉望-2026-07-30'), '工时单');
assert.strictEqual(api.matchApprovalType('顾问工时登记-浙江大区-#张嘉荣-2026-08-03(由#张嘉荣原发)'), '工时单');
assert.strictEqual(api.matchApprovalType('顾问工时登记 – 浙江大区 – #张嘉荣 – 2026-08-03(由#张嘉荣原发)'), '工时单');
assert.strictEqual(api.matchApprovalType('【补录】顾问工时登记-浙江军团-宋汉望-2026-01-26'), '工时单');
assert.strictEqual(api.matchApprovalType('【补录】顾问工时登记-浙江军团-#张嘉荣-2026-01-26(由#张嘉荣原发)'), '工时单');
assert.strictEqual(api.matchApprovalType('顾问工时登记-其他区域-宋汉望-2026-07-30'), '');
assert.ok(api.DEFAULT_PHRASES.includes('同意，按规定办理'), '应内置截图中的审批意见');
assert.ok(api.DEFAULT_PHRASES.includes('保留意见'), '应内置保留意见');

const filtered = api.filterApprovalItems([
  { affairId: '1', subject: '顾问工时登记-浙江大区-宋汉望-2026-07-30', receiveTime: '2026-07-30' },
  { affairId: '2', subject: '普通流程' },
  { affairId: '1', subject: '顾问工时登记-浙江大区-宋汉望-2026-07-30' },
  { affairId: '3', subject: '交付序列周计划-浙江客开二部-宋汉望-2026年-8月-第1周' },
  { affairId: '4', subject: '交付序列周计划-浙江客开二部-陈培托-2026年-8月-第1周(由陈培托原发)' },
  { affairId: '5', subject: '【浙江大区】SAP集成项目-2026-08-03项目周报' },
  { affairId: '6', subject: '交付月度绩效考核-宋汉望-浙江客开二部-2026年度-8月度' },
  { affairId: '7', subject: '顾问工时登记-浙江大区-#张嘉荣-2026-08-03(由#张嘉荣原发)' }
]);
assert.deepStrictEqual(filtered.map((item) => item.affairId), ['1', '3', '4', '5', '6', '7']);
assert.match(api.buildDetailUrl('123'), /openFrom=listPending&affairId=123/);

assert.match(source, /id="ball"[\s\S]*aria-label="ZJAI"/, '应先显示圆形入口按钮');
assert.match(source, /id="open-batch"[\s\S]*批量处理/, '圆形入口菜单应包含“批量处理”');
assert.match(source, /#open-batch b\{display:block;font-size:13px;color:#dc2626\}/, '菜单项主文字应参考 project-check 使用红色强调');
assert.match(source, /function bindBallDrag\(/, '圆形入口应支持拖动');
assert.match(source, /seeyon-batch-approval-pos/, '圆形入口拖动位置应保存');
assert.match(source, /document\.addEventListener\('pointermove', move, true\)/, '圆形入口拖动应使用 document 级 pointermove，避免 OA 页面抢事件后拖不动');
assert.match(source, /#\$\{PANEL_ID\}\{position:fixed;right:72px;top:48px/, '弹框初始位置应在可视区内，并给列表留出更多高度');
assert.match(source, /待办批量处理/, '弹框标题应为待办批量处理');
assert.match(source, /function bindDrag\(/, '弹框应支持拖动');
assert.match(source, /table\{[^}]*table-layout:fixed/, '待办列表应使用固定表格布局，避免刷新后列宽变化');
assert.match(source, /\.list\{[^}]*max-height:520px/, '待办列表高度应支持最多约 20 条数据展示');
assert.match(source, /list\.style\.height = listHeight\(\);/, '待办列表高度应固定按 10 行显示');
assert.match(source, /function listHeight\(\)/, '应有列表高度计算函数');
assert.match(source, /th,td\{[^}]*padding:5px 8px/, '表格行距应适当收紧，提升单屏可见行数');
assert.match(source, /th,td\{[^}]*white-space:nowrap[^}]*text-overflow:ellipsis/, '表格单元格应单行省略，避免类型/时间/状态换行');
assert.match(source, /td\.subject\{max-width:none;word-break:normal\}/, '标题列不应按内容换行撑开布局');
assert.match(source, /<a class="detail-link" href="' \+ buildDetailUrl\(item\.affairId\) \+ '" target="_blank" rel="noopener noreferrer"/, '点击标题应以新页签打开待办详情');
assert.match(source, /\.detail-link\{[^}]*text-decoration:none/, '标题详情链接应保持列表样式');
assert.match(source, /function startSilentRunner\(/, '批量处理应通过隐藏 iframe 静默运行');
assert.match(source, /id = RUNNER_ID|frame\.id = RUNNER_ID/, '静默处理 iframe 应使用固定 RUNNER_ID');
assert.doesNotMatch(source, /window\.open\(/, '开始批量处理不应打开新网页');
assert.match(source, /const PAGE_SIZE_OPTIONS = \[5, 10, 20, 30\]/, '列表分页应支持每页 5/10/20/30 行');
assert.match(source, /const DEFAULT_PAGE_SIZE = 10/, '待办列表默认每页应为 10 条');
assert.match(source, /let pageSize = DEFAULT_PAGE_SIZE/, '首次打开默认每页条数应为 10');
assert.match(source, /const RUN_TIMEOUT_MS = 30000/, '静默批量处理应有超时出口，避免页面卡死后一直处理中');
assert.match(source, /const RUN_HANDOFF_DELAY_MS = 5000/, '多条批量处理应延迟接力下一条，避免打断上一条提交');
assert.match(source, /seeyon-batch-approval-page-size/, '每页行数设置应持久化保存');
assert.match(source, /id="page-size"/, '分页组件应包含每页行数下拉');
assert.match(source, /async function loadPageSize\(/, '打开插件时应读取用户保存的每页行数');
assert.match(source, /PAGE_SIZE_OPTIONS\.includes\(saved\) \? saved : DEFAULT_PAGE_SIZE/, '无有效保存配置时应回退到默认 10 条');
assert.match(source, /PAGE_SIZE_OPTIONS\.includes\(value\) \? value : DEFAULT_PAGE_SIZE/, '用户选择无效时应回退到默认 10 条');
assert.match(source, /return 10 \* 29 \+ 31 \+ 'px';/, '不管用户选择每页多少条，列表高度都应按 10 行显示');
assert.match(source, /let selectedIds = new Set\(\)/, '跨页选择状态应独立保存，不能只依赖当前页 DOM');
assert.match(source, /items = filterApprovalItems\(raw\);\s*selectedIds = new Set\(\);/, '首次加载或刷新待办后默认不应选中任何数据');
assert.match(source, /if \(!run \|\| !run\.active\) await chromeSet\(\{ \[STORAGE_RUN\]: null \}\);/, '刷新待办时应清理已结束批次状态，避免旧状态覆盖新列表');
assert.doesNotMatch(source, /class=\\"row-box\\"[^>]* checked/, '行复选框模板不应写死 checked');
assert.match(source, /function syncSelectedWithTypes\(\)|const syncSelectedWithTypes = \(\) =>/, '类型筛选变化应联动选择集合');
assert.doesNotMatch(source, /const syncSelectedWithTypes = \(\) => \{[\s\S]{0,260}selectedIds\.add/, '类型筛选不应把可见数据重新自动选中');
assert.match(source, /syncSelectedWithTypes\(\);\s*pageIndex = 0;\s*renderList\(\);/, '点击周计划/工时单筛选后应立即刷新列表和选择状态');
assert.match(source, /data-type="项目周报" checked>项目周报/, '类型筛选应包含项目周报');
assert.match(source, /data-type="绩效考核" checked>绩效考核/, '类型筛选应包含绩效考核');
assert.doesNotMatch(source, /id="select-all"|id="select-none"|>全选<|>全不选</, '顶部不应再显示全选/全不选按钮');
assert.match(source, /id="all-box"/, '应保留表头复选框用于当前页选择');
assert.match(source, /上一页[\s\S]*下一页/, '分页控件应包含上一页和下一页');
assert.match(source, /function startSilentRunner\([\s\S]*iframe/, '静默处理应创建 iframe runner');
assert.match(source, /处理超时，仍在待办/, '静默处理超时后应把未完成数据标记为仍在待办');
assert.match(source, /function resumeProcessingItem\(/, '首页应负责接力启动队列中下一条处理中待办');
assert.match(source, /resumeProcessingItem\(run\);/, '同步队列状态时应检查并接力下一条');
assert.match(source, /startSilentRunner\(current\.affairId\)/, '接力时应重新指向当前处理中待办详情');
assert.match(source, /async function dismissRecoveryPrompt\(/, '静默打开待办时应自动处理恢复提示');
assert.match(source, /不恢复/, '有未保存数据提示应自动选择“不恢复”');
assert.match(source, /await dismissRecoveryPrompt\(\);[\s\S]*waitAndFillOpinion/, '应先关闭恢复提示，再填写审批意见');
assert.match(source, /function verifyQueueStatus\(/, '提交后应回查待办列表确认真实状态');
assert.match(source, /clicked \? '已提交'/, '点击提交成功后应直接显示已提交');
assert.match(source, /回查失败，请刷新待办/, '待办回查失败时应提示用户刷新确认');
assert.match(source, /仍在待办/, '回查后仍存在的待办应显示仍在待办');
assert.match(source, /已办结/, '回查后消失的待办才允许显示已办结');
assert.doesNotMatch(source, /已点击提交/, '不能把点击提交按钮误当成处理结果');
assert.doesNotMatch(source, /已提交，回查中/, '不应使用“回查中”展示状态');
assert.doesNotMatch(source, /已触发提交，待复核/, '不应继续使用“待复核”作为提交后的展示状态');
assert.match(source, /let detailAutoSubmitStarted = false/, '详情页自动提交应有单次执行锁，避免 DOMContentLoaded/load 重复触发');
assert.match(source, /if \(detailAutoSubmitStarted\) return;\s*detailAutoSubmitStarted = true;/, '自动提交前应先加锁');
assert.match(source, /\^\(确定\|继续提交\)\$/, '二次确认只应点击确认类按钮');
assert.doesNotMatch(source, /clickConfirmButtons[\s\S]{0,260}\|提交/, '二次确认不能再次点击普通提交按钮');
assert.match(source, /closePanel\(\)/, '关闭按钮应调用 closePanel');
assert.match(source, /id="phrase-toggle"[\s\S]*常用语/, '常用语入口应在审批意见输入框右侧');
assert.match(source, /id="phrase-panel"/, '常用语应使用弹层展示');
assert.match(source, /\.phrase-panel\{[^}]*position:absolute/, '常用语弹层应浮在输入区上方，不占用列表空间');
assert.match(source, /\.phrase-panel\{[^}]*width:360px/, '常用语弹层宽度应紧凑');
assert.match(source, /\.phrase-list\{[^}]*max-height:88px/, '常用语列表高度应进一步收紧，避免弹层过高');
assert.match(source, /\.phrase-item\{[^}]*padding:2px 4px/, '常用语列表项应使用紧凑行距');
assert.match(source, /\.phrase-item\{[^}]*border:none/, '常用语列表项不应显示边框');
assert.match(source, /\.approval button:not\(\.phrase-item\),\.custom button/, '常用语列表项应排除通用按钮边框样式');
assert.match(source, /id="phrase-list"/, '常用语弹层应渲染常用语列表');
assert.match(source, /新增\/编辑/, '常用语弹层应提供新增编辑入口');
assert.match(source, /审批意见不能为空/, '审批意见不能为空时应阻止提交');
assert.match(source, /chrome\.storage\.local/, '自定义常用语应保存到 chrome.storage.local');
assert.match(source, /batchApprovalGetPending/, '内容脚本应通过独立 action 查询批量待办');
assert.doesNotMatch(source, /weeklyPlanAiSummarize/, '批量处理插件不应依赖 weekly-plan 功能');

const batchScript = manifest.content_scripts.find((item) => item.js && item.js.includes('batch-approval/content.js'));
assert.ok(batchScript, 'manifest 应注入 batch-approval/content.js');
assert.strictEqual(batchScript.all_frames, true);
assert.match(backgroundSource, /case 'batchApprovalGetPending':/, 'background 应处理批量待办查询 action');
assert.match(backgroundSource, /getBatchApprovalPending/, 'background 应提供批量待办查询函数');
assert.match(backgroundSource, /subject: '工时登记'/, 'background 应使用工时登记关键字兜底查询工时待办');
assert.match(backgroundSource, /subject: '项目周报'/, 'background 应查询项目周报待办');
assert.match(backgroundSource, /subject: '交付月度绩效考核'/, 'background 应查询交付月度绩效考核待办');

console.log('batch approval contract checks passed');
