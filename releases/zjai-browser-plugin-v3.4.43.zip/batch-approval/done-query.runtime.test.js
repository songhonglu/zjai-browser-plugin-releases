const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'background.js'), 'utf8');

function createSandbox() {
    const sandbox = {
        console,
        setTimeout,
        clearTimeout,
        fetch: async () => ({ ok: true, status: 200, text: async () => 'null' }),
        chrome: {
            cookies: { getAll: async () => [{ name: 'JSESSIONID', value: 'test' }] },
            runtime: {
                getManifest: () => ({ version: '3.4.32' }),
                getURL: (file) => 'chrome-extension://test/' + file,
                onMessage: { addListener: () => {} }
            },
            scripting: { executeScript: async () => [] },
            storage: {
                local: {
                    set: (_obj, cb) => { cb && cb(); },
                    get: (_keys, cb) => { cb({}); }
                }
            },
            tabs: { query: async () => [] }
        }
    };
    vm.createContext(sandbox);
    vm.runInContext(source, sandbox);
    return sandbox;
}

async function main() {
    const sandbox = createSandbox();
    const empty = await sandbox.fetchColManager('deleteAffair', ['finish', '1001']);
    assert.equal(empty, null, 'void 方法返回 null 时不能抛 reading data');

    const calls = [];
    sandbox.fetch = async (_url, options) => {
        const body = String(options && options.body || '');
        calls.push(body);
        let text = 'null';
        if (body.includes('checkCanDelete')) text = JSON.stringify('success');
        if (body.includes('getDoneList')) {
            const args = JSON.parse(decodeURIComponent(body.split('arguments=')[1]));
            const page = args[0].page;
            const size = args[0].size;
            const start = (page - 1) * size;
            const all = Array.from({ length: 25 }, (_item, index) => ({
                id: String(1000 + index),
                subject: '流程' + (index % 7)
            }));
            text = JSON.stringify({
                page: page,
                size: size,
                total: 0,
                data: all.slice(start, start + size)
            });
        }
        return { ok: true, status: 200, text: async () => text };
    };

    const deleted = await sandbox.deleteDoneAffairs({ affairIds: ['1001'] });
    assert.equal(deleted && deleted.deleted, 1, 'deleteAffair 返回 null 时应视为删除完成');
    assert.equal(sandbox.isTrustworthyListTotal(0, 20, 1, 20), false, '有数据时总数 0 不可信');
    assert.equal(sandbox.isTrustworthyListTotal(25, 20, 1, 20), true, '大于本页行数的总数可信');

    sandbox.clearDoneDedupCountCache();
    const counted = await sandbox.resolveDedupedDoneTotal({ deduplication: 'true', subject: '' }, '');
    assert.equal(counted && counted.total, 25, '去重查询总数为 0 时应按返回行数累计');
    assert.equal(counted && counted.openEnded, false, '未到上限时总数应是精确值');
    assert.ok(calls.some((body) => body.includes('deleteAffair')), '应实际调用 deleteAffair');

    function installPagedList(totalCount) {
        sandbox.fetch = async (_url, options) => {
            const body = String(options && options.body || '');
            const args = JSON.parse(decodeURIComponent(body.split('arguments=')[1]));
            const page = args[0].page;
            const size = args[0].size;
            const start = (page - 1) * size;
            const data = [];
            for (let index = start; index < Math.min(totalCount, start + size); index += 1) {
                data.push({ id: String(index + 1), subject: '流程' + index });
            }
            return { ok: true, status: 200, text: async () => JSON.stringify({ page: page, size: size, total: 0, data: data }) };
        };
    }
    installPagedList(2134);
    sandbox.clearDoneDedupCountCache();
    const exact = await sandbox.resolveDedupedDoneTotal({ deduplication: 'true', subject: 'exact' }, 'exact');
    assert.equal(exact && exact.total, 2134, '超过 2000 条时也应返回精确总数');
    assert.equal(exact && exact.openEnded, false, '精确总数不应再显示加号');
    console.log('done query runtime checks passed');
}

main().catch((error) => {
    console.error(error);
    process.exit(1);
});
