const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'background.js'), 'utf8');

function createSandbox(models) {
    const sandbox = {
        console,
        setTimeout,
        clearTimeout,
        fetch: async () => ({ ok: true, json: async () => ({ data: models.map(id => ({ id })) }) }),
        chrome: {
            cookies: { getAll: async () => [] },
            runtime: { onMessage: { addListener: () => {} } },
            scripting: { executeScript: async () => [] }
        }
    };
    vm.createContext(sandbox);
    vm.runInContext(source, sandbox);
    return sandbox;
}

async function main() {
    const sandbox = createSandbox(['agnes-2.5-pro-alpha', 'agnes-3.0-flash']);
    assert.equal(await sandbox.getWeeklyPlanAiModel(), 'agnes-3.0-flash');

    const missingSandbox = createSandbox(['agnes-2.5-pro-alpha']);
    await assert.rejects(
        () => missingSandbox.getWeeklyPlanAiModel(),
        /AI模型不可用: agnes-3\.0-flash/
    );
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
