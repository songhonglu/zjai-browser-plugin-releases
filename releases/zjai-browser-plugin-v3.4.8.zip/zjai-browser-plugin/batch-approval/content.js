(function () {
  const DEFAULT_PHRASES = [
    '收到，谢谢。',
    'OK，全力支持',
    '同意，按规定办理',
    '按流程办理',
    '交相关部门处理',
    '按单位相关规章制度办理',
    '保留意见'
  ];

  const TYPE_RULES = [
    { type: '周计划', pattern: /^交付序列周计划-.+-.+-\d{4}年-\d{1,2}月-第\d+周(?:\(由.+原发\))?$/ },
    { type: '项目周报', pattern: /^【(浙江大区|浙江军团|江浙大区)】.+-\d{4}(?:-\d{1,2}-\d{1,2}|年\d{1,2}月\d{1,2}日)项目周报$/ },
    { type: '绩效考核', pattern: /^(?:\(自动发起\))?交付月度绩效考核-.+-.+-\d{4}(?:年度-\d{1,2}月度|年-\d{1,2}月|-\d{1,2})$/ },
    { type: '前置评估', pattern: /^交付报价前置评估(?:变更)?_.+$/ },
    { type: '客开作业单', pattern: /^【[^】]+】交付作业申请：【.+-.+】\([^)]+\)_[^_]+_\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/ },
    { type: '工时单', pattern: /^顾问工时登记-(浙江大区|浙江军团|江浙大区)-.+-\d{4}-\d{2}-\d{2}(?:\(由.+原发\))?$/ },
    { type: '工时单', pattern: /^【补录】顾问工时登记-(浙江大区|浙江军团|江浙大区)-.+-\d{4}-\d{2}-\d{2}(?:\(由.+原发\))?$/ },
    { type: '工时单', pattern: /^运维顾问工时登记-.+-.+-\d{4}-\d{2}-\d{2}$/ },
    { type: '工时单', pattern: /^【流程】运维顾问工时补录\(.+\s.+\)$/ }
  ];

  const api = {
    DEFAULT_PHRASES,
    normalizeText,
    matchApprovalType,
    filterApprovalItems,
    buildDetailUrl
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
    return;
  }

  if (window.__seeyon_batch_approval__) return;
  window.__seeyon_batch_approval__ = true;

  const HOST_ID = 'seeyon-batch-approval-host';
  const PANEL_ID = 'seeyon-batch-approval-panel';
  const STORAGE_PHRASES = 'seeyon-batch-approval-phrases';
  const STORAGE_RUN = 'seeyon-batch-approval-run';
  const STORAGE_POS = 'seeyon-batch-approval-pos';
  const STORAGE_PAGE_SIZE = 'seeyon-batch-approval-page-size';
  const RUNNER_ID = 'seeyon-batch-approval-runner';
  const PAGE_SIZE_OPTIONS = [5, 10, 20, 30];
  const DEFAULT_PAGE_SIZE = 10;
  const RUN_TIMEOUT_MS = 30000;
  const RUN_HANDOFF_DELAY_MS = 5000;
  const LOG_PREFIX = '[kk-helper:batch-approval]';
  const REQUIREMENT_PAGE_URL = runtimeUrl('requirement/request.html');
  let detailAutoSubmitStarted = false;

  const Log = {
    info: (...args) => console.log(LOG_PREFIX, ...args),
    warn: (...args) => console.warn(LOG_PREFIX, ...args)
  };

  function normalizeText(value) {
    return String(value || '')
      .replace(/[\u200b-\u200d\ufeff]/g, '')
      .replace(/[‐‑‒–—―－]/g, '-')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .replace(/\s*-\s*/g, '-')
      .trim();
  }

  function matchApprovalType(subject) {
    const text = normalizeText(subject);
    const rule = TYPE_RULES.find((item) => item.pattern.test(text));
    return rule ? rule.type : '';
  }

  function itemId(item) {
    return String((item && (item.affairId || item.id || item.summaryId)) || '');
  }

  function itemTime(item) {
    return String((item && (item.receiveTime || item.startDate || item.createDate || item.createTime || item.updateDate)) || '');
  }

  function filterApprovalItems(items) {
    const seen = new Set();
    return (Array.isArray(items) ? items : []).map((item) => {
      const subject = normalizeText(item && item.subject);
      const type = matchApprovalType(subject);
      const affairId = itemId(item);
      if (!type || !affairId || seen.has(affairId)) return null;
      seen.add(affairId);
      return {
        affairId,
        subject,
        type,
        time: itemTime(item),
        status: '待处理'
      };
    }).filter(Boolean);
  }

  function buildDetailUrl(affairId) {
    return 'https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=listPending&affairId=' + encodeURIComponent(affairId) + '&showTab=true';
  }

  function chromeGet(key, fallback) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(key, (res) => resolve((res && res[key]) || fallback));
      } catch (_) {
        resolve(fallback);
      }
    });
  }

  function chromeSet(values) {
    return new Promise((resolve) => {
      try { chrome.storage.local.set(values, resolve); } catch (_) { resolve(); }
    });
  }

  function send(action, params) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action, params: params || {} }, (resp) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || '消息发送失败'));
          return;
        }
        if (!resp || !resp.success) {
          reject(new Error((resp && resp.error) || '后台处理失败'));
          return;
        }
        resolve(resp.data);
      });
    });
  }

  function runtimeUrl(path) {
    try {
      return chrome.runtime.getURL(path);
    } catch (_) {
      return '';
    }
  }

  function openRequirementPage() {
    if (!REQUIREMENT_PAGE_URL) {
      window.alert('插件刚刚更新，请刷新 OA 页面后再点击提需求');
      return;
    }
    const link = document.createElement('a');
    link.href = REQUIREMENT_PAGE_URL;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.documentElement.appendChild(link);
    link.click();
    link.remove();
  }

  function isTopWindow() {
    return window.top === window;
  }

  function isHomePage() {
    if (!isTopWindow()) return false;
    const path = location.pathname || '';
    if (/\/seeyon\/main\.do$/.test(path)) return true;
    return /\/seeyon\/index\.jsp$|\/seeyon\/portal/.test(location.href);
  }

  function ensureHost() {
    if (!document.body || !isHomePage()) return null;
    let host = document.getElementById(HOST_ID);
    if (host) return host;

    host = document.createElement('div');
    host.id = HOST_ID;
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        :host{font-family:"Microsoft YaHei",Arial,sans-serif;color:#111827}
        button,input,textarea{font-family:inherit}
        #ball{width:42px;height:42px;border-radius:50%;background:#fff;border:2px solid #fff;box-shadow:0 4px 14px rgba(56,189,248,.45);cursor:grab;touch-action:none;user-select:none;display:flex;align-items:center;justify-content:center;overflow:hidden}
        #ball:active{cursor:grabbing}
        #ball img{width:42px;height:42px;display:block;object-fit:cover}
        #menu{position:absolute;right:54px;top:-8px;min-width:210px;background:#fff;border-radius:10px;padding:6px;box-shadow:0 8px 30px rgba(0,0,0,.18);display:none}
        #menu.show{display:block}
        .menu-action{display:flex;align-items:center;gap:10px;width:100%;border:none;background:transparent;cursor:pointer;border-radius:8px;padding:10px 12px;color:#1f2937;text-align:left}
        .menu-action:hover{background:#eff6ff}
        .menu-action .ico{font-size:15px;color:#64748b;line-height:1}
        .menu-action b{display:block;font-size:13px;color:#dc2626}
        .menu-action span{display:block;font-size:11px;color:#64748b;margin-top:2px}
        #open-batch b{display:block;font-size:13px;color:#dc2626}
        #${PANEL_ID}{position:fixed;right:72px;top:48px;width:680px;max-width:calc(100vw - 96px);max-height:calc(100vh - 64px);background:#fff;border:1px solid #d1d5db;border-radius:8px;box-shadow:0 18px 50px rgba(15,23,42,.22);display:none;overflow:hidden}
        #${PANEL_ID}.show{display:block}
        .hd{height:42px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;background:#f8fafc;border-bottom:1px solid #e5e7eb;cursor:move}
        .hd b{font-size:14px}.hd span{font-size:12px;color:#64748b}
        .close{border:none;background:transparent;font-size:18px;line-height:1;cursor:pointer;color:#475569}
        .body{padding:12px;max-height:calc(100vh - 116px);overflow:auto}
        .bar{display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap}
        .bar button,.actions button{height:30px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:0 10px;font-size:12px;cursor:pointer}
        .bar button.primary,.actions button.primary{background:#2563eb;border-color:#2563eb;color:#fff}
        .bar label{font-size:12px;color:#334155;display:flex;gap:4px;align-items:center}
        .list{border:1px solid #e5e7eb;border-radius:6px;max-height:520px;overflow:auto}
        table{width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed}
        th,td{border-bottom:1px solid #eef2f7;padding:5px 8px;text-align:left;vertical-align:top;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        th{background:#f8fafc;color:#475569;position:sticky;top:0}
        th:nth-child(1),td:nth-child(1){width:32px;text-align:center}
        th:nth-child(2),td:nth-child(2){width:48px}
        th:nth-child(4),td:nth-child(4){width:116px}
        th:nth-child(5),td:nth-child(5){width:112px}
        td.subject{max-width:none;word-break:normal}
        .detail-link{color:inherit;text-decoration:none}
        .detail-link:hover{color:#2563eb;text-decoration:underline}
        .empty{padding:26px;text-align:center;color:#64748b;font-size:13px}
        .approval{position:relative;margin-top:10px}
        .approval-line{display:flex;align-items:center;gap:8px}
        textarea{flex:1;box-sizing:border-box;height:34px;min-height:34px;border:1px solid #cbd5e1;border-radius:6px;padding:7px 8px;font-size:13px;resize:none}
        .phrase-panel{position:absolute;right:72px;bottom:42px;width:360px;max-width:calc(100% - 84px);background:#fff;border:1px solid #cbd5e1;border-radius:8px;box-shadow:0 10px 28px rgba(15,23,42,.18);padding:8px;display:none;z-index:1}
        .phrase-panel.show{display:block}
        .phrase-title{font-weight:700;font-size:13px;margin-bottom:6px}
        .phrase-list{max-height:88px;overflow:auto;border-top:1px solid #eef2f7;padding-top:4px}
        .phrase-item{display:block;width:100%;border:none;background:#fff;text-align:left;padding:2px 4px;font-size:12px;line-height:1.45;cursor:pointer;color:#111827}
        .phrase-item:hover{background:#eff6ff;color:#2563eb}
        .approval button:not(.phrase-item),.custom button{height:32px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:0 10px;font-size:12px;cursor:pointer;white-space:nowrap}
        .approval button.primary{background:#2563eb;border-color:#2563eb;color:#fff}
        .custom{display:flex;gap:6px;margin-top:6px}
        .custom input{flex:1;height:30px;border:1px solid #cbd5e1;border-radius:6px;padding:0 8px;font-size:12px}
        .pager{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin:8px 0 10px;color:#64748b;font-size:12px}
        .pager button{height:28px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:0 9px;font-size:12px;cursor:pointer}
        .pager select{height:28px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;padding:0 6px;font-size:12px}
        .pager button:disabled{opacity:.45;cursor:not-allowed}
        .actions{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:6px}
        .msg{font-size:12px;color:#dc2626}
      </style>
      <div id="menu">
        <button class="menu-action" id="open-batch" title="批量处理周计划、工时单、项目周报、绩效考核、前置评估、客开作业单">
          <span class="ico">▦</span>
          <span><b>批量处理</b><span>周计划、工时单、项目周报、绩效考核、前置评估、客开作业单</span></span>
        </button>
        <button class="menu-action" id="open-work-hours" title="查看本人最近30天工时、签卡情况">
          <span class="ico">▦</span>
          <span><b>工时签卡</b><span>查看本人最近30天工时、签卡情况</span></span>
        </button>
        <button class="menu-action" id="open-request" title="提交客开提效需求">
          <span class="ico">＋</span>
          <span><b>提需求</b><span>描述需求、联系人和在线文档</span></span>
        </button>
      </div>
      <button id="ball" title="ZJAI" aria-label="ZJAI"><img id="logo" alt=""></button>
      <section id="${PANEL_ID}" aria-label="待办批量处理">
        <div class="hd" id="drag"><div><b>待办批量处理</b> <span id="count">0 条</span></div><button class="close" id="close" title="关闭">x</button></div>
        <div class="body">
          <div class="bar">
            <button id="refresh" class="primary">刷新待办</button>
            <label><input type="checkbox" data-type="周计划" checked>周计划</label>
            <label><input type="checkbox" data-type="工时单" checked>工时单</label>
            <label><input type="checkbox" data-type="项目周报" checked>项目周报</label>
            <label><input type="checkbox" data-type="绩效考核" checked>绩效考核</label>
            <label><input type="checkbox" data-type="前置评估" checked>前置评估</label>
            <label><input type="checkbox" data-type="客开作业单" checked>客开作业单</label>
          </div>
          <div class="list" id="list"><div class="empty">点击“刷新待办”读取当前用户待办</div></div>
          <div class="pager" id="pager"></div>
          <div class="approval">
            <div class="phrase-panel" id="phrase-panel"><div class="phrase-title">常用语</div><div class="phrase-list" id="phrase-list"></div><div class="custom" id="custom-box"><input id="custom-text" placeholder="新增或修改常用语"><button id="add-phrase">新增/编辑</button><button id="delete-phrase">删除当前意见</button></div></div>
            <div class="approval-line"><textarea id="opinion" placeholder="请输入审批意见，不能为空"></textarea><button id="phrase-toggle">常用语</button><button id="start" class="primary">开始批量处理</button></div>
            <div class="actions"><span class="msg" id="msg"></span></div>
          </div>
        </div>
      </section>
    `;
    document.documentElement.appendChild(host);
    const logo = shadow.getElementById('logo');
    try {
      logo.src = chrome.runtime.getURL('icons/fab-84.png');
      logo.draggable = false;
    } catch (_) {}
    bindPanel(host, shadow);
    return host;
  }

  async function bindPanel(host, shadow) {
    const panel = shadow.getElementById(PANEL_ID);
    const ball = shadow.getElementById('ball');
    const menu = shadow.getElementById('menu');
    const openBatch = shadow.getElementById('open-batch');
    const openWorkHours = shadow.getElementById('open-work-hours');
    const openRequest = shadow.getElementById('open-request');
    const list = shadow.getElementById('list');
    const count = shadow.getElementById('count');
    const msg = shadow.getElementById('msg');
    const opinion = shadow.getElementById('opinion');
    const pager = shadow.getElementById('pager');
    const phrasePanel = shadow.getElementById('phrase-panel');
    const phraseList = shadow.getElementById('phrase-list');
    const customBox = shadow.getElementById('custom-box');
    let items = [];
    let phraseSource = DEFAULT_PHRASES.slice();
    let pageIndex = 0;
    let pageSize = DEFAULT_PAGE_SIZE;
    let selectedIds = new Set();

    const setMsg = (text) => { msg.textContent = text || ''; };
    const selectedTypes = () => Array.from(shadow.querySelectorAll('input[data-type]:checked')).map((el) => el.dataset.type);
    const visibleItems = () => {
      const types = selectedTypes();
      return items.filter((item) => types.includes(item.type));
    };
    const syncSelectedWithTypes = () => {
      const types = selectedTypes();
      items.forEach((item) => {
        if (!types.includes(item.type)) selectedIds.delete(item.affairId);
      });
    };
    const closePanel = () => {
      panel.classList.remove('show');
      setMsg('');
    };

    const renderList = () => {
      const allRows = visibleItems();
      const pageCount = Math.max(1, Math.ceil(allRows.length / pageSize));
      if (pageIndex >= pageCount) pageIndex = pageCount - 1;
      const rows = allRows.slice(pageIndex * pageSize, pageIndex * pageSize + pageSize);
      const selectedCount = allRows.filter((item) => selectedIds.has(item.affairId)).length;
      count.textContent = allRows.length + ' 条，已选 ' + selectedCount + ' 条';
      if (!allRows.length) {
        list.style.height = '';
        list.innerHTML = '<div class="empty">未读取到符合条件的周计划、工时单待办</div>';
        pager.innerHTML = '';
        return;
      }
      list.style.height = listHeight();
      list.innerHTML = '<table><thead><tr><th><input id="all-box" type="checkbox"></th><th>类型</th><th>标题</th><th>时间</th><th>状态</th></tr></thead><tbody>' +
        rows.map((item) => '<tr><td><input class="row-box" type="checkbox" data-id="' + escapeHtml(item.affairId) + '"></td><td>' + escapeHtml(item.type) + '</td><td class="subject" title="' + escapeHtml(item.subject) + '"><a class="detail-link" href="' + buildDetailUrl(item.affairId) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(item.subject) + '</a></td><td title="' + escapeHtml(item.time || '-') + '">' + escapeHtml(item.time || '-') + '</td><td data-status="' + escapeHtml(item.affairId) + '" title="' + escapeHtml(item.status || '待处理') + '">' + escapeHtml(item.status || '待处理') + '</td></tr>').join('') +
        '</tbody></table>';
      const allBox = shadow.getElementById('all-box');
      if (allBox) {
        const pageSelectedCount = rows.filter((item) => selectedIds.has(item.affairId)).length;
        allBox.checked = pageSelectedCount === rows.length;
        allBox.indeterminate = pageSelectedCount > 0 && pageSelectedCount < rows.length;
        allBox.addEventListener('change', () => setPageSelected(rows, allBox.checked));
      }
      shadow.querySelectorAll('.row-box').forEach((box) => {
        box.checked = selectedIds.has(box.dataset.id);
        box.addEventListener('change', () => {
          if (box.checked) selectedIds.add(box.dataset.id);
          else selectedIds.delete(box.dataset.id);
          renderList();
        });
      });
      renderPager(allRows.length, pageCount);
    };

    function listHeight() {
      return 10 * 29 + 31 + 'px';
    }

    const renderPhrases = async () => {
      phraseSource = await chromeGet(STORAGE_PHRASES, DEFAULT_PHRASES);
      if (!Array.isArray(phraseSource) || !phraseSource.length) phraseSource = DEFAULT_PHRASES.slice();
      phraseList.innerHTML = phraseSource.map((text, index) => '<button class="phrase-item" data-index="' + index + '">' + (index + 1) + '：' + escapeHtml(text) + '</button>').join('');
      phraseList.querySelectorAll('.phrase-item').forEach((button) => {
        button.addEventListener('click', () => {
          opinion.value = phraseSource[Number(button.dataset.index)] || '';
          shadow.getElementById('custom-text').value = opinion.value;
          phrasePanel.classList.remove('show');
          setMsg('');
        });
      });
    };

    const setPageSelected = (rows, checked) => {
      rows.forEach((item) => {
        if (checked) selectedIds.add(item.affairId);
        else selectedIds.delete(item.affairId);
      });
      renderList();
    };

    const renderPager = (total, pageCount) => {
      pager.innerHTML = '<span>每页</span><select id="page-size">' + PAGE_SIZE_OPTIONS.map((size) => '<option value="' + size + '"' + (size === pageSize ? ' selected' : '') + '>' + size + '</option>').join('') + '</select><button id="prev-page"' + (pageIndex <= 0 ? ' disabled' : '') + '>上一页</button><span>第 ' + (pageIndex + 1) + ' / ' + pageCount + ' 页，共 ' + total + ' 条</span><button id="next-page"' + (pageIndex >= pageCount - 1 ? ' disabled' : '') + '>下一页</button>';
      const sizeSelect = shadow.getElementById('page-size');
      const prev = shadow.getElementById('prev-page');
      const next = shadow.getElementById('next-page');
      if (sizeSelect) sizeSelect.addEventListener('change', async () => {
        const value = Number(sizeSelect.value);
        pageSize = PAGE_SIZE_OPTIONS.includes(value) ? value : DEFAULT_PAGE_SIZE;
        pageIndex = 0;
        await chromeSet({ [STORAGE_PAGE_SIZE]: pageSize });
        renderList();
      });
      if (prev) prev.addEventListener('click', () => { pageIndex = Math.max(0, pageIndex - 1); renderList(); });
      if (next) next.addEventListener('click', () => { pageIndex = Math.min(pageCount - 1, pageIndex + 1); renderList(); });
    };

    bindBallDrag(host, ball, menu);
    document.addEventListener('pointerdown', (event) => {
      if (!menu.classList.contains('show')) return;
      const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
      if (path.includes(ball) || path.includes(menu)) return;
      menu.classList.remove('show');
    });
    openBatch.addEventListener('click', async () => {
      menu.classList.remove('show');
      panel.classList.toggle('show');
      if (panel.classList.contains('show')) {
        await loadPageSize();
        renderPhrases();
        refreshItems();
      }
    });
    openWorkHours.addEventListener('click', () => {
      menu.classList.remove('show');
      document.dispatchEvent(new CustomEvent('seeyon-helper:work-hours-open'));
    });
    openRequest.addEventListener('click', () => {
      menu.classList.remove('show');
      openRequirementPage();
    });
    shadow.getElementById('close').addEventListener('pointerdown', (event) => {
      event.stopPropagation();
      closePanel();
    });
    shadow.getElementById('close').addEventListener('click', closePanel);
    shadow.getElementById('refresh').addEventListener('click', refreshItems);
    shadow.querySelectorAll('input[data-type]').forEach((el) => el.addEventListener('change', () => {
      syncSelectedWithTypes();
      pageIndex = 0;
      renderList();
    }));
    shadow.getElementById('phrase-toggle').addEventListener('click', async () => {
      await renderPhrases();
      phrasePanel.classList.toggle('show');
      shadow.getElementById('custom-text').value = opinion.value || '';
    });
    shadow.getElementById('add-phrase').addEventListener('click', async () => {
      const text = normalizeText(shadow.getElementById('custom-text').value || opinion.value);
      if (!text) return setMsg('常用语不能为空');
      phraseSource = phraseSource.filter((item) => item !== text).concat(text);
      await chromeSet({ [STORAGE_PHRASES]: phraseSource });
      await renderPhrases();
      opinion.value = text;
      setMsg('');
    });
    shadow.getElementById('delete-phrase').addEventListener('click', async () => {
      const text = normalizeText(opinion.value || shadow.getElementById('custom-text').value);
      if (!text) return setMsg('请选择要删除的常用语');
      phraseSource = phraseSource.filter((item) => item !== text);
      await chromeSet({ [STORAGE_PHRASES]: phraseSource });
      await renderPhrases();
      opinion.value = '';
      setMsg('');
    });
    shadow.getElementById('start').addEventListener('click', startBatch);
    bindDrag(panel, shadow.getElementById('drag'));
    setInterval(syncRunStatus, 1500);

    async function loadPageSize() {
      const saved = Number(await chromeGet(STORAGE_PAGE_SIZE, pageSize));
      pageSize = PAGE_SIZE_OPTIONS.includes(saved) ? saved : DEFAULT_PAGE_SIZE;
    }

    async function refreshItems() {
      setMsg('正在读取待办...');
      try {
        const raw = await send('batchApprovalGetPending');
        items = filterApprovalItems(raw);
        selectedIds = new Set();
        const run = await chromeGet(STORAGE_RUN, null);
        if (!run || !run.active) await chromeSet({ [STORAGE_RUN]: null });
        pageIndex = 0;
        renderList();
        setMsg('');
      } catch (error) {
        items = [];
        renderList();
        setMsg(error.message || '读取待办失败');
      }
    }

    async function startBatch() {
      const text = normalizeText(opinion.value);
      if (!text) return setMsg('审批意见不能为空');
      const selected = visibleItems().filter((item) => selectedIds.has(item.affairId));
      if (!selected.length) return setMsg('请先选择待办');
      selected.forEach((item, index) => { item.status = index === 0 ? '处理中' : '排队中'; });
      renderList();
      await chromeSet({ [STORAGE_RUN]: { active: true, opinion: text, queue: selected, index: 0, updatedAt: Date.now() } });
      startSilentRunner(selected[0].affairId);
      setMsg('已启动静默批量处理，列表状态会实时更新');
    }

    async function syncRunStatus() {
      if (!panel.classList.contains('show') || !items.length) return;
      const run = await chromeGet(STORAGE_RUN, null);
      if (!run || !Array.isArray(run.queue)) return;
      if (run.active && Date.now() - Number(run.updatedAt || 0) > RUN_TIMEOUT_MS) {
        run.active = false;
        run.updatedAt = Date.now();
        run.queue.forEach((runItem) => {
          const oldReviewStatus = '已触发提交，' + '待复核';
          if (/^(处理中|排队中|已提交)$/.test(runItem.status || '') || runItem.status === oldReviewStatus) runItem.status = '处理超时，仍在待办';
        });
        await chromeSet({ [STORAGE_RUN]: run });
        const frame = document.getElementById(RUNNER_ID);
        if (frame) frame.remove();
        setMsg('静默处理超时，已停止，请刷新待办后重试');
      } else {
        resumeProcessingItem(run);
      }
      let changed = false;
      run.queue.forEach((runItem) => {
        const item = items.find((candidate) => candidate.affairId === runItem.affairId);
        const oldClickedStatus = '已' + '点击提交';
        const oldReviewStatus = '已触发提交，' + '待复核';
        const status = runItem.status === oldClickedStatus ? '仍在待办' : (runItem.status === oldReviewStatus ? '已提交' : runItem.status);
        if (item && status && item.status !== status) {
          item.status = status;
          changed = true;
        }
      });
      if (changed) renderList();
    }

    function resumeProcessingItem(run) {
      if (!run.active || Date.now() - Number(run.updatedAt || 0) < RUN_HANDOFF_DELAY_MS) return;
      const current = run.queue.find((runItem) => runItem.status === '处理中');
      if (!current) return;
      const frame = document.getElementById(RUNNER_ID);
      const targetUrl = buildDetailUrl(current.affairId);
      if (frame && frame.src === targetUrl) return;
      startSilentRunner(current.affairId);
    }
  }

  function startSilentRunner(affairId) {
    let frame = document.getElementById(RUNNER_ID);
    if (!frame) {
      frame = document.createElement('iframe');
      frame.id = RUNNER_ID;
      frame.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;border:0;opacity:0;pointer-events:none;';
      document.documentElement.appendChild(frame);
    }
    frame.src = buildDetailUrl(affairId);
  }

  function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }

  function bindDrag(panel, handle) {
    let active = false, sx = 0, sy = 0, left = 0, top = 0;
    handle.addEventListener('pointerdown', (e) => {
      active = true;
      sx = e.clientX;
      sy = e.clientY;
      const rect = panel.getBoundingClientRect();
      left = rect.left;
      top = rect.top;
      panel.style.left = left + 'px';
      panel.style.top = top + 'px';
      panel.style.right = 'auto';
      try { handle.setPointerCapture(e.pointerId); } catch (_) {}
    });
    handle.addEventListener('pointermove', (e) => {
      if (!active) return;
      panel.style.left = Math.max(8, Math.min(window.innerWidth - 80, left + e.clientX - sx)) + 'px';
      panel.style.top = Math.max(8, Math.min(window.innerHeight - 60, top + e.clientY - sy)) + 'px';
    });
    handle.addEventListener('pointerup', () => { active = false; });
    handle.addEventListener('pointercancel', () => { active = false; });
  }

  async function bindBallDrag(host, ball, menu) {
    const size = 42;
    const setPos = (left, top) => {
      host.style.left = Math.max(0, Math.min(window.innerWidth - size, left)) + 'px';
      host.style.top = Math.max(0, Math.min(window.innerHeight - size, top)) + 'px';
      host.style.right = 'auto';
    };
    const saved = await chromeGet(STORAGE_POS, null);
    if (saved && typeof saved.left === 'number' && typeof saved.top === 'number') {
      setPos(saved.left, saved.top);
    } else {
      setPos(window.innerWidth - size - 18, Math.round(window.innerHeight * 0.62));
    }
    window.addEventListener('resize', () => setPos(parseFloat(host.style.left) || 0, parseFloat(host.style.top) || 0));

    let pressing = false, moved = false, sx = 0, sy = 0, offX = 0, offY = 0, pointerId = null;
    ball.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      event.stopPropagation();
      pressing = true;
      moved = false;
      pointerId = event.pointerId;
      sx = event.clientX;
      sy = event.clientY;
      const rect = host.getBoundingClientRect();
      offX = event.clientX - rect.left;
      offY = event.clientY - rect.top;
      document.addEventListener('pointermove', move, true);
      document.addEventListener('pointerup', end, true);
      document.addEventListener('pointercancel', end, true);
    });
    const move = (event) => {
      if (!pressing) return;
      if (pointerId != null && event.pointerId !== pointerId) return;
      event.preventDefault();
      if (!moved && Math.hypot(event.clientX - sx, event.clientY - sy) > 5) moved = true;
      if (moved) {
        menu.classList.remove('show');
        setPos(event.clientX - offX, event.clientY - offY);
      }
    };
    const end = async (event) => {
      if (!pressing) return;
      if (pointerId != null && event.pointerId !== pointerId) return;
      event.preventDefault();
      event.stopPropagation();
      pressing = false;
      document.removeEventListener('pointermove', move, true);
      document.removeEventListener('pointerup', end, true);
      document.removeEventListener('pointercancel', end, true);
      if (moved) {
        await chromeSet({ [STORAGE_POS]: { left: parseFloat(host.style.left) || 0, top: parseFloat(host.style.top) || 0 } });
      } else {
        menu.classList.toggle('show');
      }
      pointerId = null;
    };
  }

  async function maybeAutoSubmitDetail() {
    if (!/collaboration\.do/.test(location.href) || !/method=summary/.test(location.href)) return;
    const affairId = new URLSearchParams(location.search).get('affairId') || '';
    if (!affairId) return;
    const run = await chromeGet(STORAGE_RUN, null);
    if (!run || !run.active || !Array.isArray(run.queue)) return;
    const index = run.queue.findIndex((item) => item.affairId === affairId);
    if (index < 0) return;
    const opinion = normalizeText(run.opinion);
    if (!opinion) return;
    if (detailAutoSubmitStarted) return;
    detailAutoSubmitStarted = true;
    Log.info('详情页自动处理:', affairId);
    await dismissRecoveryPrompt();
    const filled = await waitAndFillOpinion(opinion);
    const clicked = filled ? clickSubmit() : false;
    run.queue[index].status = filled ? (clicked ? '已提交' : '未找到提交按钮') : '未找到意见框';
    run.index = index + 1;
    run.updatedAt = Date.now();
    if (clicked) setTimeout(clickConfirmButtons, 900);
    const next = run.queue.find((item) => item.status === '排队中');
    if (next) {
      next.status = '处理中';
      await chromeSet({ [STORAGE_RUN]: run });
      setTimeout(() => { location.href = buildDetailUrl(next.affairId); }, 1800);
    } else {
      run.active = false;
      await chromeSet({ [STORAGE_RUN]: run });
      await wait(1800);
      await verifyQueueStatus(run);
    }
  }

  async function verifyQueueStatus(run) {
    try {
      const raw = await send('batchApprovalGetPending');
      const pendingIds = new Set(filterApprovalItems(raw).map((item) => item.affairId));
      run.queue.forEach((item) => {
        if (/^未找到/.test(item.status || '')) return;
        item.status = pendingIds.has(item.affairId) ? '仍在待办' : '已办结';
      });
      run.verifiedAt = Date.now();
      await chromeSet({ [STORAGE_RUN]: run });
    } catch (error) {
      run.queue.forEach((item) => {
        const oldReviewStatus = '已触发提交，' + '待复核';
        if (item.status === '已提交' || item.status === oldReviewStatus) item.status = '回查失败，请刷新待办';
      });
      run.verifyError = error.message || '复核失败';
      await chromeSet({ [STORAGE_RUN]: run });
    }
  }

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function accessibleDocs() {
    const docs = [document];
    try {
      if (window.top && window.top.document && window.top.document !== document) docs.push(window.top.document);
    } catch (_) {}
    return docs;
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  async function dismissRecoveryPrompt() {
    for (let i = 0; i < 20; i++) {
      for (const doc of accessibleDocs()) {
        const text = normalizeText(doc.body && doc.body.innerText);
        if (!/有未保存数据|是否恢复/.test(text)) continue;
        const buttons = Array.from(doc.querySelectorAll('button,input[type="button"],a,span,div'));
        const target = buttons.find((el) => normalizeText(el.innerText || el.textContent || el.value) === '不恢复' && isVisible(el));
        if (target) {
          (target.closest('button,a') || target).click();
          await wait(500);
          return true;
        }
      }
      await wait(250);
    }
    return false;
  }

  async function waitAndFillOpinion(opinion) {
    for (let i = 0; i < 20; i++) {
      const field = document.querySelector('textarea[placeholder*="请输入处理意见"], textarea');
      if (field) {
        field.value = opinion;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        field.dispatchEvent(new Event('blur', { bubbles: true }));
        return true;
      }
      await wait(300);
    }
    return false;
  }

  function clickableText(el) {
    return normalizeText(el && (el.innerText || el.textContent || el.value || el.title));
  }

  function clickSubmit() {
    const nodes = Array.from(document.querySelectorAll('button,input[type="button"],input[type="submit"],a,span,div'));
    const target = nodes.find((el) => clickableText(el) === '提交' && el.offsetParent !== null);
    if (!target) return false;
    const clickable = target.closest('button,a') || target;
    clickable.click();
    return true;
  }

  function clickConfirmButtons() {
    const target = Array.from(document.querySelectorAll('button,input[type="button"],a,span'))
      .find((el) => /^(确定|继续提交)$/.test(clickableText(el)) && el.offsetParent !== null);
    if (!target) return;
    try { (target.closest('button,a') || target).click(); } catch (_) {}
  }

  function bootstrap() {
    ensureHost();
    maybeAutoSubmitDetail();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
  } else {
    bootstrap();
  }
  window.addEventListener('load', bootstrap, { once: true });
})();
