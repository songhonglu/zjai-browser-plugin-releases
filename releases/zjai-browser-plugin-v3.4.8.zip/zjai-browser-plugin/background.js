/**
 * 致远网页辅助工具 - 后台脚本
 * 负责Cookie获取和API请求
 */

// 工时签卡后台日志
const LOGGER = {
    info: (...args) => console.log(`[kk-helper:work-hours][bg][INFO]`, ...args),
    warn: (...args) => console.warn(`[kk-helper:work-hours][bg][WARN]`, ...args),
    error: (...args) => console.error(`[kk-helper:work-hours][bg][ERROR]`, ...args)
};
// 代码合规扫描后台日志（与工时签卡区分，便于按模块排查）
const LOGGER_CS = {
    info: (...args) => console.log(`[kk-helper:code-scan][bg][INFO]`, ...args),
    warn: (...args) => console.warn(`[kk-helper:code-scan][bg][WARN]`, ...args),
    error: (...args) => console.error(`[kk-helper:code-scan][bg][ERROR]`, ...args)
};

// 目标域名
const TARGET_DOMAIN = 'xt.seeyon.com';
const WEEKLY_PLAN_AI_BASE_URL = 'https://apihub.agnes-ai.com/v1';
const WEEKLY_PLAN_AI_API_KEY = 'sk-xuDeOWfchiuzIRCxeqeGHMWwz9nOakFDW1fTnvAVktvg9g8L';
const REQUIREMENT_DINGTALK_WEBHOOK = 'https://oapi.dingtalk.com/robot/send?access_token=23029f38fc14ea7513d3ab8f7a572821baf4f27a0faeac37ae03990c73091ebb';
const REQUIREMENT_DINGTALK_SECRET = 'SEC97d5b1c98d558d9caefebe97ea646045b61e636789b9c771365d6588ddbac6cf';
let weeklyPlanAiModelCache = '';

// API基础URL
const API_BASE_URL = `https://${TARGET_DOMAIN}/seeyon/ajax.do`;

/**
 * 从标题识别签卡类型
 * @param {string} subject - 表单标题
 * @returns {'workHours'|'signIn'|'signOut'|null}
 */
function getSignTypeFromSubject(subject) {
    if (!subject) return null;

    // 顾问公司登记/工时登记
    if (subject.includes('工时登记') || subject.includes('顾问')) {
        return 'workHours';
    }

    // 离场 = 签退
    if (subject.includes('离场')) {
        return 'signOut';
    }

    // 进场 = 签到
    if (subject.includes('进场')) {
        return 'signIn';
    }

    return null;
}

/**
 * 从标题中提取日期
 * @param {string} subject - 表单标题
 * @returns {string|null} YYYY-MM-DD格式日期
 */
function extractDateFromSubject(subject) {
    if (!subject) return null;
    const match = subject.match(/(\d{4}-\d{2}-\d{2})/);
    return match ? match[1] : null;
}

/**
 * 从startDate中提取日期
 * @param {string} startDate - 开始日期字符串
 * @returns {string|null} YYYY-MM-DD格式日期
 */
function extractDateFromStartDate(startDate) {
    if (!startDate) return null;
    return startDate.split(' ')[0];
}

function getItemTimeValue(item) {
    if (!item) return '';
    return item.startDate || item.createDate || item.receiveTime || item.completeTime || item.finishDate || item.updateDate || item.createTime || '';
}

function getItemAffairId(item) {
    if (!item) return '';
    return item.affairId || item.id || item.summaryId || '';
}

function ensureDateBucket(dateMap, date) {
    if (!dateMap[date]) {
        dateMap[date] = { workHours: [], signIn: [], signOut: [] };
    }
    return dateMap[date];
}

function dedupeItems(items) {
    const seen = new Set();
    const result = [];
    (items || []).forEach(item => {
        const key = String(getItemAffairId(item) || '') + '|' + String(item.subject || '');
        if (!key.trim() || seen.has(key)) return;
        seen.add(key);
        result.push(item);
    });
    return result;
}

function normalizeWorkHourPersonName(name) {
    return String(name || '').trim().replace(/^#/, '');
}

const DEPARTMENT_ALIAS_GROUPS = Object.freeze([
    Object.freeze(['浙江军团', '浙江大区', '江浙大区'])
]);

function expandDepartmentAliases(department) {
    const normalizedDepartment = String(department || '').trim();
    if (!normalizedDepartment) return [];
    const matchGroup = DEPARTMENT_ALIAS_GROUPS.find((group) => group.includes(normalizedDepartment));
    return matchGroup ? [...matchGroup] : [normalizedDepartment];
}

function extractWorkHourPersonName(subject) {
    const match = String(subject || '').match(/顾问工时登记-(.+?)-(.+?)-(\d{4}-\d{2}-\d{2})/);
    return match ? normalizeWorkHourPersonName(match[2]) : '';
}

function buildSubjectPrefixCandidates(params) {
    const prefixes = [];
    const push = (value) => {
        const text = String(value || '').trim();
        if (!text || prefixes.includes(text)) return;
        prefixes.push(text);
    };

    push(params && params.subjectPrefix);
    (params && Array.isArray(params.subjectPrefixes) ? params.subjectPrefixes : []).forEach(push);

    const departments = expandDepartmentAliases(params && params.department);
    const personName = normalizeWorkHourPersonName(params && params.personName);
    departments.forEach((department) => {
        if (!department || !personName) return;
        push('顾问工时登记-' + department + '-#' + personName);
        push('顾问工时登记-' + department + '-' + personName);
    });

    return prefixes;
}

/**
 * 获取指定域名的Cookie
 */
async function getCookies() {
    LOGGER.info('开始获取Cookie:', TARGET_DOMAIN);
    try {
        const cookies = await chrome.cookies.getAll({ domain: TARGET_DOMAIN });
        LOGGER.info('获取到Cookie数量:', cookies.length);

        if (cookies.length === 0) {
            LOGGER.warn('未找到任何Cookie，请确保已登录目标网站');
            return null;
        }

        // 构造成Cookie字符串
        const cookieStr = cookies.map(c => `${c.name}=${c.value}`).join('; ');
        LOGGER.info('Cookie字符串长度:', cookieStr.length);
        return cookieStr;
    } catch (error) {
        LOGGER.error('获取Cookie失败:', error);
        return null;
    }
}

/**
 * 发送API请求
 * @param {string} managerMethod - 请求方法名
 * @param {object} filter - 过滤条件
 * @param {number} page - 页码
 * @param {number} size - 每页数量
 */
async function fetchData(managerMethod, filter, page = 1, size = 20) {
    LOGGER.info('开始请求API:', { managerMethod, filter, page, size });
    return fetchColManager(managerMethod, [{ page, size }, { ...filter }]);
}

/**
 * 发送 colManager AJAX 请求，支持自定义 arguments 数组结构
 */
async function fetchColManager(managerMethod, argsArray) {
    LOGGER.info('开始请求colManager:', { managerMethod, argsArray });

    const cookieStr = await getCookies();
    if (!cookieStr) {
        throw new Error('无法获取认证Cookie，请确认已登录系统');
    }

    const argumentsData = JSON.stringify(argsArray);
    const url = `${API_BASE_URL}?method=ajaxAction&managerName=colManager`;

    LOGGER.info('请求URL:', url);
    LOGGER.info('请求参数:', argumentsData);

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': cookieStr,
                'Referer': `https://${TARGET_DOMAIN}/seeyon/main.do`
            },
            body: `managerMethod=${managerMethod}&arguments=${encodeURIComponent(argumentsData)}`
        });

        LOGGER.info('响应状态:', response.status);

        if (!response.ok) {
            throw new Error(`HTTP错误: ${response.status}`);
        }

        const data = await response.json();
        LOGGER.info('请求成功,返回数据条数:', data.data?.length || 0);

        return data;
    } catch (error) {
        LOGGER.error('API请求失败:', error);
        throw error;
    }
}

async function weeklyPlanAiRequest(path, body, method = 'POST') {
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${WEEKLY_PLAN_AI_API_KEY}`
    };
    const response = await fetch(`${WEEKLY_PLAN_AI_BASE_URL}${path}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined
    });
    if (!response.ok) {
        const text = await response.text();
        throw new Error(`AI请求失败: ${response.status} ${text.slice(0, 200)}`);
    }
    return response.json();
}

function requirementMarkdown(record) {
    const docLine = record.docUrl ? '\n>在线文档：' + record.docUrl : '\n>在线文档：未填写';
    return [
        '### 新需求提交',
        '>姓名：' + record.name,
        '>联系方式：' + record.contact,
        docLine,
        '>提交时间：' + record.createdAt,
        '',
        record.description
    ].join('\n');
}

function requirementBase64(buffer) {
    return btoa(String.fromCharCode.apply(null, Array.from(new Uint8Array(buffer))));
}

function normalizeRequirementMobile(value) {
    const digits = String(value || '').replace(/\D/g, '');
    return /^1[3-9]\d{9}$/.test(digits) ? digits : '';
}

function getPersonalInfoFrameUrl() {
    return `https://${TARGET_DOMAIN}/seeyon/portal/portalController.do?method=personalInfoFrame&path=/personalAffair.do?method=personalInfo`;
}

function readInputValueAfterLabel(html, label) {
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const match = String(html || '').match(new RegExp(escaped + "[\\s\\S]{0,400}?<input[^>]*value=[\"']([^\"']*)[\"']", 'i'));
    return match && match[1] ? match[1].trim() : '';
}

function emptyCurrentUserProfile() {
    return { userId: '', userCode: '', loginName: '', name: '', department: '', email: '', mobile: '', contact: '', subject: '' };
}

function mergeCurrentUserProfiles() {
    const result = emptyCurrentUserProfile();
    Array.from(arguments).forEach((item) => {
        const profile = item || {};
        result.userId = result.userId || profile.userId || '';
        result.userCode = result.userCode || profile.userCode || '';
        result.loginName = result.loginName || profile.loginName || '';
        result.name = result.name || profile.name || '';
        result.department = result.department || profile.department || '';
        result.email = result.email || profile.email || '';
        result.mobile = result.mobile || profile.mobile || profile.contact || '';
        result.contact = result.contact || profile.contact || profile.mobile || '';
        result.subject = result.subject || profile.subject || '';
    });
    result.mobile = normalizeRequirementMobile(result.mobile);
    result.contact = normalizeRequirementMobile(result.contact || result.mobile);
    return result;
}

async function requirementSignedWebhook() {
    const timestamp = String(Date.now());
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey('raw', encoder.encode(REQUIREMENT_DINGTALK_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const signature = await crypto.subtle.sign('HMAC', key, encoder.encode(timestamp + '\n' + REQUIREMENT_DINGTALK_SECRET));
    const url = new URL(REQUIREMENT_DINGTALK_WEBHOOK);
    url.searchParams.set('timestamp', timestamp);
    url.searchParams.set('sign', requirementBase64(signature));
    return url.href;
}

async function submitRequirementToDingTalk(params) {
    const record = {
        description: String((params && params.description) || '').trim(),
        docUrl: String((params && params.docUrl) || '').trim(),
        name: String((params && params.name) || '').trim(),
        contact: String((params && params.contact) || '').trim(),
        createdAt: String((params && params.createdAt) || '').trim() || new Date().toLocaleString('zh-CN', { hour12: false })
    };
    if (!record.description || !record.name || !record.contact) {
        throw new Error('需求描述、姓名、联系方式不能为空');
    }
    const response = await fetch(await requirementSignedWebhook(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ msgtype: 'markdown', markdown: { title: '新需求提交', text: requirementMarkdown(record) } })
    });
    const result = await response.json();
    if (!response.ok || result.errcode !== 0) {
        throw new Error(result.errmsg || `HTTP ${response.status}`);
    }
    return { submitted: true };
}

async function getWeeklyPlanAiModel() {
    if (weeklyPlanAiModelCache) return weeklyPlanAiModelCache;
    const result = await weeklyPlanAiRequest('/models', null, 'GET');
    const models = Array.isArray(result && result.data) ? result.data : [];
    if (!models.length) throw new Error('AI模型列表为空');
    const ids = models.map(item => item && item.id).filter(Boolean);
    const preferred = ids.find(id => /gpt-4o-mini|gpt-4\.1-mini|gpt-4o|deepseek|qwen|glm|gpt/i.test(id));
    weeklyPlanAiModelCache = preferred || ids[0];
    LOGGER.info('[weekly-plan][AI] 使用模型:', weeklyPlanAiModelCache);
    return weeklyPlanAiModelCache;
}

function buildWeeklyPlanAiPrompt(payload) {
    const rows = Array.isArray(payload && payload.rows) ? payload.rows : [];
    const draftSummary = String(payload && payload.draftSummary || '').trim();
    const feedbackDigest = Array.isArray(payload && payload.feedbackDigest) ? payload.feedbackDigest : [];
    const rowText = rows.map((row, index) => {
        const partnerPart = row.partner ? `；伙伴类型:${row.partner}` : '';
        return `${index + 1}. 日期:${row.date || '-'}；星期:${row.weekday || '-'}；项目名称:${row.project || '-'}；当前阶段:${row.currentStage || '-'}；目标阶段:${row.targetStage || '-'}；项目推进概率:${row.priority || '-'}${partnerPart}；事项内容:${row.content || '-'}；完成反馈:${row.feedback || '-'}`;
    }).join('\n');
    const feedbackText = feedbackDigest.map((item) => (
        `${item.index}. 项目名称:${item.project || '-'}；当前阶段:${item.currentStage || '-'}；目标阶段:${item.targetStage || '-'}；项目推进概率:${item.priority || '-'}；事项内容:${(item.contents || []).join(' / ') || '-'}；完成反馈:${(item.feedbacks || []).join(' / ') || '-'}`
    )).join('\n');
    return [
        '请根据提供的项目跟进数据，输出一份完整“客户项目周工作汇总周报”，严格遵循以下要求。',
        '必须严格基于表格原文、网页初步汇总、以及按项目整理后的事项内容与完成反馈，不编造信息。',
        '完成反馈是判断实际完成情况的第一依据，所有项目进展、风险、建议都要优先参考完成反馈，而不是只看事项内容。',
        '如果完成反馈内容明显无意义、过短或无法支撑判断，也要如实说明“反馈信息有限”，不要自行脑补。',
        '特别注意：如果完成反馈写法是“1.xxx；2.xxx；3.xxx”或“1.xxx\\n2.xxx\\n3.xxx”这类编号列表，必须将其视为多条有效反馈逐条理解，不能因为开头是“1.”就误判为信息不足。',
        '如果完成反馈中已经明确写了“完成”“已上线”“已闭环”“持续推进”“待联调”“待确认”等状态词，必须把这些状态体现在汇总结论中。',
        '输出必须结构化、可扫读、适合领导查看，严禁输出一整段连续大段文字。',
        '请严格按以下结构输出：',
        '📊 客户项目周工作汇总周报：',
        '一、基础信息梳理',
        '1. 统计本周所有记录日期覆盖范围；',
        '2. 归纳对应项目名称、客户主体、项目阶段（当前阶段 / 目标阶段）、项目推进概率；',
        '',
        '二、本周开展工作',
        '按客户项目逐条整理事项内容，清晰区分需求调研、上线支持、问题排查、新需求沟通、系统数据同步对接等工作类型。',
        '',
        '三、各项目完成进度',
        '基于完成反馈，标注各事项完成百分比或完成状态，明确已闭环 / 持续推进 / 信息有限。',
        '',
        '四、项目阶段进度汇总',
        '按四大阶段分类统计本周项目数量：项目启动 0%、蓝图确认 20%、上线阶段 40%、项目验收 100%，并说明阶段推进变化与未达标项目。',
        '',
        '五、本周整体总结',
        '总结本周整体工作概况、重点攻坚项目与核心难点。',
        '',
        '⚠️ 目前的工作风险：',
        '1. xxx',
        '2. xxx',
        '3. xxx',
        '如果不足3条，只输出实际有依据的条目；每条单独一行。',
        '',
        '📝 下周工作建议：',
        '1. xxx',
        '2. xxx',
        '3. xxx',
        '基于当前未完成事项推导可落地行动；如果不足3条，只输出实际有依据的条目；每条单独一行。',
        '',
        '硬性要求：',
        '1. 不遗漏表格内任何一条项目记录。',
        '2. 每个大标题后必须换行；每个编号条目必须单独成行。',
        '3. 语言正式、商务化，适配对内部门工作汇报。',
        '4. 如果某维度信息不足，要明确写“表格中未体现”或“反馈信息有限”。',
        '5. 输出纯文本，不要Markdown，不要解释你的思考过程。',
        '',
        '网页初步汇总如下：',
        draftSummary || '（暂无）',
        '',
        '按项目整理后的事项内容与完成反馈如下：',
        feedbackText || '（暂无）',
        '',
        '表格原始数据如下：',
        rowText
    ].join('\n');
}

async function weeklyPlanAiSummarize(payload) {
    const model = await getWeeklyPlanAiModel();
    const prompt = buildWeeklyPlanAiPrompt(payload);
    const body = {
        model,
        temperature: 0.3,
        messages: [
            {
                role: 'system',
                content: '你是企业周报写作助手，擅长把结构化项目明细提炼成正式、简洁、可信的周报。'
            },
            {
                role: 'user',
                content: prompt
            }
        ]
    };
    const result = await weeklyPlanAiRequest('/chat/completions', body, 'POST');
    const content = result && result.choices && result.choices[0] && result.choices[0].message && result.choices[0].message.content;
    if (!content) throw new Error('AI未返回内容');
    return String(content).trim();
}

/**
 * 获取顾问工时登记数据
 */
async function getWorkHoursData(page = 1, size = 70) {
    return fetchData('getSentList', {
        state: '2',
        type: '',
        deduplication: false,
        dumpData: 'false',
        aiProcessing: false,
        templeteIds: '',
        subject: '工时登记'
    }, page, size);
}

/**
 * 获取项目作业签卡单数据
 */
async function getSignCardData(page = 1, size = 70) {
    return fetchData('getSentList', {
        state: '2',
        type: '',
        deduplication: false,
        dumpData: 'false',
        aiProcessing: false,
        templeteIds: '',
        subject: '项目作业签卡单'
    }, page, size);
}

async function getOtherDoneWorkHours(subjectPrefix) {
    return fetchColManager('getDoneList', [
        { page: 1 },
        { dumpData: 'false', templeteIds: '', isGroupBy: false, subject: subjectPrefix, isCounter: 'false' }
    ]);
}

async function getOtherPendingWorkHours(subjectPrefix) {
    return fetchColManager('getPendingList', [
        { page: 1 },
        { aiSort: 'false', templeteIds: '', subject: subjectPrefix, isCounter: 'false' }
    ]);
}

async function getOtherDoneSignCards(subjectKeyword) {
    return fetchColManager('getDoneList', [
        { page: 1 },
        { dumpData: 'false', templeteIds: '', isGroupBy: false, subject: subjectKeyword, isCounter: 'false' }
    ]);
}

async function getOtherPendingSignCards(subjectKeyword) {
    return fetchColManager('getPendingList', [
        { page: 1 },
        { aiSort: 'false', templeteIds: '', subject: subjectKeyword, isCounter: 'false' }
    ]);
}

function buildSignCardSubjectCandidates(params) {
    const candidates = [];
    const push = (value) => {
        const text = String(value || '').trim();
        if (!text || candidates.includes(text)) return;
        candidates.push(text);
    };

    const departments = expandDepartmentAliases(params && params.department);
    const personName = normalizeWorkHourPersonName(params && params.personName);
    push(personName);
    if (personName) push('#' + personName);
    departments.forEach((department) => {
        if (!department || !personName) return;
        push(department + '-' + personName);
        push(department + '-#' + personName);
    });

    return candidates;
}

function mergeDateMaps(targetMap, sourceMap) {
    Object.entries(sourceMap || {}).forEach(([date, data]) => {
        const bucket = ensureDateBucket(targetMap, date);
        bucket.workHours.push(...((data && data.workHours) || []));
        bucket.signIn.push(...((data && data.signIn) || []));
        bucket.signOut.push(...((data && data.signOut) || []));
    });
    return targetMap;
}

function aggregateOtherWorkHours(doneResult, pendingResult, targetPersonName) {
    const dateMap = {};
    const doneRows = ((doneResult && doneResult.data) || []).map(item => ({ ...item, _source: 'done' }));
    const pendingRows = ((pendingResult && pendingResult.data) || []).map(item => ({ ...item, _source: 'pending' }));
    const normalizedTargetName = normalizeWorkHourPersonName(targetPersonName);
    const merged = dedupeItems(doneRows.concat(pendingRows)).filter(item => {
        if (!normalizedTargetName) return true;
        return extractWorkHourPersonName(item.subject) === normalizedTargetName;
    });

    merged.sort((a, b) => {
        const ad = extractDateFromSubject(a.subject) || extractDateFromStartDate(getItemTimeValue(a)) || '';
        const bd = extractDateFromSubject(b.subject) || extractDateFromStartDate(getItemTimeValue(b)) || '';
        if (ad !== bd) return ad < bd ? 1 : -1;
        return String(getItemTimeValue(b)).localeCompare(String(getItemTimeValue(a)));
    });

    LOGGER.info('他人工时合并后条数:', merged.length);
    merged.forEach((item, idx) => {
        const subject = item.subject || '';
        const date = extractDateFromSubject(subject) || extractDateFromStartDate(getItemTimeValue(item));
        const affairId = getItemAffairId(item);
        LOGGER.info('他人工时[' + idx + '] 标题:', subject, '| 日期:', date, '| affairId:', affairId);
        if (!date || !affairId) return;
        ensureDateBucket(dateMap, date).workHours.push({
            affairId: affairId,
            subject: subject,
            source: item._source || ''
        });
    });
    return dateMap;
}

function aggregateOtherSignCards(doneResult, pendingResult, targetPersonName) {
    const dateMap = {};
    const doneRows = ((doneResult && doneResult.data) || []).map(item => ({ ...item, _source: 'done' }));
    const pendingRows = ((pendingResult && pendingResult.data) || []).map(item => ({ ...item, _source: 'pending' }));
    const normalizedTargetName = normalizeWorkHourPersonName(targetPersonName);
    const merged = dedupeItems(doneRows.concat(pendingRows)).filter(item => {
        if (!normalizedTargetName) return true;
        const subject = String(item.subject || '');
        return subject.includes(normalizedTargetName) || subject.includes('#' + normalizedTargetName);
    });

    merged.sort((a, b) => {
        const ad = extractDateFromStartDate(getItemTimeValue(a)) || extractDateFromSubject(a.subject) || '';
        const bd = extractDateFromStartDate(getItemTimeValue(b)) || extractDateFromSubject(b.subject) || '';
        if (ad !== bd) return ad < bd ? 1 : -1;
        return String(getItemTimeValue(b)).localeCompare(String(getItemTimeValue(a)));
    });

    LOGGER.info('他人签卡合并后条数:', merged.length);
    merged.forEach((item, idx) => {
        const subject = item.subject || '';
        const date = extractDateFromStartDate(getItemTimeValue(item)) || extractDateFromSubject(subject);
        const affairId = getItemAffairId(item);
        const signType = getSignTypeFromSubject(subject);
        LOGGER.info('他人签卡[' + idx + '] 标题:', subject, '| 日期:', date, '| 类型:', signType, '| affairId:', affairId);
        if (!date || !affairId || !signType) return;
        const bucket = ensureDateBucket(dateMap, date);
        if (signType === 'signIn') {
            bucket.signIn.push({ affairId: affairId, subject: subject, source: item._source || '' });
        } else if (signType === 'signOut') {
            bucket.signOut.push({ affairId: affairId, subject: subject, source: item._source || '' });
        }
    });
    return dateMap;
}

async function getRecentDataForPerson(params) {
    const subjectPrefixes = buildSubjectPrefixCandidates(params);
    if (!subjectPrefixes.length) throw new Error('缺少 subjectPrefix');
    LOGGER.info('=== 开始获取他人工时数据 ===', JSON.stringify(subjectPrefixes));

    const results = await Promise.all(subjectPrefixes.map(async (subjectPrefix) => {
        const doneResult = await getOtherDoneWorkHours(subjectPrefix);
        let pendingResult = { data: [] };
        try {
            pendingResult = await getOtherPendingWorkHours(subjectPrefix);
        } catch (e) {
            LOGGER.warn('获取他人待办工时失败，继续使用已办数据:', subjectPrefix, e.message || e);
        }
        return {
            done: (doneResult && doneResult.data) || [],
            pending: (pendingResult && pendingResult.data) || []
        };
    }));

    const doneResult = { data: results.flatMap(item => item.done) };
    const pendingResult = { data: results.flatMap(item => item.pending) };
    const workHourDateMap = aggregateOtherWorkHours(doneResult, pendingResult, params && params.personName);

    const signCardKeywords = buildSignCardSubjectCandidates(params);
    LOGGER.info('=== 开始获取他人签卡数据 ===', JSON.stringify(signCardKeywords));
    const signCardResults = await Promise.all(signCardKeywords.map(async (subjectKeyword) => {
        const doneSignCardResult = await getOtherDoneSignCards(subjectKeyword);
        let pendingSignCardResult = { data: [] };
        try {
            pendingSignCardResult = await getOtherPendingSignCards(subjectKeyword);
        } catch (e) {
            LOGGER.warn('获取他人待办签卡失败，继续使用已办数据:', subjectKeyword, e.message || e);
        }
        return {
            done: (doneSignCardResult && doneSignCardResult.data) || [],
            pending: (pendingSignCardResult && pendingSignCardResult.data) || []
        };
    }));

    const doneSignCardResult = { data: signCardResults.flatMap(item => item.done) };
    const pendingSignCardResult = { data: signCardResults.flatMap(item => item.pending) };
    const signCardDateMap = aggregateOtherSignCards(doneSignCardResult, pendingSignCardResult, params && params.personName);
    return mergeDateMaps(workHourDateMap, signCardDateMap);
}

/**
 * 获取最近30天的签卡数据聚合
 * 返回格式: { "2026-05-26": { workHours: [{affairId, subject}, ...], signIn: [...], signOut: [...] }, ... }
 */
async function getRecentData() {
    LOGGER.info('=== 开始获取最近30天数据 ===');

    try {
        // 并行获取两类数据（扩大取数范围，避免近期流程较多时今天数据被第一页截断）
        const [workHoursResult, signCardResult] = await Promise.all([
            getWorkHoursData(1, 200),
            getSignCardData(1, 200)
        ]);

        // 初始化日期聚合对象（保留affairId列表）
        const dateMap = {};

        // 处理工时登记数据
        LOGGER.info('--- 处理工时登记数据 ---');
        if (workHoursResult && workHoursResult.data) {
            LOGGER.info('工时登记数据条数:', workHoursResult.data.length);
            workHoursResult.data.forEach(item => {
                const date = extractDateFromSubject(item.subject);
                const affairId = item.affairId;
                LOGGER.info('工时登记 - 标题:', item.subject, '| 提取日期:', date, '| affairId:', affairId);
                if (date && affairId) {
                    if (!dateMap[date]) {
                        dateMap[date] = { workHours: [], signIn: [], signOut: [] };
                    }
                    dateMap[date].workHours.push({
                        affairId: affairId,
                        subject: item.subject
                    });
                }
            });
        } else {
            LOGGER.info('工时登记数据为空');
        }

        // 处理签卡单数据
        LOGGER.info('--- 处理签卡单数据 ---');
        LOGGER.info('signCardResult:', JSON.stringify(signCardResult));
        if (signCardResult && signCardResult.data) {
            LOGGER.info('签卡单数据条数:', signCardResult.data.length);
            signCardResult.data.forEach((item, idx) => {
                LOGGER.info('签卡单[' + idx + '] 完整数据:', JSON.stringify(item));

                const startDateStr = item.startDate || '';
                const subject = item.subject || '';
                const affairId = item.affairId;
                const date = extractDateFromStartDate(startDateStr) || extractDateFromSubject(subject);
                const signType = getSignTypeFromSubject(subject);

                LOGGER.info('  -> 标题:[' + subject + ']');
                LOGGER.info('  -> startDate:[' + startDateStr + ']');
                LOGGER.info('  -> 提取日期:[' + date + ']');
                LOGGER.info('  -> 签卡类型:[' + signType + ']');
                LOGGER.info('  -> affairId:[' + affairId + ']');

                if (date && signType && affairId) {
                    if (!dateMap[date]) {
                        dateMap[date] = { workHours: [], signIn: [], signOut: [] };
                    }
                    if (signType === 'signIn') {
                        dateMap[date].signIn.push({
                            affairId: affairId,
                            subject: subject
                        });
                        LOGGER.info('  -> 标记为签到');
                    } else if (signType === 'signOut') {
                        dateMap[date].signOut.push({
                            affairId: affairId,
                            subject: subject
                        });
                        LOGGER.info('  -> 标记为签退');
                    }
                } else {
                    LOGGER.warn('  -> 无法识别: date=' + date + ', signType=' + signType + ', affairId=' + affairId);
                }
            });
        } else {
            LOGGER.info('签卡单数据为空或结构异常');
            LOGGER.info('signCardResult:', signCardResult);
        }

        LOGGER.info('--- 数据聚合结果 ---');
        LOGGER.info('日期数量:', Object.keys(dateMap).length);
        for (const [date, data] of Object.entries(dateMap)) {
            LOGGER.info(date + ':', JSON.stringify(data));
        }

        return dateMap;
    } catch (error) {
        LOGGER.error('获取最近数据失败:', error);
        throw error;
    }
}

/**
 * 读取当前页面主世界的全局变量（当前登录人员姓名、单据标题）
 * 通过 chrome.scripting 注入到 MAIN world，绕过 content script 隔离世界与页面 CSP 限制。
 * func 必须是纯函数引用（会被序列化），不能闭包外部变量。
 */
function PAGE_GLOBALS_FUNC() {
    const normalizeMobile = (value) => {
        const digits = String(value || '').replace(/\D/g, '');
        return /^1[3-9]\d{9}$/.test(digits) ? digits : '';
    };
    const pickId = (user) => String((user && (user.id || user.memberId || user.userId || user.loginId)) || '');
    const pickDepartment = (user) => String((user && (user.departmentName || user.deptName || user.orgDepartmentName || user.department)) || '');
    const pickEmail = (user) => String((user && (user.email || user.emailAddress || user.mail)) || '');
    let name = '';
    let contact = '';
    let userId = '';
    let department = '';
    let email = '';
    try {
        const cu = window._currentUser || {};
        name = (cu && cu.name != null ? cu.name : '') || window._currentUserName || '';
        userId = pickId(cu);
        department = pickDepartment(cu);
        email = pickEmail(cu);
        contact = normalizeMobile(cu && (cu.telNumber || cu.mobile || cu.mobilePhone || cu.phone || cu.telephone || cu.officePhone));
        if ((!name || !contact || !userId || !department || !email) && window.top && window.top !== window) {
            const tcu = window.top._currentUser || {};
            name = name || (tcu.name != null ? tcu.name : '') || window.top._currentUserName || '';
            userId = userId || pickId(tcu);
            department = department || pickDepartment(tcu);
            email = email || pickEmail(tcu);
            contact = normalizeMobile(tcu && (tcu.telNumber || tcu.mobile || tcu.mobilePhone || tcu.phone || tcu.telephone || tcu.officePhone)) || contact;
        }
    } catch (e) {}
    let subject = '';
    try {
        subject = (typeof window.subject === 'string' ? window.subject : '') || '';
        if (!subject && window.top && window.top !== window && typeof window.top.subject === 'string') {
            subject = window.top.subject;
        }
    } catch (e) {}
    return {
        userId: String(userId || ''),
        name: String(name || ''),
        department: String(department || ''),
        email: String(email || ''),
        mobile: String(contact || ''),
        contact: String(contact || ''),
        subject: String(subject || '')
    };
}

async function PAGE_PERSONAL_INFO_FUNC() {
    const url = '/seeyon/portal/portalController.do?method=personalInfoFrame&path=/personalAffair.do?method=personalInfo';
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const normalizeMobile = (value) => {
        const digits = String(value || '').replace(/\D/g, '');
        return /^1[3-9]\d{9}$/.test(digits) ? digits : '';
    };
    const valueAfterLabel = (doc, label) => {
        const spans = Array.from(doc.querySelectorAll('span'));
        const hit = spans.find((span) => String(span.textContent || '').replace(/[：:]/g, '').trim() === label);
        const row = hit && (hit.closest('tr') || hit.parentElement);
        const field = row && row.querySelector('input[value], textarea, select');
        if (!field) return '';
        if (field.tagName === 'SELECT') {
            const selected = field.selectedOptions && field.selectedOptions[0];
            return selected ? String(selected.textContent || '').trim() : '';
        }
        return String(field.value || '').trim();
    };
    const readFromDoc = (doc) => {
        const tel = doc.querySelector('#telNumber');
        const email = doc.querySelector('#email');
        const mobile = normalizeMobile(tel ? tel.value : valueAfterLabel(doc, '手机号码'));
        return {
            userCode: valueAfterLabel(doc, '人员编号'),
            loginName: valueAfterLabel(doc, '登录名'),
            name: valueAfterLabel(doc, '姓名'),
            department: valueAfterLabel(doc, '所属部门') || valueAfterLabel(doc, '部门') || valueAfterLabel(doc, '单位') || valueAfterLabel(doc, '组织') || valueAfterLabel(doc, '流程发起部门'),
            email: email ? String(email.value || '').trim() : valueAfterLabel(doc, '电子邮件'),
            mobile: mobile,
            contact: mobile
        };
    };
    let ownedFrame = null;
    try {
        let doc = document;
        let frame = doc.querySelector('#content_div');
        if (!frame) {
            ownedFrame = document.createElement('iframe');
            ownedFrame.src = url;
            ownedFrame.style.cssText = 'position:absolute;width:1px;height:1px;left:-9999px;top:-9999px;opacity:0;pointer-events:none;border:0;';
            document.documentElement.appendChild(ownedFrame);
            frame = ownedFrame;
        }
        for (let i = 0; frame && i < 40; i += 1) {
            if (frame.contentDocument) {
                const inner = frame.contentDocument.querySelector('#content_div');
                if (inner && inner.contentDocument && inner.contentDocument.querySelector('#telNumber')) {
                    doc = inner.contentDocument;
                    break;
                }
                if (frame.contentDocument.querySelector('#telNumber')) {
                    doc = frame.contentDocument;
                    break;
                }
            }
            await sleep(250);
        }
        const result = readFromDoc(doc);
        if (ownedFrame && ownedFrame.parentNode) ownedFrame.parentNode.removeChild(ownedFrame);
        return result;
    } catch (error) {
        if (ownedFrame && ownedFrame.parentNode) ownedFrame.parentNode.removeChild(ownedFrame);
        return { userCode: '', loginName: '', name: '', department: '', email: '', mobile: '', contact: '' };
    }
}

/**
 * 通过 fetch personalInfo 页面获取当前登录用户名（兜底方案）
 * 解析返回 HTML 中的 var currentUserName = "xxx"
 */
async function fetchCurrentUserNameFromPersonalInfo() {
    LOGGER.info('尝试通过 personalInfo 获取当前用户名...');
    try {
        const cookieStr = await getCookies();
        if (!cookieStr) {
            LOGGER.warn('personalInfo fallback: 无法获取Cookie');
            return '';
        }
        const response = await fetch(getPersonalInfoFrameUrl(), {
            method: 'GET',
            headers: {
                'Cookie': cookieStr,
                'Referer': `https://${TARGET_DOMAIN}/seeyon/main.do`
            }
        });
        if (!response.ok) {
            LOGGER.warn('personalInfo fallback: HTTP错误', response.status);
            return '';
        }
        const html = await response.text();
        const labelName = readInputValueAfterLabel(html, '姓名');
        if (labelName) return labelName;
        // 解析 var currentUserName = "谢飏"
        const match = html.match(/var\s+currentUserName\s*=\s*"([^"]*)"/);
        if (match && match[1]) {
            LOGGER.info('personalInfo fallback 获取到用户名:', match[1]);
            return match[1];
        }
        // 备用匹配：单引号
        const match2 = html.match(/var\s+currentUserName\s*=\s*'([^']*)'/);
        if (match2 && match2[1]) {
            LOGGER.info('personalInfo fallback 获取到用户名(单引号):', match2[1]);
            return match2[1];
        }
        LOGGER.warn('personalInfo fallback: 未能解析到 currentUserName');
        return '';
    } catch (e) {
        LOGGER.warn('personalInfo fallback 异常:', e.message);
        return '';
    }
}

async function fetchCurrentUserProfileFromPersonalInfo() {
    try {
        const cookieStr = await getCookies();
        if (!cookieStr) return emptyCurrentUserProfile();
        const response = await fetch(getPersonalInfoFrameUrl(), {
            method: 'GET',
            headers: {
                'Cookie': cookieStr,
                'Referer': `https://${TARGET_DOMAIN}/seeyon/main.do`
            }
        });
        const html = await response.text();
        const nameMatch = html.match(/var\s+currentUserName\s*=\s*["']([^"']*)["']/);
        const labelName = readInputValueAfterLabel(html, '姓名');
        const labelUserCode = readInputValueAfterLabel(html, '人员编号');
        const labelLoginName = readInputValueAfterLabel(html, '登录名');
        const labelEmail = readInputValueAfterLabel(html, '电子邮件');
        const labelDepartment = readInputValueAfterLabel(html, '所属部门') || readInputValueAfterLabel(html, '部门') || readInputValueAfterLabel(html, '单位') || readInputValueAfterLabel(html, '组织');
        const labelMobile = readInputValueAfterLabel(html, '手机号码');
        const phoneMatch = html.match(/(?:id|name)=["'](?:telNumber|mobile|mobilePhone|phone|telephone)["'][^>]*value=["']([^"']*)["']/i)
            || html.match(/value=["']([^"']*)["'][^>]*(?:id|name)=["'](?:telNumber|mobile|mobilePhone|phone|telephone)["']/i);
        const mobile = normalizeRequirementMobile(labelMobile || (phoneMatch && phoneMatch[1] ? phoneMatch[1] : ''));
        if (!response.ok) return emptyCurrentUserProfile();
        return {
            userId: '',
            userCode: labelUserCode,
            loginName: labelLoginName,
            name: labelName || (nameMatch && nameMatch[1] ? nameMatch[1] : ''),
            department: labelDepartment,
            email: labelEmail,
            mobile: mobile,
            contact: mobile,
            subject: ''
        };
    } catch (e) {
        LOGGER.warn('personalInfo 用户资料 fallback 异常:', e.message);
        return emptyCurrentUserProfile();
    }
}

async function getPageGlobals(sender) {
    if (!sender.tab || sender.tab.id == null) {
        return { userId: '', name: '', subject: '' };
    }
    if (!String(sender.tab.url || '').startsWith(`https://${TARGET_DOMAIN}/`)) {
        return { userId: '', name: '', subject: '' };
    }
    const frameId = (typeof sender.frameId === 'number') ? sender.frameId : 0;
    try {
        const injections = await chrome.scripting.executeScript({
            target: { tabId: sender.tab.id, frameIds: [frameId] },
            world: 'MAIN',
            func: PAGE_GLOBALS_FUNC
        });
        const result = (injections && injections[0] && injections[0].result) || { userId: '', name: '', subject: '' };
        // 如果 MAIN world 注入获取不到姓名，尝试通过 fetch personalInfo 兜底
        if (!result.name) {
            LOGGER.info('MAIN world 未获取到用户名，尝试 personalInfo fallback');
            const fallbackName = await fetchCurrentUserNameFromPersonalInfo();
            if (fallbackName) {
                result.name = fallbackName;
            }
        }
        return result;
    } catch (e) {
        LOGGER.warn('getPageGlobals 注入失败:', e.message);
        // 注入失败也尝试 fallback
        try {
            const fallbackName = await fetchCurrentUserNameFromPersonalInfo();
            return { userId: '', name: fallbackName, subject: '' };
        } catch (e2) {
            return { userId: '', name: '', subject: '' };
        }
    }
}

async function getPersonalInfoFrameFromTab(tabId) {
    if (tabId == null) return emptyCurrentUserProfile();
    try {
        const injections = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            world: 'MAIN',
            func: PAGE_PERSONAL_INFO_FUNC
        });
        return (injections && injections[0] && injections[0].result) || emptyCurrentUserProfile();
    } catch (e) {
        LOGGER.warn('getPersonalInfoFrameFromTab 读取失败:', e.message);
        return emptyCurrentUserProfile();
    }
}

async function getCurrentUserProfile(sender) {
    const senderResult = await getPageGlobals(sender || {});
    let tabResult = {};
    let tabProfile = {};
    try {
        const tabs = await chrome.tabs.query({ url: `https://${TARGET_DOMAIN}/*` });
        const tab = tabs && tabs[0];
        if (tab && tab.id != null) {
            const injections = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: 'MAIN',
                func: PAGE_GLOBALS_FUNC
            });
            tabResult = (injections && injections[0] && injections[0].result) || {};
            if (!tabResult.contact || !tabResult.email || !tabResult.department) {
                tabProfile = await getPersonalInfoFrameFromTab(tab.id);
            }
        }
    } catch (e) {
        LOGGER.warn('getCurrentUserProfile 从 OA 标签读取失败:', e.message);
    }
    const combined = mergeCurrentUserProfiles(senderResult, tabResult, tabProfile);
    if (!combined.name || !combined.contact || !combined.email) {
        const profile = await fetchCurrentUserProfileFromPersonalInfo();
        return mergeCurrentUserProfiles(combined, profile);
    }
    return combined;
}

async function getRequirementCurrentUser(sender) {
    const profile = await getCurrentUserProfile(sender);
    return { name: profile.name || '', contact: profile.contact || profile.mobile || '' };
}

/**
 * 根据 rightId/moduleId/affairId 抓取单天工时明细
 * 调用 rest/cap4/form/createOrEdit，解析 formson_77937 表的 items
 */
async function getWorkHourDetail(params) {
    const rightId = params && params.rightId;
    const moduleId = params && params.moduleId;
    const affairId = params && params.affairId;
    LOGGER.info('获取工时明细:', { rightId, moduleId, affairId });

    if (!rightId || !moduleId || !affairId) {
        throw new Error('缺少 rightId/moduleId/affairId');
    }

    const cookieStr = await getCookies();
    if (!cookieStr) {
        throw new Error('无法获取认证Cookie，请确认已登录系统');
    }

    const url = `https://${TARGET_DOMAIN}/seeyon/rest/cap4/form/createOrEdit`;
    const payload = {
        v: 'V11_xx',
        hasSignAction: 'false',
        type: 'browse',
        rightId: rightId,
        moduleId: moduleId,
        isSubFlow: 'false',
        moduleType: '1',
        affairId: affairId,
        flowListAppId: '',
        flowListButtonId: '',
        flowBatchDealAffairIds: '',
        operateType: '2',
        forceDb: true,
        cacheRecoveryId: ''
    };

    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=UTF-8',
            'Cookie': cookieStr
        },
        body: JSON.stringify(payload)
    });

    if (!response.ok) {
        throw new Error('createOrEdit HTTP错误: ' + response.status);
    }

    const json = await response.json();
    const tableInfo = json && json.data && json.data.data && json.data.data.tableInfo;
    const formson = (tableInfo && tableInfo.formson) || [];
    const arr = Array.isArray(formson) ? formson : [];
    LOGGER.info('工时明细子表列表:', arr.map(function (n) {
        const items = n && n.pageData && n.pageData.items;
        return (n && n.tableName ? n.tableName : '(无表名)') + ':' + (Array.isArray(items) ? items.length : 0);
    }).join(', ') || '(空)');
    const node = arr.find(function (n) { return n && n.tableName === 'formson_77937'; });
    if (!node) {
        LOGGER.warn('未找到工时明细子表 formson_77937，可能是模板子表名已变化');
    }
    const items = (node && node.pageData && node.pageData.items) || [];
    LOGGER.info('工时明细解析完成, 条数:', items.length);
    if (items.length > 0) {
        const first = items[0] || {};
        LOGGER.info('工时明细首行字段:', Object.keys(first).join(', '));
    }

    return items.map(function (it) {
        return {
            type: (it && it.field0037 && it.field0037.showValue) || '',
            project: (it && it.field0072 && it.field0072.showValue) || (it && it.field0039 && (it.field0039.showValue || it.field0039.value)) || '',
            content: (it && it.field0040 && it.field0040.value) || '',   // 富文本
            hours: (it && it.field0041 && it.field0041.value) || ''
        };
    });
}

async function getBatchApprovalPending() {
    const results = await Promise.all([
        fetchColManager('getPendingList', [
            { page: 1, size: 200 },
            { aiSort: 'false', templeteIds: '', subject: '交付序列周计划', isCounter: 'false' }
        ]),
        fetchColManager('getPendingList', [
            { page: 1, size: 200 },
            { aiSort: 'false', templeteIds: '', subject: '顾问工时登记', isCounter: 'false' }
        ]),
        fetchColManager('getPendingList', [
            { page: 1, size: 200 },
            { aiSort: 'false', templeteIds: '', subject: '工时登记', isCounter: 'false' }
        ]),
        fetchColManager('getPendingList', [
            { page: 1, size: 200 },
            { aiSort: 'false', templeteIds: '', subject: '项目周报', isCounter: 'false' }
        ]),
        fetchColManager('getPendingList', [
            { page: 1, size: 200 },
            { aiSort: 'false', templeteIds: '', subject: '交付月度绩效考核', isCounter: 'false' }
        ]),
        fetchColManager('getPendingList', [
            { page: 1, size: 200 },
            { aiSort: 'false', templeteIds: '', subject: '绩效考核', isCounter: 'false' }
        ]),
        fetchColManager('getPendingList', [
            { page: 1, size: 200 },
            { aiSort: 'false', templeteIds: '', subject: '交付报价前置评估', isCounter: 'false' }
        ]),
        fetchColManager('getPendingList', [
            { page: 1, size: 200 },
            { aiSort: 'false', templeteIds: '', subject: '交付作业申请', isCounter: 'false' }
        ])
    ]);
    const seen = new Set();
    return results.flatMap(function (result) {
        return (result && result.data) || [];
    }).map(function (item) {
        return {
            affairId: getItemAffairId(item),
            id: item && item.id,
            summaryId: item && item.summaryId,
            subject: (item && item.subject) || '',
            receiveTime: item && item.receiveTime,
            startDate: item && item.startDate,
            createDate: item && item.createDate,
            createTime: item && item.createTime,
            updateDate: item && item.updateDate
        };
    }).filter(function (item) {
        const key = String(item.affairId || '') + '|' + String(item.subject || '');
        if (!item.affairId || seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

// [已临时禁用] 百度统计：暂时注释，恢复时需同步放开 manifest.json 的 host_permissions
// 注入百度统计脚本到主页面（绕过CSP限制）
// async function injectBaiduTongji(tabId) {
//     LOGGER.info('开始注入百度统计脚本');
//     try {
//         // 先获取百度统计脚本内容（后台脚本不受页面CSP限制）
//         const tongjiUrl = "https://hm.baidu.com/hm.js?dc7fec7f2cccab9759e98f10b603f48d";
//         const response = await fetch(tongjiUrl);
//         const scriptContent = await response.text();
//
//         // 使用 eval 直接执行脚本内容，绕过CSP限制
//         await chrome.scripting.executeScript({
//             target: { tabId: tabId },
//             world: 'MAIN',
//             func: (code) => {
//                 // 通过 Function 构造函数执行代码，避免 eval 的安全警告
//                 new Function(code)();
//             },
//             args: [scriptContent]
//         });
//
//         LOGGER.info('百度统计脚本注入成功');
//         return { success: true };
//     } catch (error) {
//         LOGGER.error('百度统计注入失败:', error);
//         return { success: false, error: error.message };
//     }
// }

// 监听来自content script的消息
const runtimeOnMessage = globalThis.chrome && chrome.runtime && chrome.runtime.onMessage;
if (runtimeOnMessage && typeof runtimeOnMessage.addListener === 'function') {
runtimeOnMessage.addListener((request, sender, sendResponse) => {
    // 守卫：仅处理本模块消息（带字符串 action 字段）。
    // 客开冲突雷达用 type / replyTo 字段，走 conflict-radar/bg/service-worker.js 的监听器；
    // 此处跳过，避免交叉处理与日志污染（两组监听器字段不重叠，互不干扰）。
    if (!request || typeof request.action !== 'string') return false;
    LOGGER.info('收到消息:', request.action);

    const handleResponse = async () => {
        try {
            // 先尝试代码检测模块的消息处理
            const codeScanActions = ['getCodeScanResult', 'startCodeScan', 'getCodeScanProgress'];
            if (codeScanActions.includes(request.action)) {
                const handled = await handleCodeScanMessage(request, sender, sendResponse);
                if (handled) return;
            }

            let result;
            switch (request.action) {
                case 'getWorkHours':
                    result = await getWorkHoursData(1, 70);
                    break;
                case 'getSignCard':
                    result = await getSignCardData(1, 70);
                    break;
                case 'getRecentData':
                    result = await getRecentData();
                    break;
                case 'getRecentDataForPerson':
                    result = await getRecentDataForPerson(request.params || {});
                    break;
                case 'getPageGlobals':
                    result = await getPageGlobals(sender);
                    break;
                case 'getWorkHourDetail':
                    result = await getWorkHourDetail(request.params || {});
                    break;
                case 'weeklyPlanAiSummarize':
                    result = await weeklyPlanAiSummarize(request.params || {});
                    break;
                case 'projectHandoverGetTemplate':
                    result = await getProjectHandoverTemplate();
                    break;
                case 'batchApprovalGetPending':
                    result = await getBatchApprovalPending();
                    break;
                case 'submitRequirementToDingTalk':
                    result = await submitRequirementToDingTalk(request.params || {});
                    break;
                case 'getRequirementCurrentUser':
                    result = await getRequirementCurrentUser(sender);
                    break;
                case 'getCurrentUserProfile':
                    result = await getCurrentUserProfile(sender);
                    break;
                // [已临时禁用] case 'injectBaiduTongji':
                //     if (sender.tab && sender.tab.id) {
                //         result = await injectBaiduTongji(sender.tab.id);
                //     } else {
                //         throw new Error('无法获取当前标签页ID');
                //     }
                //     break;
                default:
                    throw new Error('未知操作: ' + request.action);
            }
            sendResponse({ success: true, data: result });
        } catch (error) {
            LOGGER.error('处理请求失败:', error);
            sendResponse({ success: false, error: error.message });
        }
    };

    handleResponse();
    return true; // 保持消息通道开启以支持异步响应
});
} else {
    LOGGER.warn('chrome.runtime.onMessage 不可用，后台消息监听未注册');
}

console.log('[kk-helper:bg] service worker 已加载（工时签卡 + 代码合规扫描）');


// =====================================================================
// ====== 代码检测模块 (CTP-Studio Code Scan) ==========================
// ====== 功能：遍历项目、请求代码数据、汇总结果 ========================
// ====== 作者：代码检测功能独立模块，与工时签卡助手完全隔离 ===========
// =====================================================================

const CODE_SCAN_STORAGE_KEY = 'codeScanState';
const CODE_SCAN_RESULT_TTL = 24 * 60 * 60 * 1000; // 24小时有效期
const CODE_SCAN_STALE_TIMEOUT = 3 * 60 * 60 * 1000;

/**
 * 获取 studio.kk.seeyon.com 域名的 Cookie
 */
async function getCodeStudioCookies() {
    LOGGER_CS.info('[kk-helper:code-scan] 开始获取 studio Cookie');
    try {
        const cookies = await chrome.cookies.getAll({ domain: 'studio.kk.seeyon.com' });
        if (cookies.length === 0) {
            LOGGER_CS.warn('[kk-helper:code-scan] 未找到 studio Cookie，请确保已登录 studio 系统');
            return null;
        }
        const cookieStr = cookies.map(c => `${c.name}=${c.value}`).join('; ');
        LOGGER_CS.info('[kk-helper:code-scan] 获取到 Cookie 数量:', cookies.length);
        return cookieStr;
    } catch (error) {
        LOGGER_CS.error('[kk-helper:code-scan] 获取 Cookie 失败:', error);
        return null;
    }
}

/**
 * 向 studio 系统发送 POST 请求
 */
async function codeStudioPost(url, bodyParams, cookieStr) {
    const formBody = Object.entries(bodyParams)
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
        .join('&');

    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': cookieStr,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.97 Safari/537.36'
        },
        body: formBody
    });

    if (!response.ok) {
        throw new Error(`HTTP 错误: ${response.status} ${response.statusText}`);
    }
    return response.json();
}

/**
 * 获取所有项目列表（分页），并过滤 area == "上海军团直客中心"
 */
async function codeScanGetAllProjects(cookieStr, onProgress) {
    const url = 'http://studio.kk.seeyon.com/system/customizationInfo/list';
    const pageSize = 50;
    let allProjects = [];
    let pageNum = 1;
    let totalPages = 1;

    while (pageNum <= totalPages) {
        const data = await codeStudioPost(url, {
            pageSize: pageSize,
            pageNum: pageNum,
            orderByColumn: 'updateTime',
            isAsc: 'desc'
        }, cookieStr);

        if (data.code !== 0) {
            throw new Error(`获取项目列表失败: ${JSON.stringify(data)}`);
        }

        const total = data.total || 0;
        totalPages = Math.ceil(total / pageSize);
        const rows = data.rows || [];
        allProjects = allProjects.concat(rows);

        if (onProgress) {
            await onProgress({
                phase: 'projects',
                current: pageNum,
                total: totalPages,
                percent: totalPages > 0 ? Math.round((pageNum / totalPages) * 100) : 0,
                projectCount: allProjects.length
            });
        }

        LOGGER_CS.info(`[kk-helper:code-scan] 获取项目列表第 ${pageNum}/${totalPages} 页，累计 ${allProjects.length} 个项目`);
        pageNum++;
    }

    // 过滤 "上海军团直客中心"
    const filtered = allProjects.filter(p => (p.area || '') === '上海军团直客中心');
    LOGGER_CS.info(`[kk-helper:code-scan] 过滤后保留 ${filtered.length} 个上海军团直客中心项目`);
    return filtered;
}

/**
 * 查询单个项目的代码源码记录（分页）
 */
async function codeScanGetSourceRows(dogNum, buildId, cookieStr) {
    const url = 'http://studio.kk.seeyon.com/system/sourceApply/scanningSource';
    const pageSize = 50;
    let allRows = [];
    let pageNum = 1;
    let totalPages = 1;

    while (pageNum <= totalPages) {
        const data = await codeStudioPost(url, {
            dogNum: dogNum,
            buildId: buildId,
            ck: 1,
            pageSize: pageSize,
            pageNum: pageNum
        }, cookieStr);

        if (data.code !== 0) {
            LOGGER_CS.warn(`[kk-helper:code-scan] 查询 ${dogNum} 第 ${pageNum} 页源码失败: ${JSON.stringify(data)}`);
            break;
        }

        const total = data.total || 0;
        totalPages = Math.ceil(total / pageSize);
        const rows = data.rows || [];
        allRows = allRows.concat(rows);
        pageNum++;
    }

    return allRows;
}

/**
 * 获取当前登录用户的姓名
 * 通过 GET http://studio.kk.seeyon.com/system/user/profile 解析 HTML 中 input#userName 的值
 */
async function codeScanGetCurrentUserName(cookieStr) {
    LOGGER_CS.info('[kk-helper:code-scan] 获取当前用户姓名');
    try {
        const response = await fetch('http://studio.kk.seeyon.com/system/user/profile', {
            method: 'GET',
            headers: {
                'Cookie': cookieStr,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.97 Safari/537.36'
            }
        });

        if (!response.ok) {
            LOGGER_CS.warn('[kk-helper:code-scan] 获取用户信息失败:', response.status);
            return null;
        }

        const html = await response.text();
        // 解析 HTML 中 id="userName" 的 input 的 value
        const match = html.match(/id="userName"[^>]*value="([^"]*)"/);
        if (match && match[1]) {
            LOGGER_CS.info('[kk-helper:code-scan] 当前用户姓名:', match[1]);
            return match[1];
        }

        // 备用匹配：value 在 id 前面的情况
        const match2 = html.match(/value="([^"]*)"[^>]*id="userName"/);
        if (match2 && match2[1]) {
            LOGGER_CS.info('[kk-helper:code-scan] 当前用户姓名(备用匹配):', match2[1]);
            return match2[1];
        }

        LOGGER_CS.warn('[kk-helper:code-scan] 未能解析用户姓名');
        return null;
    } catch (error) {
        LOGGER_CS.error('[kk-helper:code-scan] 获取用户姓名失败:', error.message);
        return null;
    }
}

/**
 * 保存代码检测状态到 storage
 */
async function codeScanSaveState(stateObj) {
    return new Promise((resolve) => {
        chrome.storage.local.set({ [CODE_SCAN_STORAGE_KEY]: stateObj }, resolve);
    });
}

/**
 * 读取代码检测状态
 */
async function codeScanLoadState() {
    return new Promise((resolve) => {
        chrome.storage.local.get([CODE_SCAN_STORAGE_KEY], (result) => {
            resolve(result[CODE_SCAN_STORAGE_KEY] || null);
        });
    });
}

async function codeScanGetActiveState() {
    const state = await codeScanLoadState();
    if (!state || state.status !== 'scanning') {
        return state;
    }

    const startedAt = Number(state.scanStartedAt);
    const isStale = !Number.isFinite(startedAt) || Date.now() - startedAt > CODE_SCAN_STALE_TIMEOUT;
    if (!isStale) {
        return state;
    }

    const errorState = {
        ...state,
        status: 'error',
        progress: {
            ...(state.progress || {}),
            phase: 'error',
            currentProject: '上次检测已失效，请重新检测'
        },
        timestamp: null,
        error: '上次代码检测未在规定时间内完成，已自动释放，请重新检测'
    };
    await codeScanSaveState(errorState);
    LOGGER_CS.warn('[kk-helper:code-scan] 检测状态已失效，允许重新启动');
    return errorState;
}

/**
 * 主扫描流程：遍历项目 -> 查询代码 -> 汇总结果
 */
async function codeScanExecute() {
    LOGGER_CS.info('[kk-helper:code-scan] ══════════════════════════════════════');
    LOGGER_CS.info('[kk-helper:code-scan] ====== 开始代码检测 ======');
    LOGGER_CS.info('[kk-helper:code-scan] ══════════════════════════════════════');
    const scanStartTime = Date.now();

    // 初始化状态
    await codeScanSaveState({
        status: 'scanning',
        progress: { phase: 'init', current: 0, total: 0, percent: 0, currentProject: '正在初始化...' },
        result: null,
        timestamp: null,
        scanStartedAt: scanStartTime,
        error: null
    });

    try {
        // 1. 获取 Cookie
        const cookieStr = await getCodeStudioCookies();
        if (!cookieStr) {
            throw new Error('无法获取 studio Cookie，请确认已登录 CTP-Studio 系统');
        }

        // 1.5 获取当前用户姓名
        const currentUserName = await codeScanGetCurrentUserName(cookieStr);
        LOGGER_CS.info('[kk-helper:code-scan] 当前登录用户:', currentUserName || '未知');

        // 2. 获取项目列表
    await codeScanSaveState({
        status: 'scanning',
        progress: { phase: 'projects', current: 0, total: 0, percent: 0, currentProject: '正在获取项目列表...' },
        result: null,
        timestamp: null,
        scanStartedAt: scanStartTime,
        error: null
    });

    const projects = await codeScanGetAllProjects(cookieStr, async (progress) => {
            const currentState = await codeScanGetActiveState();
            if (currentState && currentState.status === 'scanning') {
                currentState.progress = {
                    ...currentState.progress,
                    ...progress,
                    currentProject: `正在获取项目列表 (${progress.projectCount} 个已找到)`
                };
                currentState.scanStartedAt = currentState.scanStartedAt || scanStartTime;
                await codeScanSaveState(currentState);
            }
        });

        LOGGER_CS.info(`[kk-helper:code-scan] API返回项目总数: ${projects.length}，开始逐项目扫描代码...`);
        LOGGER_CS.info('[kk-helper:code-scan] ──────────────────────────────────────');

        if (projects.length === 0) {
            throw new Error('未找到"上海军团直客中心"的项目');
        }

        // 3. 逐项目扫描代码
        const projectsDict = {};
        const failedProjects = [];
        const skippedProjects = [];  // 缺少 dogNum/buildId 的项目
        const emptyCodeProjects = [];  // 扫描成功但无代码记录的项目
        let processedCount = 0;

        for (const project of projects) {
            const dogNum = project.dogNum || '';
            const buildId = project.buildid || '';
            const projectAlias = project.projectAlias || '(未命名)';
            const creator = project.creator || '-';

            if (!dogNum || !buildId) {
                const reason = !dogNum ? '缺少 dogNum' : '缺少 buildId';
                LOGGER_CS.warn(`[kk-helper:code-scan] ⚠️ 跳过项目 ${processedCount + 1}/${projects.length}: ${projectAlias} (${reason})`, {
                    dogNum: project.dogNum,
                    buildId: project.buildid,
                    creator: project.creator
                });
                skippedProjects.push({
                    projectAlias: projectAlias,
                    reason: reason
                });
                processedCount++;
                continue;
            }

            LOGGER_CS.info(`[kk-helper:code-scan] ▶ 处理项目 ${processedCount + 1}/${projects.length}: ${projectAlias} (dogNum=${dogNum}, buildId=${buildId})`);
            const projectStartTime = Date.now();

            // 更新进度
            const percent = Math.round(((processedCount + 1) / projects.length) * 100);
            const progressState = await codeScanLoadState();
            if (progressState && progressState.status === 'scanning') {
                progressState.progress = {
                    phase: 'scanning',
                    current: processedCount + 1,
                    total: projects.length,
                    percent: percent,
                    currentProject: projectAlias
                };
                progressState.scanStartedAt = progressState.scanStartedAt || scanStartTime;
                await codeScanSaveState(progressState);
            }

            try {
                // 查询代码
                const sourceRows = await codeScanGetSourceRows(dogNum, buildId, cookieStr);
                const projectDuration = Date.now() - projectStartTime;
                LOGGER_CS.info(`[kk-helper:code-scan]   ← ${projectAlias}: 返回 ${sourceRows.length} 条代码记录，耗时 ${projectDuration}ms`);

                const projectKey = `${projectAlias}#${buildId}`;
                if (!projectsDict[projectKey]) {
                    projectsDict[projectKey] = {
                        projectAlias: projectAlias,
                        buildId: buildId,
                        creator: creator,
                        repositories: '',
                        projectCode: [],
                        non_compliant_code_count: 0
                    };
                }

                if (!projectsDict[projectKey].repositories && sourceRows.length > 0) {
                    projectsDict[projectKey].repositories = sourceRows[0].repositories || '';
                }

                // 存储代码记录（将空值统一转为 '-'）
                for (const row of sourceRows) {
                    projectsDict[projectKey].projectCode.push({
                        filePath: row.filePath || '',
                        applicant: row.applicant || '-',
                        applicationDate: row.applicationDate || '-',
                        fileSource: row.fileSource || '-'
                    });
                }

                // 从已存储的 projectCode 中计算不合规代码（使用标准化后的数据，避免原始API字段名不一致）
                // 不合规定义：applicant 或 applicationDate 为 '-'（即原始值为空）
                // 但两者同时为 '-' 的排除
                var ncCount = 0;
                projectsDict[projectKey].projectCode.forEach(function (code) {
                    var noApplicant = (code.applicant === '-');
                    var noDate = (code.applicationDate === '-');
                    if (noApplicant && noDate) return;
                    if (noApplicant || noDate) ncCount++;
                });
                projectsDict[projectKey].non_compliant_code_count = ncCount;

                if (ncCount > 0) {
                    LOGGER_CS.warn(`[kk-helper:code-scan]   ⚠ ${projectAlias}: 发现 ${ncCount} 条不合规代码`);
                } else if (sourceRows.length > 0) {
                    LOGGER_CS.info(`[kk-helper:code-scan]   ✓ ${projectAlias}: ${sourceRows.length} 条代码，全部合规`);
                } else {
                    LOGGER_CS.info(`[kk-helper:code-scan]   ○ ${projectAlias}: 无代码记录`);
                    emptyCodeProjects.push({ projectAlias: projectAlias, creator: creator });
                }

            } catch (projErr) {
                LOGGER_CS.error(`[kk-helper:code-scan] ❌ 处理项目 ${projectAlias} 出错:`, projErr.message, {
                    dogNum: dogNum,
                    buildId: buildId,
                    creator: creator
                });
                failedProjects.push({ projectAlias: projectAlias, error: projErr.message });
            }

            processedCount++;
        }

        const scanEndTime = Date.now();
        const scanDurationMs = scanEndTime - scanStartTime;

        // 4. 构建最终结果
        const result = { total: 0, rows: [], totalProjectsScanned: projects.length, failedProjects: failedProjects, skippedProjects: skippedProjects, emptyCodeProjects: emptyCodeProjects, scanStartTime: scanStartTime, scanDurationMs: scanDurationMs, nonCompliantTotal: 0, nonCompliantProjectCount: 0 };
        for (const entry of Object.values(projectsDict)) {
            const codeCount = entry.projectCode.length;
            if (codeCount > 0) {
                result.total += codeCount;
                result.rows.push(entry);
                if (entry.non_compliant_code_count > 0) {
                    result.nonCompliantTotal += entry.non_compliant_code_count;
                    result.nonCompliantProjectCount++;
                }
            }
        }

        // 4.5 计算当前用户自己的不合规代码
        // 不合规定义：applicant 或 applicationDate 为空
        // 但如果两者同时为空/-'，则排除（无任何信息的记录不纳入）
        // 只统计当前用户的不合规代码
        const currentUserNonCompliant = [];
        if (currentUserName) {
            for (const entry of result.rows) {
                for (const code of entry.projectCode) {
                    // 只关注当前用户的代码
                    if (code.applicant !== currentUserName) continue;

                    const noApplicant = !code.applicant || code.applicant === '-';
                    const noDate = !code.applicationDate || code.applicationDate === '-';

                    // 两者都为空，跳过
                    if (noApplicant && noDate) continue;

                    // 至少有一项为空，则为不合规
                    if (noApplicant || noDate) {
                        currentUserNonCompliant.push({
                            projectAlias: entry.projectAlias,
                            filePath: code.filePath,
                            applicant: code.applicant,
                            applicationDate: code.applicationDate,
                            fileSource: code.fileSource
                        });
                    }
                }
            }
        }

        // 4.6 计算当前用户在所有项目中的代码明细
        const currentUserCodes = [];
        if (currentUserName) {
            for (const entry of result.rows) {
                for (const code of entry.projectCode) {
                    if (code.applicant === currentUserName) {
                        currentUserCodes.push({
                            projectAlias: entry.projectAlias,
                            filePath: code.filePath,
                            applicant: code.applicant,
                            applicationDate: code.applicationDate,
                            fileSource: code.fileSource
                        });
                    }
                }
            }
        }

        LOGGER_CS.info('[kk-helper:code-scan] ══════════════════════════════════════');
        LOGGER_CS.info(`[kk-helper:code-scan] ====== 检测完成 ======`);
        LOGGER_CS.info('[kk-helper:code-scan] ══════════════════════════════════════');
        LOGGER_CS.info(`[kk-helper:code-scan] 总耗时: ${Math.round(scanDurationMs / 1000)} 秒`);
        LOGGER_CS.info(`[kk-helper:code-scan] 目标项目总数: ${projects.length}`);
        LOGGER_CS.info(`[kk-helper:code-scan] 有代码记录的项目: ${result.rows.length}`);
        LOGGER_CS.info(`[kk-helper:code-scan] 代码记录总数: ${result.total}`);
        LOGGER_CS.info(`[kk-helper:code-scan] 不合规代码总数: ${result.nonCompliantTotal} (${result.nonCompliantProjectCount} 个项目)`);
        if (skippedProjects.length > 0) {
            LOGGER_CS.warn(`[kk-helper:code-scan] 跳过的项目 (${skippedProjects.length} 个):`);
            skippedProjects.forEach(function (sp) {
                LOGGER_CS.warn(`[kk-helper:code-scan]   - ${sp.projectAlias}: ${sp.reason}`);
            });
        }
        if (failedProjects.length > 0) {
            LOGGER_CS.error(`[kk-helper:code-scan] 扫描失败的项目 (${failedProjects.length} 个):`);
            failedProjects.forEach(function (fp) {
                LOGGER_CS.error(`[kk-helper:code-scan]   - ${fp.projectAlias}: ${fp.error}`);
            });
        }
        if (emptyCodeProjects.length > 0) {
            LOGGER_CS.info(`[kk-helper:code-scan] 无代码记录的项目 (${emptyCodeProjects.length} 个):`);
            emptyCodeProjects.forEach(function (ep) {
                LOGGER_CS.info(`[kk-helper:code-scan]   - ${ep.projectAlias} (创建人: ${ep.creator})`);
            });
        }
        LOGGER_CS.info(`[kk-helper:code-scan] 当前用户: ${currentUserName || '未知'}, 用户代码数: ${currentUserCodes.length}, 用户不合规代码数: ${currentUserNonCompliant.length}`);
        LOGGER_CS.info('[kk-helper:code-scan] ══════════════════════════════════════');

        // 5. 保存结果
        const finalState = {
            status: 'completed',
            progress: { phase: 'done', current: projects.length, total: projects.length, percent: 100, currentProject: '检测完成' },
            result: result,
            currentUser: currentUserName || null,
            currentUserCodes: currentUserCodes,
            currentUserNonCompliant: currentUserNonCompliant,
            scanDurationMs: scanDurationMs,
            timestamp: Date.now(),
            error: null
        };
        await codeScanSaveState(finalState);

        return finalState;

    } catch (error) {
        LOGGER_CS.error('[kk-helper:code-scan] 检测失败:', error.message);
        const errorState = {
            status: 'error',
            progress: { phase: 'error', current: 0, total: 0, percent: 0, currentProject: '检测失败' },
            result: null,
            timestamp: null,
            error: error.message
        };
        await codeScanSaveState(errorState);
        return errorState;
    }
}

// 监听代码检测相关的消息
// 注意：原有的消息监听器在上方，这里使用 chrome.runtime.onMessage 的追加监听方式
// 由于 MV3 中一个事件只能有一个 addListener，我们需要修改原有的监听器
// 为了避免修改原有代码，在此通过额外的方式处理

// 备注：由于 MV3 的限制，onMessage 只能有一个监听器，
// 我们需要在原有的 handleResponse 中处理新 action。
// 为了保持代码隔离，我们在原有 switch-case 中追加新的 case。
// 这里定义处理函数，供上方监听器调用。

async function handleCodeScanMessage(request, sender, sendResponse) {
    switch (request.action) {
        case 'getCodeScanResult': {
            // 查询缓存结果，检查是否在有效期内
            const state = await codeScanGetActiveState();
            if (state && state.status === 'completed' && state.result && state.timestamp) {
                const elapsed = Date.now() - state.timestamp;
                if (elapsed < CODE_SCAN_RESULT_TTL) {
                    LOGGER_CS.info('[kk-helper:code-scan] 返回有效缓存结果，剩余有效期:', Math.round((CODE_SCAN_RESULT_TTL - elapsed) / 1000), '秒');
                    sendResponse({ success: true, data: { status: 'completed', result: state.result, currentUser: state.currentUser || null, currentUserCodes: state.currentUserCodes || [], currentUserNonCompliant: state.currentUserNonCompliant || [], scanDurationMs: state.scanDurationMs || 0, cached: true, remainingMs: CODE_SCAN_RESULT_TTL - elapsed } });
                } else {
                    LOGGER_CS.info('[kk-helper:code-scan] 缓存已过期');
                    sendResponse({ success: true, data: { status: 'expired', result: null, cached: false } });
                }
            } else if (state && state.status === 'scanning') {
                sendResponse({ success: true, data: { status: 'scanning', progress: state.progress } });
            } else if (state && state.status === 'error') {
                sendResponse({ success: true, data: { status: 'error', error: state.error } });
            } else {
                sendResponse({ success: true, data: { status: 'idle' } });
            }
            return true;
        }

        case 'startCodeScan': {
            // 启动检测（非阻塞）
            const currentState = await codeScanGetActiveState();
            if (currentState && currentState.status === 'scanning') {
                LOGGER_CS.info('[kk-helper:code-scan] 检测已在进行中');
                sendResponse({ success: true, data: { status: 'scanning', message: '检测已在进行中' } });
            } else {
                LOGGER_CS.info('[kk-helper:code-scan] 启动新的代码检测');
                sendResponse({ success: true, data: { status: 'started', message: '检测已启动' } });
                // 异步执行，不阻塞响应
                codeScanExecute().then(result => {
                    LOGGER_CS.info('[kk-helper:code-scan] 检测流程结束:', result.status);
                }).catch(err => {
                    LOGGER_CS.error('[kk-helper:code-scan] 检测流程异常:', err.message);
                });
            }
            return true;
        }

        case 'getCodeScanProgress': {
            const state = await codeScanGetActiveState();
            if (state) {
                sendResponse({ success: true, data: { status: state.status, progress: state.progress, error: state.error } });
            } else {
                sendResponse({ success: true, data: { status: 'idle', progress: null } });
            }
            return true;
        }

        default:
            return false; // 非代码检测消息，由原有处理器处理
    }
}

LOGGER_CS.info('代码检测模块已加载');

async function getProjectHandoverTemplate() {
    const response = await fetch(chrome.runtime.getURL('project-handover/assets/项目交接会议纪要模板.docx'));
    if (!response.ok) throw new Error('项目交接会议纪要模板读取失败：HTTP ' + response.status);
    const bytes = new Uint8Array(await response.arrayBuffer());
    let binary = '';
    for (let index = 0; index < bytes.length; index += 0x8000) {
        binary += String.fromCharCode.apply(null, bytes.subarray(index, index + 0x8000));
    }
    return { base64: btoa(binary) };
}
