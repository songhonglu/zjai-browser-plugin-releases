const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, 'content.js'), 'utf8');
const instrumentedSource = source.replace(
  /\}\)\(\);\s*$/,
  'globalThis.__weeklyPlanTestHooks = { validateFeedbacks, positionSummaryPanel, bindSummaryPanelDrag, appendSummaryLog, getOverlayDocument, generateSummary };})();'
);
const sandbox = {
  console,
  window: {
    addEventListener() {},
    innerWidth: 1280,
    innerHeight: 720,
  },
  document: {
    readyState: 'loading',
    addEventListener() {},
  },
  setTimeout() {},
  setInterval() {},
};
vm.runInNewContext(instrumentedSource, sandbox);
const { validateFeedbacks } = sandbox.__weeklyPlanTestHooks;
const topDocument = { name: 'top-document' };
sandbox.window.top = { document: topDocument };
assert.strictEqual(
  sandbox.__weeklyPlanTestHooks.getOverlayDocument(),
  topDocument,
  '悬浮入口和面板应挂载到顶层页面，避免跟随内嵌表单滚动'
);
sandbox.window.top = sandbox.window;

const invalidFeedbacks = validateFeedbacks([
  { rowNumber: 1, feedback: '' },
  { rowNumber: 2, feedback: '已处理，等待后续安排' },
  { rowNumber: 3, feedback: '' },
]);
assert.strictEqual(invalidFeedbacks.ok, false, '不合规反馈应阻止汇总');
assert.match(invalidFeedbacks.message, /第1、3行完成反馈不能为空/, '空反馈应列出具体行号');
assert.match(invalidFeedbacks.message, /第2行完成反馈缺少进度信息/, '缺少进度应列出具体行号');

['完成', '已完成', '已上线', '已闭环', '进行中', '持续推进', '待联调', '待确认'].forEach((feedback) => {
  assert.strictEqual(
    validateFeedbacks([{ rowNumber: 1, feedback }]).ok,
    true,
    `${feedback} 应视为有效进度`
  );
});

const panel = {
  hidden: false,
  style: {},
  dataset: {},
  getBoundingClientRect() {
    return { width: 300, height: 135 };
  },
};
sandbox.__weeklyPlanTestHooks.positionSummaryPanel(panel);
assert.strictEqual(panel.style.left, 'auto', '面板不应随入口横向移动');
assert.strictEqual(panel.style.right, '72px', '面板应固定在页面右侧');
assert.strictEqual(panel.style.top, '72px', '面板应固定在首屏高度');
assert.strictEqual(panel.style.transform, 'none', '面板不应再以页面中线定位');

const panelDragEvents = {};
const panelHeader = {
  addEventListener(type, listener) {
    panelDragEvents[type] = listener;
  },
  setPointerCapture() {},
  releasePointerCapture() {},
};
const dragPanel = {
  dataset: {},
  style: {},
  offsetWidth: 300,
  offsetHeight: 135,
  querySelector() {
    return panelHeader;
  },
  getBoundingClientRect() {
    return { left: 100, top: 100 };
  },
};
sandbox.__weeklyPlanTestHooks.bindSummaryPanelDrag(dragPanel, sandbox.document);
panelDragEvents.pointerdown({
  target: { closest() { return null; } },
  clientX: 120,
  clientY: 110,
  pointerId: 1,
});
panelDragEvents.pointermove({ clientX: 220, clientY: 210 });
assert.strictEqual(dragPanel.style.left, '200px', '拖动标题栏应更新面板横坐标');
assert.strictEqual(dragPanel.style.top, '200px', '拖动标题栏应更新面板纵坐标');
assert.strictEqual(dragPanel.style.right, 'auto', '拖动后仍应保持固定定位');

const logEntries = [];
const summaryLog = {
  appendChild(entry) {
    logEntries.push(entry);
  },
  scrollHeight: 120,
  scrollTop: 0,
};
sandbox.document.getElementById = () => ({
  querySelector(selector) {
    return selector === '#summary-log' ? summaryLog : null;
  },
});
sandbox.document.createElement = () => ({ className: '', textContent: '' });
sandbox.__weeklyPlanTestHooks.appendSummaryLog('正在汇总，请稍后', 'processing');
assert.strictEqual(logEntries.length, 1, '执行状态应追加到面板日志区');
assert.strictEqual(logEntries[0].textContent, '正在汇总，请稍后', '日志应保留执行信息');
assert.strictEqual(summaryLog.scrollTop, 120, '日志区应自动滚动到最新记录');

assert.match(source, /const FAB_ID = 'seeyon-weekly-plan-fab'/, '周计划应提供圆形入口');
assert.match(source, /id="weekly-plan-auto-summary"/, '入口菜单应提供自动汇总操作');
assert.match(source, /const PANEL_ID = 'weekly-plan-summary-panel'/, '周计划应定义自动汇总面板 ID');
assert.match(source, /panel\.id = PANEL_ID/, '点击入口后应显示自动汇总面板');
assert.match(source, /function ensureSummaryPanel\(/, '自动汇总面板应独立于圆形入口创建');
assert.match(source, /uiDocument\.documentElement\.appendChild\(panel\)/, '面板应挂在顶层页面根节点以固定于视口');
assert.match(source, /'width:440px'/, '自动汇总面板宽度应与台账检查保持一致');
assert.match(source, /\.summary-log\{max-height:300px;[^}]*overflow:auto/, '执行日志应在超过 300px 后才出现垂直滚动条');
assert.match(source, /function resetSummaryPanel\(\)/, '重新打开面板时应统一重置上次执行状态');
assert.match(source, /setSummaryStatus\('', ''\);/, '重新打开面板时应清空上次汇总结果');
assert.match(
  source,
  /if \(resetLog\) \{\s+resetSummaryPanel\(\);\s+appendSummaryLog\('已打开自动汇总，等待开始校验。'\);/,
  '从入口重新打开时应重置面板后再记录本次打开信息'
);
assert.match(
  source,
  /if \(!isTargetPage\(\)\) \{\s+if \(activated\) removeFab\(\);\s+activated = false;/,
  '非目标 iframe 不应删除已由目标表单创建的顶层入口'
);
assert.match(
  source,
  /if \(!isEditableMode\(detail\)\) \{\s+if \(activated\) removeFab\(\);\s+activated = false;/,
  '未激活 iframe 不应因只读判断删除顶层入口'
);
assert.match(source, /function defaultFabTop\(uiWindow\)/, '入口应提供基于视口的默认纵向位置');
assert.match(source, /Math\.round\(\(uiWindow\.innerHeight - FAB_SIZE\) \/ 2\)/, '入口默认应垂直居中');
assert.match(source, /function bindFabDrag\(/, '入口应支持拖动');
assert.match(source, /ball\.addEventListener\('pointerdown'/, '入口拖动应从 pointerdown 开始');
assert.match(source, /uiDocument\.addEventListener\('pointermove', move, true\)/, '入口拖动应使用顶层 document 级 pointermove');
assert.match(source, /host\.style\.top = Math\.max\(8, Math\.min\(uiWindow\.innerHeight - size - 8, top\)\) \+ 'px'/, '入口拖动后应限制在顶层首屏可视范围内');
assert.match(source, /setPos\(uiWindow\.innerWidth - size - 18, defaultFabTop\(uiWindow\)\);/, '入口初始位置应使用视口垂直居中坐标');
assert.match(source, /function validateFeedbacks\(rows\)/, '汇总前应统一校验完成反馈');
assert.match(source, /完成反馈不能为空/, '完成反馈为空时应给出明确提示');
assert.match(source, /PROGRESS_STATUS_PATTERN/, '完成反馈应支持状态词进度识别');
assert.match(source, /parsePercent\(row\.feedback\)/, '完成反馈应支持百分比进度识别');
assert.match(source, /进度信息/, '完成反馈缺少进度时应给出明确提示');
assert.match(source, /汇总中，请稍后/, '执行汇总时应展示等待状态');
assert.match(source, /let summaryRunId = 0;/, '自动汇总应具备本次执行标识，用于终止后丢弃异步结果');
assert.match(source, /function cancelManualSummary\(\)/, '执行中的自动汇总应支持终止');
assert.match(source, /if \(aiBusy\) \{\s+cancelManualSummary\(\);\s+return;\s+\}/, '再次点击按钮时应终止正在执行的汇总');
assert.match(source, /button\.textContent = '终止汇总';/, '执行中的按钮应显示终止汇总');
assert.doesNotMatch(source, /button\.disabled = true/, '执行中的按钮不应被禁用，以便用户终止汇总');
assert.match(source, /async function generateSummary\(rows, isCurrentRun\)/, '异步汇总应接收当前执行状态判断');
assert.match(source, /if \(!isCurrentRun\(\)\) return \{ ok: false, reason: 'cancelled' \};/, '终止后不得继续写入上周总结');
assert.match(source, /async function runManualSummary\(\)/, '汇总应由手动操作触发');
assert.doesNotMatch(source, /scheduleGenerate\('bootstrap'\)|scheduleGenerate\('input'\)|scheduleGenerate\('change'\)|scheduleGenerate\('mutation'\)/, '页面加载或表格变化不应自动触发汇总');

sandbox.__weeklyPlanTestHooks.generateSummary([], () => false).then((result) => {
  assert.strictEqual(result.reason, 'cancelled', '终止后的汇总不应继续调用 AI 或写入上周总结');
  console.log('weekly plan contract checks passed');
});
