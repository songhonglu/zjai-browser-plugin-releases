(function () {
  if (window.__seeyon_weekly_plan__) return;
  window.__seeyon_weekly_plan__ = true;

  const LOG_PREFIX = '[kk-helper:weekly-plan]';
  const TARGET_LABELS = ['上周总结', '上周工作明细', '关联上周计划'];
  const HEADER_ALIASES = {
    date: ['日期'],
    weekday: ['星期几', '星期'],
    project: ['项目名称'],
    currentStage: ['当前阶段'],
    targetStage: ['目标阶段'],
    priority: ['概率'],
    partner: ['伙伴名称', '协作人员', '伙伴人员'],
    content: ['事项内容'],
    feedback: ['完成反馈'],
  };
  const FAB_ID = 'seeyon-weekly-plan-fab';
  const GUIDE_ID = 'seeyon-weekly-plan-guide';
  const MENU_ID = 'seeyon-weekly-plan-menu';
  const PANEL_ID = 'weekly-plan-summary-panel';
  const FAB_SIZE = 42;
  const PANEL_DEFAULT_TOP = 72;
  const PANEL_DEFAULT_RIGHT = 72;
  const PROGRESS_STATUS_PATTERN = /(?:^|[^未])完成|已上线|已闭环|进行中|持续推进|待联调|待确认/;
  let observer = null;
  let writeLock = false;
  let scheduleTimer = null;
  let heartbeatTimer = null;
  let activated = false;
  let aiBusy = false;
  let summaryRunId = 0;
  const SUGGESTION_MAX_LEN = 300;

  const Log = {
    info: (...args) => console.log(LOG_PREFIX, ...args),
    warn: (...args) => console.warn(LOG_PREFIX, ...args),
    debug: (...args) => console.debug(LOG_PREFIX, ...args),
  };

  function getOverlayDocument() {
    try {
      return window.top && window.top.document ? window.top.document : document;
    } catch (_) {
      return document;
    }
  }

  function getOverlayWindow(uiDocument) {
    return uiDocument.defaultView || window;
  }

  function defaultFabTop(uiWindow) {
    return Math.max(8, Math.round((uiWindow.innerHeight - FAB_SIZE) / 2));
  }

  function normalizeText(text) {
    return String(text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function pageText() {
    return normalizeText(document.body ? document.body.innerText || document.body.textContent : '');
  }

  function isTargetPage() {
    const text = pageText();
    return TARGET_LABELS.every((label) => text.includes(label));
  }

  function hasRelatedLastWeekPlan() {
    const labels = Array.from(document.querySelectorAll('td, th, span, div, a'));
    for (const el of labels) {
      if (normalizeText(el.textContent) !== '关联上周计划') continue;
      const cell = el.closest('td, th') || el.parentElement;
      if (!cell) continue;
      let sib = cell.nextElementSibling;
      while (sib) {
        const text = normalizeText(sib.textContent);
        if (text && text !== '关联上周计划' && !/^单位[:：]?\s*元?$/.test(text)) {
          return /工作计划/.test(text) || text.length >= 6;
        }
        sib = sib.nextElementSibling;
      }
    }
    return Array.from(document.querySelectorAll('a'))
      .some((a) => /工作计划/.test(normalizeText(a.textContent)));
  }

  function isTableElement(node) {
    return node instanceof HTMLElement && Boolean(node.closest('table'));
  }

  function extractCellText(cell) {
    if (!cell) return '';

    const values = [];
    const push = (value) => {
      const text = normalizeText(value);
      if (text && !values.includes(text)) values.push(text);
    };

    cell.querySelectorAll('textarea, input, [contenteditable="true"]').forEach((el) => {
      push('value' in el ? el.value : el.textContent);
    });

    if (!values.length) {
      const clone = cell.cloneNode(true);
      clone.querySelectorAll('script, style, button, a, svg, img, input, textarea, select').forEach((el) => el.remove());
      push(clone.innerText || clone.textContent);
    }

    return values.join('\n');
  }

  function extractFeedbackStrictText(cell) {
    if (!cell) return '';

    const controls = Array.from(cell.querySelectorAll('textarea, input, [contenteditable="true"]'));
    if (controls.length) {
      const values = controls.map((el) => normalizeText('value' in el ? el.value : el.textContent)).filter(Boolean);
      return values.join('\n');
    }

    const clone = cell.cloneNode(true);
    clone.querySelectorAll('script, style, button, a, svg, img, input, textarea, select').forEach((el) => el.remove());
    return normalizeText(clone.innerText || clone.textContent);
  }

  function isFieldEditable(field) {
    if (!field || !(field instanceof HTMLElement)) return false;
    if (field.matches('textarea, input, select')) {
      return !field.disabled && !field.readOnly;
    }
    if (field.isContentEditable) return true;
    return false;
  }

  function findSummaryField() {
    const areas = Array.from(document.querySelectorAll('textarea, input[type="text"]'));
    let best = null;
    let bestScore = -1;

    for (const area of areas) {
      const box = area.closest('tr, table, td, section, div, li') || area.parentElement;
      const scopeText = normalizeText(box ? box.innerText || box.textContent : '');
      let score = 0;
      if (scopeText.includes('上周总结')) score += 10;
      if (scopeText.includes('实际上周') || scopeText.includes('实际完成')) score += 4;
      if (area.tagName === 'TEXTAREA') score += 2;
      score += Math.min((area.cols || 0) / 10, 3);
      score += Math.min((area.rows || 0) / 5, 3);
      if (score > bestScore) {
        best = area;
        bestScore = score;
      }
    }

    return best;
  }

  function hasEditableDetailControl(detail) {
    if (!detail || !detail.table) return false;
    return Array.from(detail.table.querySelectorAll('textarea, input, select, [contenteditable="true"]'))
      .some((el) => isFieldEditable(el));
  }

  function isEditableMode(detail) {
    const summaryField = findSummaryField();
    const summaryEditable = isFieldEditable(summaryField);
    const detailEditable = hasEditableDetailControl(detail);
    return summaryEditable || detailEditable;
  }

  function headerIndexMap(row) {
    const cells = Array.from(row.cells || row.querySelectorAll('th,td'));
    const map = {};
    cells.forEach((cell, index) => {
      const text = normalizeText(cell.innerText || cell.textContent);
      for (const [key, aliases] of Object.entries(HEADER_ALIASES)) {
        if (map[key] != null) continue;
        if (aliases.some((alias) => text.includes(alias))) map[key] = index;
      }
    });
    return map;
  }

  function hasRequiredIndexes(map) {
    return ['project', 'content', 'feedback'].every((key) => Number.isInteger(map[key]));
  }

  function findDetailTable() {
    const tables = Array.from(document.querySelectorAll('table'));
    for (const table of tables) {
      const text = normalizeText(table.innerText || table.textContent);
      if (!text.includes('上周工作明细')) continue;
      const rows = Array.from(table.rows || []);
      for (const row of rows) {
        const map = headerIndexMap(row);
        if (hasRequiredIndexes(map)) return { table, headerMap: map, headerRow: row };
      }
    }

    for (const table of tables) {
      const rows = Array.from(table.rows || []);
      for (const row of rows) {
        const map = headerIndexMap(row);
        if (hasRequiredIndexes(map)) return { table, headerMap: map, headerRow: row };
      }
    }

    return null;
  }

  function parseRows(detail) {
    if (!detail) return [];
    const rows = [];
    let passedHeader = false;

    for (const row of Array.from(detail.table.rows || [])) {
      if (row === detail.headerRow) {
        passedHeader = true;
        continue;
      }
      if (!passedHeader) continue;

      const cells = Array.from(row.cells || []);
      if (!cells.length) continue;

      const date = extractCellText(cells[detail.headerMap.date]);
      const weekday = extractCellText(cells[detail.headerMap.weekday]);
      const project = extractCellText(cells[detail.headerMap.project]);
      const currentStage = extractCellText(cells[detail.headerMap.currentStage]);
      const targetStage = extractCellText(cells[detail.headerMap.targetStage]);
      const priority = extractCellText(cells[detail.headerMap.priority]);
      const partner = extractCellText(cells[detail.headerMap.partner]);
      const content = extractCellText(cells[detail.headerMap.content]);
      const feedback = extractFeedbackStrictText(cells[detail.headerMap.feedback]);

      if (!project && !content && !feedback) continue;
      rows.push({
        rowNumber: rows.length + 1,
        date,
        weekday,
        project,
        currentStage,
        targetStage,
        priority,
        partner,
        content,
        feedback,
      });
    }

    return rows;
  }

  function splitLines(text) {
    return String(text || '')
      .replace(/[；;]/g, '\n')
      .split(/\n+/)
      .map((line) => normalizeText(line))
      .filter(Boolean);
  }

  function parsePercent(text) {
    const match = String(text || '').match(/(\d+(?:\.\d+)?)\s*%/);
    return match ? Number(match[1]) : null;
  }

  function validateFeedbacks(rows) {
    const incompleteRows = rows.filter((row) => !normalizeText(row.feedback));
    const missingProgressRows = rows.filter((row) => {
      const feedback = normalizeText(row.feedback);
      return feedback && parsePercent(row.feedback) == null && !PROGRESS_STATUS_PATTERN.test(feedback);
    });
    const rowNumbers = (invalidRows) => `第${invalidRows.map((row) => row.rowNumber).join('、')}行`;
    const messages = [];
    if (incompleteRows.length) {
      messages.push(`${rowNumbers(incompleteRows)}完成反馈不能为空，请补齐后再汇总。`);
    }
    if (missingProgressRows.length) {
      messages.push(`${rowNumbers(missingProgressRows)}完成反馈缺少进度信息，请补充百分比或完成状态。`);
    }
    if (messages.length) {
      return { ok: false, message: messages.join(' ') };
    }

    return { ok: true };
  }

  function stageCategory(row) {
    const text = [row.currentStage, row.targetStage].join(' ');
    if (text.includes('验收')) return '验收类';
    if (text.includes('蓝图')) return '蓝图类';
    return '开发类';
  }

  function uniquePush(list, value) {
    const text = normalizeText(value);
    if (text && !list.includes(text)) list.push(text);
  }

  function collectProjectSummaries(rows) {
    const map = new Map();
    rows.forEach((row) => {
      const key = normalizeText(row.project) || '未命名项目';
      if (!map.has(key)) {
        map.set(key, {
          project: key,
          weekday: [],
          currentStage: normalizeText(row.currentStage),
          targetStage: normalizeText(row.targetStage),
          priority: normalizeText(row.priority),
          category: stageCategory(row),
          contentLines: [],
          feedbackLines: [],
        });
      }
      const item = map.get(key);
      uniquePush(item.weekday, row.weekday);
      splitLines(row.content).forEach((line) => uniquePush(item.contentLines, line));
      splitLines(row.feedback).forEach((line) => uniquePush(item.feedbackLines, line));
      if (!item.currentStage) item.currentStage = normalizeText(row.currentStage);
      if (!item.targetStage) item.targetStage = normalizeText(row.targetStage);
      if (!item.priority) item.priority = normalizeText(row.priority);
    });
    return Array.from(map.values());
  }

  function workloadBalanceText(dayStats) {
    const counts = dayStats.map((item) => item.count);
    const max = Math.max.apply(null, counts);
    const min = Math.min.apply(null, counts);
    if (max === min) return '整体分布均衡';
    if (max - min <= 1) return '整体较为均衡';
    return '工作量存在明显波动，需关注高峰日资源安排';
  }

  function classifyWorkType(text) {
    const value = String(text || '');
    if (/(上线支持|升级支持|升级准备|切换支持)/.test(value)) return '升级支撑';
    if (/(升级|迁移|信创|切换)/.test(value)) return '升级支撑';
    if (/(对接|同步|接口|联调|集成)/.test(value)) return '集成';
    if (/(调研|需求|沟通|分析)/.test(value)) return '调研';
    if (/(运维|支持|保障|修复|排查|维护)/.test(value)) return '运维';
    if (/(开发|上线|优化|实现|改造|新增)/.test(value)) return '开发';
    return '其他';
  }

  function collectRiskText(projects) {
    const risks = [];
    projects.forEach((item) => {
      const currentPercent = parsePercent(item.currentStage);
      const targetPercent = parsePercent(item.targetStage);
      if (currentPercent != null && targetPercent != null && currentPercent < targetPercent) {
        risks.push(`${item.project}当前阶段${item.currentStage}，低于目标阶段${item.targetStage}`);
      }
      const joined = item.feedbackLines.concat(item.contentLines).join('；');
      if (/(待|持续|沟通中|协调|准备|未完成|未达|风险|问题|排查)/.test(joined)) {
        risks.push(`${item.project}存在“${joined.slice(0, 24)}${joined.length > 24 ? '...' : ''}”类持续跟进事项`);
      }
    });
    return risks.filter((value, index) => value && risks.indexOf(value) === index);
  }

  function buildCompactTime(rows) {
    const dayMap = new Map();
    rows.forEach((row) => {
      const weekday = normalizeText(row.weekday) || '未知';
      if (!dayMap.has(weekday)) dayMap.set(weekday, new Set());
      dayMap.get(weekday).add(normalizeText(row.project) || '未命名项目');
    });
    const stats = Array.from(dayMap.entries()).map(([weekday, set]) => ({ weekday, count: set.size }));
    if (!stats.length) return '时间：未提取';
    const peak = stats.slice().sort((a, b) => b.count - a.count)[0];
    return `时间：${stats.length}天，${peak.weekday}${peak.count}项最高`;
  }

  function buildCompactProject(projects) {
    const counts = { 验收类: 0, 开发类: 0, 蓝图类: 0 };
    projects.forEach((item) => { counts[item.category] = (counts[item.category] || 0) + 1; });
    return `项目：验收${counts['验收类'] || 0}、开发${counts['开发类'] || 0}、蓝图${counts['蓝图类'] || 0}`;
  }

  function buildCompactProgress(projects) {
    let lagging = 0;
    projects.forEach((item) => {
      const currentPercent = parsePercent(item.currentStage);
      const targetPercent = parsePercent(item.targetStage);
      if (currentPercent != null && targetPercent != null && currentPercent < targetPercent) lagging += 1;
    });
    return lagging ? `进度：${lagging}项未达目标` : '进度：整体达标';
  }

  function buildCompactWork(rows) {
    const countMap = new Map();
    rows.forEach((row) => {
      const type = classifyWorkType(row.content || row.feedback);
      countMap.set(type, (countMap.get(type) || 0) + 1);
    });
    const top = Array.from(countMap.entries()).sort((a, b) => b[1] - a[1]).slice(0, 2);
    if (!top.length) return '事项：未提取';
    return `事项：${top.map(([k, v]) => `${k}${v}项`).join('，')}`;
  }

  function buildCompactPriority(projects) {
    const guaranteed = projects.filter((item) => item.priority.includes('保底')).length;
    const striving = projects.filter((item) => item.priority.includes('争取')).length;
    const risks = collectRiskText(projects);
    return `优先级：保底${guaranteed}、争取${striving}${risks.length ? `；风险${Math.min(risks.length, 9)}项` : '；风险可控'}`;
  }

  function trimToLength(text, maxLen) {
    const value = normalizeText(text).replace(/\s+/g, '');
    return value.length <= maxLen ? value : value.slice(0, maxLen - 1) + '…';
  }

  function buildNextWeekSuggestion(projects, rows) {
    const laggingProjects = projects.filter((item) => {
      const currentPercent = parsePercent(item.currentStage);
      const targetPercent = parsePercent(item.targetStage);
      return currentPercent != null && targetPercent != null && currentPercent < targetPercent;
    });
    const hasStriving = projects.some((item) => item.priority.includes('争取'));
    const hasSupport = rows.some((row) => /(支持|排查|沟通|调研)/.test([row.content, row.feedback].join('；')));
    const upgradeProjects = projects.filter((item) => /(升级|信创|蓝图)/.test([item.project, item.currentStage, item.targetStage].join(' ')));
    let text = '下周计划建议：';
    if (laggingProjects.length) {
      text += `优先推动${laggingProjects.slice(0, 2).map((item) => item.project).join('、')}补齐阶段差距，`;
    } else if (hasStriving) {
      text += '优先推进争取类项目资源落实与关键事项闭环，';
    } else {
      text += '优先围绕核心项目阶段成果落地与交付节点推进，';
    }
    if (upgradeProjects.length) {
      text += `同步关注${upgradeProjects.slice(0, 2).map((item) => item.project).join('、')}的升级/蓝图事项，`;
    }
    text += hasSupport
      ? '继续收敛持续沟通、排查和支持类事项，形成可确认的阶段结果。'
      : '同步准备阶段性交付材料，确保重点任务按计划推进。';
    return trimToLength(text, SUGGESTION_MAX_LEN);
  }

  function buildTimeSection(rows) {
    const order = ['周一', '周二', '周三', '周四', '周五'];
    const dayMap = new Map(order.map((key) => [key, new Set()]));
    rows.forEach((row) => {
      const weekday = normalizeText(row.weekday);
      if (!dayMap.has(weekday)) dayMap.set(weekday, new Set());
      dayMap.get(weekday).add(normalizeText(row.project) || '未命名项目');
    });
    const stats = Array.from(dayMap.entries()).map(([weekday, projects]) => ({
      weekday,
      count: projects.size,
    })).filter((item) => item.count > 0);
    if (!stats.length) return '一、时间维度\n未提取到可统计的日期与星期信息。';
    const summary = stats.map((item) => `${item.weekday}承接${item.count}个项目`).join('，');
    return `一、时间维度\n本周上周工作明细共覆盖${stats.length}个工作日，${summary}；${workloadBalanceText(stats)}。`;
  }

  function buildProjectSection(projects) {
    const categories = ['验收类', '开发类', '蓝图类'];
    const lines = ['二、项目主体维度'];
    categories.forEach((category) => {
      const items = projects.filter((item) => item.category === category);
      if (!items.length) return;
      lines.push(`${category}项目共${items.length}个：`);
      items.forEach((item, index) => {
        const workText = item.contentLines.slice(0, 3).join('；') || '未提取到事项内容';
        const feedbackText = item.feedbackLines.slice(0, 3).join('；') || '未填写完成反馈';
        lines.push(`${index + 1}. ${item.project}：本周工作为${workText}；当前阶段${item.currentStage || '未提取'}，目标阶段${item.targetStage || '未提取'}；完成情况为${feedbackText}。`);
      });
    });
    return lines.join('\n');
  }

  function buildProgressSection(projects) {
    const lines = ['三、进度维度'];
    const lagging = [];
    projects.forEach((item) => {
      const currentPercent = parsePercent(item.currentStage);
      const targetPercent = parsePercent(item.targetStage);
      if (currentPercent != null && targetPercent != null) {
        if (currentPercent < targetPercent) lagging.push(`${item.project}（当前${item.currentStage}，目标${item.targetStage}）`);
      }
    });
    if (lagging.length) {
      lines.push(`已识别进度未达标项目${lagging.length}个：${lagging.join('；')}。`);
    } else {
      lines.push('表格内可识别项目的当前阶段与目标阶段整体一致，未发现明确的阶段性未达标项目。');
    }
    return lines.join('\n');
  }

  function buildWorkSection(rows) {
    const typeMap = new Map();
    rows.forEach((row) => {
      const type = classifyWorkType(row.content || row.feedback);
      if (!typeMap.has(type)) typeMap.set(type, { count: 0, projects: [] });
      const item = typeMap.get(type);
      item.count += 1;
      uniquePush(item.projects, normalizeText(row.project) || '未命名项目');
    });
    const order = ['开发', '调研', '运维', '集成', '升级支撑', '其他'];
    const lines = ['四、工作事项维度'];
    order.forEach((type) => {
      const item = typeMap.get(type);
      if (!item) return;
      lines.push(`${type}类工作共${item.count}项，涉及项目：${item.projects.join('、')}。`);
    });
    return lines.join('\n');
  }

  function buildPrioritySection(projects) {
    const guaranteed = projects.filter((item) => item.priority.includes('保底'));
    const striving = projects.filter((item) => item.priority.includes('争取'));
    const lines = ['五、优先级维度'];
    lines.push(`保底类项目${guaranteed.length}个，争取类项目${striving.length}个。`);
    const risks = collectRiskText(projects);
    if (risks.length) {
      lines.push(`当前需重点关注的风险与持续事项：${risks.slice(0, 5).join('；')}。`);
    } else {
      lines.push('当前未从表格原文中识别到明确的资源不足、进度滞后或持续运维风险描述。');
    }
    return lines.join('\n');
  }

  function buildFallbackSummary(rows) {
    const projects = collectProjectSummaries(rows);
    const parts = [
      buildTimeSection(rows),
      buildProjectSection(projects),
      buildProgressSection(projects),
      buildWorkSection(rows),
      buildPrioritySection(projects),
    ];
    const suggestion = buildNextWeekSuggestion(projects, rows);
    const body = parts.join('\n\n').trim();
    return `${body}\n${suggestion}`;
  }

  function buildAiPayload(rows) {
    const projects = collectProjectSummaries(rows);
    const sanitizePartner = function (value) {
      const text = normalizeText(value);
      if (!text) return '';
      if (/^(上周安排[-－]?伙伴|伙伴类型|伙伴名称|未填写|无|-)$/.test(text)) return '';
      return text;
    };
    return {
      draftSummary: buildFallbackSummary(rows),
      feedbackDigest: projects.map((item, index) => ({
        index: index + 1,
        project: item.project,
        currentStage: item.currentStage,
        targetStage: item.targetStage,
        priority: item.priority,
        contents: item.contentLines,
        feedbacks: item.feedbackLines
      })),
      rows: rows.map((row) => ({
        date: normalizeText(row.date),
        weekday: normalizeText(row.weekday),
        project: normalizeText(row.project),
        currentStage: normalizeText(row.currentStage),
        targetStage: normalizeText(row.targetStage),
        priority: normalizeText(row.priority),
        partner: sanitizePartner(row.partner),
        content: normalizeText(row.content),
        feedback: normalizeText(row.feedback),
      }))
    };
  }

  function requestAiSummary(rows) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action: 'weeklyPlanAiSummarize', params: buildAiPayload(rows) }, function(resp) {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || 'AI消息失败'));
          return;
        }
        if (!resp || !resp.success) {
          reject(new Error(resp && resp.error ? resp.error : 'AI汇总失败'));
          return;
        }
        resolve(String(resp.data || '').trim());
      });
    });
  }

  function dispatchFieldEvents(field) {
    ['input', 'change', 'blur'].forEach((type) => {
      field.dispatchEvent(new Event(type, { bubbles: true }));
    });
  }

  function writeSummary(text, reason) {
    const field = findSummaryField();
    if (!field) {
      Log.warn('未找到“上周总结”输入框');
      return { ok: false, reason: 'no-summary-field' };
    }
    if (!isFieldEditable(field)) {
      return { ok: false, reason: 'summary-readonly' };
    }
    if (document.activeElement === field && reason !== 'manual') {
      return { ok: false, reason: 'summary-focused' };
    }
    if (field.value === text) {
      return { ok: true, reason: 'unchanged' };
    }

    writeLock = true;
    field.value = text;
    field.dataset.seeyonWeeklyPlanGenerated = text;
    dispatchFieldEvents(field);
    writeLock = false;
    return { ok: true, reason: 'written' };
  }

  function getSummaryRows() {
    if (!isTargetPage()) return { ok: false, reason: 'not-target-page' };
    if (!hasRelatedLastWeekPlan()) {
      return { ok: false, reason: 'no-last-week-plan' };
    }

    const detail = findDetailTable();
    if (!detail) {
      Log.warn('未找到“上周工作明细”表格');
      return { ok: false, reason: 'no-detail-table' };
    }
    if (!isEditableMode(detail)) {
      return { ok: false, reason: 'readonly-page' };
    }

    const rows = parseRows(detail);
    if (!rows.length) {
      Log.warn('表格可汇总内容为空');
      return { ok: false, reason: 'empty-summary' };
    }
    const validation = validateFeedbacks(rows);
    if (!validation.ok) {
      return { ok: false, reason: 'invalid-feedback', message: validation.message };
    }

    return { ok: true, rows };
  }

  async function generateSummary(rows, isCurrentRun) {
    if (!isCurrentRun()) return { ok: false, reason: 'cancelled' };
    let text = '';
    try {
      appendSummaryLog('正在调用 AI 生成汇总内容。', 'processing');
      text = await requestAiSummary(rows);
      if (!isCurrentRun()) return { ok: false, reason: 'cancelled' };
      Log.info('AI二次提炼完成');
      appendSummaryLog('AI 汇总完成，正在写入上周总结。', 'success');
    } catch (error) {
      Log.warn('AI汇总失败，回退本地规则汇总:', error.message);
      appendSummaryLog('AI 汇总不可用，已切换本地规则汇总。', 'processing');
      text = buildFallbackSummary(rows);
    }
    if (!isCurrentRun()) return { ok: false, reason: 'cancelled' };
    if (!text) {
      Log.warn('表格可汇总内容为空');
      return { ok: false, reason: 'empty-summary' };
    }

    if (!isCurrentRun()) return { ok: false, reason: 'cancelled' };
    const result = writeSummary(text, 'manual');
    Log.info('汇总完成', { reason: 'manual', rows: rows.length, status: result.reason });
    return result;
  }

  function bindFabDrag(host, ball, menu, uiDocument) {
    const uiWindow = getOverlayWindow(uiDocument);
    const size = FAB_SIZE;
    const setPos = (left, top) => {
      host.style.left = Math.max(8, Math.min(uiWindow.innerWidth - size - 8, left)) + 'px';
      host.style.top = Math.max(8, Math.min(uiWindow.innerHeight - size - 8, top)) + 'px';
      host.style.right = 'auto';
      host.style.transform = 'none';
    };

    setPos(uiWindow.innerWidth - size - 18, defaultFabTop(uiWindow));
    uiWindow.addEventListener('resize', () => {
      setPos(
        parseFloat(host.style.left) || uiWindow.innerWidth - size - 18,
        parseFloat(host.style.top) || defaultFabTop(uiWindow)
      );
    });

    let pressing = false;
    let moved = false;
    let startX = 0;
    let startY = 0;
    let offsetX = 0;
    let offsetY = 0;
    let pointerId = null;

    const move = (event) => {
      if (!pressing || (pointerId !== null && event.pointerId !== pointerId)) return;
      event.preventDefault();
      if (!moved && Math.hypot(event.clientX - startX, event.clientY - startY) > 5) moved = true;
      if (moved) {
        menu.classList.remove('show');
        setPos(event.clientX - offsetX, event.clientY - offsetY);
      }
    };

    const end = (event) => {
      if (!pressing || (pointerId !== null && event.pointerId !== pointerId)) return;
      event.preventDefault();
      event.stopPropagation();
      pressing = false;
      uiDocument.removeEventListener('pointermove', move, true);
      uiDocument.removeEventListener('pointerup', end, true);
      uiDocument.removeEventListener('pointercancel', end, true);
      if (!moved) menu.classList.toggle('show');
      pointerId = null;
    };

    ball.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      event.stopPropagation();
      pressing = true;
      moved = false;
      pointerId = event.pointerId;
      startX = event.clientX;
      startY = event.clientY;
      const rect = host.getBoundingClientRect();
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      uiDocument.addEventListener('pointermove', move, true);
      uiDocument.addEventListener('pointerup', end, true);
      uiDocument.addEventListener('pointercancel', end, true);
    });
  }

  function ensureFab() {
    const uiDocument = getOverlayDocument();
    const existing = uiDocument.getElementById(FAB_ID);
    if (existing) return existing;

    const host = uiDocument.createElement('div');
    host.id = FAB_ID;
    host.style.cssText = 'position:fixed;right:18px;top:50%;transform:translateY(-50%);z-index:2147483646;';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        :host{font-family:"Microsoft YaHei",Arial,sans-serif;color:#111827}
        button{font:inherit}
        #ball{width:42px;height:42px;border:2px solid #fff;border-radius:50%;padding:0;background:#fff;box-shadow:0 4px 14px rgba(56,189,248,.45);cursor:grab;overflow:hidden;touch-action:none;user-select:none}
        #ball:active{cursor:grabbing}
        #ball img{width:42px;height:42px;display:block;object-fit:cover}
        #${MENU_ID}{position:absolute;right:54px;top:-8px;min-width:210px;padding:6px;background:#fff;border-radius:10px;box-shadow:0 8px 30px rgba(0,0,0,.18);display:none}
        #${MENU_ID}.show{display:block}
        .menu-action{display:flex;align-items:center;gap:10px;width:100%;padding:10px 12px;border:0;border-radius:8px;background:transparent;color:#1f2937;cursor:pointer;text-align:left}
        .menu-action:hover,.menu-action:focus-visible{background:#eff6ff;outline:none}
        .ico{font-size:15px;color:#64748b;line-height:1}
        .menu-action b{display:block;font-size:13px;color:#dc2626}
        .menu-action span{display:block;margin-top:2px;font-size:11px;color:#64748b}
      </style>
      <div id="${MENU_ID}">
        <button class="menu-action" id="weekly-plan-auto-summary" type="button">
          <span class="ico">▦</span>
          <span><b>自动汇总</b><span>汇总上周工作明细</span></span>
        </button>
      </div>
      <button id="ball" type="button" title="自动汇总" aria-label="自动汇总"><img id="logo" alt=""></button>
    `;
    uiDocument.documentElement.appendChild(host);

    const ball = shadow.getElementById('ball');
    const menu = shadow.getElementById(MENU_ID);
    const menuAction = shadow.getElementById('weekly-plan-auto-summary');
    const logo = shadow.getElementById('logo');
    try {
      logo.src = chrome.runtime.getURL('icons/fab-84.png');
    } catch (_) {}
    bindFabDrag(host, ball, menu, uiDocument);
    menuAction.addEventListener('click', () => {
      menu.classList.remove('show');
      showSummaryPanel(true);
    });
    return host;
  }

  function removeFab() {
    const uiDocument = getOverlayDocument();
    const fab = uiDocument.getElementById(FAB_ID);
    if (fab && fab.parentNode) fab.parentNode.removeChild(fab);
    const guide = uiDocument.getElementById(GUIDE_ID);
    if (guide && guide.parentNode) guide.parentNode.removeChild(guide);
    const panel = uiDocument.getElementById(PANEL_ID);
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
  }

  function bindSummaryPanelDrag(panel, uiDocument) {
    const uiWindow = getOverlayWindow(uiDocument);
    const header = panel.querySelector('#summary-panel-header');
    if (!header || panel.dataset.summaryDragBound === '1') return;
    panel.dataset.summaryDragBound = '1';

    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const moveTo = (left, top) => {
      const maxLeft = Math.max(0, uiWindow.innerWidth - panel.offsetWidth);
      const maxTop = Math.max(0, uiWindow.innerHeight - panel.offsetHeight);
      panel.style.left = `${clamp(left, 0, maxLeft)}px`;
      panel.style.top = `${clamp(top, 0, maxTop)}px`;
      panel.style.right = 'auto';
    };

    header.addEventListener('pointerdown', (event) => {
      if (event.target && event.target.closest && event.target.closest('button')) return;
      dragging = true;
      const rect = panel.getBoundingClientRect();
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      try { header.setPointerCapture(event.pointerId); } catch (_) {}
    });
    header.addEventListener('pointermove', (event) => {
      if (!dragging) return;
      moveTo(event.clientX - offsetX, event.clientY - offsetY);
    });
    const stop = (event) => {
      if (!dragging) return;
      dragging = false;
      try { header.releasePointerCapture(event.pointerId); } catch (_) {}
    };
    header.addEventListener('pointerup', stop);
    header.addEventListener('pointercancel', stop);
    uiWindow.addEventListener('resize', () => {
      const rect = panel.getBoundingClientRect();
      moveTo(rect.left, rect.top);
    });
  }

  function ensureSummaryPanel() {
    const uiDocument = getOverlayDocument();
    let panel = uiDocument.getElementById(PANEL_ID);
    if (panel) return panel;

    panel = uiDocument.createElement('section');
    panel.id = PANEL_ID;
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', '自动汇总');
    panel.hidden = true;
    panel.style.cssText = [
      'position:fixed',
      `right:${PANEL_DEFAULT_RIGHT}px`,
      `top:${PANEL_DEFAULT_TOP}px`,
      'width:440px',
      'max-width:calc(100vw - 32px)',
      'box-sizing:border-box',
      'max-height:calc(100vh - 16px)',
      'padding:12px',
      'background:#fff',
      'border:1px solid #e5e7eb',
      'border-radius:8px',
      'box-shadow:0 18px 50px rgba(15,23,42,.22)',
      'z-index:2147483647',
      'font-family:"Microsoft YaHei",Arial,sans-serif',
      'color:#111827'
    ].join(';');
    panel.innerHTML = `
      <style>
        #${PANEL_ID} .panel-header{display:flex;align-items:center;justify-content:space-between;margin:-12px -12px 12px;padding:10px 12px;background:#f8fafc;border-bottom:1px solid #e5e7eb;cursor:move;user-select:none}
        #${PANEL_ID} .panel-header b{font-size:14px}
        #${PANEL_ID} .close{width:24px;height:24px;border:0;border-radius:6px;background:transparent;color:#64748b;font-size:16px;cursor:pointer}
        #${PANEL_ID} .close:hover,#${PANEL_ID} .close:focus-visible{background:#f1f5f9;outline:none}
        #${PANEL_ID} .status{min-height:18px;margin-bottom:12px;color:#64748b;font-size:12px;line-height:1.5}
        #${PANEL_ID} .status.error{color:#dc2626}
        #${PANEL_ID} .status.success{color:#15803d}
        #${PANEL_ID} .summary-log{max-height:300px;margin-bottom:12px;padding:7px 9px;overflow:auto;background:#f8fafc;border:1px solid #e5e7eb;border-radius:6px;color:#64748b;font-size:12px;line-height:1.5}
        #${PANEL_ID} .summary-log:empty:before{content:"等待执行自动汇总";color:#94a3b8}
        #${PANEL_ID} .log-entry{padding:2px 0}
        #${PANEL_ID} .log-entry.error{color:#dc2626}
        #${PANEL_ID} .log-entry.success{color:#15803d}
        #${PANEL_ID} .actions{display:flex;justify-content:flex-end}
        #${PANEL_ID} .primary{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-width:92px;height:30px;padding:0 12px;border:1px solid #2563eb;border-radius:6px;background:#2563eb;color:#fff;font-size:12px;cursor:pointer}
        #${PANEL_ID} .primary:hover:not(:disabled),#${PANEL_ID} .primary:focus-visible:not(:disabled){background:#1d4ed8;outline:none}
        #${PANEL_ID} .primary:disabled{cursor:wait;opacity:.72}
        #${PANEL_ID} .spinner{width:12px;height:12px;border:2px solid rgba(255,255,255,.42);border-top-color:#fff;border-radius:50%;animation:weekly-plan-spin .8s linear infinite}
        @keyframes weekly-plan-spin{to{transform:rotate(360deg)}}
        @media (prefers-reduced-motion:reduce){#${PANEL_ID} .spinner{animation:weekly-plan-pulse 1.2s ease-in-out infinite}@keyframes weekly-plan-pulse{50%{opacity:.4}}}
      </style>
      <div class="panel-header" id="summary-panel-header"><b>自动汇总</b><button class="close" id="close-panel" type="button" aria-label="关闭">x</button></div>
      <div class="status" id="summary-status" aria-live="polite"></div>
      <div class="summary-log" id="summary-log" aria-live="polite"></div>
      <div class="actions"><button class="primary" id="run-summary" type="button">自动汇总</button></div>
    `;
    uiDocument.documentElement.appendChild(panel);
    bindSummaryPanelDrag(panel, uiDocument);
    panel.querySelector('#close-panel').addEventListener('click', () => {
      panel.hidden = true;
    });
    panel.querySelector('#run-summary').addEventListener('click', runManualSummary);
    return panel;
  }

  function summaryPanelElements() {
    const panel = getOverlayDocument().getElementById(PANEL_ID);
    if (!panel) return {};
    return {
      panel,
      status: panel.querySelector('#summary-status'),
      log: panel.querySelector('#summary-log'),
      button: panel.querySelector('#run-summary')
    };
  }

  function positionSummaryPanel(panel) {
    if (!panel || panel.dataset.summaryPositioned === '1') return;

    panel.style.left = 'auto';
    panel.style.top = `${PANEL_DEFAULT_TOP}px`;
    panel.style.right = `${PANEL_DEFAULT_RIGHT}px`;
    panel.style.transform = 'none';
    panel.dataset.summaryPositioned = '1';
  }

  function clearSummaryLog() {
    const log = summaryPanelElements().log;
    if (log) log.innerHTML = '';
  }

  function resetSummaryPanel() {
    clearSummaryLog();
    setSummaryStatus('', '');
    setSummaryBusy(false);
  }

  function appendSummaryLog(text, type) {
    const log = summaryPanelElements().log;
    if (!log || !text) return;
    const entry = getOverlayDocument().createElement('div');
    entry.className = `log-entry${type ? ` ${type}` : ''}`;
    entry.textContent = text;
    log.appendChild(entry);
    log.scrollTop = log.scrollHeight;
  }

  function showSummaryPanel(resetLog) {
    const panel = ensureSummaryPanel();
    panel.hidden = false;
    positionSummaryPanel(panel);
    if (resetLog) {
      resetSummaryPanel();
      appendSummaryLog('已打开自动汇总，等待开始校验。');
    }
  }

  function setSummaryStatus(text, type) {
    const status = summaryPanelElements().status;
    if (!status) return;
    status.textContent = text || '';
    status.className = `status${type ? ` ${type}` : ''}`;
    if (text) appendSummaryLog(text, type);
  }

  function setSummaryBusy(busy) {
    const button = summaryPanelElements().button;
    if (!button) return;
    if (busy) {
      button.textContent = '终止汇总';
      return;
    }
    button.textContent = '自动汇总';
  }

  function cancelManualSummary() {
    if (!aiBusy) return;
    summaryRunId += 1;
    aiBusy = false;
    setSummaryBusy(false);
    setSummaryStatus('已终止本次自动汇总。');
  }

  async function runManualSummary() {
    if (aiBusy) {
      cancelManualSummary();
      return;
    }
    appendSummaryLog('开始校验上周工作明细。', 'processing');
    const summary = getSummaryRows();
    if (!summary.ok) {
      const messages = {
        'not-target-page': '当前页面不是可汇总的周工作计划。',
        'no-last-week-plan': '请先关联上周计划后再汇总。',
        'no-detail-table': '未找到上周工作明细表格。',
        'readonly-page': '当前周工作计划不可编辑。',
        'empty-summary': '上周工作明细为空，暂时无法汇总。',
        'invalid-feedback': summary.message
      };
      showSummaryPanel(false);
      setSummaryStatus(messages[summary.reason] || '暂时无法汇总，请刷新页面后重试。', 'error');
      return;
    }

    const runId = ++summaryRunId;
    aiBusy = true;
    appendSummaryLog(`校验通过，共${summary.rows.length}条工作明细。`, 'success');
    setSummaryStatus('汇总中，请稍后');
    setSummaryBusy(true);
    try {
      const result = await generateSummary(summary.rows, () => runId === summaryRunId);
      if (runId !== summaryRunId || result.reason === 'cancelled') return;
      setSummaryStatus(result.ok ? '已写入上周总结。' : '未能写入上周总结，请确认页面仍可编辑。', result.ok ? 'success' : 'error');
    } catch (error) {
      if (runId !== summaryRunId) return;
      Log.warn('手动汇总失败:', error.message);
      setSummaryStatus('汇总失败，请稍后重试。', 'error');
    } finally {
      if (runId === summaryRunId) {
        aiBusy = false;
        setSummaryBusy(false);
      }
    }
  }

  function bindWatchers() {
    if (observer || !document.body) return;

    observer = new MutationObserver(() => {
      if (writeLock) return;
      if (scheduleTimer) clearTimeout(scheduleTimer);
      scheduleTimer = setTimeout(() => bootstrap('mutation'), 300);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function startHeartbeat() {
    if (heartbeatTimer) return;
    heartbeatTimer = setInterval(() => {
      if (activated) {
        clearInterval(heartbeatTimer);
        heartbeatTimer = null;
        return;
      }
      bootstrap('heartbeat');
    }, 1000);
  }

  function bootstrap(reason) {
    if (!document.body) return;
    bindWatchers();
    if (!isTargetPage()) {
      if (activated) removeFab();
      activated = false;
      Log.debug('周工作计划页特征未就绪', reason || 'bootstrap');
      return;
    }
    const detail = findDetailTable();
    if (!isEditableMode(detail)) {
      if (activated) removeFab();
      activated = false;
      Log.info('检测到已发/已办只读周工作计划页，功能不执行');
      return;
    }
    activated = true;
    ensureFab();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => bootstrap('domcontentloaded'), { once: true });
  } else {
    bootstrap('immediate');
  }
  window.addEventListener('load', () => bootstrap('load'), { once: true });
  setTimeout(() => bootstrap('delayed-1200'), 1200);
  setTimeout(() => bootstrap('delayed-3000'), 3000);
  startHeartbeat();
})();
