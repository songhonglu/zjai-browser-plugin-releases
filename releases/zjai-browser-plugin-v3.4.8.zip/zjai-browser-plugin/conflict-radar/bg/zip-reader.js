// 依赖无关的最小归档 reader（zip + tar）。
// 冲突检测只需文件「路径列表」，因此只解析中央目录(Central Directory)/tar 头取文件名，
// 不解压文件内容 —— 无需 DecompressionStream/pako，零依赖。
// 支持：标准 ZIP、ZIP64、TAR(ustar, 含 GNU 长文件名 'L' / PAX 'x' path)、UTF-8 文件名、目录条目跳过。
import { normalizePath } from './util.js';

const SIG_EOCD = 0x06054b50;       // End of Central Directory
const SIG_CD = 0x02014b50;         // Central Directory entry
const SIG_EOCD64 = 0x06064b50;     // ZIP64 End of Central Directory
const SIG_EOCD64_LOC = 0x07064b50; // ZIP64 EOCD Locator
const UTF8_FLAG = 0x800;

const utf8 = new TextDecoder('utf-8');
const gb18030 = new TextDecoder('gb18030');

function decodeZipName(nameBytes, flags) {
  // ZIP 通用位第 11 位表示 UTF-8；未置位时，Windows/国产打包工具常用 GBK/GB18030。
  const dec = (flags & UTF8_FLAG) ? utf8 : gb18030;
  return dec.decode(nameBytes);
}

// 小端 64 位整数（zip 大小/偏移远小于 2^53，用 Number 安全）
function readUint64LE(dv, off) {
  const lo = dv.getUint32(off, true);
  const hi = dv.getUint32(off + 4, true);
  return hi * 0x100000000 + lo;
}

/**
 * @param {ArrayBuffer} arrayBuffer
 * @returns {Promise<{path:string}[]>} 压缩包内普通文件的相对路径列表（已归一化、去目录条目）
 */
export async function readZipEntries(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  if (bytes.length < 22) throw new Error('zip: 文件过小，非有效 zip');
  const dv = new DataView(arrayBuffer);

  // 1) 从尾部查找 EOCD（注释区最长 65535）
  let eocd = -1;
  const floor = Math.max(0, bytes.length - 65557);
  for (let i = bytes.length - 22; i >= floor; i--) {
    if (dv.getUint32(i, true) === SIG_EOCD) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('zip: 未找到 EOCD，可能不是 zip 或已损坏');

  let cdCount = dv.getUint16(eocd + 10, true);
  let cdOffset = dv.getUint32(eocd + 16, true);

  // 2) ZIP64：常规字段为哨兵值(0xffff / 0xffffffff)时，从 ZIP64 EOCD 取真实值
  if (cdCount === 0xffff || cdOffset === 0xffffffff) {
    const locOff = eocd - 20;
    if (locOff >= 0 && dv.getUint32(locOff, true) === SIG_EOCD64_LOC) {
      const zOff = readUint64LE(dv, locOff + 8);
      if (zOff + 56 <= bytes.length && dv.getUint32(zOff, true) === SIG_EOCD64) {
        if (cdCount === 0xffff) cdCount = readUint64LE(dv, zOff + 32); // 总条目数
        if (cdOffset === 0xffffffff) cdOffset = readUint64LE(dv, zOff + 48); // 中央目录偏移
      } else {
        throw new Error('zip: ZIP64 EOCD 记录异常');
      }
    }
  }

  // 3) 遍历中央目录条目，取文件名（ZIP64 的每条目扩展字段按 extraLen 跳过即可）
  const files = [];
  let p = cdOffset;
  for (let i = 0; i < cdCount; i++) {
    if (p + 46 > bytes.length || dv.getUint32(p, true) !== SIG_CD) {
      throw new Error(`zip: 中央目录签名异常 @${p}（已解析 ${files.length}/${cdCount}）`);
    }
    const nameLen = dv.getUint16(p + 28, true);
    const extraLen = dv.getUint16(p + 30, true);
    const commentLen = dv.getUint16(p + 32, true);
    const flags = dv.getUint16(p + 8, true);
    const nameBytes = bytes.subarray(p + 46, p + 46 + nameLen);
    const rawName = decodeZipName(nameBytes, flags);
    // 目录条目：Windows 压缩工具可能以 '\' 结尾，需同时识别 '/' 与 '\'。
    const isDir = /[/\\]$/.test(rawName);
    if (!isDir) {
      const np = normalizePath(rawName);
      if (np) files.push({ path: np });
    }
    p += 46 + nameLen + extraLen + commentLen;
  }
  return files;
}

// ---- TAR ----
const tarDec = new TextDecoder('utf-8');

/** 判断 ArrayBuffer 是否为 tar（ustar magic @257）。 */
export function isTar(buf) {
  const b = new Uint8Array(buf);
  if (b.length < 262) return false;
  return b[257] === 0x75 && b[258] === 0x73 && b[259] === 0x74 && b[260] === 0x61 && b[261] === 0x72; // 'u','s','t','a','r'
}

/**
 * 解析 tar，返回普通文件路径列表。支持 GNU 长文件名(typeflag 'L')与 PAX path(typeflag 'x'/'g')。
 * @param {ArrayBuffer} arrayBuffer
 * @returns {Promise<{path:string}[]>}
 */
export async function readTarEntries(arrayBuffer) {
  const b = new Uint8Array(arrayBuffer);
  const readStr = (start, len) => tarDec.decode(b.subarray(start, start + len)).split('\0')[0];
  const files = [];
  let p = 0;
  let pendingName = null;
  while (p + 512 <= b.length) {
    let zero = true;
    for (let i = p; i < p + 512; i++) { if (b[i] !== 0) { zero = false; break; } }
    if (zero) break; // 全零块 = 结束

    const name100 = readStr(p, 100);
    const size = parseInt(readStr(p + 124, 12).trim(), 8) || 0; // 八进制
    const typeflag = String.fromCharCode(b[p + 156]);
    const prefix = readStr(p + 345, 155);
    const dataStart = p + 512;
    const dataLen = Math.ceil(size / 512) * 512;

    if (typeflag === 'L') {
      // GNU 长文件名：数据块是下一条目的真实文件名
      pendingName = readStr(dataStart, size);
    } else if (typeflag === 'x' || typeflag === 'g') {
      // PAX 扩展头：解析 path= 记录（格式 "len key=value\n"）
      const pax = tarDec.decode(b.subarray(dataStart, dataStart + size));
      let off = 0;
      while (off < pax.length) {
        const sp = pax.indexOf(' ', off);
        if (sp < 0) break;
        const recLen = parseInt(pax.slice(off, sp), 10);
        if (!recLen || off + recLen > pax.length + off) break;
        const rec = pax.slice(off, off + recLen);
        const eq = rec.indexOf('=');
        if (eq > 0) {
          const key = rec.slice(sp + 1, eq);
          const val = rec.slice(eq + 1).replace(/\n$/, '');
          if (key === 'path') pendingName = val;
        }
        off += recLen;
      }
    } else {
      let name = pendingName || (prefix ? prefix + '/' + name100 : name100);
      pendingName = null;
      const isDir = typeflag === '5' || /[/\\]$/.test(name);
      if (!isDir && name) {
        const np = normalizePath(name);
        if (np) files.push({ path: np });
      }
    }
    p = dataStart + dataLen;
  }
  return files;
}

// ---- RAR ----
// 冲突检测只需文件名列表，故只解析 RAR 块头取文件名，不解压内容、零依赖。
// RAR 是私有格式，无开放规范；这里据 RAR5 技术说明 + RAR4 块结构实现「头部取文件名」：
//   RAR5（签名 ...01 00）：vint 变长整数编码的块头，文件名在 File 头内明文；
//   RAR4（签名 ...00）   ：定长字段的块头，文件名在 File 头(0x74)内明文。
// 局限：头部加密（RAR5「加密文件名」/ 出现 Encryption 头）→ 抛错回退手工。
const SIG_RAR5 = [0x52, 0x61, 0x72, 0x21, 0x1a, 0x07, 0x01, 0x00];
const SIG_RAR4 = [0x52, 0x61, 0x72, 0x21, 0x1a, 0x07, 0x00];

function bytesEq(b, off, sig) {
  if (off + sig.length > b.length) return false;
  for (let i = 0; i < sig.length; i++) if (b[off + i] !== sig[i]) return false;
  return true;
}

/** 判断 ArrayBuffer 是否为 rar（RAR4 或 RAR5 签名）。 */
export function isRar(buf) {
  const b = new Uint8Array(buf);
  return bytesEq(b, 0, SIG_RAR5) || bytesEq(b, 0, SIG_RAR4);
}

// RAR5 变长整数：每字节低 7 位、小端拼接，最高位(0x80)=继续。用乘法累加避免 << 的 32 位截断。
function rarVint(b, off) {
  let v = 0, mult = 1, n = 0;
  for (;;) {
    if (off + n >= b.length) throw new Error('rar5 vint 越界 @' + off);
    const x = b[off + n]; n++;
    v += (x & 0x7f) * mult;
    if (v > Number.MAX_SAFE_INTEGER) throw new Error('rar5 vint 超出安全整数范围');
    if (!(x & 0x80)) break;
    mult *= 128;
    if (n > 10) throw new Error('rar5 vint 过长');
  }
  return { value: v, len: n };
}

function readRar5Entries(arrayBuffer) {
  const b = new Uint8Array(arrayBuffer);
  const files = [];
  let p = 8; // 跳过 8 字节签名
  let guard = 0;
  while (p + 4 < b.length && guard++ < 500000) {
    const hsStart = p + 4; // 跳过 4 字节 CRC
    const hs = rarVint(b, hsStart);
    const headerEnd = hsStart + hs.len + hs.value; // HeaderSize 不含其自身 vint
    if (headerEnd > b.length) throw new Error('rar5 头部越界');
    let c = hsStart + hs.len;
    const type = rarVint(b, c); c += type.len;
    const hflags = rarVint(b, c); c += hflags.len;
    let dataSize = 0;
    if (hflags.value & 0x0001) { const e = rarVint(b, c); c += e.len; } // extra area size（跳过）
    if (hflags.value & 0x0002) { const d = rarVint(b, c); dataSize = d.value; c += d.len; } // data area size
    if (type.value === 4) throw new Error('rar5 头部加密（加密文件名），无法读取');
    if (type.value === 2) { // File
      const ff = rarVint(b, c); c += ff.len;       // file_flags
      const unp = rarVint(b, c); c += unp.len;      // unpacked_size
      const attr = rarVint(b, c); c += attr.len;    // attributes
      if (ff.value & 0x0002) c += 4;                // mtime（uint32）
      if (ff.value & 0x0004) c += 4;                // data_crc（uint32）
      const comp = rarVint(b, c); c += comp.len;    // compression_info
      const host = rarVint(b, c); c += host.len;    // host_os
      const nlen = rarVint(b, c); c += nlen.len;    // name_length
      if (c + nlen.value > headerEnd) throw new Error('rar5 文件名越界');
      const rawName = utf8.decode(b.subarray(c, c + nlen.value));
      const isDir = !!(ff.value & 0x0001);
      if (!isDir) { const np = normalizePath(rawName); if (np) files.push({ path: np }); }
    }
    if (type.value === 5) break; // End of archive
    const dataEnd = headerEnd + dataSize;
    if (dataEnd <= p) break; // 无推进则停止，防死循环
    p = dataEnd;
  }
  return files;
}

function readRar4Entries(arrayBuffer) {
  const b = new Uint8Array(arrayBuffer);
  const dv = new DataView(arrayBuffer);
  const files = [];
  let p = 7; // 跳过 7 字节签名
  let guard = 0;
  while (p + 7 <= b.length && guard++ < 500000) {
    const type = b[p + 2];
    const flags = dv.getUint16(p + 3, true);
    const headSize = dv.getUint16(p + 5, true);
    if (headSize < 7 || p + headSize > b.length) throw new Error('rar4 HEAD_SIZE 异常');
    const addSize = (flags & 0x8000) ? dv.getUint32(p + 7, true) : 0; // LONG_BLOCK：附加数据大小
    if (type === 0x74) { // File
      const nameSize = dv.getUint16(p + 26, true);
      const nameOff = p + ((flags & 0x0100) ? 40 : 32); // LARGE_FILE 标志：多 8 字节高 32 位尺寸
      if (nameOff + nameSize > p + headSize) throw new Error('rar4 文件名越界');
      const rawName = utf8.decode(b.subarray(nameOff, nameOff + nameSize));
      const isDir = /[/\\]$/.test(rawName);
      if (!isDir) { const np = normalizePath(rawName); if (np) files.push({ path: np }); }
    } else if (type === 0x7b) { break; } // End of archive
    p += headSize + addSize;
  }
  return files;
}

/**
 * 解析 rar，返回普通文件路径列表（RAR5 / RAR4）。
 * 头部加密或结构异常会抛错，调用方据此回退「手工处理」。
 * @param {ArrayBuffer} arrayBuffer
 * @returns {Promise<{path:string}[]>}
 */
export async function readRarEntries(arrayBuffer) {
  const b = new Uint8Array(arrayBuffer);
  if (bytesEq(b, 0, SIG_RAR5)) return readRar5Entries(arrayBuffer);
  if (bytesEq(b, 0, SIG_RAR4)) return readRar4Entries(arrayBuffer);
  throw new Error('非 RAR 归档');
}
