// 补丁包（.pak）产物名 → 源码名 推导。
// .pak = 致远官方补丁包，本质是加密 ZIP，装的是后端 jar 里编译后的 .class。
// readZipEntries 已能无密码读出其文件名清单（传统 ZIP 加密只加密文件数据、不加密中央目录）；
// 本模块把这些产物名「推回」源码名，再交给 detectConflicts 与客开仓库比对。
//
// 推导规则（docs/update3.md §二，已在 dist/ 两真包上验证）：
//   <xxx>.jar/com/seeyon/.../FormulaOrgFunction$1.class -> com/seeyon/.../FormulaOrgFunction.java（去 jar 前缀 + 内部类折叠 + .class→.java）
//   <xxx>.jar/com/seeyon/.../FormulaOrgFunction.class   -> com/seeyon/.../FormulaOrgFunction.java（与上一行折叠去重）
//   其他文件（.jsp / .xml …）-> 取 basename
//   check.crc / patch.properties 为 PAK 自带版本元信息，每个 PAK 都有，忽略不参与比对
import { normalizePath, basename } from './util.js';

// 去除开头的「<name>.jar/」类归档前缀，贴合仓库 com/seeyon/.../*.java 相对路径，利于路径尾部命中
const ARCHIVE_PREFIX_RE = /^[^/]+\.(?:jar|zip|war|ear)\//i;
const CLASS_RE = /\.class$/i;
// PAK 自带的版本/校验元信息，每个 PAK 都有，与客开源码无关，直接忽略不参与比对
const PAK_META_BASE = new Set(['check.crc', 'patch.properties']);

/**
 * 把 readZipEntries 的 [{path}] 映射为源码文件列表。
 * @param {{path?:string}[]} entries readZipEntries 输出
 * @returns {{path:string, name:string, orig:string}[]} orig 为归一化后的原始条目路径，用于冲突项溯源展示
 */
export function pakEntriesToSourceFiles(entries) {
  const out = [];
  const seen = new Set(); // 按映射后 path 去重（内部类 $1/$Inner 折叠到主类后归并）
  for (const e of entries || []) {
    const orig = normalizePath(e && e.path) || '';
    if (!orig) continue;

    // 去归档前缀后判定是否 .class
    const stripped = orig.replace(ARCHIVE_PREFIX_RE, '');
    const base = basename(stripped);
    // 忽略 PAK 自带元信息（check.crc / patch.properties），它们不参与比对
    if (PAK_META_BASE.has(base.toLowerCase())) continue;
    let mapped;
    if (CLASS_RE.test(stripped)) {
      // .class -> .java，并折叠内部类（Foo$1 / Foo$Bar / Foo$Bar$1 -> Foo）
      const nameNoExt = base.replace(CLASS_RE, '').replace(/\$.+$/, '');
      const dir = stripped.slice(0, stripped.length - base.length); // 保留包路径
      mapped = normalizePath(dir + nameNoExt + '.java');
    } else {
      // 其他文件：取 basename 参与比对（check.crc / patch.properties 等几乎不会命中，无害）
      mapped = normalizePath(base);
    }
    if (!mapped || seen.has(mapped)) continue;
    seen.add(mapped);
    out.push({ path: mapped, name: basename(mapped), orig });
  }
  return out;
}
