// 各域名接口封装（方案 §9 接口清单）。
// 所有请求经 background 发起：host_permissions 内域名会自动携带 cookie（credentials:'include'）。
import { safeGet, basename, normalizePath } from './util.js';

const URL_CREATE_EDIT = 'https://xt.seeyon.com/seeyon/rest/cap4/form/createOrEdit';
const URL_BASE_INFO = 'https://xt.seeyon.com/seeyon/rest/collaboration/v1/web/new/baseInfo';
const URL_STUDIO_PROFILE = 'http://studio.kk.seeyon.com/system/user/profile';
const URL_STUDIO_CUSTOM = 'http://studio.kk.seeyon.com/system/customizationInfo/list';
const URL_GITLAB_USER = 'http://gitlab.kk.seeyon.com/api/v4/user';
const gitlabFilesUrl = (dog, branch) =>
  `http://gitlab.kk.seeyon.com/customize/${encodeURIComponent(dog)}/v5/-/files/${encodeURIComponent(branch)}?format=json`;

// ---- 日志：默认打到 SW 控制台；service-worker 会 setLogger 把日志同时转发到页面控制台/面板 ----
let _log = (...a) => console.log('[kk-helper:conflict-radar][bg]', ...a);
export function setLogger(fn) { if (typeof fn === 'function') _log = fn; }
function bodyPreview(opts) {
  if (!opts || !opts.body) return '';
  return ' body=' + String(opts.body).slice(0, 300);
}
// 深度收集所有含 showValue 的节点路径（用于定位加密狗号字段）
function findShowValues(obj, path, out, depth) {
  if (depth > 8 || !obj || typeof obj !== 'object') return;
  for (const k of Object.keys(obj)) {
    const v = obj[k];
    if (v && typeof v === 'object' && Object.prototype.hasOwnProperty.call(v, 'showValue')) {
      out.push(path + '/' + k + ' => ' + JSON.stringify(v.showValue));
    }
    if (v && typeof v === 'object') findShowValues(v, path + '/' + k, out, depth + 1);
  }
}
// 兼容多种响应结构定位 fieldInfo（spec: data.datatableInfo...；实测: data.data.tableInfo...）
function findFieldInfo(json) {
  const candidates = [
    ['data', 'data', 'tableInfo', 'formmain', 'fieldInfo'],
    ['data', 'datatableInfo', 'formmain', 'fieldInfo'],
    ['data', 'tableInfo', 'formmain', 'fieldInfo'],
    ['datatableInfo', 'formmain', 'fieldInfo'],
  ];
  for (const path of candidates) {
    const fi = safeGet(json, ...path);
    if (fi && typeof fi === 'object') return { path: path.join('.'), fieldInfo: fi };
  }
  return null;
}

async function fetchText(url, opts = {}) {
  _log('→', opts.method || 'GET', url + bodyPreview(opts));
  const res = await fetch(url, { credentials: 'include', ...opts });
  const text = await res.text();
  _log('←', res.status, url, 'len=' + text.length);
  return { ok: res.ok, status: res.status, text };
}

function extractCap4FieldFromText(jsonText, fieldName) {
  if (typeof jsonText !== 'string' || !jsonText) return '';

  let cap4Start = jsonText.indexOf('"cap4"');
  if (cap4Start < 0) cap4Start = jsonText.indexOf('\\"cap4\\"');
  if (cap4Start < 0) return '';

  const keys = ['"' + fieldName + '"', '\\"' + fieldName + '\\"'];
  let keyPos = -1;
  let keyLen = 0;
  for (let k = 0; k < keys.length; k++) {
    keyPos = jsonText.indexOf(keys[k], cap4Start);
    if (keyPos >= 0) {
      keyLen = keys[k].length;
      break;
    }
  }
  if (keyPos < 0) return '';

  const colon = jsonText.indexOf(':', keyPos + keyLen);
  if (colon < 0) return '';

  let i = colon + 1;
  while (i < jsonText.length && /\s/.test(jsonText.charAt(i))) i++;

  const escapedQuote = jsonText.charAt(i) === '\\' && jsonText.charAt(i + 1) === '"';
  if (jsonText.charAt(i) === '"' || escapedQuote) {
    if (escapedQuote) i++;
    i++;
    let out = '';
    while (i < jsonText.length) {
      const ch = jsonText.charAt(i);
      if (ch === '\\') {
        const next = jsonText.charAt(i + 1);
        if (next === '"') break;
        out += next || '';
        i += 2;
        continue;
      }
      if (ch === '"') break;
      out += ch;
      i++;
    }
    return out;
  }

  const start = i;
  while (i < jsonText.length && /[-0-9.]/.test(jsonText.charAt(i))) i++;
  return jsonText.slice(start, i);
}

async function fetchJson(url, opts = {}) {
  _log('→', opts.method || 'GET', url + bodyPreview(opts));
  const res = await fetch(url, { credentials: 'include', ...opts });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch (_) { json = null; }
  _log('←', res.status, url, json ? ('keys=[' + Object.keys(json).slice(0, 25).join(',') + ']') : ('non-json len=' + text.length + ' head=' + text.slice(0, 150)));
  return { ok: res.ok, status: res.status, json, text };
}

export async function getBaseInfoParams(affairId) {
  const affairIdText = String(affairId || '');
  if (!affairIdText) throw new Error('缺少 affairId，无法获取 moduleId/rightId');

  const url = URL_BASE_INFO + '?method=summary&openFrom=listDone&affairId=' + encodeURIComponent(affairIdText) + '&showTab=true&templateId=&from=listDone&projectId=&summaryId=&baseObjectId=&baseApp=&cashId=&processId=&designId=&docId=&_r=';
  _log('baseInfo 获取参数 affairId=' + affairIdText);
  const { ok, status, json, text } = await fetchJson(url);
  if (!ok || !json) {
    _log('baseInfo 失败 affairId=' + affairIdText + ' status=' + status + ' body前500=' + String(text).slice(0, 500));
    throw new Error(`baseInfo 请求失败 ${status}：${String(text).slice(0, 120)}`);
  }

  const data = json && json.data;
  const cap4 = data && data.zwIframe && data.zwIframe.cap4;
  let moduleId = cap4 && cap4.moduleId;
  let rightId = cap4 && cap4.rightId;

  const rawModuleId = extractCap4FieldFromText(text, 'moduleId');
  const rawRightId = extractCap4FieldFromText(text, 'rightId');
  // 必须优先使用原始文本值：moduleId/rightId 是超长 ID，JSON.parse 后即使有值也可能已精度丢失
  moduleId = rawModuleId || moduleId;
  rightId = rawRightId || rightId;

  moduleId = moduleId != null ? String(moduleId) : '';
  rightId = rightId != null ? String(rightId) : '';

  if (!moduleId || !rightId) {
    _log('baseInfo 缺 moduleId/rightId affairId=' + affairIdText,
      'topKeys=' + Object.keys(json || {}).join(','),
      'dataKeys=' + ((data && typeof data === 'object') ? Object.keys(data).join(',') : '(无data)'),
      'zwIframeKeys=' + ((data && data.zwIframe && typeof data.zwIframe === 'object') ? Object.keys(data.zwIframe).join(',') : '(无zwIframe)'),
      'cap4=' + JSON.stringify(cap4 || null));
    throw new Error('baseInfo 未返回 moduleId/rightId');
  }

  _log('baseInfo 参数获取成功 affairId=' + affairIdText + ' moduleId=' + moduleId + ' rightId=' + rightId.slice(0, 24) + '…');
  return { affairId: affairIdText, moduleId, rightId };
}


/** 下载附件，返回 ArrayBuffer。 */
export async function downloadAttachment(url) {
  const res = await fetch(url, { credentials: 'include' });
  if (!res.ok) throw new Error(`附件下载失败 ${res.status}：${url}`);
  return res.arrayBuffer();
}

/** 判断 ArrayBuffer 是否为 zip（PK 头）。 */
export function isZip(buf) {
  const b = new Uint8Array(buf.slice(0, 4));
  return b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;
}

/** 取加密狗号（方案 §6 Step2）。 */
export async function getDongleNumber({ moduleId, rightId, affairId }) {
  if (!moduleId || !rightId || !affairId) {
    throw new Error(`取参不完整：moduleId/rightId/affairId 缺失（${moduleId}|${rightId}|${affairId}）`);
  }
  const payload = {
    v: 'V11_xx', hasSignAction: 'false', type: 'browse',
    rightId, moduleId, isSubFlow: 'false', moduleType: '1',
    nodeName: 'KK_%E5%AE%A2%E5%BC%80BUG%E4%BF%AE%E6%94%B9%E4%BA%BA',
    affairId, flowListAppId: '', flowListButtonId: '',
    flowBatchDealAffairIds: '', operateType: '2', forceDb: true, cacheRecoveryId: '',
  };
  _log('createOrEdit 入参 moduleId=' + moduleId + ' rightId=' + rightId + ' affairId=' + affairId);
  const { ok, status, json, text } = await fetchJson(URL_CREATE_EDIT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json;charset=UTF-8' },
    body: JSON.stringify(payload),
  });
  if (!ok || !json) {
    _log('createOrEdit 非 JSON 或失败，原文前 500：', String(text).slice(0, 500));
    throw new Error(`createOrEdit 请求失败 ${status}：${String(text).slice(0, 120)}`);
  }
  // 兼容多种响应结构定位 fieldInfo（spec: data.datatableInfo...；实测: data.data.tableInfo...）
  const found = findFieldInfo(json);
  if (!found) {
    _log('createOrEdit 未能定位 fieldInfo；顶层键=', Object.keys(json).join(','),
      '；data 键=', (json.data && typeof json.data === 'object') ? Object.keys(json.data).join(',') : '(非对象)');
    throw new Error('工单中未找到加密狗号，无法匹配 Git 仓库代码进行比对。');
  }
  const fi = found.fieldInfo;
  const dog = fi.field1425 && fi.field1425.showValue;
  if (dog) {
    _log('加密狗号取得（路径 ' + found.path + '.field1425）：', dog);
    return String(dog).trim();
  }
  // 诊断：列出全部字段键及字段级 showValue，便于定位真实狗号字段
  const fieldKeys = Object.keys(fi).filter((k) => /^field\d+$/i.test(k));
  _log('createOrEdit fieldInfo 路径=' + found.path + '；字段键(' + fieldKeys.length + ')：', fieldKeys.join(','));
  const shows = fieldKeys.map((k) => k + '=' + JSON.stringify(fi[k] && fi[k].showValue));
  _log('createOrEdit 各字段 showValue：', shows.join('  |  '));
  throw new Error('工单中未找到加密狗号，无法匹配 Git 仓库代码进行比对。');
}

/** ctpStudio 登录检查（方案 §6 Step3.1）。 */
export async function checkStudioLogin() {
  const { ok, text } = await fetchText(URL_STUDIO_PROFILE);
  if (!ok) return { loggedIn: false, userName: '' };
  const userName = parseInputValue(text, 'userName') || '';
  return { loggedIn: !!userName.trim(), userName: userName.trim() };
}

/** 查询客开项目（方案 §6 Step3.2）。 */
export async function queryCustomization(dogNum) {
  const body = new URLSearchParams({
    pageSize: '20', pageNum: '1', orderByColumn: 'updateTime', isAsc: 'desc',
    customerName: '', dogNum: String(dogNum), area: '', creator: '',
    productLine: '', productVersion: '', buildid: '', businessLine: '',
  });
  const { ok, status, json, text } = await fetchJson(URL_STUDIO_CUSTOM, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
    body: body.toString(),
  });
  if (!ok || !json) throw new Error(`customizationInfo 请求失败 ${status}：${text.slice(0, 120)}`);
  const total = Number(safeGet(json, 'total') || 0);
  const rows = Array.isArray(safeGet(json, 'rows')) ? json.rows : [];
  return { total, rows };
}

/** GitLab 登录检查（方案 §6 Step4.1）。返回 401/重定向到登录则视为未登录。 */
export async function checkGitlabLogin() {
  const { ok, status, json } = await fetchJson(URL_GITLAB_USER);
  if (ok && json && json.username) return { loggedIn: true, userName: json.username };
  return { loggedIn: false, userName: '' };
}

/** 取客开文件列表（方案 §6 Step4.2）。响应结构待确认，做兼容归一化。 */
export async function getGitlabFiles(dogNum, branch) {
  const url = gitlabFilesUrl(dogNum, branch);
  const { ok, status, json, text } = await fetchJson(url);
  if (!ok) throw new Error(`gitlab files 请求失败 ${status}：${url}`);
  const list = json ? normalizeFileList(json) : normalizeFileListFromText(text);
  return list;
}

/** 从 HTML 文本中取 <input id="..."> 的 value（属性顺序无关）。 */
export function parseInputValue(html, id) {
  const re = new RegExp('<input\\b[^>]*\\bid=["\']' + id + '["\'][^>]*>', 'i');
  const m = html.match(re);
  if (!m) return null;
  const v = m[0].match(/\bvalue=["']([^"']*)["']/i);
  return v ? v[1] : null;
}

/** repositories 字段兼容解析为分支名（字符串 / JSON）。 */
export function parseBranch(repositories) {
  if (repositories == null) return '';
  if (typeof repositories === 'string') {
    const s = repositories.trim();
    if (!s) return '';
    try {
      const j = JSON.parse(s);
      return pickBranch(j);
    } catch (_) {
      return s; // 纯字符串即分支名
    }
  }
  if (typeof repositories === 'object') return pickBranch(repositories);
  return '';
}
function pickBranch(obj) {
  if (!obj || typeof obj !== 'object') return '';
  if (typeof obj.branch === 'string') return obj.branch;
  if (typeof obj.name === 'string') return obj.name;
  // 兜底：第一个字符串值
  for (const k of Object.keys(obj)) {
    if (typeof obj[k] === 'string') return obj[k];
  }
  return '';
}

/** 把多种可能的 gitlab files 响应结构归一化为路径数组。 */
function normalizeFileList(data) {
  let arr = [];
  if (Array.isArray(data)) arr = data;
  else if (data && typeof data === 'object') {
    arr = data.files || data.data || data.tree || data.nodes || data.list || [];
  }
  const out = [];
  for (const e of arr) {
    if (typeof e === 'string') out.push(e);
    else if (e && typeof e === 'object') {
      const p = e.path ?? e.name ?? e.file_path ?? e.filePath ?? e.id;
      if (typeof p === 'string') out.push(p);
    }
  }
  return out.map(normalizePath).filter(Boolean);
}

/** 若响应非 JSON（HTML），尝试用正则粗提取路径 —— 兜底，结构待确认。 */
function normalizeFileListFromText(text) {
  const out = new Set();
  const re = /["']([^"']+\.(?:java|jsp|js|xml|properties|sql|css|html?|tag|tld|json|txt))["']/gi;
  let m;
  while ((m = re.exec(text))) out.add(normalizePath(m[1]));
  return [...out];
}

export { basename };
