// 通用工具：路径归一化、basename、URL 参数提取、安全取值。

/** 路径归一化：反斜杠->正斜杠，去前导 ./ 与 /，去尾部分隔符，保留大小写。 */
export function normalizePath(p) {
  if (!p) return '';
  let s = String(p).replace(/\\/g, '/').trim();
  s = s.replace(/^\.\//, '').replace(/^\/+/, '').replace(/\/+$/, '');
  return s;
}

/** 取 basename（区分大小写）。 */
export function basename(p) {
  const n = normalizePath(p);
  if (!n) return '';
  const i = n.lastIndexOf('/');
  return i < 0 ? n : n.slice(i + 1);
}

/** 从完整 URL 字符串中按参数名（大小写不敏感）取值，找不到返回 ''。 */
export function getQueryParam(urlStr, name) {
  if (!urlStr || !name) return '';
  try {
    const u = new URL(urlStr);
    const lower = name.toLowerCase();
    for (const [k, v] of u.searchParams) {
      if (k.toLowerCase() === lower) return v;
    }
  } catch (_) { /* ignore */ }
  return '';
}

/** 安全逐层取值，任一层缺失返回 undefined。 */
export function safeGet(obj, ...path) {
  let cur = obj;
  for (const k of path) {
    if (cur == null) return undefined;
    cur = cur[k];
  }
  return cur;
}
