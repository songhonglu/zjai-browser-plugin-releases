// Background service worker（MV3, type:module）。
// 职责：消息路由 + 与 content 的 RPC + step1~4 主流程编排。
// 所有联网在此发起（host_permissions 自动带 cookie）。
import {
  downloadAttachment, isZip, getDongleNumber, getBaseInfoParams,
  checkStudioLogin, queryCustomization, parseBranch,
  checkGitlabLogin, getGitlabFiles, setLogger,
} from './api.js';
import { readZipEntries, isTar, readTarEntries, isRar, readRarEntries } from './zip-reader.js';
import { detectConflicts } from './match.js';
import { pakEntriesToSourceFiles } from './pak.js';
import { basename, normalizePath } from './util.js';

console.log('[kk-helper:conflict-radar][bg] service worker module loaded');

// 把 ArrayBuffer 前 N 字节解码为文本（诊断下载内容用）
function bufHeadText(buf, n) {
  try { return new TextDecoder('utf-8').decode(new Uint8Array(buf).slice(0, n)).replace(/[\r\n\t]+/g, ' '); } catch (_) { return ''; }
}

// ---------- 与 content 的 RPC ----------
let rpcSeq = 0;
const pending = new Map(); // id -> {resolve, reject, timer}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.replyTo != null) {
    const slot = pending.get(msg.replyTo);
    if (slot) {
      pending.delete(msg.replyTo);
      clearTimeout(slot.timer);
      if (msg.error) slot.reject(new Error(msg.error));
      else slot.resolve(msg.result);
    }
  }
  return false;
});

// 发起检测的框架（用户点球所在的当前工单框架）—— RPC 与进度消息定向下发到它，
// 避免同 tab 内多个工单框架（都含 #subject）竞争响应，误读到旧工单的 moduleId/客户/加密狗号。
const tabFrameMap = Object.create(null);

function sendTab(tabId, payload) {
  const fid = tabFrameMap[tabId];
  const cb = () => void chrome.runtime.lastError;
  try {
    if (fid != null) chrome.tabs.sendMessage(tabId, payload, { frameId: fid }, cb);
    else chrome.tabs.sendMessage(tabId, payload, cb);
  } catch (_) { /* tab gone */ }
}

/** 构造一个日志器：打到 SW 控制台，并转发到对应 tab 的页面控制台/面板。 */
function makeTabLogger(tabId) {
  return (...a) => {
    const msg = a.map((x) => {
      if (x instanceof Error) return x.message;
      if (typeof x === 'object') { try { return JSON.stringify(x); } catch (_) { return String(x); } }
      return String(x);
    }).join(' ');
    // eslint-disable-next-line no-console
    console.log('[kk-helper:conflict-radar][bg]', msg);
    sendTab(tabId, { type: 'LOG', message: msg });
  };
}

/**
 * 清理一个 fileDownload.do 下载项：cancel → 删磁盘文件 → 从历史抹除。
 * best-effort，全部异常吞掉（removeFile 仅对 complete 有效，失败忽略）。
 */
function purgeItem(it) {
  const id = it && it.id;
  if (id == null) return;
  try { chrome.downloads.cancel(id, () => void chrome.runtime.lastError); } catch (_) { /* ignore */ }
  try { chrome.downloads.erase({ id }, () => void chrome.runtime.lastError); } catch (_) { /* ignore */ }
}

/**
 * 扫描下载列表，清掉所有 fileDownload.do 残留项（历史遗留 / 上次 cancel 卡住 / 重启后续传的）。
 * cancel 会让下载进入 interrupted 从而「卡死」下载窗口、并在浏览器重启后被续传——这里把它们抹除。
 */
function purgeFileDownloadItems() {
  try {
    chrome.downloads.search({}, (items) => {
      if (!Array.isArray(items)) return;
      items.forEach((it) => {
        const u = (it && (it.finalUrl || it.url)) || '';
        if (/fileDownload\.do/i.test(u)) purgeItem(it);
      });
    });
  } catch (_) { /* ignore */ }
}

/**
 * 点击「单个」指定附件的下载图标，用 chrome.downloads.onCreated 捕获其 fileDownload.do 真实 URL。
 *
 * 为什么逐个串行：cap4 的下载触发多为单导航机制（location.href 等），同时点击多个下载图标时
 * 浏览器只会真正发起一次导航 → 只有一个下载能被 onCreated 捕获，其余附件的 URL 全部丢失
 * （表现为「未能取得压缩包下载链接」）。改为 background 串行逐个点击 + 逐个捕获，彻底规避。
 *
 * ⚠️ 不 cancel！cancel 会让下载进入 interrupted（下载窗口卡死 + 重启后续传，erase 对 in_progress 无效）。
 * 让其自然 complete，再 removeFile(删磁盘) + erase(抹历史)，全程不留 interrupted 态。
 * 机制无关（location.href / anchor / open / fetch 均可被 onCreated 捕获）。
 *
 * 单次只点击一个图标 → 至多一个 fileDownload.do 下载；等其终态并清理后 resolve 该 URL（失败返回 null）。
 */
function captureOneDownloadViaClick(tabId, fieldId, fileName) {
  return new Promise((resolve) => {
    const captured = [];
    const tracked = new Set(); // 本次点击触发的下载 id，待终态后清理
    let clickedDone = false;
    let settled = false;

    // complete：删磁盘文件再抹历史；interrupted：直接抹历史。两终态都从 tracked 移除。
    const cleanOne = (id, removeFile) => {
      const after = () => {
        try { chrome.downloads.erase({ id }, () => void chrome.runtime.lastError); } catch (_) { /* ignore */ }
        tracked.delete(id);
        maybeFinish();
      };
      if (removeFile) { try { chrome.downloads.removeFile(id, after); } catch (_) { after(); } }
      else after();
    };
    const onCreated = (item) => {
      const u = (item && (item.finalUrl || item.url)) || '';
      if (!/fileDownload\.do/i.test(u)) return;
      captured.push(u);
      if (item && item.id != null) {
        tracked.add(item.id);
        if (item.state === 'complete') cleanOne(item.id, true);          // 极小文件 onCreated 即已完成
        else if (item.state === 'interrupted') cleanOne(item.id, false);
      }
    };
    const onChanged = (delta) => {
      if (!tracked.has(delta.id) || !delta.state) return;
      if (delta.state.current === 'complete') cleanOne(delta.id, true);
      else if (delta.state.current === 'interrupted') cleanOne(delta.id, false);
    };

    const finish = () => {
      if (settled) return; settled = true;
      clearTimeout(maxTimer);
      try { chrome.downloads.onCreated.removeListener(onCreated); } catch (_) { /* ignore */ }
      try { chrome.downloads.onChanged.removeListener(onChanged); } catch (_) { /* ignore */ }
      tracked.forEach((id) => purgeItem({ id }));
      tracked.clear();
      resolve(captured[0] || null); // 单次捕获：取唯一 URL（无则 null）
    };
    const maybeFinish = () => { if (!settled && clickedDone && tracked.size === 0) finish(); };
    const maxTimer = setTimeout(finish, 20000);

    try { chrome.downloads.onCreated.addListener(onCreated); } catch (_) { /* ignore */ }
    try { chrome.downloads.onChanged.addListener(onChanged); } catch (_) { /* ignore */ }
    tabRpc(tabId, { type: 'CLICK_ONE_DOWNLOAD', fieldId, fileName }, 10000)
      // content 返回后，Chrome 的 onCreated 仍可能稍晚才触发；保留一个短等待窗口，避免空 captured 竞态。
      .then(() => { setTimeout(() => { clickedDone = true; maybeFinish(); }, 1500); })
      .catch(() => { clickedDone = true; finish(); });
  });
}

/** 向 content 发起一次请求并等待其回复。 */
function tabRpc(tabId, request, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const id = ++rpcSeq;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error('RPC 超时：' + request.type)); }, timeoutMs);
    pending.set(id, { resolve, reject, timer });
    const reply = () => {
      // content 用独立通道（chrome.runtime.sendMessage + replyTo）回复、不走 sendResponse，
      // 因此「The message port closed before a response was received」属正常现象，必须忽略；
      // 仅当「接收端不存在」（content 未注入/已失效）时才立即失败，其余靠 replyTo 或超时。
      const le = chrome.runtime.lastError;
      if (le && /does not exist|Could not establish connection/i.test(le.message)) {
        pending.delete(id); clearTimeout(timer);
        reject(new Error('content 未注入：请确认当前在工单页且已重载扩展（' + le.message + '）'));
      }
    };
    const fid = tabFrameMap[tabId];
    try {
      if (fid != null) chrome.tabs.sendMessage(tabId, { ...request, id }, { frameId: fid }, reply);
      else chrome.tabs.sendMessage(tabId, { ...request, id }, reply);
    } catch (e) {
      pending.delete(id); clearTimeout(timer);
      reject(new Error('RPC 发送失败：' + (e && e.message)));
    }
  });
}

// 进度下发：不带 section → 共享步骤（加密狗/仓库/比对），两个区块同步推进；
// 带 section → 仅该区块的「识别」步骤或其比对完成态。
const progress = (tabId, step, status, message) =>
  sendTab(tabId, { type: 'PROGRESS', step, status, message });
const progressSection = (tabId, section, step, status, message) =>
  sendTab(tabId, { type: 'PROGRESS', section, step, status, message });
const sendError = (tabId, message, section) => sendTab(tabId, { type: 'ERROR', message, section });
const sendNeedLogin = (tabId, target, url) => sendTab(tabId, { type: 'NEED_LOGIN', target, url });

// ---------- 入口 ----------
// SW 每次启动：清理历史遗留 / 重启续传的 fileDownload.do 卡住项（用户重启电脑后浏览器会续传这些）
purgeFileDownloadItems();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'RUN_DETECT') {
    const tabId = sender.tab && sender.tab.id;
    if (tabId == null) return false;
    // 记录发起框架（用户点球所在的当前工单框架），后续 RPC/进度定向下发，避免多工单框架串台
    if (sender.frameId != null) tabFrameMap[tabId] = sender.frameId;
    sendResponse({ ok: true }); // 同步 ack
    runPipeline(tabId).catch((e) => sendError(tabId, String((e && e.message) || e)));
    return false;
  }
  return false;
});

// ---------- 主流程 ----------

/**
 * 解析单个「源码附件」item 为文件列表（zip/tar/rar 解压取文件名；单文件直取文件名）。
 * @returns {Promise<{files:{path,name}[]|null, manual:{name,reason}|null}>}
 */
async function resolveItemFiles(it, log) {
  if (it.manual) {
    return { files: null, manual: { name: it.fileName, reason: '不支持的压缩格式（非 zip 类），请手工解压比对' } };
  }
  if (it.url) {
    const buf = await downloadAttachment(it.url);
    if (isZip(buf)) {
      try { return { files: (await readZipEntries(buf)).map((e) => ({ path: e.path, name: basename(e.path) })), manual: null }; }
      catch (ze) { return { files: null, manual: { name: it.fileName || basename(it.url), reason: '解压失败：' + ze.message + '，请手工解压比对' } }; }
    }
    if (isTar(buf)) {
      try { return { files: (await readTarEntries(buf)).map((e) => ({ path: e.path, name: basename(e.path) })), manual: null }; }
      catch (te) { return { files: null, manual: { name: it.fileName || basename(it.url), reason: 'tar 解析失败：' + te.message + '，请手工' } }; }
    }
    if (isRar(buf)) {
      try { return { files: (await readRarEntries(buf)).map((e) => ({ path: e.path, name: basename(e.path) })), manual: null }; }
      catch (re) { return { files: null, manual: { name: it.fileName || basename(it.url), reason: 'RAR 解析失败：' + re.message + '，请手工解压比对' } }; }
    }
    const head = bufHeadText(buf, 300);
    log('下载内容非 zip/tar：', it.fileName, ' len=' + buf.byteLength, ' head=', head);
    return { files: null, manual: { name: it.fileName || basename(it.url), reason: '下载后非 zip/tar 归档（详见控制台），请手工' } };
  }
  if (it.nameOnly) {
    const name = normalizePath(it.fileName) || 'unknown';
    return { files: [{ path: name, name }], manual: null };
  }
  return { files: null, manual: { name: it.fileName, reason: '未能取得压缩包下载链接，请手工' } };
}

/**
 * 解析单个「补丁包」.pak item：下载后直接读中央目录取文件名清单。
 * .pak 为加密 ZIP，传统加密只加在文件数据上、不影响中央目录，故 readZipEntries 无需密码即可读出文件名；
 * 不经 isZip 门控（pak 首字节未必是标准 PK 头，但尾部 EOCD 仍在），readZipEntries 内部已校验结构。
 * @returns {Promise<{files:{path}[]|null, manual:{name,reason}|null}>}
 */
async function resolvePakEntries(it, log) {
  if (it.manual) {
    return { files: null, manual: { name: it.fileName, reason: '不支持的补丁包格式，请手工解包比对' } };
  }
  if (!it.url) {
    return { files: null, manual: { name: it.fileName, reason: '未能取得补丁包下载链接，请手工' } };
  }
  const buf = await downloadAttachment(it.url);
  try {
    return { files: await readZipEntries(buf), manual: null };
  } catch (ze) {
    const head = bufHeadText(buf, 300);
    log('补丁包 readZipEntries 失败：', it.fileName, ' len=' + buf.byteLength, ' head=', head);
    return { files: null, manual: { name: it.fileName || basename(it.url), reason: '补丁包解析失败：' + ze.message + '（若为非标准加密 pak，请手工解包比对）' } };
  }
}

async function runPipeline(tabId) {
  const log = makeTabLogger(tabId);
  setLogger(log); // 把 api.js 的日志也转发到页面控制台/面板
  purgeFileDownloadItems(); // 捕获前先清掉残留下载项，避免下载窗口里堆积
  log('==== 开始检测（tab=' + tabId + '）====');

  // STEP 1：识别源码 + 补丁包（两路并行收集；「识别」步骤各自独立推进）
  progressSection(tabId, 'source', 'source', 'start', '识别源码附件…');
  progressSection(tabId, 'pak', 'source', 'start', '识别补丁包附件…');
  const [src, pak] = await Promise.all([
    tabRpc(tabId, { type: 'COLLECT_SOURCE' }),
    // COLLECT_PAK 失败不应拖垮源码检测：补丁包为可选，失败时按「无补丁包」继续
    tabRpc(tabId, { type: 'COLLECT_PAK' }).catch((e) => {
      log('COLLECT_PAK 失败，按无补丁包继续：' + ((e && e.message) || e));
      return { items: [], reason: 'rpc-error' };
    }),
  ]);
  log('COLLECT_SOURCE reason=' + (src && src.reason) + ' items=' + JSON.stringify(((src && src.items) || []).map((it) => ({ fileName: it.fileName, hasUrl: !!it.url, nameOnly: !!it.nameOnly, from: it.from }))));
  log('COLLECT_PAK reason=' + (pak && pak.reason) + ' items=' + JSON.stringify(((pak && pak.items) || []).map((it) => ({ fileName: it.fileName, hasUrl: !!it.url, from: it.from }))));
  const sourceItems = (src && src.items) || [];
  const pakItems = (pak && pak.items) || [];
  const hasPak = pakItems.length > 0;

  // 源码、补丁包全无 → 结束（两者均无可比对的入口）
  if (!sourceItems.length && !hasPak) {
    sendError(tabId, '当前工单，无源码附件与补丁包附件');
    return;
  }

  // 压缩包/补丁包的 fileDownload.do URL 不在 DOM：逐个点击对应附件图标，经 chrome.downloads 捕获真实 URL
  // （cap4 同时点击多个下载图标时可能只发起最后/第一个下载，串行逐个捕获可避免相互抢导航）
  const needUrlItems = [
    ...sourceItems.filter((it) => it.needUrl && !it.url && !it.manual),
    ...pakItems.filter((it) => it.needUrl && !it.url && !it.manual),
  ];
  if (needUrlItems.length) {
    if (sourceItems.some((it) => it.needUrl && !it.url && !it.manual)) progressSection(tabId, 'source', 'source', 'start', '捕获源码包下载链接…');
    if (pakItems.some((it) => it.needUrl && !it.url && !it.manual)) progressSection(tabId, 'pak', 'source', 'start', '捕获补丁包下载链接…');
    // 串行逐个点击 + 捕获：同时点击多个下载图标会因 cap4 单导航机制（location.href 等）只发起一个下载，
    // 其余附件 URL 丢失。逐个点击 → 每个附件各自拿到自己的 URL，不再需要按 filename 二次匹配/兜底。
    for (const it of needUrlItems) {
      const url = await captureOneDownloadViaClick(tabId, it.from, it.fileName);
      if (url) { it.url = url; delete it.needUrl; log('捕获 ' + it.fileName + '：' + url); }
      else log('未能捕获下载链接：' + it.fileName + '（from=' + it.from + '）');
    }
  }

  // —— 解析源码附件 ——
  const sourceFiles = [];
  const manualFiles = []; // 无法自动解析/解压的附件，提示用户手工
  const seen = new Set();
  if (sourceItems.length) {
    progressSection(tabId, 'source', 'source', 'start', `解析 ${sourceItems.length} 个源码附件…`);
    for (const it of sourceItems) {
      try {
        const { files, manual } = await resolveItemFiles(it, log);
        if (manual) { manualFiles.push(manual); continue; }
        if (files) for (const f of files) {
          const key = normalizePath(f.path) || f.name;
          if (key && !seen.has(key)) { seen.add(key); sourceFiles.push({ ...f, from: it.from }); }
        }
      } catch (e) {
        manualFiles.push({ name: it.fileName || it.url || '(未知)', reason: '解析失败：' + e.message + '，请手工' });
      }
    }
    if (manualFiles.length) log('source manualFiles：', manualFiles.map((m) => `${m.name} [${m.reason}]`).join('  |  '));
  }
  progressSection(tabId, 'source', 'source', 'done', sourceItems.length
    ? `识别到 ${sourceFiles.length} 个源码文件` + (manualFiles.length ? `（另有 ${manualFiles.length} 个需手工）` : '')
    : '无源码附件');

  // —— 解析补丁包（.pak 加密 zip → 文件名清单 → 源码名推导）——
  const pakSourceFiles = [];
  const pakManual = [];
  const pakSeen = new Set();
  if (hasPak) {
    progressSection(tabId, 'pak', 'source', 'start', `解析 ${pakItems.length} 个补丁包…`);
    for (const it of pakItems) {
      try {
        const { files, manual } = await resolvePakEntries(it, log);
        if (manual) { pakManual.push(manual); continue; }
        // class→java 推导 + 内部类折叠 + 其他取 basename（pakEntriesToSourceFiles 内部已按 path 去重）
        const mapped = pakEntriesToSourceFiles(files);
        for (const f of mapped) {
          const key = normalizePath(f.path) || f.name;
          if (key && !pakSeen.has(key)) { pakSeen.add(key); pakSourceFiles.push(f); }
        }
      } catch (e) {
        pakManual.push({ name: it.fileName || it.url || '(未知)', reason: '解析失败：' + e.message + '，请手工' });
      }
    }
    if (pakManual.length) log('pak manualFiles：', pakManual.map((m) => `${m.name} [${m.reason}]`).join('  |  '));
    progressSection(tabId, 'pak', 'source', 'done', `识别到 ${pakSourceFiles.length} 个补丁包源文件` + (pakManual.length ? `（另有 ${pakManual.length} 个需手工）` : ''));
  } else {
    progressSection(tabId, 'pak', 'source', 'done', '无补丁包附件');
  }

  // 两边都解析不出可比对文件 → 结束（dongle/studio/gitlab 无需再跑）
  if (!sourceFiles.length && !pakSourceFiles.length) {
    const bits = [];
    if (sourceItems.length && !sourceFiles.length) bits.push('源码附件无法自动解析/解压' + (manualFiles.length ? '：' + manualFiles.map((m) => `${m.name}（${m.reason}）`).join('；') : ''));
    if (hasPak && !pakSourceFiles.length) bits.push('补丁包无法自动解析' + (pakManual.length ? '：' + pakManual.map((m) => `${m.name}（${m.reason}）`).join('；') : ''));
    sendError(tabId, (bits.join('；') || '无可比对文件') + '，请手工处理');
    return;
  }

  // STEP 2：加密狗号（共享：一次拉取，两区块同步推进）
  progress(tabId, 'dongle', 'start', '获取加密狗号…');
  const formDom = await tabRpc(tabId, { type: 'EXTRACT_FORM' });
  log('EXTRACT_FORM ' + JSON.stringify(formDom));
  const form = await getBaseInfoParams(formDom && formDom.affairId);
  log('BASE_INFO_FORM ' + JSON.stringify(form));
  const dongle = await getDongleNumber(form);
  progress(tabId, 'dongle', 'done', '加密狗号：' + dongle);

  // STEP 3：仓库地址（共享）
  progress(tabId, 'studio', 'start', '检查 ctpStudio 登录…');
  const studio = await checkStudioLogin();
  if (!studio.loggedIn) {
    sendNeedLogin(tabId, 'studio', 'http://studio.kk.seeyon.com');
    return;
  }
  progress(tabId, 'studio', 'start', '查询客开项目…');
  const cust = await queryCustomization(dongle);
  if (cust.total === 0) { sendError(tabId, '通过加密狗未查询到客开项目，结束'); return; }
  let row = cust.rows[0];
  if (cust.total > 1) {
    const choice = await tabRpc(tabId, { type: 'CHOOSE_PROJECT', rows: cust.rows }, 120000);
    row = choice && choice.row;
    if (!row) { sendError(tabId, '未选择项目，结束'); return; }
  }
  const customer = row.projectAlias || '(无名)';
  const branch = parseBranch(row.repositories);
  if (!branch) { sendError(tabId, '未能解析仓库分支（repositories 字段为空），结束'); return; }
  progress(tabId, 'studio', 'done', `客户：${customer}　分支：${branch}`);

  // STEP 4：拉取仓库文件（共享一次）+ 分别比对（源码区块 / 补丁包区块各出结果）
  progress(tabId, 'gitlab', 'start', '检查 GitLab 登录…');
  const git = await checkGitlabLogin();
  if (!git.loggedIn) {
    sendNeedLogin(tabId, 'gitlab', 'http://gitlab.kk.seeyon.com/users/sign_in');
    return;
  }
  progress(tabId, 'gitlab', 'start', '拉取客开文件列表…');
  const repoFiles = await getGitlabFiles(dongle, branch);

  // —— 源码比对 ——
  if (sourceFiles.length) {
    progressSection(tabId, 'source', 'gitlab', 'start', `比对（源码 ${sourceFiles.length} ↔ 客开 ${repoFiles.length}）…`);
    const result = detectConflicts(sourceFiles, repoFiles);
    progressSection(tabId, 'source', 'gitlab', 'done', `比对完成：冲突 ${result.conflicts.length} / 无冲突 ${result.clean.length}`);
    sendTab(tabId, {
      type: 'RESULT', section: 'source',
      payload: { dongle, customer, branch, sourceCount: sourceFiles.length, repoCount: repoFiles.length, result, manual: manualFiles },
    });
  } else {
    progressSection(tabId, 'source', 'gitlab', 'done', '—');
    // empty=true 但带 manual：区分「无附件」与「有附件但全部解析失败」，后者需展示手工清单
    sendTab(tabId, { type: 'RESULT', section: 'source', payload: { empty: true, manual: manualFiles } });
  }

  // —— 补丁包比对（冲突项额外标注原始 .class 名做溯源）——
  if (pakSourceFiles.length) {
    progressSection(tabId, 'pak', 'gitlab', 'start', `比对（补丁包 ${pakSourceFiles.length} ↔ 客开 ${repoFiles.length}）…`);
    const pakResult = detectConflicts(pakSourceFiles, repoFiles);
    const origMap = new Map(pakSourceFiles.map((f) => [normalizePath(f.path) || f.name, f.orig]));
    pakResult.conflicts.forEach((c) => { if (c.orig == null) c.orig = origMap.get(c.source) || ''; });
    progressSection(tabId, 'pak', 'gitlab', 'done', `比对完成：冲突 ${pakResult.conflicts.length} / 无冲突 ${pakResult.clean.length}`);
    sendTab(tabId, {
      type: 'RESULT', section: 'pak',
      payload: { dongle, customer, branch, sourceCount: pakSourceFiles.length, repoCount: repoFiles.length, result: pakResult, manual: pakManual },
    });
  } else {
    progressSection(tabId, 'pak', 'gitlab', 'done', '—');
    sendTab(tabId, { type: 'RESULT', section: 'pak', payload: { empty: true, manual: pakManual } });
  }
}
