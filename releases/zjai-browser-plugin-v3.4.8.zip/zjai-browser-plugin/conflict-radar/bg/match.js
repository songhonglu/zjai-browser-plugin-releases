// 冲突匹配策略（方案 §7）。
// 冲突定义：源码补丁要改的文件，在客开仓库里也存在。
// 匹配优先级：1) 双方都有路径且客开路径「尾部命中」源码相对路径（高置信）
//             2) basename 相同（区分大小写，普通冲突）
import { normalizePath, basename } from './util.js';

/**
 * @param {{path?:string, name?:string}[]} sourceFiles 源码文件
 * @param {string[]} repoFiles 客开仓库文件路径列表
 */
export function detectConflicts(sourceFiles, repoFiles) {
  const repoNorm = repoFiles.map(normalizePath).filter(Boolean);
  const repoSet = new Set(repoNorm);

  // basename -> [repoPaths]（区分大小写）
  const repoByBase = new Map();
  for (const rp of repoNorm) {
    const b = basename(rp);
    if (!b) continue;
    if (!repoByBase.has(b)) repoByBase.set(b, []);
    repoByBase.get(b).push(rp);
  }

  const conflicts = [];
  const clean = [];
  for (const sf of sourceFiles || []) {
    const sp = normalizePath(sf && sf.path) || '';
    const sb = (sf && sf.name) || basename(sp) || '';
    const key = sp || sb;

    let hit = null;
    let kind = null;

    // 1) 路径尾部命中：只有源码侧确实带目录时才算高置信路径命中。
    // 纯 basename（如 index.html）若用 rp.endsWith('/index.html') 会把任意同名文件误标为「路径命中」，应交给第 2 步文件名命中。
    if (sp && sp.includes('/')) {
      if (repoSet.has(sp)) { hit = sp; kind = 'path'; }
      else {
        const tail = repoNorm.find(rp => rp.endsWith('/' + sp));
        if (tail) { hit = tail; kind = 'path'; }
      }
    }
    // 2) basename 命中
    if (!hit && sb) {
      const arr = repoByBase.get(sb);
      if (arr && arr.length) { hit = arr[0]; kind = 'name'; }
    }

    if (hit) {
      conflicts.push({ source: key, repo: hit, kind });
    } else {
      clean.push({ source: key });
    }
  }

  return {
    conflicts,          // [{source, repo, kind:'path'|'name'}]
    clean,              // [{source}]
    pathHits: conflicts.filter(c => c.kind === 'path').length,
    nameHits: conflicts.filter(c => c.kind === 'name').length,
  };
}
