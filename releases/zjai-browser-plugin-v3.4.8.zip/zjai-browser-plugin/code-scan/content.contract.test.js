const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'content-code-scan.js'), 'utf8');

assert.match(source, /function handleRuntimeInvalidated\(/, '应统一处理扩展上下文失效');
assert.match(source, /function safeRuntimeSendMessage\(/, '应提供安全的 runtime sendMessage 包装');
assert.match(source, /message\.includes\('Extension context invalidated'\)/, '应识别 Extension context invalidated 错误');
assert.match(source, /message\.includes\('message channel closed before a response was received'\)/, '应识别 message channel 提前关闭错误');
assert.match(source, /Logger\.info\('扩展上下文已失效，停止 code-scan 轮询'\)/, '扩展上下文失效应记录为 info，避免污染错误页');
assert.doesNotMatch(source, /Logger\.warn\('扩展上下文已失效，停止 code-scan 轮询'\)/, '扩展上下文失效不应再记录为 warn');
assert.match(source, /stopPolling\(\);[\s\S]*isScanning = false;[\s\S]*updateRefreshBtnState\(\)/, '上下文失效时应停止轮询并重置扫描状态');
assert.match(source, /showError\('插件已更新或重载，请刷新页面后重试'\)/, '上下文失效时应展示友好提示');
assert.doesNotMatch(source, /chrome\.runtime\.sendMessage\(\{ action: 'getCodeScanProgress' \}/, '轮询不应直接调用原始 sendMessage');
assert.match(source, /safeRuntimeSendMessage\(\{ action: 'getCodeScanProgress' \}/, '轮询应走安全消息发送');
assert.match(source, /safeRuntimeSendMessage\(\{ action: 'getCodeScanResult' \}/, '结果读取应走安全消息发送');
assert.match(source, /safeRuntimeSendMessage\(\{ action: 'startCodeScan' \}/, '启动扫描应走安全消息发送');
