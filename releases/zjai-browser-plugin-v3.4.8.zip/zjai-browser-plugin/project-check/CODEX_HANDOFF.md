## 当前目标

梳理 `project-check` 现有功能与当前主要问题，供下一轮继续实现或修复。

## 已完成事项

- 确认 `project-check` 已通过主插件 `manifest.json` 注入到 `*://xt.seeyon.com/*`。
- 确认目录内当前只有一个实现文件：`content.js`。
- 完成对 `content.js` 的功能梳理与静态问题识别。
- 运行 `node --check content.js`，语法通过。
- 补充完成“取值不准确”根因分析，确认当前主要问题在统一取值层而不是校验规则层。
- 已完成第一轮取值层重构：
- 新增统一读取入口 `readFieldNodeMeta()`，改为“编辑态控件值优先，只读态文本/链接兜底”。
- `readDirectCellText()` 不再丢掉 `A` 标签文本，链接型字段可被读取。
- 行内值定位改为 `findRowValueMeta()` 扫描标题右侧后续单元格，而不是只取紧邻一个单元格。
- `findStrictRowMeta()`、`findDeliveryFieldMeta()`、`findSectionRowMeta()`、`findRowValueByPeerLabels()` 已接入新取值链路。
- 已完成第二轮字段定位收敛：
- 新增 `findRowMetaInRoots()`，把“按行匹配 + 按右侧值扫描”抽成统一定位函数。
- 新增 `findTopFormFieldMeta()`，顶部字段先在 `项目盘点信息 / 区域盘点记录` 范围内定位，再兜底全页。
- `findStrictRowMeta()` 与 `findSectionRowMeta()` 也已复用统一定位逻辑，减少各自的猜测分支。
- 已完成第三轮可测试性增强：
- 元信息补充为 `label / scope / source`，通过 `withMetaContext()` 在定位阶段透传。
- 新增 `describeMeta()`，结果面板现在会展示字段取值的定位范围和读取模式。
- `盘点验收时间 / 当前项目进度 / 下一步安排 / 客开基础字段 / 项目主计划` 的 trace 已改成结构化来源信息，便于真实页面联调。
- 已根据真实截图修复一处串列误取：
- 根因是 `findRowValueMeta()` 会跨过当前字段的空值单元格，继续读到同一行后面下一组字段的值，导致 `盘点验收时间` 误读成 `保底/争取=争取`。
- 现已改为：向右扫描时，一旦后续单元格本身像新的字段标题，就停止，不再跨字段组串读。
- 已根据第二张真实截图追加两类修复：
- 字段名匹配新增 `fieldLabelMatches()`，字段定位改为精确匹配，不再用宽松前缀匹配去命中 `项目主计划确认` 这类非目标字段。
- 新增 `isLikelyActionText()`，把 `变更次数 / 查询 / 确认 / 发起 / 锁定` 一类短操作文案排除在字段值之外，避免被当成真实值。
- 已对比解析 `/Users/songhw/Downloads/sh-browser-plugin/bug-flow/bug-flow.js`（只读）：
- `bug-flow` 的取值稳定，不是因为“通用 DOM 猜得更准”，而是因为它几乎全程依赖稳定锚点：
- DOM 取值走固定 selector，如 `#field0161_id`、`#subject`、`#summaryId`，见 `CONFIG.customerSelectors` / `CONFIG.field.subject`。
- 业务关键值大量走接口和固定字段 key，如 `baseInfo -> moduleId/rightId`、`createOrEdit -> field1259`，不是在页面表格里模糊扫文本。
- 结论：`project-check` 现在的问题不是“修得不够久”，而是路径选错了；它在做通用表格文本抓取，而 `bug-flow` 在做字段锚点读取。
- 已按用户要求把关键字段切到“显式锚点取值”：
- 新增 `readAdjacentValueMeta()` / `findExactAdjacentMeta()` / `getAnchorRootsByKey()` / `getExplicitFieldMeta()`。
- 以下字段已不再走原来的通用全页兜底逻辑，而是只在明确区块里按“标签右侧紧邻值单元格”取值：
- `盘点验收时间`、`当前项目进度`、`下一步安排`
- `客开负责人`、`客开启动时间`、`客开进度`、`Ctp-Studio仓库地址`
- `项目主计划`、`主计划锁定`
- 这意味着：这些字段取不到时会直接返回空，不会再回退到全页模糊扫描去串读别的值。
- 已继续把截图里的两块也收紧为显式锚点：
- `客开任务基础字段`：新增 `FIELD_ANCHOR_ALIASES`，支持 `客开负责人/客开责任人` 等字段别名，仍按显式区块 + 紧邻值单元格取值。
- `客开任务明细`：新增 `findTablesByHeaders()` / `getExplicitKkTaskTable()`，只在 `客开任务` 区块候选表里选“最像任务明细、有效行数最多”的那张表，不再用通用 `resolveDeliveryTable()`。
- 针对“客开负责人 / 客开启动时间 / Ctp-Studio仓库地址 明明有值却没取到”的截图，已进一步判断：
- 不是优先怀疑页签未加载。证据：同一 `客开任务` 页签下的明细表已经能读到有效行，说明页签内容本身已加载。
- 更可能是基础字段那张小表的锚点不够准，或标签文本存在 `客开责任人`、冒号、必填符等导致精确匹配 miss。
- 已新增 `normalizeFieldLabel()` 和 `getExplicitKkBaseTable()`：
- 标签比较会去掉空白、冒号、星号等噪音。
- `客开任务基础字段` 现在先定位那张同时包含 `客开负责人/客开责任人`、`客开启动时间`、`客开进度`、`Ctp-Studio仓库地址` 的小表，再在这张表里按显式锚点取值。
- 已新增 `项目投放明细` 的显式锚点：
- 新增 `getExplicitProjectPutTable()`，优先找 `项目投放明细` 标题块，再在该块内找表头包含 `序号 / 顾问名称` 的表；找不到时再退到 `项目投放` 区块 / tabbed area 邻近范围。
- `项目投放明细` 检查已不再走通用 `resolveTabbedTable()`，而是走这条显式选表路径。
- 已按用户要求调整结果展示顺序：
- `项目主计划` 已移动到 `下一步安排` 后、`客开任务基础字段` 前，仅调整输出顺序，不影响取值逻辑。
- 针对“客开任务明细应该只有 1 条，但统计成 10 条”的截图，当前判断更像是选错表，不是单纯行数算法错：
- 已把 `getExplicitKkTaskTable()` 再收紧：在候选表里优先选择同时包含 `项目规划 / 蓝图设计 / 系统建设 / 上线准备 / 持续支持` 这些阶段列的那张任务表。
- 新评分规则是 `阶段列命中数 * 100 + 有效行数`，确保带阶段列的客开任务表优先级远高于其他只碰巧含 `序号 / 任务目标 / 开始时间` 的表。
- 已按用户要求对齐 `客开任务明细` 的有效判定与展示顺序：
- `客开任务明细` 现在直接以 `countIndexedRows()` 为准，而 `countIndexedRows()` 本身就是“序号、任务目标都非空才计数”。
- 去掉了原来 `taskRows > 0 && taskGoalOk` 这种双条件混用，避免结果解释分裂。
- `实施任务明细` 已移动到 `客开任务明细` 前面展示。
- 已继续收紧 `客开任务明细` 的显式选表锚点：
- `getExplicitKkTaskTable()` 现在先找完整任务表头：`序号 / 任务目标 / 开始时间 / 项目规划 / 蓝图设计 / 系统建设 / 上线准备 / 持续支持`。
- 只有找不到完整表头时，才退回较弱的 `序号 / 任务目标 / 开始时间` 候选。
- 评分规则也改成优先完整表头命中，再看阶段列命中数和有效行数，避免误选其他结构相似表。
- 已完成校验规则展示：新增统一 `CHECK_RULES`，每个结果卡片固定显示“校验规则”，用户无需只从失败详情反推规则。
- 已修复 `kkState` 作用域问题：改为在两个客开校验分支共用的函数作用域声明，避免客开任务明细检查时出现 `ReferenceError`。
- 新增 `content.contract.test.js`，覆盖规则映射、结果卡片规则展示和 `kkState` 作用域约束。

## 修改过的文件

- `content.js`
- `content.contract.test.js`（新建）
- `CODEX_HANDOFF.md`（新建）

## 关键决策

- 只读取 `project-check/content.js` 和主插件 `manifest.json` 的直接相关片段，不做全量扫描。
- 当前“问题”以静态代码审查为准，未进入真实 OA 页面做运行态验证。
- 当前应优先重构“字段定位 + 值读取”链路，先保证编辑态/浏览态都能稳定拿到值，再谈后续校验项扩展。

## 未解决问题

- `bootstrap()` 只在页面初始加载和两个固定延时后执行，缺少对 SPA 路由切换/晚加载 DOM 的持续监听。
- 页面识别、页签识别、字段识别都强依赖中文标题和固定文案，页面结构或字段名稍改就可能失效。
- 校验规则目前以“是否为空/是否有行”为主，缺少日期、URL、内容格式等更细校验。
- `project-check` 不是独立工程形态，目前没有 README、测试、配置或构建边界说明。
- 取值层当前存在结构性问题：
- `findRowValueByPeerLabels()` 仍然保留“按整行 peer label 过滤”的老策略，虽然读值已改进，但命中行的稳定性还不够。
- `allDocs()` 仍会把当前页和可访问 iframe 全部纳入扫描，若同名字段在多个区域同时存在，仍有误取风险。
- 还没在真实 OA 页面做运行态验证，当前结论仍以静态代码路径为主。
- `findTopFormFieldMeta()` 现在只是把顶部字段搜索范围先收敛到疑似区块，仍未基于真实 DOM 特征建立“字段标签节点 -> 值节点”的强绑定。
- 当前 trace 已能看到 `scope/source`，但还没把真实 DOM 节点路径或表格标题一起展示；如果仍有误取，下一步需要继续补更细粒度定位证据。
- `findRowValueMeta()` 现在能避免读到右侧下一组字段值，但如果某些页面存在更复杂的跨列/隐藏列结构，还需要继续按真实页面样例微调。
- 显式锚点现在假设“目标值就在标签右侧紧邻单元格”；如果真实 DOM 是跨列、嵌套 section、控件不在紧邻单元格，需要继续按字段单独加特征。
- `客开任务明细` 现在按“候选表中有效行数最多”选表；若页面后续出现多张结构相似表，还需要进一步加页签或区域特征。
- `客开任务基础字段` 目前仍假设值在标签右侧紧邻单元格；如果真实 DOM 把值渲染到跨列单元格或内部嵌套控件，还要继续加单字段特征。
- `项目投放明细` 目前按“标题块 + 表头 + 有效行数最多”选表；若后续发现标题块 DOM 有固定 id/class，可继续进一步收紧。
- `客开任务明细` 现在优先选带阶段列的任务表；若后续仍有误选，下一步要继续加“按钮条/页签标题邻近关系”等更细锚点。
- `hasNonEmptyTaskGoal()` 目前对 `客开任务明细` 已不再参与通过判定；若未来别处也不再需要，可考虑删掉，避免混淆。
- 本地只能完成静态和契约检查；规则文案在真实 OA 结果面板中的换行、字段取值和页签切换仍需浏览器运行态回归。

## 下一步最小指令

重新加载浏览器插件并刷新目标 OA 页面，回归字段取值、结果顺序、校验规则展示，以及 `客开任务明细` 是否只统计“序号、任务目标”都有值的行。

## 2026-07-13 字段标识分析

- 用户已提供主表字段 `fieldXXXX_id` 和各明细表字段 class；本阶段只分析，未修改代码。
- 结论：主表字段改为精确 ID 定位，可显著降低同名字段、跨列和跨区块串读；明细表应按“页签激活 -> 字段组合定位明细表 -> 同一行读取 `.fieldXXXX`”处理。
- `cap-field-content`、`cap-field` 是通用 class，不能作为唯一锚点；稳定锚点应使用字段 class 组合，如实施任务 `.field0363/.field0364/.field0365`。
- 不建议依赖完整 `formson_<表号>_<长数字>_fieldXXXX` class；中间长数字可能随表单定义或实例变化，优先使用表号范围和 `.fieldXXXX` 组合。
- `fieldXXXX_id` 对人员、枚举等控件可能保存内部 ID，不能一律读取 `.value`；需要区分隐藏值节点与可见显示节点。
- 未激活页签可能尚未渲染明细 DOM，仍需先激活页签并等待目标字段 class 出现。
- 待确认命名：用户列出的“客开集成内容”字段为 `序号/任务目标/开始时间`，结构更像客开任务明细；“客开集成复用”结构对应当前客开集成明细。

## 2026-07-13 精确 selector 第一版

- 已按用户提供的命名直接落地，不再调整“客开集成内容 / 客开集成复用”的业务名称。
- 新增 `FIELD_ID_MAP`，收录项目信息、项目盘点信息、项目计划、客开基础字段的 `fieldXXXX_id`。
- 新增 `DETAIL_FIELD_MAP`，收录实施任务、实施业务应用、客开集成内容、客开集成复用、阶段交付物、项目投放的字段 class 组合。
- 当前已有校验项已切换到精确 selector：单字段走 ID；明细走“激活页签 -> 字段 class 组合锁表 -> 同一行读取必填字段”。
- 人员选择等控件支持“隐藏 ID + 可见标签文本”读取，trace 会显示 `id-visible-text`。
- 删除已无调用的旧明细路径：按中文表头猜表、按固定列下标计数。
- 结果名称已按用户提供的信息调整为“客开集成内容明细”和“客开集成复用明细”。
- 验证通过：`node content.contract.test.js`；`node --check content.js`；`node --check content.contract.test.js`。
- 待真实页面验证：浏览态与编辑态下各字段 ID 是否都存在；未激活页签点击后字段 class 是否在 1600ms 内完成渲染。

## 2026-07-13 校验结果第二版

- `项目信息` 改为纯表格化数据展示，包含 12 个字段，不参与通过/不通过统计，空值仅显示 `(空)`。
- `项目盘点信息` 合并为一个校验项，5 个字段均不允许为空。
- `项目计划` 合并为一个校验项，`项目主计划 / 主计划锁定` 均不允许为空。
- 新增 `实施业务应用` 校验，要求同一行 `序号 / 业务应用类型 / 业务模块 / 业务名称` 均有值。
- 明细规则已按用户最新清单更新：客开集成复用包含序号；项目投放包含顾问类型和项目角色；阶段交付物要求序号、文档阶段、阶段交付物。
- 明细 selector 改为动态匹配：`[class*="formson_<表号>_"][class~="fieldXXXX"]`，不写死 `{xxxxxxxx}` 明细数据 ID。
- 结果名称更新为：实施任务分解、实施业务应用、客开基础信息、客开任务分解、客开集成复用明细。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 CAP 输入框运行时值分析

- 截图中的 `input.ui-input__inner` 没有 `value="..."` HTML 属性，但页面显示了值；这是 Vue/CAP 将值写入 `input.value` 运行时属性的正常现象。
- 当前 `readControlValue()` 已读取 `el.value`，因此该字段理论上可取；不能使用 `textContent` 或 `getAttribute('value')` 判断。
- 若插件仍判空，优先怀疑页签激活后的异步时序：当前 `waitForTable()` 只等待表格出现，可能在输入框 `.value` 注入前就开始计数。
- 下一步应在真实页面用 `$0.value` 验证；若能返回显示文本，则把等待条件升级为“表格存在且必填字段值已完成渲染”。

## 2026-07-13 输入控件双通道取值

- 已按用户要求修改统一控件读取：优先读取运行时 `el.value`，为空时读取 `el.getAttribute('value')`，两者均为空才按无值处理。
- 修改位于 `readControlValue()`，主字段和所有明细字段统一生效。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 多字段校验表格

- `项目盘点信息` 改为校验表格：保留通过/不通过、校验规则和缺失字段提示，同时逐行展示字段和值。
- `项目计划` 复用同一多字段校验表格展示。
- 表格中的空值显示为 `(空)`，校验表格仍计入通过/不通过统计；纯 `项目信息` 表格仍不计入统计。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 精确页签切换与展示修正

- 已新增 `TAB_SELECTOR_MAP`，明细取值前优先按精确页签 ID 切换：
- `实施任务 -> div#tab-clientId1894-0`
- `客开任务 -> div#tab-clientId1894-1`
- `阶段交付物 -> div#tab-clientId2089-0`
- `项目投放 / 项目投放明细 -> div#tab-clientId2089-1`
- `项目信息` 表格右侧值新增展示清洗，去掉开头重复字段 label，例如 `合同编号TQPMP...` 显示为 `TQPMP...`。
- `按期验收` 字段补充错别字兼容：`暗器验收概率`、`按期验收概率` 均映射到 `field0108_id`；同时清理旧错字 `按照验收率`。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件并刷新 OA 页面，重点回归 `实施任务 / 客开任务 / 阶段交付物 / 项目投放明细` 是否都会先切页签再统计有效行。

## 2026-07-13 空控件与占位符取值修正

- 修复 `是否提前进场` 空下拉框被误读成 `提前进场`：`readFieldByIdMeta()` 对带编辑控件但控件真实值为空的候选节点，不再回退读取外层容器文本。
- `项目盘点信息` 和 `项目计划` 的表格右侧值也统一走 `cleanFieldDisplayValue()`，去掉字段 label 前缀。
- 新增 placeholder 黑名单：`项目当前进展描述`、`项目下一步的策略及推动动作` 不再作为真实字段值。
- `保底/争取` 展示时去掉 `预测维度` 前缀。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件并刷新 OA 页面，重点回归 `是否提前进场` 空值、`当前项目进度` 空 placeholder、`下一步安排` 空 placeholder、`保底/争取` 展示。

## 2026-07-13 客开基础信息表格化

- `客开基础信息` 已改为多字段校验表格展示，包含 `客开负责人 / 客开启动时间 / 客开进度 / Ctp-Studio仓库地址`。
- 右侧字段值统一经过 `cleanFieldDisplayValue()` 清洗，不重复显示字段名称。
- 不通过详情改为列出缺失字段，例如 `不允许为空：客开启动时间、客开进度`。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件并刷新 OA 页面，回归 `客开基础信息` 表格右侧是否只显示实际值。

## 2026-07-13 字段展示清洗补充

- `按期验收率 / 按期验收概率 / 暗器验收概率` 展示时只保留百分比，例如 `暗器验收概率60%` 显示为 `60%`；提取不到百分比则按空值展示。
- `cleanFieldDisplayValue()` 已支持按 `FIELD_ANCHOR_ALIASES` 清理字段别名前缀，例如 `客开责任人杨大友` 显示为 `杨大友`。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件并刷新 OA 页面，回归 `按期验收率` 和 `客开负责人` 的右侧展示值。

## 2026-07-13 明细三态合规判断

- 新增明细通用统计：`valueRows` 表示有任一相关字段值的行，`validRows` 表示规则要求字段都完整的合规行。
- 所有带合规性要求的明细统一三态显示：
- 有值且合规：绿色，通过。
- 有值但不合规：黄色，待完善。
- 无值：红色，不通过。
- 已应用到 `实施任务分解 / 实施业务应用 / 客开任务分解 / 客开集成复用明细 / 阶段交付物明细表 / 项目投放明细`。
- 结果 trace 改为展示 `有值行数` 和 `合规行数`，便于判断为什么是黄色或红色。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件并刷新 OA 页面，重点回归 `客开集成复用明细` 有值但缺列时是否显示黄色。

## 2026-07-13 表格读取值详情收敛

- `客开基础信息` 和 `项目盘点信息` 的表格卡片不再显示底部 `读取值：...` 详情，保留字段表格、校验规则和结论。
- 其他校验项的读取值详情暂时保留，方便继续排查明细定位问题。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 项目计划与明细三态修正

- `项目计划` 规则改为 `项目主计划 / 主计划锁定` 不允许全部为空，任一字段有值即通过。
- `项目计划` 表格卡片不再显示底部 `读取值：...` 详情。
- `项目主计划` 的展示值中如包含 `http://` 或 `https://` 链接，会渲染成可点击链接并新窗口打开。
- 明细三态修正：`合规行数 = 0` 时一律红色；只有 `合规行数 > 0` 且 `有值行数 > 合规行数` 时才显示黄色。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 明细黄色例外规则

- `实施业务应用` 和 `客开集成复用明细` 去掉“不允许为空”的红色规则。
- 这两项现在只按合规行数判断：`合规行数 > 0` 显示绿色，否则显示黄色。
- 其他明细仍保持原规则：合规行数为 0 时默认红色，除非后续明确指定例外。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 上一条下一条自动重检

- 浏览状态下点击上一条 / 下一条导航箭头后，`project-check` 会自动延迟重新检查当前页面数据。
- 识别的箭头 class：`.cap-icon-zuojiantou`、`.cap-icon-youjiantou`。
- 自动重检采用 900ms 防抖延迟；如果当前检查仍在运行，会继续延迟，避免并发检查。
- 监听器只绑定一次，并排除插件自身面板点击。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在浏览态点击上一条/下一条，确认面板自动刷新为最新记录的检查结果。

## 2026-07-13 上一条下一条监听增强

- 针对现场点击上一条/下一条后检查结果不变的问题，判断原监听大概率没有命中导航事件。
- 监听事件已从单一 `click` 扩展为 `pointerup / mouseup / click`，覆盖 CAP 图标可能拦截 click 的情况。
- 自动重检监听已提前到 `bootstrap()` 的目标页判断前绑定，避免导航按钮位于外层 document/frame 时没有监听。
- 触发后不再二次依赖 `isTargetPage()`，900ms 后直接重新执行 `runChecksStream()`。
- 已增加控制台日志：`[kk-helper:project-check] record navigation detected, rerun project check`，便于现场确认是否触发。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 上一条下一条等待数据就绪

- 针对现场自动重检后结果全空的问题，修正为导航后先等待项目数据就绪，再执行检查。
- 新增 `resetReadCaches()`，统一清空读取缓存，避免切换记录后继续使用旧 document/table 缓存。
- 新增 `isProjectDataReady()`，通过 `项目编号 / 合同编号 / 客户经理 / 项目经理` 任一主字段能读到值来判断当前记录 DOM 已就绪。
- 自动重检现在先延迟 900ms，再最多轮询 6 秒，每 300ms 检查一次数据是否就绪；就绪后才执行 `runChecksStream()`。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在浏览态点上一条/下一条，确认不再出现 `项目信息` 全部 `(空)`。

## 2026-07-13 自动重检等待时间与字段别名清洗

- 上一条/下一条自动重检等待数据就绪的最长时间从 6 秒调整为 3 秒；仍保持每 300ms 轮询一次。
- `是否提前进场` 展示增加别名清洗：`提前进场是` 显示为 `是`。
- `项目类型` 展示增加别名清洗：`项目类别实施` 显示为 `实施`。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 编辑态保存自动重检

- 编辑状态点击 `保存并修改下一条` 或 `保存` 后，也会触发项目台账自动重检。
- 识别图标 class：`.cap-icon-save-and-modify-next`、`.cap-icon-baocun`。
- 同时增加按钮文本兜底识别：`保存并修改下一条`、`保存`。
- 复用上一条/下一条的 3 秒数据就绪等待逻辑，不新增独立流程。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在编辑态分别点击 `保存`、`保存并修改下一条`，确认约 3 秒内结果面板自动刷新。

## 2026-07-13 编辑态保存自动重检日志增强

- 保存按钮识别增强：优先匹配 `.cap4-headers__btn`，再读取按钮文本和图标 class。
- 自动重检新增控制台日志，便于现场判断卡在哪一步：
- `auto check trigger captured`：事件已捕获。
- `auto check scheduled`：已进入等待流程。
- `auto check waiting`：正在等待数据就绪/签名变化/页面稳定。
- `auto check rerun`：正式执行重新检查。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在编辑态点击 `保存` 或 `保存并修改下一条`，打开控制台查看上述日志是否出现。

## 2026-07-13 自动重检 onChange 及时性优化

- 自动重检等待逻辑新增 `MutationObserver`，监听页面 DOM 变化；DOM 变化后 50ms 内重新判断是否可以执行检查。
- 数据稳定窗口从 600ms 缩短到 200ms，减少网页加载完成后的等待时间。
- 保留 300ms 轮询作为兜底，保留 30 秒异常超时，避免页面无变化时永久等待。
- 自动重检完成或超时执行后会断开 DOM 观察器，避免持续监听。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，点击 `保存并修改下一条`，观察控制台 `auto check waiting` 到 `auto check rerun` 的间隔是否明显缩短。

## 2026-07-13 自动重检 loading 误判修复

- 针对日志 `ready=true changed=true loading=true stable=true` 重复多次的问题，收窄 `isProjectPageLoading()` 判断。
- 删除 `[class*="loading"] / [class*="Loading"]` 这类过宽匹配，避免页面常驻 loading class 导致一直等待。
- 删除整页文本扫描，只检查可见加载遮罩或消息节点：`.el-loading-mask / .ant-spin / .ui-loading / .cap-loading / .cap4-loading / .ui-message / .el-message / .ant-message`。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 自动重检等待页面加载完成

- 自动重检不再依赖固定 3 秒触发，改为等待页面数据稳定后执行。
- 点击触发时会先记录当前项目数据签名，签名字段包括 `项目编号 / 合同编号 / 客户经理 / 项目经理`。
- `上一条 / 下一条 / 保存并修改下一条` 需要等待数据签名变化；普通 `保存` 不要求签名变化。
- 等待条件：页面加载/保存提示消失、关键字段有值、数据签名稳定至少 600ms。
- 保留 30 秒异常兜底，避免页面异常时无限等待；正常情况下不是按 30 秒触发。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在网络慢或表单复杂时点击 `保存并修改下一条`，确认页面新记录加载完成后再刷新检查结果。

## 2026-07-13 Ctp-Studio 仓库地址去重和链接化

- `Ctp-Studio仓库地址` 展示值新增专门清洗：从重复文本中只提取第一个 `http/https` 链接。
- 示例：`http://... / Ctp-Studio仓库地址http://...` 只显示第一个 `http://...`。
- 表格渲染新增链接样式，`Ctp-Studio仓库地址` 和 `项目主计划` 中的 URL 都可点击并新窗口打开。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 项目主计划链接去重

- `项目主计划` 展示值新增 URL 优先清洗：如果内容里有 `http/https` 链接，只显示第一个链接。
- 解决 `链接 / 项目主计划标题 链接` 这种重复展示问题。
- 如果没有 URL，则仍保留清洗后的文本值。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-13 长文本换行展示

- `当前项目进度`、`下一步安排` 改为保留表单原始换行，不再通过 `normalizeText()` 压缩成一整段文本。
- 新增 `preserveText()` 路径，控件运行时值、可见文本和字段清洗阶段都会保留 `\n`。
- 表格右侧值统一使用 `white-space:pre-wrap` 渲染，换行会按表单显示出来。
- 其他短字段仍使用规范化清洗，避免影响 `项目类型 / 客开负责人 / 链接字段` 等已修复展示。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件并刷新 OA 页面，检查 `项目盘点信息` 表格中的 `当前项目进度`、`下一步安排` 是否按换行显示。

## 2026-07-13 主计划锁定附件下载

- 链接读取从只取 `a` 标签文本，改为同时保留可用 `href`，相对地址会转成当前站点下的完整 `http/https` 地址。
- `主计划锁定` 加入链接渲染字段，结果表格中附件链接可点击打开/下载。
- 跳过 `javascript:` 和 `#` 链接，避免把不可下载的伪链接展示成下载地址。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，找一条 `主计划锁定` 已上传附件的数据，确认结果表格里附件链接可点击下载。

## 2026-07-13 主计划锁定 CAP4 附件真实下载链接

- 只读参考 `conflict-radar` 的 CAP4 附件处理逻辑，确认真实下载地址由 `.cap4-attach` Vue 组件数据组装，不是普通 `href`。
- 新增最小附件解析：从 Vue2/Vue3 组件数据递归查找含 `fileId` 的附件对象，并组装 `/seeyon/fileDownload.do?method=doDownload&filename=...&v=...&fileId=...&createDate=...`。
- `主计划锁定` 现在会显示单个附件文件名和可点击下载链接；同时避免把“全部下载”文本混入字段值。
- 链接渲染改为 `linkifyHttpUrls()`，避免 URL 参数显示被 HTML 转义打乱。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 已知问题：`content.js` 当前纯代码行数约 1657，明显超出单文件健康范围；本次按最小补丁处理，未做结构性拆分。
- 下一步最小指令：重新加载插件，检查 `主计划锁定` 是否只展示 `千年舟客开计划表.xlsx (454KB)` 对应的单个可点击下载链接。

## 2026-07-14 主计划锁定批量下载链接

- 用户确认页面存在隐藏批量下载链接：`.cap4-attach-downall[href]`，可直接打包下载 `主计划锁定` 控件上传的附件。
- `readAttachmentLinks()` 现在优先使用该批量下载链接，展示名取 `download` 属性，例如 `主计划锁定.zip`。
- 继续过滤展示文本里的 `全部下载`，不再把它作为字段值显示。
- 删除未使用的模拟点击下载图标逻辑，保留更短的直接链接方案。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，确认 `主计划锁定` 行只显示 `主计划锁定.zip` 下载链接，点击后浏览器下载 zip。

## 2026-07-14 bug-flow 附件下载只读核查

- 按用户要求只读核查 `sh-browser-plugin/bug-flow`，未修改该插件任何文件。
- `bug-flow` 目录只有 `bug-flow.js`，没有独立 manifest/background，也没有 `download / fileDownload / batchDownload / cap4-attach / chrome.downloads` 相关实现。
- `bug-flow` 的 CAP4 表单能力主要是：递归定位同源 iframe、通过 `#field0161_id` 找表单、调用 `baseInfo` 获取 `moduleId/rightId`、调用 `/rest/cap4/form/createOrEdit` 读取字段 `field1259`。
- 结论：`bug-flow` 不能作为 CAP4 附件下载样例；附件下载实现应参考 `conflict-radar`，或直接使用当前页面 `.cap4-attach-downall[href]`。
- 下一步最小指令：继续修 `project-check` 时，不再从 `bug-flow` 找下载逻辑；只参考 CAP4 页面 DOM 或 `conflict-radar` 附件处理链路。

## 2026-07-14 主计划锁定附件名称下载展示

- 用户给出真实单附件下载 URL，要求结果面板不能显性展示 URL，只显示附件名称，点击文件名下载。
- `renderTableValue()` 针对 `主计划锁定` 改为 `renderNamedLink()`：内部仍使用 `文件名 / URL` 的读取值，但渲染时只显示 URL 前的文件名。
- 链接增加 `download` 属性，点击文件名交给浏览器下载。
- 普通链接字段仍走 `linkifyHttpUrls()`，不影响 `项目主计划`、`Ctp-Studio仓库地址`。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，确认 `主计划锁定` 右侧只显示 `千年舟客开计划表.xlsx` 或 `主计划锁定.zip`，点击文件名触发下载。

## 2026-07-14 主计划锁定附件名被裁剪修复

- 截图显示附件名只剩 `.zip`，根因是 `cleanFieldDisplayValue()` 把 `主计划锁定.zip` 开头的 `主计划锁定` 当字段名前缀裁掉。
- `主计划锁定` 现在跳过通用字段名前缀清洗，仅去掉 `全部下载` 前缀，保留完整附件名。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，确认结果显示 `主计划锁定.zip`，不是 `.zip`。

## 2026-07-14 主计划锁定 iframe 下载

- 用户确认 CAP4 附件下载通过隐藏 iframe `id="myFormIframe"` 设置 `src` 触发。
- `主计划锁定` 链接不再直接跳转真实 URL，而是把下载地址挂到 `data-pc-download-url`，点击文件名后写入/复用隐藏 iframe。
- 对 `/seeyon/fileDownload.do` 下载地址，点击时将 `method` 统一设置为 `download`，匹配页面原生 iframe 下载格式。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，点击 `主计划锁定` 附件名，检查页面是否生成/复用 `#myFormIframe` 并触发浏览器下载。

## 2026-07-14 主计划锁定原生图标下载

- 用户确认 `#myFormIframe` 只有前台点击下载后才生成，不是稳定入口；稳定入口是原附件行里的 `span.icon.CAP.cap-icon-download`。
- `主计划锁定` 结果面板点击文件名时，改为定位 `field1598_id` 下同名附件行，并触发 CAP4 原生下载图标点击。
- 不再优先使用 `.cap4-attach-downall[href]`，避免下载成 `主计划锁定.zip`；保持原文件类型下载，例如 `.xlsx`。
- 下载地址不再挂在结果面板 URL 上，只挂附件名 `data-pc-download-name`，避免显性 URL 展示。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，点击 `千年舟客开计划表.xlsx` 文件名，确认触发原 CAP4 下载图标并下载原始 xlsx 文件。

## 2026-07-14 Ctp-Studio 长链接换行

- 结果表格改为 `table-layout:fixed`，避免长 URL 撑开检查窗体。
- 表格值单元格增加 `overflow-wrap:anywhere; word-break:break-all; white-space:normal`，长 `Ctp-Studio仓库地址` 会在单元格内换行。
- 链接渲染也增加同样断行样式，避免可点击 URL 自身撑出横向滚动条。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，检查 `Ctp-Studio仓库地址` 长地址是否自动换行且面板无横向滚动条。

## 2026-07-14 明细空行业务字段判定

- 截图显示 `实施任务分解`、`实施业务应用` 只有系统序号 `1`，业务字段为空，但被统计为合规行。
- 根因是 `detailRowsStatsInTable()` 把 `seq` 序号字段也纳入 `values.every(Boolean)`，导致序号自动生成时空业务行被判合规。
- 现改为明细统计忽略 `seq`：有值行必须至少一个非序号业务字段有值；合规行要求所有非序号必填业务字段都有值。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，确认仅有序号、业务字段为空的明细合规行数为 0。

## 2026-07-14 回退到 Ctp-Studio 长链接换行后状态

- 按用户要求，当前状态回到 `Ctp-Studio 长链接换行` 修改之后。
- 已撤销 `明细空行业务字段判定` 的代码与契约测试，明细统计恢复为 requiredFields 全字段判断。
- 保留 `Ctp-Studio 长链接换行`：结果表格仍使用 `table-layout:fixed`，长 URL 仍使用 `overflow-wrap:anywhere` 换行。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。

## 2026-07-14 明细页签旧缓存修复

- 现象：多个明细结果显示 `未定位到表格`，包括 `客开任务分解 / 客开集成复用明细 / 阶段交付物 / 项目投放`。
- 根因判断：CAP4 页签切换后动态重渲染 DOM，但原逻辑只清 `tableResolveCache`，`docsCache/tabNodeCache/section*` 等缓存仍可能指向旧 DOM。
- 修复：`waitForTable()` 每轮查表前刷新完整读取缓存；`withTabActivated()` 和 `withTabGroup()` 每次点击页签后调用 `resetReadCaches()`。
- 修改文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，确认切换到 `客开任务 / 阶段交付物 / 项目投放` 后不再显示 `未定位到表格`。

## 2026-07-14 浏览态明细页签硬绑定

- 当前目标：让浏览状态下的明细读取和编辑状态一样，先切到明确页签，再读取当前页签下的明细表字段。
- 已完成事项：新增 `DETAIL_TAB_MAP`，把 `implementTask / implementBusiness / kkTask / kkIntegrationReuse / phaseDeliver / projectPut` 绑定到 `实施任务 / 客开任务 / 阶段交付物 / 项目投放`。
- 已完成事项：新增 `readDetailStateOnTab()`，所有目标明细检查统一走“切页签 -> waitForTable -> detailRowsStatsByKey”。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：不修改 `readDetailFieldValue()`、`detailRowsStatsInTable()` 等已验证编辑态取值函数，只在调用入口补浏览态页签硬约束。
- 未解决问题：未在真实浏览态页面做现场 DOM 验证；若仍未定位到表格，需要抓当前浏览态页签下真实 DOM。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在浏览状态分别测试 `实施任务 / 客开任务 / 阶段交付物 / 项目投放明细` 的检查结果。

## 2026-07-14 浏览态明细顺序切页读取

- 当前目标：浏览状态下按用户指定顺序切换页签并读取对应明细，避免读到未加载或非当前页签数据。
- 已完成事项：`readDetailStateOnTab()` 改为通过 `activateTabForRead()` 强制点击 `DETAIL_TAB_MAP` 对应页签后再读取，不再自动恢复原页签。
- 已完成事项：去掉明细读取外层 `withTabActivated()` / `withTabGroup()` 包裹，按顺序读取：实施任务页签、客开任务页签、阶段交付物页签、项目投放页签。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：编辑态底层取值函数不动，只调整浏览态/通用明细读取入口的页签切换策略。
- 未解决问题：若 `div#tab-clientId...` 在真实页面不是可点击页签头而是内容容器，还需要抓浏览态真实 DOM 确认点击目标。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在浏览态执行项目台账检查，确认四个页签是否按顺序切换并输出对应明细数据。

## 2026-07-14 浏览态当前页签优先读取

- 当前目标：浏览状态下先获取当前页签下已加载的数据；只有当前页签无值时，再切换到配置页签读取。
- 已完成事项：`readDetailStateOnTab()` 现在先执行当前 DOM 读取，若找到表且 `valueRows` 或 `validRows` 大于 0，直接返回当前页签结果。
- 已完成事项：只有当前页签未读到有效/有值数据时，才调用 `activateTabForRead()` 切到 `DETAIL_TAB_MAP` 对应页签后重读。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：减少浏览态不必要页签切换，降低误切到别的明细页签导致取错值的风险；编辑态底层取值逻辑未修改。
- 未解决问题：真实页面仍需验证“当前页签有值但合规为 0”的业务场景是否应保留当前页签结果还是继续切页签。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在浏览态分别停留在实施/客开/阶段交付物/项目投放页签执行检查，确认当前页签有数据时不会被强制切走。

## 2026-07-14 浏览态明细表头兜底读取

- 当前目标：修复浏览状态下可见明细表有数据，但检查结果显示“未定位到表格”的问题。
- 已完成事项：新增 `DETAIL_LABEL_MAP`，为各明细字段配置浏览态表头名称。
- 已完成事项：`getDetailTableByKey()` 在 `formson_* + field*` class 找表失败时，改为按表头前 3 个列名兜底找表。
- 已完成事项：`detailRowsStatsInTable()` 在字段 class 取不到单元格值时，改为按表头列下标读取单元格。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：编辑态仍优先走字段 class 精准取值；浏览态只在 class 失败时才走表头兜底。
- 未解决问题：如果浏览态某些必填列没有渲染在 DOM 中，仍可能只能定位表但合规数为 0，需要真实 DOM 再确认。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，在截图所示浏览态测试阶段交付物明细是否不再显示“未定位到表格”。

## 2026-07-14 同表头明细串表修复

- 当前目标：修复浏览态当前页签优先读取导致 `实施任务分解` 与 `客开任务分解` 等同表头明细互相串表的问题。
- 已完成事项：`readDetailStateOnTab()` 现在只有在目标页签已经处于激活状态时，才会先读取当前 DOM。
- 已完成事项：如果目标页签未激活，先调用 `activateTabForRead()` 切到目标页签，再读取明细，避免 `序号/任务目标/开始时间` 这类相同表头串用。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：保留浏览态表头兜底，但增加页签激活前提；编辑态字段 class 取值逻辑未修改。
- 未解决问题：仍需用户在真实浏览态确认各页签结果是否对应当前表格。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，重点测试 `实施任务分解` 与 `客开任务分解` 是否还会互相串数。

## 2026-07-14 项目投放明细角色表头修复

- 当前目标：修复浏览态 `项目投放明细` 有数据但合规行数为 0 的问题。
- 已完成事项：将 `projectPut.projectRole` 浏览态表头从错误的 `顾问角色` 改为页面真实表头 `项目角色`。
- 已完成事项：同步将项目投放明细校验规则和失败提示中的 `顾问角色` 改为 `项目角色`。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：字段 class 仍使用用户给定的 `field0312`；只修浏览态表头兜底名称和展示文案。
- 未解决问题：真实页面需重新加载插件确认项目投放明细合规行数是否按可见 3 行计算。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，测试项目投放明细是否从红色变为绿色并显示合规行数大于 0。

## 2026-07-14 明细序号空行业务判断修复

- 当前目标：修复浏览态明细只有系统序号、业务字段为空时仍被判定为有值/合规的问题。
- 已完成事项：`detailRowsStatsInTable()` 统计 `valueRows` 和 `validRows` 时，优先使用非 `seq` 的业务字段判断。
- 已完成事项：序号字段仍保留用于行定位和展示，但不再单独撑起有值行或合规行。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：这次恢复用户之前确认过的规则：明细有效性不能只靠系统序号，必须业务字段有值。
- 未解决问题：真实页面需重新加载插件确认 `实施业务应用` 空业务行不再显示绿色。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，测试截图中 `实施业务应用` 是否从绿色变为黄色或红色，且合规行数为 0。

## 2026-07-14 明细字段名误判为值修复

- 当前目标：修复浏览态明细业务字段为空，但读取到字段名/表头名本身后被判定为合规的问题。
- 已完成事项：`detailRowsStatsInTable()` 逐字段取值后，如果值等于当前表头名，强制按空值处理。
- 已完成事项：保留非 `seq` 业务字段判断规则，序号仍不参与有值/合规判断。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：只在明细统计层做字段名置空，不改编辑态字段 class 精准读取路径。
- 未解决问题：真实页面需重新加载插件确认截图中的 `实施业务应用` 合规行数变为 0。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，测试只有序号、业务字段为空的明细是否不再判绿。

## 2026-07-14 sh-browser-plugin 备份与版本升级

- 当前目标：备份当前 `sh-browser-plugin` 并升级插件版本号。
- 已完成事项：完整备份目录已创建：`/Users/songhw/BDWPS/mac/CodeX/致远提效浏览器插件/backups/sh-browser-plugin-3.4.3-20260714-020643`。
- 已完成事项：主插件 `manifest.json` 版本号从 `3.4.3` 升级到 `3.4.4`。
- 修改过的文件：`manifest.json`、`project-check/CODEX_HANDOFF.md`。
- 关键决策：备份放在 `sh-browser-plugin` 同级 `backups` 目录，避免影响浏览器加载当前插件目录。
- 未解决问题：未重新加载浏览器扩展，需要用户在 Chrome 扩展页手动刷新后确认版本显示为 `3.4.4`。
- 验证通过：`node -e "JSON.parse(...)"` 读取 manifest 成功并输出 `3.4.4`；备份目录大小 `588K` 且包含 `manifest.json`。
- 下一步最小指令：打开 Chrome 扩展管理页刷新 `ZJAI-PLUGIN`，确认版本号为 `3.4.4`。

## 2026-07-14 项目信息新增项目名称

- 当前目标：浏览、编辑状态下在 `项目信息` 表格中增加 `项目名称` 字段。
- 已完成事项：`FIELD_ID_MAP` 新增 `项目名称: field0045_id`。
- 已完成事项：`projectInfoLabels` 在 `客户名称` 与 `项目编号` 之间新增 `项目名称`。
- 修改过的文件：`content.js`、`content.contract.test.js`、`project-check/CODEX_HANDOFF.md`。
- 关键决策：项目名称使用现有表格渲染样式，长文本会随表格单元格 `overflow-wrap:anywhere` / `white-space:normal` 自动换行，不新增专用样式。
- 未解决问题：需真实页面重新加载插件确认 `项目名称` 在浏览态和编辑态都能取到 `field0045_id` 的值。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，执行项目台账检查，确认项目信息中出现 `项目名称` 且长名称自动换行。

## 2026-07-14 复制当前检查结果按钮

- 当前目标：在结果面板 `重新检查` 后面增加复制按钮，复制当前数据行的所有检查结果。
- 已完成事项：结果面板新增 `复制检查结果` 按钮和 `pc-copy-tip` 提示区域。
- 已完成事项：新增 `copyPanelResults()`，从面板缓存的 `__pcResults` 生成纯文本并写入 `navigator.clipboard`。
- 已完成事项：新增 `formatResultForCopy()`，复制内容包含状态、标题、校验规则、结果、表格字段值和必要读取值。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：复制当前面板已完成的检查结果，不额外重新读取页面，避免复制动作改变页面状态。
- 未解决问题：浏览器剪贴板权限若被站点策略拦截，按钮会显示复制失败信息；需真实页面验证。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，执行检查后点击 `复制检查结果`，确认剪贴板内容和成功提示。

## 2026-07-14 项目经理 memberId 展示试验

- 当前目标：尝试从项目经理选人控件获取 `memberId`，并在 `项目信息` 的项目经理下面展示。
- 已完成事项：新增 `readProjectManagerMemberId()`，从 `field0048_id` 的 DOM 中尝试匹配人员卡片链接或 `memberId` 字段。
- 已完成事项：`项目信息` 表格中在 `项目经理` 后插入 `项目经理memberId` 行。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：只从 `field0048_id` 范围内提取明确的 `memberId`，找不到显示空，不猜测其它长数字。
- 未解决问题：需真实页面重新加载插件确认 `field0048_id` 的 DOM 是否实际包含 `memberId`。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，执行项目台账检查，查看 `项目信息 -> 项目经理memberId` 是否有值。

## 2026-07-14 项目经理人员卡片弹窗

- 当前目标：去掉无效的 `项目经理memberId` 展示；在检查结果项目信息里点击项目经理名称弹出 OA 人员卡片。
- 已完成事项：`readProjectManagerMemberId()` 改为内部使用的 `readProjectManagerCardMemberId()`，不再单独展示 memberId 行。
- 已完成事项：`renderTableValue()` 对 `项目经理` 做特殊渲染；如果能从 `field0048_id` 附近提取 memberId，则显示为可点击链接。
- 已完成事项：新增 `bindPanelPeopleCard()` 和 `showPeopleCardFrame()`，点击项目经理后通过 iframe 打开 `/seeyon/organization/peopleCard.do?method=showPeoPleCard...`。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：不显示 memberId；只在能提取到明确 memberId 时启用点击，否则保留普通项目经理文本。
- 未解决问题：需真实页面验证 `field0048_id` 附近是否含 memberId，以及 OA 是否允许 peopleCard 页面嵌入 iframe。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，执行检查后点击项目信息里的项目经理名称，确认是否弹出人员卡片。

## 2026-07-14 暂停项目经理人员卡片功能

- 当前目标：按用户要求暂停 `项目经理人员卡片` 功能。
- 已完成事项：删除 `readProjectManagerCardMemberId()`、`bindPanelPeopleCard()`、`showPeopleCardFrame()` 及项目经理链接渲染逻辑。
- 已完成事项：项目经理恢复为普通文本显示；`项目经理memberId` 仍不展示。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：在无法稳定获取 `memberId` 前，不继续做人员卡片弹窗，避免误导用户。
- 未解决问题：后续若要恢复，需要先确认 `field0048_id` 或接口中能稳定拿到项目经理 memberId。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，确认项目经理仅普通文本显示且无人员卡片弹窗入口。

## 2026-07-14 浏览态实施任务空目标误判修复

- 当前目标：修复浏览态 `实施任务分解` 只有序号、任务目标为空，但合规行数显示 1 的问题。
- 已完成事项：`detailRowsStatsInTable()` 在存在表头列下标时，优先按表头对应单元格读取值；字段 class 仅作为兜底。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：浏览态表格以可见表头列为准，避免字段 class 串到同一行后面的阶段状态值（如 `未开始`）。
- 未解决问题：需真实页面重新加载插件确认截图中的 `实施任务分解` 合规行数变为 0。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，测试只有序号、任务目标为空的实施任务明细是否不再判绿。

## 2026-07-14 浏览态空表头列禁止 fallback

- 当前目标：修复浏览态 `实施任务分解` 任务目标为空仍被判定合规的问题。
- 已完成事项：`detailRowsStatsInTable()` 改为只要字段存在表头列下标，就只读取该表头列；即使该列为空，也不再回退字段 class。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：浏览态表头列是当前可见表格的真实边界，空值必须保持空，不能 fallback 到同一行后续阶段列或隐藏字段。
- 未解决问题：需真实页面重新加载插件确认截图中的 `实施任务分解` 合规行数变为 0。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，测试任务目标为空时 `实施任务分解` 不再判绿。

## 2026-07-14 多级表头辅助行误判修复

- 当前目标：修复浏览态 `实施任务分解` 多级表头第二行 `开始/确认` 被当成数据行，导致合规行数误为 1 的问题。
- 已完成事项：新增 `isDetailHeaderLikeRow()`，识别只包含当前字段表头词和 `开始/确认` 的辅助表头行。
- 已完成事项：`detailRowsStatsInTable()` 在统计前跳过多级表头辅助行。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：只过滤纯表头辅助行，不扩大到业务文本，避免误删真实数据行。
- 未解决问题：需真实页面重新加载插件确认截图中的 `实施任务分解` 合规行数为 0。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，测试多级表头下空任务目标不再判绿。

## 2026-07-14 明细合规行必须包含序号

- 当前目标：修复浏览态说明文字行或非数据行被当成 `实施任务分解` 合规行的问题。
- 已完成事项：`detailRowsStatsInTable()` 中 `valueRows` 仍按非 `seq` 业务字段是否有值统计，避免只有系统序号算有值。
- 已完成事项：`validRows` 改为必须所有 required 字段都有值，包括 `seq`，避免无序号说明行被判合规。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：合规行必须满足规则中的全部字段；`seq` 不能单独撑起合规，但缺少 `seq` 的说明行也不能合规。
- 未解决问题：需真实页面重新加载插件确认截图中的 `实施任务分解` 合规行数为 0。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，测试空任务目标及说明文字行不会被计为合规。

## 2026-07-14 实施任务分解读取明细调试输出

- 当前目标：按用户要求显示 `实施任务分解` 实际读取到了哪些字段值，辅助定位合规行误判。
- 已完成事项：`detailRowsStatsInTable()` 新增 `samples`，最多记录前 8 行的 required 字段读取值。
- 已完成事项：`createDetailCheckResult()` 支持 `showSamples` 选项，将 `读取明细=...` 加入读取值 trace。
- 已完成事项：仅 `实施任务分解` 开启 `{ showSamples: true }`，其他明细暂不展开，避免面板过乱。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：这是排查性输出，不改变合规统计逻辑。
- 未解决问题：需真实页面重新加载插件查看 `实施任务分解` 读取明细内容，确认是哪一行/哪一列被读到了值。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，查看 `实施任务分解` 卡片下的 `读取明细`。

## 2026-07-14 明细统计从表头后数据行开始

- 当前目标：按用户明确规则，`实施任务分解` 表头有两行，取数必须从第三行 `序号=1` 开始。
- 已完成事项：`detailHeaderIndexes()` 现在返回 `{ indexes, headerEndIndex }`，记录表头区域最后一行。
- 已完成事项：连续的 `开始/确认` 多级表头辅助行会纳入 `headerEndIndex`，不会参与数据统计。
- 已完成事项：`detailRowsStatsInTable()` 现在跳过 `rowIndex <= headerEndIndex` 的所有表头行，从真实数据行开始统计。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：浏览态明细按可见表头区域切分，数据行从表头之后开始；`实施任务分解` 合规仍要求 `序号+任务目标` 都有值。
- 未解决问题：需真实页面重新加载插件确认空任务目标场景合规行数为 0。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，查看 `实施任务分解` 的 `读取明细` 是否从 `序号=1` 行开始。

## 2026-07-14 明细字段标识文本判空

- 当前目标：修复浏览态 `任务目标` 空值却读取为 `实施任务分解-任务目标` 并被判定合规的问题。
- 已完成事项：明细逐字段取值后，若归一化后的值等于或包含当前表头名，统一按空值处理。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：`实施任务分解-任务目标` 这类字段标识文本不是用户填写值，不能参与合规判断。
- 未解决问题：需真实页面重新加载插件确认 `任务目标=(空)` 且合规行数为 0。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，查看 `实施任务分解` 的 `读取明细` 是否显示 `任务目标=(空)`。

## 2026-07-14 明细表内层表优先选择

- 当前目标：修复客开集成复用、阶段交付物、项目投放等一行表头明细被错误判定的问题。
- 已完成事项：`findTableByHeaders()` 不再返回第一个包含表头的表，而是收集候选后选择文本长度最小的内层表。
- 已完成事项：`getDetailTableByKey()` 字段 class 候选表评分相同时，优先选择文本长度更小的内层表。
- 已完成事项：多级表头逻辑仍仅限 `implementTask`、`kkTask`，其它明细保持一行表头读取。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：问题根因更像选到了外层容器表；最小修复是优先内层具体明细表，不扩大字段规则。
- 未解决问题：需真实页面重新加载插件验证四个明细的合规行数是否恢复正确。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，重新测试客开任务分解、客开集成复用、阶段交付物、项目投放明细。

## 2026-07-14 客开任务与阶段交付物逐列调试输出

- 当前目标：按用户要求，在 `客开任务分解`、`阶段交付物明细表` 中打印实际参与统计的数据行每一列读取值。
- 已完成事项：`detailRowsStatsInTable()` 返回 `debugRows`，记录跳过表头/合计后的每一行、每一列读取结果。
- 已完成事项：`客开任务分解` 和 `阶段交付物明细表` 调用 `createDetailCheckResult()` 时启用 `{ showDebugRows: true }`。
- 已完成事项：新增 `cleanDetailValue()`，不再把 `顾问名称张三` 这类真实“字段名前缀+值”整体清空；仅清空纯表头或字段标识文本。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：调试输出只对这两个用户指定明细开启，避免所有检查项面板过载。
- 未解决问题：需真实页面重新加载插件，查看两个卡片的 `读取值` 中每行每列内容，再据此判断具体哪列未取到。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，重新检查当前数据行，把 `客开任务分解` 和 `阶段交付物明细表` 的 `读取值` 截图发回来。

## 2026-07-14 移除明细逐行逐列调试输出

- 当前目标：问题已定位解决，移除 `客开任务分解`、`阶段交付物明细表` 的每行每列调试内容。
- 已完成事项：删除 `detailDebugHeaders()`、`formatDetailDebugRow()`、`debugRows`、`showDebugRows` 相关逻辑。
- 已完成事项：保留 `cleanDetailValue()`，避免回退“字段名前缀+真实值”被整体清空的问题。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：只移除排查性输出，不回退取值修复。
- 未解决问题：无。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，确认结果面板不再展示逐行逐列明细。

## 2026-07-14 版本备份与升级

- 当前目标：备份当前 `sh-browser-plugin`，并调整插件版本号。
- 已完成事项：完整备份目录已创建：`backups/sh-browser-plugin-3.4.4-20260714-082342`。
- 已完成事项：`manifest.json` 版本号从 `3.4.4` 调整为 `3.4.5`。
- 修改过的文件：`manifest.json`、`project-check/CODEX_HANDOFF.md`。
- 关键决策：仅递增补丁版本，不调整插件描述和功能代码。
- 未解决问题：无。
- 验证通过：`node -e "const m=require('./sh-browser-plugin/manifest.json'); console.log(m.version)"` 输出 `3.4.5`；`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：在浏览器扩展页重新加载插件，确认版本显示为 `3.4.5`。

## 2026-07-15 汇总栏数字高亮与失败项跳转

- 当前目标：增强项目台账检查结果顶部汇总栏，所有数字指标加粗高亮；当 `不通过` 数量大于 0 时，点击数字跳转到第一个不通过项。
- 已完成事项：`updatePanelSummary()` 从纯文本改为 HTML 汇总，`通过/不通过/待完善/数据表/已完成` 数字均使用高亮数字样式。
- 已完成事项：`不通过` 数量大于 0 时数字使用红色、加粗、下划线和可点击标识。
- 已完成事项：结果卡片新增 `data-pc-status`，`scrollToFirstFailedResult()` 可滚动到第一个失败卡片并短暂高亮。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：只增强汇总栏表现和跳转，不改变任何校验规则与通过/不通过/待完善统计逻辑。
- 未解决问题：LSP 未安装，按当前项目状态用 Node 语法检查和契约检查兜底。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`、本地汇总 HTML 运行态脚本检查。
- 下一步最小指令：重新加载插件，执行一次项目台账检查，确认顶部汇总数字高亮；如存在不通过项，点击红色数字能跳到第一个不通过卡片。

## 2026-07-15 汇总栏数字高亮增强

- 当前目标：用户反馈顶部汇总数字视觉上没有明显变化，需要增强高亮效果。
- 已完成事项：汇总数字样式从浅色背景改为实体色胶囊，白色数字、14px、900 字重，并增加阴影。
- 已完成事项：`不通过` 数字大于 0 时继续使用红色实体胶囊，并保留点击跳转到第一个不通过项。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：只调整视觉强度，不改变统计逻辑和跳转逻辑。
- 未解决问题：LSP 未安装，按当前项目状态用 Node 检查兜底。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`、本地汇总 badge HTML 运行态脚本检查。
- 下一步最小指令：重新加载插件，确认顶部数字显示为明显的彩色胶囊。

## 2026-07-15 汇总栏数字改为纯文本高亮

- 当前目标：用户明确不需要圆圈和背景效果，汇总数字只做颜色和加粗高亮。
- 已完成事项：移除汇总数字的背景色、圆角、padding 和阴影。
- 已完成事项：保留数字颜色、15px 字号、900 字重；`不通过` 大于 0 时仍保留红色和点击跳转。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：只调整视觉样式，不改变统计和跳转逻辑。
- 未解决问题：LSP 未安装，按当前项目状态用 Node 检查兜底。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`、本地汇总纯数字 HTML 运行态脚本检查。
- 下一步最小指令：重新加载插件，确认顶部汇总数字不再有圆圈和背景，仅显示彩色加粗数字。

## 2026-07-15 汇总数字指标全量跳转

- 当前目标：每一个汇总数字指标都能点击跳转到第一个对应结果卡片，鼠标悬浮显示 `跳转查看`。
- 已完成事项：汇总数字统一增加 `data-pc-summary-target` 和 `title="跳转查看"`，数量为 0 时不生成可点击目标。
- 已完成事项：`通过/不通过/待完善/数据表/检查中已完成` 分别跳转到第一张 `ok/fail/warn/table/任意结果` 卡片。
- 已完成事项：数据表卡片新增 `data-pc-status="table"`，普通检查和校验表格继续使用已有状态锚点。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：复用结果卡片状态作为锚点，不额外引入复杂锚点 ID。
- 未解决问题：LSP 未安装，按当前项目状态用 Node 检查兜底。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`、本地汇总 target HTML 运行态脚本检查。
- 下一步最小指令：重新加载插件，检查每个非 0 数字悬浮提示为 `跳转查看`，点击后能跳到对应第一张卡片。

## 2026-07-21 非项目台账页面误弹分析

- 当前目标：只读分析为什么打开非项目台账页面也出现 `项目台账检查`。
- 已完成事项：读取 `manifest.json`、`project-check/content.js`、`shared/launcher.js` 中注入范围、页面识别、初始化、自动重检相关代码。
- 已完成事项：确认 `project-check/content.js` 通过 `manifest.json` 注入到 `*://xt.seeyon.com/*` 且 `all_frames=true`。
- 已完成事项：确认当前 `isTargetPage()` 只用正文文本包含 `项目盘点底表 + 项目计划 + 交付物及成本` 判断，缺少 URL、模板、标题或字段组合等强约束。
- 已完成事项：确认 `bootstrap()` 在非目标页只 `return`，不会清理已存在的 `#pc-check-fab` / `#pc-check-panel`；OA 单页切表单后旧面板可能残留。
- 已完成事项：确认 `bindRecordNavigationAutoCheck()` 在 `isTargetPage()` 前绑定，自动重检路径最终可调用 `runChecksStream()`，而 `runChecksStream()` 本身没有再次校验目标页面。
- 修改过的文件：`CODEX_HANDOFF.md`。
- 关键决策：本阶段按用户要求只分析，不修改 JS 代码。
- 未解决问题：需要下一步落地入口守卫：非目标页清理 UI、`runChecksStream()` 执行前二次校验、自动重检调度前/执行前校验目标页。
- 下一步最小指令：允许修改代码后，优先在 `bootstrap()`、`runChecksStream()`、`scheduleAutoCheckAfterNavigation()` 三处补目标页守卫。

## 2026-07-21 project-check 页面白名单入口修复

- 当前目标：仅在 `【区域查看】项目盘点底表` 和 `【区域维护】区域项目档案` 两个界面调用 `project-check`。
- 已完成事项：新增 `PROJECT_CHECK_PAGE_TITLES` 白名单，页面识别只匹配两个指定标题。
- 已完成事项：`isTargetPage()` 同时检查当前文档和可访问的 top 文档，适配 iframe 表单场景。
- 已完成事项：非目标页 `bootstrap()` 会清理 `#pc-check-fab` 和 `#pc-check-panel`，避免 SPA 切换后残留。
- 已完成事项：`runChecksStream()` 执行前二次校验目标页；`scheduleAutoCheckAfterNavigation()` 调度前和执行前都校验目标页。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：不再使用 `项目盘点底表 + 项目计划 + 交付物及成本` 的宽松正文组合判断，改为用户指定页面标题白名单。
- 未解决问题：无法在当前回合直接登录真实 OA 页面做人工点击验证；需浏览器重新加载插件后在两类页面和非目标页面回归。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`、本地白名单入口判定脚本。
- 下一步最小指令：重新加载插件，分别打开 `【区域查看】项目盘点底表`、`【区域维护】区域项目档案`、`交付报价前置评估` 页面，确认前两者显示入口，后者不显示且不会自动弹面板。

## 2026-07-29 project-check 弹框拖动与位置保持

- 当前目标：`project-check` 检查结果弹出框支持拖动，避免遮挡网页内容；上一页/下一页自动重检后保持拖动位置不变。
- 已完成事项：新增 `PANEL_POS_KEY = 'project-check:panel-pos'`，使用 `localStorage` 保存弹框位置。
- 已完成事项：新增 `bindPanelDrag(panel)`，标题栏 `#pc-panel-header` 作为拖动手柄，拖动范围限制在当前视口内。
- 已完成事项：拖动定位后设置 `left/top` 并取消固定 `right`，再次创建弹框时读取历史位置恢复。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：复用现有弹框，不改检查逻辑；上一页/下一页重检本身复用同一 panel，因此拖动后位置天然保持，`localStorage` 用于重新创建/刷新后恢复。
- 未解决问题：LSP 未安装，按当前项目状态用 Node 检查兜底；真实浏览器拖动需重新加载插件后回归。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`、本地 panel drag 静态行为脚本。
- 下一步最小指令：重新加载插件，打开项目台账检查面板，拖动标题栏到左侧/下方，再点上一条/下一条，确认弹框位置不回到右上角。

## 2026-07-29 project-check 多弹框修复

- 当前目标：修复点击下一页后出现多个 `项目台账检查` 弹出框的问题。
- 已完成事项：新增 `isTopWindow()`，UI/面板创建、手动检查、自动重检调度只允许顶层窗口执行。
- 已完成事项：`removeProjectCheckUi()` 改为遍历 `allDocs()`，清理当前页和可访问 iframe 内历史遗留的 `#pc-check-fab` / `#pc-check-panel`。
- 已完成事项：契约测试补充非顶层 frame 不创建 UI、不执行检查、不调度自动重检，以及跨 frame 清理断言。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：保留 `manifest all_frames=true`，避免影响取值读取；只收敛 UI 和执行入口到顶层窗口。
- 未解决问题：LSP 未安装，按当前项目状态用 Node 检查兜底；真实浏览器需重新加载插件后点击上一页/下一页回归。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`、本地 single panel frame guard 静态行为脚本。
- 下一步最小指令：重新加载插件，打开区域项目档案，先拖动检查弹框，再点击下一页，确认只保留一个弹框且位置不变。

## 2026-07-29 project-check 合法页面入口消失修复

- 当前目标：修复 `【区域维护】区域项目档案` / `项目盘点底表` 页面上 `project-check` 入口消失的问题。
- 已完成事项：非顶层 iframe 启动时只清理自身文档内历史 UI，不再调用全局 `removeProjectCheckUi()` 删除 top 页面入口。
- 已完成事项：页面白名单识别新增 `pageIdentityText(doc)`，同时读取 `document.title` 和正文，避免只靠 body 文本导致合法页面漏判。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：继续保留“只允许顶层窗口创建 UI”的单弹框策略；只收窄 iframe 清理范围，避免回到多弹框问题。
- 未解决问题：当前环境无法直接登录真实 OA 页面做浏览器回归；需重新加载插件后在真实页面验证。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，打开 `【区域维护】区域项目档案` 页面，确认右下角入口恢复；点击上一条/下一条后确认仍只有一个弹框。

## 2026-07-29 project-check 翻页自动重检旧数据修复

- 当前目标：修复点击上一页/下一页后弹框内容没有切到最新数据，但关闭重开能读取最新数据的问题。
- 已完成事项：`allDocs()` 增加可见 frame 评分并按可见面积排序，优先读取当前显示表单，降低旧 iframe 抢先命中的概率。
- 已完成事项：`readFieldByIdMeta()` 跳过不可见字段节点，避免翻页期间隐藏旧表单的 `fieldXXXX_id` 被当作当前值。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：不改弹框渲染和校验逻辑，只修正共享取值入口的文档选择顺序。
- 未解决问题：当前环境无法直接登录真实 OA 页面做上一页/下一页人工回归；需重新加载插件后验证。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，打开区域项目档案，保持弹框打开后点击上一页/下一页，确认合同编号、项目编号、项目名称等立即变为当前页数据。

## 2026-07-29 project-check 翻页自动重检整条旧结果修复

- 当前目标：修复保持弹框打开时点击上一页/下一页后，弹框仍显示第一次检查整条旧数据的问题。
- 已完成事项：`runChecksStream()` 在检查运行中再次触发时不再直接丢弃，而是设置 `pendingAutoCheck`，当前检查结束后立即补跑一次。
- 已完成事项：自动重检监听改为按文档去重绑定 `allDocs()` 中的 top 和可访问 iframe 文档，避免上一页/下一页按钮在 iframe 内时捕获不到事件。
- 已完成事项：DOM 变化观察器触发时清空 `docsCache` 并补绑新文档事件，适配翻页后新 iframe/新表单生成。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：不改字段校验逻辑；本次修复自动重检“最后一次必须执行并覆盖旧结果”的调度问题。
- 未解决问题：当前环境无法直接登录真实 OA 页面做上一页/下一页人工回归；需重新加载插件后验证。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，打开区域项目档案，保持弹框打开后点击上一页/下一页，观察控制台应出现 `auto check trigger captured`、`auto check rerun` 或 `auto check queued`，弹框项目编号应更新为当前页面。

## 2026-07-29 project-check 翻页签名守护兜底

- 当前目标：用户控制台截图显示点击下一页只有 OA 自身 `call onChange/formRendered` 日志，没有 `kk-helper:project-check` 触发日志；需要绕开按钮事件不稳定问题。
- 已完成事项：新增 `startPanelSignatureWatch()`，弹框打开期间每秒读取当前项目关键签名。
- 已完成事项：检查完成后记录 `lastRenderedSignature`；当页面签名与已渲染签名不同且页面不在 loading、没有检查运行、没有已排队重检时，触发 `scheduleAutoCheckAfterNavigation('signature-watch')`。
- 已完成事项：`scheduleAutoCheckAfterNavigation()` 仅对 `record-change` 要求签名再次变化；`signature-watch` 只等待页面稳定后重检，避免把新签名当 before 后卡住。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：保留按钮事件监听，同时增加数据签名兜底；不再依赖 OA 上一页/下一页按钮事件一定能冒泡到插件。
- 未解决问题：当前环境无法直接登录真实 OA 页面做上一页/下一页人工回归；需重新加载插件后验证。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，打开弹框后点击下一页，控制台应至少出现 `auto check signature changed` 和后续 `auto check rerun`，弹框数据应切到当前记录。

## 2026-07-29 project-check 空值不回填字段名修复

- 当前目标：无实际值时必须显示空，不能把 `项目经理`、`内部项目经理`、`交付类型` 等字段名当成字段值。
- 已完成事项：修复 `cleanFieldDisplayValue()`，清洗后值等于字段名或字段别名时返回空。
- 已完成事项：移除 `return cleaned || text` 回退，避免清洗为空后又把原始 label 文本显示出来。
- 修改过的文件：`content.js`、`content.contract.test.js`、`CODEX_HANDOFF.md`。
- 关键决策：字段没有真实值就统一交给表格渲染显示 `(空)`，不做推测和兜底填充。
- 未解决问题：当前环境无法直接登录真实 OA 页面做人工回归；需重新加载插件后验证。
- 验证通过：`node content.contract.test.js`、`node --check content.js`、`node --check content.contract.test.js`。
- 下一步最小指令：重新加载插件，打开该记录确认项目经理、内部项目经理、交付类型无实际值时显示 `(空)`。
