const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'content.js'), 'utf8');

assert.match(
    source,
    /document\.addEventListener\('seeyon-helper:work-hours-open', function \(\) \{\s*showModal\(\);\s*\}\);/,
    '首页工时签卡入口应复用既有 showModal 查询当前登录人'
);
assert.doesNotMatch(
    source,
    /Logger\.error\('baseInfo 缺少 moduleId\/rightId/,
    'baseInfo 缺参是可降级业务失败，不应写入 Chrome 扩展错误页'
);
assert.match(
    source,
    /Logger\.warn\('baseInfo 缺少 moduleId\/rightId/,
    'baseInfo 缺参仍需保留 warn 级别诊断'
);

console.log('work-hours content contract checks passed');
