const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const source = fs.readFileSync(require('node:path').join(__dirname, '..', 'background.js'), 'utf8');

function loadSandbox() {
    const sandbox = {
        console,
        setTimeout,
        clearTimeout,
        fetch: async () => ({ ok: true, json: async () => ({}), text: async () => '' }),
        chrome: {
            cookies: { getAll: async () => [] },
            runtime: { onMessage: { addListener: () => {} } },
            scripting: { executeScript: async () => [] }
        }
    };
    vm.createContext(sandbox);
    vm.runInContext(source, sandbox);
    return sandbox;
}

async function main() {
    const sandbox = loadSandbox();

    sandbox.fetchColManager = async (_method, args) => {
        const subject = args[1].subject;
        if (subject === '顾问工时登记-浙江军团-王渝' || subject === '顾问工时登记-浙江军团-#王渝') {
            return { data: [{ affairId: 'W-old', subject: '顾问工时登记-浙江军团-王渝-2026-07-20', startDate: '2026-07-20 09:00:00' }] };
        }
        if (subject === '顾问工时登记-浙江大区-王渝' || subject === '顾问工时登记-浙江大区-#王渝') {
            return { data: [{ affairId: 'W-new', subject: '顾问工时登记-浙江大区-王渝-2026-07-23', startDate: '2026-07-23 09:00:00' }] };
        }
        if (subject === '浙江军团-王渝' || subject === '浙江军团-#王渝') {
            return { data: [{ affairId: 'S-old-in', subject: '项目作业签卡单-浙江军团-王渝-进场', startDate: '2026-07-20 08:30:00' }] };
        }
        if (subject === '浙江大区-王渝' || subject === '浙江大区-#王渝') {
            return { data: [{ affairId: 'S-new-out', subject: '项目作业签卡单-浙江大区-王渝-离场', startDate: '2026-07-23 18:00:00' }] };
        }
        if (subject === '王渝' || subject === '#王渝') {
            return { data: [] };
        }
        return { data: [] };
    };

    const resultFromNewDeptPage = await sandbox.getRecentDataForPerson({
        subjectPrefix: '顾问工时登记-浙江大区-王渝',
        subjectPrefixes: ['顾问工时登记-浙江大区-王渝'],
        personName: '王渝',
        department: '浙江大区'
    });
    assert.ok(resultFromNewDeptPage['2026-07-20']?.workHours.length, '新页面查询时应兼容命中旧“浙江军团”工时');
    assert.ok(resultFromNewDeptPage['2026-07-20']?.signIn.length, '新页面查询时应兼容命中旧“浙江军团”签到');
    assert.ok(resultFromNewDeptPage['2026-07-23']?.workHours.length, '新页面查询时应命中新“浙江大区”工时');
    assert.ok(resultFromNewDeptPage['2026-07-23']?.signOut.length, '新页面查询时应命中新“浙江大区”签退');

    const resultFromOldDeptPage = await sandbox.getRecentDataForPerson({
        subjectPrefix: '顾问工时登记-浙江军团-王渝',
        subjectPrefixes: ['顾问工时登记-浙江军团-王渝'],
        personName: '王渝',
        department: '浙江军团'
    });
    assert.ok(resultFromOldDeptPage['2026-07-20']?.workHours.length, '旧页面查询时应命中旧“浙江军团”工时');
    assert.ok(resultFromOldDeptPage['2026-07-23']?.workHours.length, '旧页面查询时应兼容命中新“浙江大区”工时');
    assert.ok(resultFromOldDeptPage['2026-07-23']?.signOut.length, '旧页面查询时应兼容命中新“浙江大区”签退');
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
