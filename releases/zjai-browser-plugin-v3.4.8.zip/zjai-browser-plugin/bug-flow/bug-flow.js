// =============================================================================
// 工单速配（致远 BUG 工单工程师识别助手）—— content script
// 来源：seeyon-bug-flow-plugin（原 config / log / extract / api / ui / content 六文件）。
//
// ⚠️ 整体包进 IIFE 的原因：
//   原六文件均为经典脚本、靠顶层全局变量互相通信（CONFIG / LOG_PREFIX / Log /
//   FloatingIcon / init / isTargetPage …）。本插件合并后，work-hours 模块在同一页面
//   （xt.seeyon.com 的 collaboration.do）与之共享同一个 content script 隔离世界，
//   裸全局会与 work-hours 的 LOG_PREFIX / init / isTargetPage 重名冲突（const 重复
//   声明会直接 SyntaxError，function 重复声明会互相覆盖）。故合并为单文件 + IIFE，
//   把所有符号收敛为闭包内局部变量，原逻辑一行不改。
//
// 段内顺序与原插件一致，按依赖排列：config → log → extract → api → ui → content。
// =============================================================================
(function () {
  // ---------------------------------------------------------------------------
  // ---- config.js ----
  // 全局常量集中管理；字段 id / 模板变更时只需改这里。
  const CONFIG = {
    // Step1：页面判定
    urlPrefix: 'https://xt.seeyon.com/seeyon/collaboration/collaboration.do',
    // #subject 的 value 必须以此前缀开头，才认定为「分配工单」节点
    subjectPrefix: 'BUG_',

    // Step2：客户名称选择器（多个候选，按顺序尝试，适配真实 DOM 结构差异）
    // spec 原始为直接子级：#field0161_id > section > .field-content__wrapper
    customerSelectors: [
      '#field0161_id > section > .field-content__wrapper',
      '#field0161_id .field-content__wrapper',
      '#field0161_id',
    ],

    // 接口
    endpoints: {
      // 已办列表查询
      doneList: 'https://xt.seeyon.com/seeyon/ajax.do?method=ajaxAction&managerName=colManager',
      // 工单 baseInfo（取 moduleId / rightId）
      baseInfo: (affairId) =>
        `https://xt.seeyon.com/seeyon/rest/collaboration/v1/web/new/baseInfo?method=summary&openFrom=listDone&affairId=${encodeURIComponent(affairId)}&showTab=true&templateId=&from=listDone&projectId=&summaryId=&baseObjectId=&baseApp=&cashId=&processId=&designId=&docId=&_r=`,
      // 表单详情（取工程师姓名）
      formEdit: 'https://xt.seeyon.com/seeyon/rest/cap4/form/createOrEdit',
    },

    // 字段定位
    field: {
      subject: '#subject',
    },

    // createOrEdit payload 中固定的 nodeName：KK_客户BUG修改人（已 URL 编码）
    nodeName: 'KK_%E5%AE%A2%E6%88%B7BUG%E4%BF%AE%E6%94%B9%E4%BA%BA',

    // 客户名拼装：前后各加下划线。
    // ⚠️ spec 文字说「前后各加 _」（单下划线，对应真实标题 ..._单位名称_...），
    //    但示例 formdata 写成 __单位名称__（双下划线）。这里默认单下划线；
    //    若真实抓包为双下划线，把下面改为 '__' 拼接即可。详见 docs/plan.md §9.3 / §12。
    // 'single' => `_客户名称_`；'double' => `__客户名称__`
    subjectUnderscore: 'single',

    // 等待目标元素出现的轮询参数
    poll: { interval: 200, timeout: 8000 },

    // Step4：历史 BUG 工单候选最多回溯条数（遇到"自身/无工程师"时继续往下找的上限）
    candidateCap: 5,
  };

  // ---------------------------------------------------------------------------
  // ---- log.js ----
  // 统一日志，带固定前缀，便于在 console 中过滤。
  const LOG_PREFIX = '[kk-helper:bug-flow]';
  const Log = {
    info: (...args) => console.log(LOG_PREFIX, ...args),
    warn: (...args) => console.warn(LOG_PREFIX, ...args),
    error: (...args) => console.error(LOG_PREFIX, ...args),
    debug: (...args) => console.debug(LOG_PREFIX, ...args),
  };

  Log.info('content loaded @ ' + location.href);

  // ---------------------------------------------------------------------------
  // ---- extract.js ----
  // 纯解析/取值函数：DOM（含同源 iframe）、正则、JSON 过滤。无网络。

  // 收集可访问的文档：主文档 + 所有同源 iframe 的 contentDocument（递归，覆盖 cap4 等多层嵌套）
  function getAllDocuments() {
    const docs = [];
    const seen = new Set();
    const walk = (doc) => {
      if (!doc || seen.has(doc)) return;
      seen.add(doc);
      docs.push(doc);
      let iframes = [];
      try { iframes = doc.querySelectorAll('iframe'); } catch (e) { iframes = []; }
      for (const ifr of iframes) {
        let d = null;
        try { d = ifr.contentDocument; } catch (e) { d = null; }
        if (d) walk(d);
      }
    };
    walk(document);
    return docs;
  }

  // 在主文档与所有同源 iframe 中查找第一个匹配 selector 的元素
  function queryAllDocuments(selector) {
    for (const doc of getAllDocuments()) {
      const el = doc.querySelector(selector);
      if (el) return el;
    }
    return null;
  }

  // 定位表单 iframe（cap4 表单）：返回含 #field0161_id 的那个 contentDocument
  function getFormDocument() {
    for (const doc of getAllDocuments()) {
      if (doc.querySelector('#field0161_id')) return doc;
    }
    return null;
  }

  // Step2：尝试取客户名称（在表单 iframe 内，静默，返回 {name, selector, el, iframeMissing}）
  function readCustomerNameOnce() {
    const doc = getFormDocument();
    if (!doc) return { name: '', selector: null, el: null, iframeMissing: true };
    for (const sel of CONFIG.customerSelectors) {
      const el = doc.querySelector(sel);
      if (!el) continue;
      const text = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      if (text) return { name: text, selector: sel, el };
    }
    for (const sel of CONFIG.customerSelectors) {
      const el = doc.querySelector(sel);
      if (el) return { name: '', selector: sel, el, iframeMissing: false };
    }
    return { name: '', selector: null, el: null, iframeMissing: false };
  }
  function getCustomerName() {
    return readCustomerNameOnce().name;
  }

  // 当前工单的 moduleId（#summaryId 的 value，跨主文档与 iframe 查找），用于在历史候选中跳过自身
  function getCurrentModuleId() {
    const el = queryAllDocuments('#summaryId');
    if (!el) return '';
    const v = el.value != null ? el.value : el.getAttribute('value') || '';
    return String(v).trim();
  }

  // 标题获取支持两种方式：
  // 1) #subject 元素；2) 当前可访问文档的 window.subject（及 top.subject 兜底）
  // 3) 兜底读取文档 title（新页面/iframe 场景 subject 元素未就绪时仍可识别标题）
  function normalizeSubject(raw) {
    return String(raw || '').replace(/^﻿+/, '').trim();
  }

  function pickBugSubjectFromText(text) {
    const subject = normalizeSubject(text);
    if (!subject) return '';
    if (subject.startsWith(CONFIG.subjectPrefix)) return subject;
    const idx = subject.indexOf(CONFIG.subjectPrefix);
    return idx >= 0 ? subject.slice(idx).trim() : '';
  }

  function getCurrentSubject() {
    const el = queryAllDocuments(CONFIG.field.subject);
    if (el) {
      const val = el.value != null ? el.value : el.getAttribute('value') || '';
      if (val) {
        const subject = pickBugSubjectFromText(val);
        if (subject) {
          Log.debug('[subject] 来源=CONFIG.field.subject：', subject);
          return subject;
        }
      }
    }

    for (const doc of getAllDocuments()) {
      const win = doc && doc.defaultView;
      if (!win) continue;
      try {
        if (typeof win.subject === 'string' && win.subject) {
          const subject = pickBugSubjectFromText(win.subject);
          if (subject) {
            Log.debug('[subject] 来源=window.subject：', subject);
            return subject;
          }
        }
      } catch (_) {}
    }

    for (const doc of getAllDocuments()) {
      const win = doc && doc.defaultView;
      if (!win) continue;
      try {
        if (win.top && win.top !== win && typeof win.top.subject === 'string' && win.top.subject) {
          const subject = pickBugSubjectFromText(win.top.subject);
          if (subject) {
            Log.debug('[subject] 来源=window.top.subject：', subject);
            return subject;
          }
        }
      } catch (_) {}
    }

    for (const doc of getAllDocuments()) {
      try {
        if (doc && doc.title) {
          const subject = pickBugSubjectFromText(doc.title);
          if (subject) {
            Log.debug('[subject] 来源=doc.title：', subject);
            return subject;
          }
        }
      } catch (_) {}
    }

    Log.debug('[subject] 所有来源都未获取到标题');
    return '';
  }

  function extractBaseInfoFieldFromText(jsonText, fieldName) {
    if (typeof jsonText !== 'string' || !jsonText) return '';
    let cap4Start = jsonText.indexOf('"cap4"');
    if (cap4Start < 0) cap4Start = jsonText.indexOf('\\"cap4\\"');
    if (cap4Start < 0) return '';

    const keys = ['"' + fieldName + '"', '\\"' + fieldName + '\\"'];
    let keyPos = -1;
    let keyLen = 0;
    for (let k = 0; k < keys.length; k++) {
      keyPos = jsonText.indexOf(keys[k], cap4Start);
      if (keyPos >= 0) {
        keyLen = keys[k].length;
        break;
      }
    }
    if (keyPos < 0) return '';

    const colon = jsonText.indexOf(':', keyPos + keyLen);
    if (colon < 0) return '';

    let i = colon + 1;
    while (i < jsonText.length && /\s/.test(jsonText.charAt(i))) i++;

    const escapedQuote = jsonText.charAt(i) === '\\' && jsonText.charAt(i + 1) === '"';
    if (jsonText.charAt(i) === '"' || escapedQuote) {
      if (escapedQuote) i++;
      i++;
      let out = '';
      while (i < jsonText.length) {
        const ch = jsonText.charAt(i);
        if (ch === '\\') {
          const next = jsonText.charAt(i + 1);
          if (next === '"') break;
          out += next || '';
          i += 2;
          continue;
        }
        if (ch === '"') break;
        out += ch;
        i++;
      }
      return out;
    }

    const start = i;
    while (i < jsonText.length && /[-0-9.]/.test(jsonText.charAt(i))) i++;
    return jsonText.slice(start, i);
  }

  // Step4a：从 baseInfo 响应提取 moduleId / rightId
  function extractBaseInfoParams(result, affairId) {
    const json = result && result.json;
    const text = (result && result.text) || '';
    const data = json && json.data;
    const cap4 = data && data.zwIframe && data.zwIframe.cap4;
    let moduleId = cap4 && cap4.moduleId ? String(cap4.moduleId) : '';
    let rightId = cap4 && cap4.rightId ? String(cap4.rightId) : '';
    const rawModuleId = extractBaseInfoFieldFromText(text, 'moduleId');
    const rawRightId = extractBaseInfoFieldFromText(text, 'rightId');
    Log.info('  baseInfo 原始参数 affairId:', affairId, '| rawModuleId:', rawModuleId || '(空)', '| rawRightId:', rawRightId ? rawRightId.slice(0, 24) + '…' : '(空)');
    moduleId = rawModuleId || moduleId;
    rightId = rawRightId || rightId;
    if (!moduleId || !rightId) {
      Log.warn(
        '  baseInfo 缺 moduleId/rightId affairId:', affairId,
        '| topKeys:', Object.keys(json || {}).join(','),
        '| dataKeys:', data && typeof data === 'object' ? Object.keys(data).join(',') : '(无data)',
        '| zwIframeKeys:', data && data.zwIframe && typeof data.zwIframe === 'object' ? Object.keys(data.zwIframe).join(',') : '(无zwIframe)',
        '| cap4:', cap4 ? JSON.stringify(cap4) : '(无cap4)'
      );
    }
    return { moduleId, rightId };
  }

  // Step3：筛选 BUG 工单候选（subject 以 BUG 开头且含 BUG20），保持列表顺序（最近在前）
  function getBugCandidates(data) {
    if (!Array.isArray(data)) return [];
    return data.filter(
      (d) =>
        d &&
        typeof d.subject === 'string' &&
        d.subject.indexOf('BUG') === 0 &&
        d.subject.includes('BUG20')
    );
  }

  // 递归在 JSON 树中查找指定 key，返回 [{path, value}]（限深度/数量防爆）
  function locateInJson(obj, targetKeys, path, depth, out) {
    path = path || '';
    depth = depth || 0;
    if (depth > 10 || out.length > 60) return out;
    if (obj && typeof obj === 'object') {
      for (const k of Object.keys(obj)) {
        const v = obj[k];
        const p = path ? path + '.' + k : k;
        if (targetKeys.indexOf(k) >= 0) out.push({ path: p, value: v });
        if (v && typeof v === 'object') locateInJson(v, targetKeys, p, depth + 1, out);
      }
    }
    return out;
  }

  // Step4b：从 createOrEdit 响应取工程师姓名。
  // 响应可能多层包裹（实测 data.data.…），故递归查找 field1259；找不到则打印 fieldInfo 辅助定位。
  function getEngineerName(resultJson) {
    const hits = [];
    locateInJson(resultJson, ['field1259'], '', 0, hits);
    for (const h of hits) {
      const cell = h.value;
      let sv = '';
      if (cell && typeof cell === 'object') {
        sv = cell.showValue != null ? cell.showValue : cell.value != null ? cell.value : '';
      } else if (typeof cell === 'string') {
        sv = cell;
      }
      sv = String(sv).trim();
      if (sv) {
        Log.info('[工程师] 命中 field1259 @', h.path, '=>', JSON.stringify(sv));
        return sv;
      }
    }
    // 未取到可用值：打印各 fieldInfo 的非空字段，辅助定位（或暴露接口报错）
    const fi = [];
    locateInJson(resultJson, ['fieldInfo'], '', 0, fi);
    if (fi.length) {
      fi.slice(0, 3).forEach((x) => {
        const info = x.value || {};
        const items = Object.keys(info)
          .map((k) => {
            const c = info[k] || {};
            const v = c.showValue != null ? c.showValue : c.value;
            return v != null && String(v).trim() ? k + '=' + JSON.stringify(String(v).trim()) : null;
          })
          .filter(Boolean);
        Log.info('[工程师] 未取到 field1259；', x.path, '非空字段:', items.join(' | '));
      });
    } else {
      const inner = resultJson && resultJson.data;
      Log.warn('[工程师] 响应中未找到 field1259 / fieldInfo。内层 success/code/message:', inner && inner.success, inner && inner.code, inner && inner.message);
    }
    return '';
  }

  // 诊断：把 createOrEdit 的完整响应打印出来（对象可展开 + JSON 字符串），并递归定位 datatableInfo/fieldInfo/field1259
  function dumpCreateOrEditResponse(resultJson) {
    Log.info('========== createOrEdit 完整响应诊断（首次出现空工程师）==========');
    if (!resultJson || typeof resultJson !== 'object') {
      Log.info('[dump] 响应非对象:', typeof resultJson, String(resultJson).slice(0, 300));
      return;
    }
    // 1) 可展开对象（devtools 里点开浏览整个结构）
    console.log('[kk-helper:bug-flow]', '👇 完整响应对象（可展开查看）:', resultJson);
    // 2) JSON 字符串（便于复制），过长则截断
    try {
      const s = JSON.stringify(resultJson);
      Log.info('[dump] 完整 JSON 字符串（长度 ' + s.length + '）:');
      console.log('[kk-helper:bug-flow]', s.length > 30000 ? s.slice(0, 30000) + '\n…[已截断，完整长度 ' + s.length + ']' : s);
    } catch (e) {
      Log.warn('[dump] JSON.stringify 失败:', e);
    }
    // 3) 信封字段（判断是否接口报错）
    const inner = resultJson.data;
    Log.info('[dump] 外层 code/message:', resultJson.code, '|', resultJson.message);
    Log.info('[dump] 内层 success/code/message:', inner && inner.success, '|', inner && inner.code, '|', inner && inner.message);
    // 4) 递归定位关键字段的确切路径
    const hits = [];
    locateInJson(resultJson, ['datatableInfo', 'fieldInfo', 'field1259'], '', 0, hits);
    Log.info('[dump] 递归定位到 ' + hits.length + ' 处:');
    hits.slice(0, 40).forEach((h) => {
      let preview;
      if (h.value && typeof h.value === 'object') {
        const ks = Object.keys(h.value);
        preview = '{' + ks.slice(0, 6).join(',') + (ks.length > 6 ? ',…' : '') + '}';
      } else {
        preview = JSON.stringify(h.value);
      }
      Log.info('       ', h.path, '=>', preview);
    });
    Log.info('========== dump 结束 ==========');
  }

  // 客户名 → 已办查询的 subject 参数（前后加下划线，单/双由 config 控制）
  function buildSubjectParam(customerName) {
    const us = CONFIG.subjectUnderscore === 'double' ? '__' : '_';
    return `${us}${customerName}${us}`;
  }

  // ---------------------------------------------------------------------------
  // ---- api.js ----
  // 三个接口请求封装：均同源（xt.seeyon.com），携带站点 Cookie（credentials: 'include'）。

  // Step3：已办列表查询
  async function fetchDoneList(customerName) {
    const subject = buildSubjectParam(customerName);
    // arguments 为 JSON 数组字符串；整体作为 form 字段，发送时由 URLSearchParams 做 form 编码
    const argumentsParam = JSON.stringify([
      { page: 1 },
      {
        dumpData: 'false',
        templeteIds: '',
        isGroupBy: false,
        subject, // _客户名称_ 或 __客户名称__
        isCounter: 'false',
      },
    ]);
    const body = new URLSearchParams();
    body.append('managerMethod', 'getDoneList');
    body.append('arguments', argumentsParam);

    const res = await fetch(CONFIG.endpoints.doneList, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      credentials: 'include',
      body,
    });
    if (!res.ok) throw new Error(`getDoneList HTTP ${res.status}`);
    return res.json();
  }

  // Step4a：取工单 baseInfo（JSON），用于获取 moduleId / rightId
  async function fetchBaseInfo(affairId) {
    Log.info('  请求 baseInfo:', CONFIG.endpoints.baseInfo(affairId));
    const res = await fetch(CONFIG.endpoints.baseInfo(affairId), { credentials: 'include' });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch (e) {}
    Log.info('  baseInfo 响应 status:', res.status, '| len:', text.length);
    if (!res.ok) {
      Log.error('  baseInfo HTTP失败 affairId:', affairId, '| body前500:', text.slice(0, 500));
      throw new Error(`baseInfo HTTP ${res.status}`);
    }
    if (!json) {
      Log.error('  baseInfo 非JSON affairId:', affairId, '| body前500:', text.slice(0, 500));
      throw new Error('baseInfo 响应非JSON');
    }
    return { json, text };
  }

  // Step4b：取工程师姓名
  async function fetchEngineer({ rightId, moduleId, affairId }) {
    const payload = {
      v: 'V11_xx',
      hasSignAction: 'false',
      type: 'browse',
      rightId,
      moduleId,
      isSubFlow: 'false',
      moduleType: '1',
      nodeName: CONFIG.nodeName, // KK_客户BUG修改人
      affairId,
      flowListAppId: '',
      flowListButtonId: '',
      flowBatchDealAffairIds: '',
      operateType: '2',
      forceDb: true,
      cacheRecoveryId: '',
    };
    const res = await fetch(CONFIG.endpoints.formEdit, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json;charset=UTF-8' },
      credentials: 'include',
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`createOrEdit HTTP ${res.status}`);
    return res.json();
  }

  // 剪切板写入：优先 Clipboard API（需在用户手势内，点击即满足），失败回退 execCommand
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.top = '-1000px';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        const ok = document.execCommand('copy');
        document.body.removeChild(ta);
        return ok;
      } catch (e2) {
        return false;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // ---- ui.js ----
  // 右侧悬浮图标：Shadow DOM 隔离样式，状态机 loading → ready → done / empty。
  // ready：可点击复制 + 右侧"查看工单"链接；整页可拖动（位置记忆）；empty：10s 后自动隐藏。
  const FloatingIcon = (() => {
    let host = null;
    let shadow = null;
    let btn = null;
    let label = null;
    let link = null;
    let onReadyClick = null;
    let currentAffairId = null;
    let hideTimer = null;
    let pulseTimer = null;
    let interacted = false; // 用户点过一次后，不再脉冲引导

    // 拖动状态
    let dragging = false;
    let movedDuringPress = false;
    let dragStart = null;
    let hostStart = null;

    const SUMMARY_URL = (affairId) =>
      `https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=listDone&affairId=${encodeURIComponent(affairId)}&showTab=true&showTab=true`;

    const iconUser =
      '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
    const iconCheck =
      '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
    const iconDash =
      '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="2.6" stroke-linecap="round"><line x1="6" y1="12" x2="18" y2="12"/></svg>';

    function create() {
      if (host) return;
      host = document.createElement('div');
      host.id = 'seeyon-bug-flow-host';
      host.style.cssText =
        'all:initial;position:fixed;right:24px;top:50%;transform:translateY(-50%);z-index:2147483647;';
      shadow = host.attachShadow({ mode: 'open' });
      shadow.innerHTML = `
        <style>
          .wrap { position:relative; display:flex; align-items:center; user-select:none; -webkit-user-select:none; font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif; }
          #btn {
            width:48px;height:48px;border-radius:50%;
            display:flex;align-items:center;justify-content:center;
            cursor:grab;touch-action:none;transition:transform .15s ease,background .2s ease;
            box-shadow:0 2px 10px rgba(0,0,0,.18);border:none;
          }
          #btn .icon { width:22px;height:22px;display:block; }
          #btn.loading { background:#ffffff;border:2px solid #e5e7eb; }
          #btn.loading .spinner { width:22px;height:22px;border-radius:50%;border:3px solid #e5e7eb;border-top-color:#3b82f6;animation:sbf-spin .8s linear infinite; }
          #btn.ready { background:#3b82f6;cursor:pointer;animation:sbf-pulse 1.4s ease-in-out infinite; }
          #btn.ready:hover { transform:scale(1.08); }
          #btn.empty { background:#f3f4f6;border:2px solid #e5e7eb;cursor:grab; }
          #btn.done { background:#22c55e; }
          .link {
            margin-left:10px;padding:7px 12px;border-radius:8px;background:#fff;color:#3b82f6;
            text-decoration:none;font-size:12px;box-shadow:0 2px 10px rgba(0,0,0,.18);
            white-space:nowrap;display:none;
          }
          .link:hover { background:#eff6ff; }
          .label {
            position:absolute;right:100%;margin-right:8px;top:50%;transform:translateY(-50%);
            background:rgba(17,24,39,.92);color:#fff;font-size:12px;line-height:1.4;
            padding:6px 10px;border-radius:6px;white-space:nowrap;
            opacity:0;transition:opacity .15s ease;pointer-events:none;
          }
          .wrap:hover .label { opacity:1; }
          @keyframes sbf-spin { to { transform:rotate(360deg); } }
          @keyframes sbf-pulse {
            0%,100% { box-shadow:0 0 0 0 rgba(59,130,246,.5),0 2px 10px rgba(0,0,0,.18); }
            50%     { box-shadow:0 0 0 12px rgba(59,130,246,0),0 2px 10px rgba(0,0,0,.18); }
          }
        </style>
        <div class="wrap">
          <span class="label" id="label"></span>
          <button id="btn" class="loading"><span class="spinner"></span></button>
          <a id="link" class="link" href="#" target="_blank" rel="noopener noreferrer">查看工单</a>
        </div>`;
      document.documentElement.appendChild(host);
      btn = shadow.getElementById('btn');
      label = shadow.getElementById('label');
      link = shadow.getElementById('link');

      // 恢复上次拖动位置
      try {
        const saved = JSON.parse(localStorage.getItem('seeyon-bugflow-pos') || 'null');
        if (saved && saved.left && saved.top) {
          host.style.right = 'auto';
          host.style.transform = 'none';
          host.style.left = saved.left;
          host.style.top = saved.top;
          // 恢复后按当前视口重新约束，防止分辨率/DPI/多屏变化导致坐标落到屏幕外
          clampHostIntoViewport();
        }
      } catch (e) {}

      // 点击/复制改为在 pointerup（onDragEnd）中处理，以兼容 setPointerCapture
      btn.addEventListener('pointerdown', (e) => {
        if (e.button !== 0) return; // 仅左键
        dragging = true;
        movedDuringPress = false;
        const rect = host.getBoundingClientRect();
        host.style.right = 'auto';
        host.style.transform = 'none';
        host.style.left = rect.left + 'px';
        host.style.top = rect.top + 'px';
        dragStart = { x: e.clientX, y: e.clientY };
        hostStart = { left: rect.left, top: rect.top };
        try { btn.setPointerCapture(e.pointerId); } catch (err) {}
      });
      btn.addEventListener('pointermove', onDragMove);
      btn.addEventListener('pointerup', onDragEnd);
      btn.addEventListener('pointercancel', onDragCancel);
    }

    function onDragMove(e) {
      if (!dragging) return;
      const dx = e.clientX - dragStart.x;
      const dy = e.clientY - dragStart.y;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) movedDuringPress = true;
      let nl = hostStart.left + dx;
      let nt = hostStart.top + dy;
      const maxX = window.innerWidth - host.offsetWidth;
      const maxY = window.innerHeight - host.offsetHeight;
      nl = Math.max(0, Math.min(maxX, nl));
      nt = Math.max(0, Math.min(maxY, nt));
      host.style.left = nl + 'px';
      host.style.top = nt + 'px';
    }

    function onDragEnd(e) {
      if (!dragging) return;
      dragging = false;
      try { if (e && e.pointerId != null) btn.releasePointerCapture(e.pointerId); } catch (err) {}
      if (movedDuringPress) {
        try {
          localStorage.setItem('seeyon-bugflow-pos', JSON.stringify({ left: host.style.left, top: host.style.top }));
        } catch (err2) {}
      } else {
        // 点击/轻点（未发生拖动）→ 触发复制
        if (btn.classList.contains('ready') && typeof onReadyClick === 'function') onReadyClick();
      }
    }

    function onDragCancel(e) {
      dragging = false;
      try { if (e && e.pointerId != null) btn.releasePointerCapture(e.pointerId); } catch (err) {}
    }

    // 将 host 约束在当前视口内（用于恢复保存位置后修正越界坐标）
    function clampHostIntoViewport() {
      if (!host) return;
      const rect = host.getBoundingClientRect();
      const maxX = window.innerWidth - host.offsetWidth;
      const maxY = window.innerHeight - host.offsetHeight;
      const nl = Math.max(0, Math.min(maxX, rect.left));
      const nt = Math.max(0, Math.min(maxY, rect.top));
      host.style.left = nl + 'px';
      host.style.top = nt + 'px';
      try {
        localStorage.setItem('seeyon-bugflow-pos', JSON.stringify({ left: host.style.left, top: host.style.top }));
      } catch (e) {}
    }

    function setIcon(html) { btn.innerHTML = html; }
    function setText(t) { if (label) label.textContent = t; }

    async function onCopy(engineer) {
      interacted = true; // 用户已交互，后续不再闪烁
      const ok = await copyText(engineer);
      Log.info('复制结果:', ok, '| 工程师:', engineer);
      setState('done', engineer);
      setTimeout(() => setState('ready', engineer, currentAffairId), 1500);
    }

    // state: 'loading' | 'ready' | 'empty' | 'done'
    function setState(state, engineer, affairId) {
      if (!host) create();
      if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
      if (pulseTimer) { clearTimeout(pulseTimer); pulseTimer = null; }
      btn.style.animation = '';

      btn.className = state;
      // 不 disable 按钮：disabled 会吞掉 pointer 事件导致无法拖动；复制由 pointerup + 状态判断控制

      // 链接：仅 ready 显示
      if (state === 'ready') {
        if (affairId) currentAffairId = affairId;
        if (currentAffairId) {
          link.href = SUMMARY_URL(currentAffairId);
          link.style.display = 'inline-block';
        } else {
          link.style.display = 'none';
        }
      } else {
        link.style.display = 'none';
        link.removeAttribute('href');
      }

      if (state === 'loading') {
        setIcon('<span class="spinner"></span>');
        setText('正在识别推荐工程师…');
        onReadyClick = null;
      } else if (state === 'ready') {
        setIcon(iconUser);
        setText(`推荐工程师：${engineer}（点击复制）`);
        onReadyClick = () => onCopy(engineer);
        // 通知统一启动器：推荐工程师就绪（launcher 菜单据此显示）
        try {
          document.documentElement.setAttribute('data-seeyon-engineer', engineer || '');
          if (affairId) document.documentElement.setAttribute('data-seeyon-engineer-affair', affairId);
        } catch (_) {}
        if (interacted) {
          btn.style.animation = 'none'; // 用户已点过，不再闪烁
        } else {
          // 引导动画仅闪约 10s 后停止，避免一直闪烁（图标仍保留、可点击）
          pulseTimer = setTimeout(() => { btn.style.animation = 'none'; }, 10000);
        }
      } else if (state === 'empty') {
        setIcon(iconDash);
        setText(engineer ? engineer : '未找到推荐工程师');
        onReadyClick = null;
        // 通知统一启动器：无推荐工程师
        try { document.documentElement.setAttribute('data-seeyon-engineer', ''); } catch (_) {}
        // 无工程师：10s 后自动隐藏
        hideTimer = setTimeout(() => { if (host) host.style.display = 'none'; }, 10000);
      } else if (state === 'done') {
        setIcon(iconCheck);
        setText('已复制到剪切板');
        onReadyClick = null;
      }
    }

    function hide() {
      if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
      if (host) host.style.display = 'none';
    }

    return { create, setState, hide };
  })();

  // ---------------------------------------------------------------------------
  // ---- content.js ----
  // 主入口：页面检测 + 流程编排。
  // 工单页为整页刷新，故监听 load（若脚本注入时已 loaded 则直接执行）。

  if (document.readyState === 'complete') {
    init();
  } else {
    window.addEventListener('load', init);
  }

  async function init() {
    // Step1：URL 校验
    if (!isTargetPage()) {
      Log.debug('[入口] 非目标页，入口悬浮球不显示', location.href);
      return;
    }
    Log.debug('[入口] 目标页，准备创建入口悬浮球');

    FloatingIcon.create();
    FloatingIcon.setState('loading');

    try {
      // Step1：等待 #subject 出现，再做内容校验
      const subjectReady = await waitForEl(CONFIG.field.subject);
      if (!subjectReady) {
        Log.info('[入口] BUG 工单悬浮球不显示：等待标题元素超时', {
          selector: CONFIG.field.subject,
          poll: CONFIG.poll,
          subject: getCurrentSubject() || '(空)',
          documents: getAllDocuments().map((doc) => {
            const win = doc && doc.defaultView;
            let href = '(不可读)';
            try { href = win && win.location ? win.location.href : '(无window)'; } catch (_) {}
            return { href, hasSubject: !!(doc && doc.querySelector && doc.querySelector(CONFIG.field.subject)) };
          })
        });
      }
      if (!isAssignmentNode()) {
        const subject = getCurrentSubject();
        Log.info('[入口] BUG 工单悬浮球不显示：非 BUG_ 节点', {
          subject: subject || '(空)',
          expectedSubjectPrefix: CONFIG.subjectPrefix,
          subjectStartsWithExpectedPrefix: String(subject).startsWith(CONFIG.subjectPrefix)
        });
        FloatingIcon.setState('empty', '当前单据非BUG分配单');
        FloatingIcon.hide();
        return;
      }
      Log.info('页面校验通过：#subject 以 BUG_ 开头');

      // Step2：取客户名称（表单 iframe 内字段，需等待 iframe 加载 + 字段渲染）
      const customer = await waitForCustomerName();
      Log.info('客户名称:', customer ? customer : '(空)');
      if (!customer) {
        Log.debug('[入口] 未获取到 customerName，显示 empty 态（入口仍保留）');
        FloatingIcon.setState('empty', '未取到客户名称');
        return;
      }

      // Step3：查已办列表
      const done = await fetchDoneList(customer);
      const candidates = getBugCandidates(done && done.data);
      Log.info(
        'getDoneList total:', done && done.total,
        '| BUG 候选数:', candidates.length
      );
      if (!candidates.length) {
        Log.warn('该客户无匹配的 BUG 工单');
        Log.debug('[入口] 无历史 BUG 工单，显示 empty 态（10s 后自动隐藏）');
        FloatingIcon.setState('empty', '该客户无历史 BUG 工单');
        return;
      }

      // 当前工单 moduleId（#summaryId），用于跳过自身
      const currentModuleId = getCurrentModuleId();
      Log.info('当前工单 moduleId:', currentModuleId || '(未取到)');

      // Step4：遍历候选，跳过"moduleId 与当前工单一致"的自身记录，取第一个有工程师姓名的
      const cap = Math.min(candidates.length, CONFIG.candidateCap);
      let picked = null;
      let jsonDumped = false;
      for (let i = 0; i < cap; i++) {
        const affairId = String(candidates[i].affairId || '');
        Log.info(
          `[候选 ${i + 1}/${cap}] affairId: ${affairId}`,
          '| subject:', (candidates[i].subject || '').slice(0, 40)
        );

        const baseInfo = await fetchBaseInfo(affairId);
        const params = extractBaseInfoParams(baseInfo, affairId);
        const moduleId = params.moduleId;
        const rightId = params.rightId;
        Log.info('  moduleId:', moduleId, '| rightId:', rightId ? rightId.slice(0, 24) + '…' : '(空)');
        if (!moduleId || !rightId) {
          Log.warn('  缺 moduleId/rightId，跳过');
          continue;
        }
        if (currentModuleId && moduleId === currentModuleId) {
          Log.warn('  moduleId 与当前工单一致，判定为自身，跳过');
          continue;
        }

        const formJson = await fetchEngineer({ rightId, moduleId, affairId });
        const engineer = getEngineerName(formJson);
        Log.info('  工程师姓名:', engineer || '(空)');
        if (!engineer) {
          Log.warn('  该工单无工程师姓名，继续查找下一条');
          if (!jsonDumped) {
            jsonDumped = true;
            dumpCreateOrEditResponse(formJson);
          }
          continue;
        }
        picked = { engineer, affairId, moduleId };
        break;
      }

      if (!picked) {
        Log.warn('遍历候选后未找到有效工程师');
        Log.debug('[入口] 未找到推荐工程师，显示 empty 态（10s 后自动隐藏）');
        FloatingIcon.setState('empty', '未找到推荐工程师');
        return;
      }
      Log.info('推荐工程师:', picked.engineer, '| affairId:', picked.affairId);

      // Step5：就绪，可点击复制
      FloatingIcon.setState('ready', picked.engineer, picked.affairId);
    } catch (e) {
      Log.error('流程异常:', e);
      Log.debug('[入口] 流程异常，显示 empty 态（10s 后自动隐藏）');
      FloatingIcon.setState('empty', '处理失败，请查看控制台');
    }
  }

  // —— 页面判定辅助 ——

  function isTargetPage() {
    // URL 命中协同页即目标；iframe 场景下 BUG 工单的 #subject 可能位于 URL 非 collaboration.do
    // 的表单 iframe 内，此时靠当前框架含 #subject 兜底（再由 isAssignmentNode 校验 BUG_ 前缀）。
    const href = location.href;
    const urlPrefixMatched = href.indexOf(CONFIG.urlPrefix) === 0;
    let subjectFound = false;
    let subjectQueryError = '';
    try {
      subjectFound = !!document.querySelector(CONFIG.field.subject);
    } catch (e) {
      subjectQueryError = e && e.message ? e.message : String(e || 'unknown');
    }

    const result = urlPrefixMatched || subjectFound;
    if (result) {
      Log.debug('[isTargetPage] 命中目标页规则', { urlPrefixMatched, subjectFound, href });
      return true;
    }

    Log.info('[入口] BUG 工单悬浮球不显示：目标页条件均未满足', {
      href,
      urlPrefixRule: {
        expectedPrefix: CONFIG.urlPrefix,
        urlPrefixMatched
      },
      subjectRule: {
        selector: CONFIG.field.subject,
        subjectFound,
        subjectQueryError: subjectQueryError || '(无)'
      }
    });
    return false;
  }

  function isAssignmentNode() {
    const subject = getCurrentSubject();
    return String(subject).startsWith(CONFIG.subjectPrefix);
  }

  // 轮询获取客户名称（表单 iframe 加载较慢，需等待 iframe 就绪 + 字段渲染）；命中或超时时打印一次诊断
  function waitForCustomerName() {
    const interval = CONFIG.poll.interval;
    const timeout = 15000; // 表单 iframe 加载较慢，单独放宽
    return new Promise((resolve) => {
      const logHit = (r) =>
        Log.info('[客户名] 命中(iframe 内):', r.selector, '=>', JSON.stringify(r.name));
      let r = readCustomerNameOnce();
      if (r.name) { logHit(r); return resolve(r.name); }

      const t0 = Date.now();
      const timer = setInterval(() => {
        r = readCustomerNameOnce();
        if (r.name) {
          clearInterval(timer);
          logHit(r);
          return resolve(r.name);
        }
        if (Date.now() - t0 > timeout) {
          clearInterval(timer);
          if (r.iframeMissing) {
            Log.error('[客户名] 未找到表单 iframe（含 #field0161_id 的同源 iframe）。');
            Log.error('       可能 iframe 尚未加载完成，或客户名字段 id 变更。');
          } else if (r.el) {
            Log.warn('[客户名] 容器命中但文本为空，selector:', r.selector);
            Log.warn('[客户名] textContent:', JSON.stringify((r.el.textContent || '').replace(/\s+/g, ' ').trim()));
          } else {
            Log.error('[客户名] 表单 iframe 已加载，但候选选择器均未命中：', CONFIG.customerSelectors);
          }
          resolve('');
        }
      }, interval);
    });
  }

  // 轮询等待元素出现（整页刷新下，目标元素可能晚于 load 渲染）
  function waitForEl(selector) {
    const { interval, timeout } = CONFIG.poll;
    return new Promise((resolve) => {
      // 目标元素可能在嵌套 iframe 内，跨同源 iframe 查找
      if (queryAllDocuments(selector)) return resolve(true);
      const t0 = Date.now();
      const timer = setInterval(() => {
        if (queryAllDocuments(selector)) {
          clearInterval(timer);
          resolve(true);
        } else if (Date.now() - t0 > timeout) {
          clearInterval(timer);
          resolve(false);
        }
      }, interval);
    });
  }
})();
