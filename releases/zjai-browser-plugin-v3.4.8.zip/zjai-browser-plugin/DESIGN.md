# ZJAI Browser Plugin Design

## 1. Tokens

- Font: `"Microsoft YaHei", Arial, sans-serif`
- Text: `#111827`, muted `#64748b`, danger/action `#dc2626`, primary `#2563eb`
- Surface: white panel, `#f8fafc` header, `#e5e7eb` border
- Radius: 6px controls, 8px panels, 10px launcher menu
- Shadow: launcher menu `0 8px 30px rgba(0,0,0,.18)`, panel `0 18px 50px rgba(15,23,42,.22)`

## 2. Components

- Floating ball: 42px circle, white rim, image logo, draggable.
- Launcher menu item: icon + red bold title + muted one-line description.
- Form page: compact work surface, clear labels, primary blue submit button, red validation message.
- Weekly-plan summary panel: compact white panel with an 8px radius, 440px width and `calc(100vw - 32px)` maximum width, a draggable header, a muted status line, a scrollable execution log that grows to 300px before scrolling, and an action button that changes to “终止汇总” while running. It stays fixed to the viewport after dragging, with clearance from the floating ball by default. Reopening from the launcher resets the prior status, log, and button state.

## 3. Motion

- Keep motion minimal. Use hover color changes and the existing launcher toggle only.
- Weekly-plan summarization uses a spinner while processing; with reduced motion, the spinner changes to an opacity pulse.

## 4. Accessibility

- Buttons and links keep real semantic elements.
- Inputs use labels and visible focusable controls.
- Status messages use a live region so validation, processing, and completion states are announced.

## 5. Accepted Debt

- DingTalk robot configuration is not shown to users; submitted demand content is sent through a background action.
