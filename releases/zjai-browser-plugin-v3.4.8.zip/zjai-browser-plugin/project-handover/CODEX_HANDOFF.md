## 2026-08-01 项目安排主要策略交付物保留模板规则

### 当前目标

调整 `项目安排`、`主要策略`、`交付物`：能组装成模板原始备注格式才写入，否则保留模板。

### 已完成事项

- `项目安排`、`主要策略` 使用 `remarkList()` 拆分为 `1、xxx；` 清单；少于 2 条不覆盖模板。
- `项目安排` 不再由 `实施任务目标` 明细整行汇总覆盖。
- `交付物` 只在匹配模板复选项时勾选；匹配不到则保留模板原文。
- `前期方案` 可匹配 `前期POC环境、业务包`。
- 测试页和 runtime 已覆盖可组装写入、不可组装保留两条路径。
- 已同步 `../../pak/sh-browser-plugin-v3.4.8.zip`，未修改版本号。
- 已通过完整回归和 DOCX 抽取验证。

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `fixture.html`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不修改版本号。
- 三字段保守覆盖，不确定就保留模板。

### 未解决问题

- 真实 OA 交付物同义词可能需要继续补。

### 下一步最小指令

重载插件，重新生成 DOCX，检查 `项目安排`、`主要策略`、`交付物`。

## 2026-08-01 移交单字段到会议纪要字段映射调整

### 当前目标

按用户指定口径调整会议纪要字段来源。

### 已完成事项

- 增加字段别名映射：交接时间、销售经理、最终客户、签约时间、项目实施范围、是否召开启动会、启动会召开时间、客户关键需求、非合同内承诺、指派内部项目经理、报价实施评估人天、报价客开评估人天、交付策略。
- 签约时间不为空时，是否签订合同强制为 `是`。
- 用户指定移交单字段加入优先来源，覆盖页面旧同名模板字段。
- 客户关键人员由客户干系人明细生成编号清单。
- 项目组成员改为 `1.{项目角色}：{顾问名称}，{顾问类型}`。
- `顾问名称` 纳入人员姓名识别和 fallback 表格识别。
- 测试页已改成新字段名并通过完整回归。
- 已同步 `../../pak/sh-browser-plugin-v3.4.8.zip`，未修改版本号。

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `fixture.html`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不修改版本号。
- 指定字段来源优先，不被旧字段覆盖。

### 未解决问题

- 真实 OA 若存在更多字段名变体，需要继续补映射。

### 下一步最小指令

重载插件并重新生成 DOCX，重点核对本轮字段映射。

## 2026-08-01 空风险不写整行汇总修复

### 当前目标

修复无风险描述时 DOCX 仍写入整行空风险汇总的问题。

### 已完成事项

- `numberedColumnSummary()` 过滤 `(空)`。
- `项目预计风险` 不再回退 `tableSummary()`；只取 `风险描述` 列。
- 风险描述为空时，`风险和其他说明` 写空。
- 新增 runtime 回归覆盖空风险生成 DOCX。
- 已同步 `../../pak/sh-browser-plugin-v3.4.8.zip`，未修改版本号。
- 已通过完整回归和 DOCX 抽取验证。

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不修改版本号。
- 风险只输出风险描述；没有风险描述就留空。

### 未解决问题

- 真实 OA 风险描述字段名如不同，需补映射。

### 下一步最小指令

重载插件，重新生成 DOCX，检查风险无值时该格为空。

## 2026-08-01 空值留空与明细汇总格式调整

### 当前目标

调整 DOCX 写入：空值不再写 `需手动完善`；按用户指定格式输出 `项目组成员`、`风险和其他说明`、`回款进度`。

### 已完成事项

- 普通空值写空；单选空值保留模板选项。
- `项目组成员` 只输出项目角色和顾问类型编号清单。
- `风险和其他说明` 只输出风险描述编号清单。
- `回款进度` 按收款节点、周期、单位、收款比例、收款金额拼接；兼容测试页付款阶段字段。
- 已同步 `../../pak/sh-browser-plugin-v3.4.8.zip`，未修改版本号。
- 已通过完整回归和 DOCX 抽取验证。

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不再向正式会议纪要写入 `需手动完善`。
- 明细字段不整行汇总，只取用户指定列。

### 未解决问题

- 真实 OA 回款字段名如果不同，需要后续补映射。

### 下一步最小指令

重载插件后生成真实 DOCX，检查空字段、项目组成员、风险说明、回款进度。

## 2026-08-01 会议纪要单选格式保留修复

### 当前目标

修复生成 DOCX 时单选格式被纯文本覆盖的问题。

### 已完成事项

- 新增 `valueForTemplateCell()`，检测模板右侧单元格是否包含 `☐/☑`。
- 对单选字段保留原选项文本，只把匹配项切换为 `☑`。
- 兼容 `是 ☐ 否` 模板异常格式，输出规范的 `☐是 ☑否` 或 `☑是 ☐否`。
- `runtime.test.js` 增加单选格式断言。
- 已同步 `../../pak/sh-browser-plugin-v3.4.8.zip`，未修改版本号。
- 已通过完整回归和 DOCX 文本抽取验证。

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不重建模板表格，只按模板已有选项勾选。
- 普通文本字段写入逻辑不变。

### 未解决问题

- 真实 OA 页面需重载插件后生成复查。

### 下一步最小指令

重新加载插件并重新生成会议纪要，重点检查 `会议方式`、是否类字段、`交付主体`、`交付方式`。

## 2026-08-01 实际 DOCX 仍大量需手动完善的诊断

### 当前目标

解释真实生成会议纪要仍出现大量 `需手动完善` 的原因。

### 已完成事项

- 已确认代码中 `需手动完善` 的触发条件：模板字段存在，但当前读取值表中没有对应值。
- 已确认上一份字段比对基于测试页，不代表真实 OA 当前读取结果。

### 修改过的文件

- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不改代码、不改版本号。
- 需要真实页面字段快照才能准确定位缺失字段。

### 未解决问题

- 缺少真实 OA 当前生成 DOCX 的缺失字段清单。

### 下一步最小指令

可新增弹框诊断清单：直接显示每个会议纪要字段是否命中、来源字段和值。

## 2026-08-01 会议纪要字段比对

### 当前目标

列出会议纪要 DOCX 字段与当前网页解析字段的对应关系。

### 已完成事项

- 已从模板 DOCX 表格提取写入字段。
- 已用当前测试页生成 DOCX 反查最终写入结果。
- 当前测试页只有 `售前顾问` 未取到值，其余模板字段均能对应写入。

### 修改过的文件

- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不修改代码、不修改版本号。
- 当前清单基于测试页和当前模板；真实 OA 需要现场读取结果再比对。

### 未解决问题

- 尚未直接导出真实 OA 页当前读取字段。

### 下一步最小指令

如需真实 OA 比对，请提供真实页面弹框读取结果或允许我读取当前浏览器页面 DOM。

## 2026-08-01 项目任务清单化展示

### 当前目标

简化弹框 `项目任务` 区块，只显示 `实施任务目标` 和 `客开任务目标` 两个编号清单。

### 已完成事项

- `项目任务` 不再显示整张任务明细表。
- `实施任务目标` / `客开任务目标` 分别从对应页签明细的同名列或 `任务目标` 列取值。
- 清单格式为 `1.xxx`、`2.xxx`。
- 已同步 `../../pak/sh-browser-plugin-v3.4.8.zip`，未修改版本号。
- 已通过：
  - `node --check sh-browser-plugin/project-handover/content.js`
  - `node --check sh-browser-plugin/background.js`
  - `node sh-browser-plugin/project-handover/content.contract.test.js`
  - `node sh-browser-plugin/project-handover/runtime.test.js`

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不修改版本号。
- 只改弹框展示，不动 DOCX 写入。
- 不展示任务表里的辅助列。

### 未解决问题

- 真实 OA 页面需重载插件后复查。

### 下一步最小指令

重新加载插件并刷新/重新打开项目移交页，确认 `项目任务` 只剩两个编号清单。

## 2026-08-01 弹框项目任务展示与宽度优化

### 当前目标

优化弹框展示：`项目任务` 下两个页签按类似 `项目组成员` 的明细表格式显示；弹框宽度由 480px 放大为 720px。

### 已完成事项

- `项目任务` 页签改为紧凑页签标签 + 明细表，不再使用嵌套卡片。
- 弹框 `width` 调整为 `720px`，保留小屏 `max-width:calc(100vw - 32px)`。
- `runtime.test.js` 增加宽度和 `项目任务` 明细表展示断言。
- 已同步 `../../pak/sh-browser-plugin-v3.4.8.zip`，未修改版本号。
- 已通过：
  - `node --check sh-browser-plugin/project-handover/content.js`
  - `node --check sh-browser-plugin/background.js`
  - `node sh-browser-plugin/project-handover/content.contract.test.js`
  - `node sh-browser-plugin/project-handover/runtime.test.js`

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不修改版本号。
- 本轮只调整弹框展示，不改字段读取和会议纪要写入映射。

### 未解决问题

- 真实 OA 页面需在插件重新加载后复查。

### 下一步最小指令

重新加载插件，刷新/重新打开项目移交页，点击“移”入口确认 `项目任务` 显示为两个明细表块。

## 2026-08-01 CAP4 真实表单解析修复

### 当前目标

使用真实 OA CAP4 表单 HTML 修复弹框字段为空、区块识别失败、明细行混入普通字段的问题。

### 已完成事项

- 已确认粘贴 HTML 里未选中页签内容未加载：
  - 存在 `tab-clientId366-1`，不存在 `pane-clientId366-1`。
  - 存在 `tab-clientId425-1`，不存在 `pane-clientId425-1`。
- `content.js` 增加 CAP4 字段读取：
  - label 取 `.cap4-ctrl__label .label-margin`。
  - value 取 `.field-content__view / .cap4-browse_content`。
- 区块标题支持 `█ 项目基本信息` 等带标记文本。
- 区块标题所在行右侧字段会被读取，不再漏掉 `业务线 / 签约年度 / 是否提前进场`。
- 普通字段采集跳过 `formson_` / `.cap-formson` 明细字段，避免明细行串入 `项目基本信息`。
- 新增 `cap4-fixture.html`，覆盖真实 CAP4 结构和“未选中页签点击后加载 pane”的回归场景。
- 已通过：
  - `node --check sh-browser-plugin/project-handover/content.js`
  - `node sh-browser-plugin/project-handover/content.contract.test.js`
  - `node sh-browser-plugin/project-handover/runtime.test.js`

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `cap4-fixture.html`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不修改版本号。
- 未选中页签的静态 HTML 不完整时，必须在真实页面点击页签后等待 DOM 加载；静态 HTML 本身不能证明付款阶段/客开任务明细存在。
- CAP4 字段解析放在共享读取层，弹框展示和 DOCX 写入共用同一份读取结果。

### 未解决问题

- 尚未在用户真实 OA tab 上重新加载扩展后现场复查；如真实点击页签后仍不生成 pane，需要继续基于现场 DOM 定位。

### 下一步最小指令

重新加载当前工作区插件并刷新真实 OA 项目移交页；点击“项目移交会议纪要”，确认弹框区块和两个未选中页签读取结果。

## 2026-08-01 DOCX 模板加载失败修复

### 当前目标

修复点击“写入会议纪要”时报 `Denying load of chrome-extension://...项目交接会议纪要模板.docx`。

### 已完成事项

- 确认源码 `manifest.json` 已配置模板为 `web_accessible_resources`。
- 确认 `pak/sh-browser-plugin-v3.4.8.zip` 缺少正确 UTF-8 模板条目，且残留乱码 DOCX 条目。
- 已重写 `pak/sh-browser-plugin-v3.4.8.zip`：
  - 删除乱码 DOCX 条目。
  - 保留正确条目 `sh-browser-plugin/project-handover/assets/项目交接会议纪要模板.docx`。
- `content.contract.test.js` 新增包内模板条目校验。
- 已通过完整回归。

### 修改过的文件

- `content.contract.test.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不修改版本号。
- 修复重点是安装包内容和回归保护，不改业务逻辑。

### 未解决问题

- Chrome 必须重新加载当前插件或重新安装修正后的 zip；否则仍会使用旧 manifest/旧包内容。

### 下一步最小指令

到 `chrome://extensions` 点击当前 ZJAI 插件“重新加载”，或重新安装修正后的 `pak/sh-browser-plugin-v3.4.8.zip`，然后刷新 OA 页面再点“写入会议纪要”。

## 2026-08-01 模板读取改后台通道

### 当前目标

彻底修复真实 OA 页点击“写入会议纪要”仍报 `Denying load of chrome-extension://...docx`。

### 已完成事项

- `content.js` 写入会议纪要时优先发消息 `projectHandoverGetTemplate`。
- `../background.js` 新增后台 action，由 service worker 内部读取 DOCX 并返回 `ArrayBuffer`。
- 仅在本地测试页没有 `chrome.runtime.sendMessage` 时保留页面 fetch fallback。
- `content.contract.test.js` 增加后台通道断言。
- `../../pak/sh-browser-plugin-v3.4.8.zip` 已同步更新改动文件和模板。
- 完整测试通过。

### 修改过的文件

- `content.js`
- `content.contract.test.js`
- `../background.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不改版本号。
- 不再把真实页的 DOCX 读取依赖放在 `web_accessible_resources` 上，避免页面上下文限制。

### 未解决问题

- 需要 Chrome 重新加载扩展和重新打开 OA 页，让新的 service worker/content script 生效。

### 下一步最小指令

`chrome://extensions` 里点 ZJAI 插件“重新加载”，然后关闭当前项目移交页，重新从待办打开，再点击“写入会议纪要”。

## 2026-08-01 写入按钮无反应修复

### 当前目标

修复“写入会议纪要”点击后无反应、控制台无输出。

### 已完成事项

- 后台模板返回由 `ArrayBuffer` 改为 Base64。
- `content.js` 将 Base64 还原为 `Uint8Array` 后交给 JSZip。
- 模板读取增加 8 秒超时，避免 Promise 卡住。
- 按钮点击后显示 `生成中… / 已生成 / 生成失败`。
- 失败后立即恢复按钮可点击。
- `fixture.html` 增加后台消息模拟，回归覆盖真实模板通道。
- `../../pak/sh-browser-plugin-v3.4.8.zip` 已同步。
- 完整测试通过。

### 修改过的文件

- `content.js`
- `content.contract.test.js`
- `runtime.test.js`
- `fixture.html`
- `../background.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不改版本号。
- 不直接通过 Chrome message 传二进制 `ArrayBuffer`。

### 未解决问题

- 必须重载扩展并重新打开 OA 页；旧页面不会自动换成新事件处理器。

### 下一步最小指令

重载插件，关闭当前 OA 项目移交页并重新打开，再点“写入会议纪要”；观察按钮文字是否先变为 `生成中…`。

## 2026-08-01 需要开发内容与回款进度格式修复

### 当前目标

按用户要求修复 DOCX 中 `需要开发内容` 和 `回款进度` 的写入格式。

### 已完成事项

- 新增 `numberedColumnSummary()`。
- `客开任务目标` 明细写入 `需要开发内容` 时，只取 `客开任务目标 / 任务目标` 列，输出 `1.xxx` 编号清单。
- `项目付款阶段` 明细写入 `回款进度` 时，只取 `付款阶段 / 阶段名称` 列，输出 `1.xxx` 编号清单。
- `需要开发内容` 的明细值会覆盖普通字段值。
- 回归生成 DOCX 已确认：
  - `需要开发内容` 为 `1.完成电子签章接口开发`
  - `回款进度` 为 `1.首付款`
- `../../pak/sh-browser-plugin-v3.4.8.zip` 已同步。
- 完整测试通过。

### 修改过的文件

- `content.js`
- `runtime.test.js`
- `../../pak/sh-browser-plugin-v3.4.8.zip`
- `../../CODEX_HANDOFF.md`
- `CODEX_HANDOFF.md`

### 关键决策

- 不改版本号。
- 本轮只改两个用户点名字段；其他 `需手动完善` 需要后续按字段逐项对照，不猜。

### 未解决问题

- 其他模板字段显示 `需手动完善` 的原因尚未逐项分析。

### 下一步最小指令

重载插件并重新生成 DOCX，检查 `需要开发内容`、`回款进度` 是否符合编号清单格式。

## 当前目标

为标题符合 `(自动发起)【大区名称】-{合同号-签约单位}-合同金额项目移交` 的 OA 页面提供独立项目移交入口，读取页面字段并生成自动填充的会议纪要 DOCX。

## 已完成事项

- 新增独立 `project-handover` 模块，不扩大 `project-check` 两页白名单。
- 内置 `项目交接会议纪要模板.docx` 与 JSZip 3.10.1。
- 实现标题解析：大区、合同编号、签约单位、合同金额。
- 实现当前页面及同源 iframe 的编辑态/只读态字段读取；隐藏行与插件自身弹框不会被重复采集。
- 实现可拖动“移”入口和可拖动弹框，位置记忆、重新读取、错误提示、键盘焦点与响应式布局。
- 实现浏览器端 OOXML 填充与下载，文件名为 `项目交接会议纪要-{签约单位}-{YYYY-MM-DD}.docx`。
- 文件名已过滤全部 Unicode `Cc/Cf` 控制与格式字符、系统保留字符，并按 UTF-8 160 字节限制单位名称片段，完整文件名保留在 240 字节以内。
- 本地真实 Chromium 已验证：入口/弹框拖动、字段展示、同源 iframe、隐藏字段排除、修改后重新读取、清空后不回退旧值、DOCX 下载、非目标页清理、375/768/1280px 布局。

## 修改过的文件

- `content.js`
- `content.contract.test.js`
- `runtime.test.js`
- `fixture.html`
- `DESIGN.md`
- `lib/jszip.min.js`
- `assets/项目交接会议纪要模板.docx`
- `../manifest.json`
- `../README.txt`
- `../../CODEX_HANDOFF.md`
- `../../docs/superpowers/specs/2026-07-29-project-handover-design.md`
- `../../docs/superpowers/plans/2026-07-29-project-handover.md`

## 关键决策

- 模板随插件内置，浏览器不直接读取 `/Users/...` 本地物理路径。
- 生成文件只下载到本地，不自动上传或替换 OA 流程附件。
- 字段映射优先使用网页 label 与模板 label；流程标题为签约单位、合同编号等核心字段提供兜底。
- 跨域 iframe 受浏览器同源策略限制；当前支持同源 iframe，符合现有 xt.seeyon.com 表单结构假设。

## 未解决问题

- 尚未在客户真实 OA 项目移交流程页回归固定字段 DOM；若现场 label 与模板名称差异较大，需要补充 `LABEL_ALIASES` 或稳定字段 ID。
- LibreOffice 渲染环境缺少模板使用的部分中文字体，结构与 OOXML 已验证，最终视觉需在 Word/WPS 打开复核。
- 本轮未实现生成后自动上传 OA 附件；如后续需要，必须另行确认附件控件 DOM 和替换规则。

## 下一步最小指令

浏览器扩展页加载 `sh-browser-plugin/` 或安装 `pak/sh-browser-plugin-v3.4.6.zip`，打开真实项目移交流程，点击右侧“移”球，核对字段并生成 DOCX；如有漏字段，提供该字段 DOM 或完整表单截图。

## 2026-07-30 真实 OA 空字段修复

### 当前目标

解决真实项目移交 OA 页点击“项目移交会议纪要”后弹框字段为空、只读取到标题 4 个字段的问题。

### 已完成事项

- 将项目移交字段读取从固定 `label/value` 两格步进，改为逐格识别字段名后读取右侧最近有效值，兼容真实 OA 中多字段同行、空值格、开关前缀等布局。
- `manifest.json` 为项目移交内容脚本增加 `match_origin_as_fallback`，支持继承 `xt.seeyon.com` 来源的 `about:blank/blob` 动态 frame 注入。
- 为项目移交入口和弹框增加当前扩展归属标记；发现旧插件/旧脚本创建的同名 `project-handover-fab` / `project-handover-panel` 时会删除重建，避免继续展示旧的空字段弹框。
- 增加真实 OA 兜底采集路径：当主页面区块起始行识别失败时，不再退化为标题 4 字段，而是直接读取当前可见表格字段，并按字段名归入 `项目基本信息 / 客户干系人 / 项目交接信息 / 项目预计风险 / 项目任务 / 交接结论` 等区块。
- 明细表兜底读取收紧：`序号` 明细表第一列必须是数字，否则停止该明细表，避免把后续普通字段误判为任务/风险明细。
- 普通字段兜底读取增加明细表区间跳过：遇到包含 `序号` 的明细表表头后，数字序号行不再当作 `字段名/值` 行采集，避免 `1 宋汉望 / 2 戚二康` 这类项目组成员明细出现在 `项目基本信息`。
- 测试页补充真实截图同类的 `是否AI / 是否集约交付 / 客户地址` 多字段同行样例。
- 回归脚本已验证弹框按网页区块展示、无“其他字段”、项目组成员/项目承接信息/风险/付款阶段/两个任务页签写入 DOCX；新增“删除所有区块标题行后仍能读取字段”的 fallback 回归，结果为 `8 个区块、81 个字段、4 条明细`，并断言 `项目基本信息` 不包含明细行 `1 宋汉望 / 2 戚二康`。

### 修改过的文件

- `content.js`
- `fixture.html`
- `runtime.test.js`
- `../manifest.json`

### 关键决策

- 不修改插件版本号，按用户要求只有明确要求时才 bump version。
- 这次修根采集逻辑，不新增模板字段映射表。
- Chrome 当前同时启用了两个 ZJAI 插件：旧下载目录 `3.3.2` 与当前工作区扩展；代码已增加同名 UI 抢占保护，但真实复查前仍建议禁用旧下载目录插件，并重新加载当前工作区插件。

### 未解决问题

- 当前无法直接接管用户截图中的真实 Chrome OA tab 做现场 DOM 读取，只能通过本机 Chrome 配置确认扩展加载状态，并通过本地真实 Chromium 回归验证。

### 下一步最小指令

在 `chrome://extensions` 里禁用 `/Users/songhw/Downloads/sh-browser-plugin-master-1/dist/sh-browser-plugin` 这个旧 ZJAI 插件，只保留 `/Users/songhw/BDWPS/mac/CodeX/致远提效浏览器插件/sh-browser-plugin`，点击“重新加载”后刷新 OA 项目移交页，再点“项目移交会议纪要”复查字段。

## 2026-07-29 最终加固

- 修复入口按钮无法拖动、清空字段后误读弹框旧值、窗口缩小时弹框横向溢出。
- 增加打开弹框后焦点进入、关闭后焦点返回入口，以及入口/按钮 `focus-visible`。
- 文件名增加 Unicode 控制字符清理和 UTF-8 字节限制。
- 安装包改用 UTF-8 ZIP 条目生成，中文模板路径已用 Python `zipfile` 精确校验。
- 已从解压后的 `pak/sh-browser-plugin-v3.4.6.zip` 直接运行合同测试和真实 Chromium 测试，均通过。
