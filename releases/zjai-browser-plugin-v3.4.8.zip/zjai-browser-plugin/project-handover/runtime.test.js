const assert = require('assert');
const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');
const dependencyRoot = process.env.CODEX_NODE_MODULES || path.join(os.homedir(), '.cache', 'codex-runtimes', 'codex-primary-runtime', 'dependencies', 'node', 'node_modules');
const { chromium } = require(path.join(dependencyRoot, 'playwright'));
const JSZip = require(path.join(dependencyRoot, 'jszip'));

const workspaceRoot = path.resolve(__dirname, '..', '..');
const mimeTypes = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' };

function serveFile(request, response) {
  const pathname = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
  const filePath = path.join(workspaceRoot, pathname.replace(/^\//, ''));
  if (!filePath.startsWith(workspaceRoot) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    response.writeHead(404).end('not found');
    return;
  }
  response.writeHead(200, { 'content-type': mimeTypes[path.extname(filePath)] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(response);
}

async function closeBrowser(browser) {
  const child = typeof browser.process === 'function' ? browser.process() : null;
  let closed = false;
  await Promise.race([
    browser.close().then(() => { closed = true; }),
    new Promise((resolve) => setTimeout(resolve, 5000))
  ]);
  if (!closed && child && !child.killed) child.kill('SIGKILL');
}

(async () => {
  const server = http.createServer(serveFile);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  const outputDir = fs.mkdtempSync(path.join(os.tmpdir(), 'project-handover-qa-'));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  try {
    await page.goto(`http://127.0.0.1:${address.port}/zjai-browser-plugin/project-handover/fixture.html`);
    const launcher = page.locator('#project-handover-fab');
    await launcher.waitFor({ state: 'visible' });
    const launcherBefore = await launcher.boundingBox();
    const ballBox = await launcher.locator('#ball').boundingBox();
    await page.mouse.move(ballBox.x + 20, ballBox.y + 20);
    await page.mouse.down();
    await page.mouse.move(ballBox.x - 120, ballBox.y - 60, { steps: 5 });
    await page.mouse.up();
    const launcherAfter = await launcher.boundingBox();
    assert.notStrictEqual(Math.round(launcherAfter.x), Math.round(launcherBefore.x), '入口拖动后位置应变化');
    await page.waitForTimeout(300);
    await launcher.locator('#ball').click();
    await launcher.locator('#open').click();
    const panel = page.locator('#project-handover-panel');
    await panel.waitFor({ state: 'visible' });
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    const initialPanelBox = await panel.boundingBox();
    assert.ok(initialPanelBox.width >= 720 && initialPanelBox.width <= 724, `弹框宽度应放大到约 720px：${JSON.stringify(initialPanelBox)}`);
    const panelText = await panel.locator('#ph-fields').innerText();
    for (const expected of ['项目基本信息', '客户干系人', '项目组成员', '项目交接信息', '项目任务', '补充信息', '项目预计风险', '首付款', '王涛', '杭州市滨江区', '完成项目启动和蓝图确认', '完成电子签章接口开发']) {
      assert.match(panelText, new RegExp(expected), `弹框应按网页区块展示：${expected}`);
    }
    assert.doesNotMatch(panelText, /其他字段/, '弹框不应创建网页不存在的“其他字段”区块');
    assert.doesNotMatch(panelText, /流程标题信息/, '标题解析字段应归入“项目基本信息”，不应创建虚构区块');
    assert.match(panelText, /实施人员\s+戚二康/);
    assert.match(panelText, /客开人员\s+宋汉望/);
    assert.match(panelText, /售前顾问\s+\(空\)/);
    assert.doesNotMatch(panelText, /实施顾问A|客开工程师C|售前顾问B/);
    const taskSection = panel.locator('#ph-fields section').filter({ hasText: '项目任务' });
    const taskSectionText = await taskSection.innerText();
    assert.match(taskSectionText, /实施任务目标\s+1\.完成项目启动和蓝图确认/);
    assert.match(taskSectionText, /客开任务目标\s+1\.完成电子签章接口开发/);
    assert.doesNotMatch(taskSectionText, /漏斗编号2|合同编号2|开始时间/, '项目任务弹框只展示任务目标清单');
    assert.strictEqual(await taskSection.locator('[data-ph-task-tab]').count(), 2, '项目任务页签应按编号清单展示');
    assert.strictEqual(await taskSection.locator('[data-ph-tab-card]').count(), 0, '项目任务页签不应使用嵌套卡片展示');
    assert.strictEqual(await taskSection.locator('table').count(), 0, '项目任务不应显示整张明细表');
    const acceptanceLabels = await page.evaluate(() => {
      const labels = new Set();
      document.querySelectorAll('.section-title span:not(.section-mark), .tabs button, #project-form th').forEach((node) => labels.add(node.textContent.trim()));
      document.querySelectorAll('#project-form tr').forEach((row) => {
        if (row.style.display === 'none' || row.classList.contains('section-title')) return;
        const cells = Array.from(row.children).filter((cell) => cell.tagName === 'TD');
        for (let index = 0; index + 1 < cells.length; index += 2) {
          if (cells[index + 1].querySelector('input, textarea, select')) labels.add(cells[index].textContent.trim());
        }
      });
      return Array.from(labels).filter(Boolean).filter((label) => !['任务目标', '开始时间'].includes(label));
    });
    for (const label of acceptanceLabels) assert.ok(panelText.includes(label), `完整验收页字段未展示：${label}`);
    assert.strictEqual(await page.evaluate(() => document.activeElement && document.activeElement.id), 'ph-close', '打开弹框后焦点应进入关闭按钮');
    await panel.locator('#ph-close').click();
    assert.strictEqual(await launcher.evaluate((host) => host.shadowRoot.activeElement && host.shadowRoot.activeElement.id), 'ball', '关闭弹框后焦点应返回入口');
    await launcher.locator('#ball').click();
    await launcher.locator('#open').click();
    await panel.waitFor({ state: 'visible' });
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    assert.match(await panel.locator('#ph-fields').innerText(), /紫软（苏州）信息科技有限公司/);
    assert.match(await panel.locator('#ph-fields').innerText(), /国产化环境，麒麟系统/);
    assert.match(await panel.locator('#ph-fields').innerText(), /隔离iframe补充/);
    assert.doesNotMatch(await panel.locator('#ph-fields').innerText(), /隐藏旧值|HIDDEN-OLD/);

    const header = panel.locator('#ph-header');
    const beforeDrag = await panel.boundingBox();
    const headerBox = await header.boundingBox();
    await page.mouse.move(headerBox.x + 120, headerBox.y + 16);
    await page.mouse.down();
    await page.mouse.move(headerBox.x - 80, headerBox.y + 70, { steps: 5 });
    await page.mouse.up();
    const afterDrag = await panel.boundingBox();
    assert.notStrictEqual(Math.round(afterDrag.x), Math.round(beforeDrag.x), '弹框拖动后位置应变化');

    await page.locator('#delivery-content').fill('合同管理、项目管理、电子签章');
    await panel.locator('#ph-reread').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-fields')?.textContent.includes('合同管理、项目管理、电子签章'));
    assert.match(await panel.locator('#ph-fields').innerText(), /合同管理、项目管理、电子签章/);

    const downloadPromise = page.waitForEvent('download');
    await panel.locator('#ph-generate').click();
    const download = await downloadPromise;
    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    assert.strictEqual(download.suggestedFilename(), `项目交接会议纪要-紫软（苏州）信息科技有限公司-${today}.docx`);
    const docxPath = path.join(outputDir, download.suggestedFilename());
    await download.saveAs(docxPath);
    await page.evaluate(() => {
      window.__projectHandoverGetURL = window.chrome.runtime.getURL;
      window.chrome.runtime.getURL = () => 'chrome-extension://invalid/template.docx';
    });
    await panel.locator('#ph-generate').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('生成失败'));
    assert.match(await panel.locator('#ph-status').innerText(), /模板读取失败/);
    await page.evaluate(() => { window.chrome.runtime.getURL = window.__projectHandoverGetURL; });
    await panel.locator('#ph-reread').focus();
    await page.keyboard.press('Tab');
    assert.strictEqual(await page.evaluate(() => document.activeElement && document.activeElement.id), 'ph-generate');
    const focusStyle = await panel.locator('#ph-generate').evaluate((node) => getComputedStyle(node).outlineStyle);
    assert.notStrictEqual(focusStyle, 'none', '键盘焦点应有可见轮廓');
    await panel.locator('#ph-reread').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    await panel.locator('#ph-fields').evaluate((node) => { node.parentElement.scrollTop = 0; });
    await page.screenshot({ path: path.join(outputDir, 'project-handover-panel.png'), fullPage: true });
    await taskSection.scrollIntoViewIfNeeded();
    await page.screenshot({ path: path.join(outputDir, 'project-handover-task-tabs.png'), fullPage: true });
    for (const width of [768, 375]) {
      await page.setViewportSize({ width, height: 900 });
      await page.evaluate(() => window.dispatchEvent(new Event('resize')));
      await page.waitForTimeout(100);
      const box = await panel.boundingBox();
      assert.ok(box.x >= 0 && box.x + box.width <= width + 1, `${width}px 下弹框不应横向溢出：${JSON.stringify(box)}`);
      assert.strictEqual(await panel.locator('#ph-fields').evaluate((node) => node.scrollWidth <= node.clientWidth), true, `${width}px 下字段区不应横向滚动`);
      await page.screenshot({ path: path.join(outputDir, `project-handover-panel-${width}.png`), fullPage: true });
    }

    const zip = await JSZip.loadAsync(fs.readFileSync(docxPath));
    const documentXml = await zip.file('word/document.xml').async('string');
    assert.match(documentXml, /紫软（苏州）信息科技有限公司项目交接会议纪要/);
    assert.match(documentXml, /合同管理、项目管理、电子签章/);
    assert.match(documentXml, /国产化环境，麒麟系统/);
    assert.match(documentXml, /合同在线用印/);
    assert.match(documentXml, /2026-09-10 前完成上线/);
    assert.match(documentXml, /1、第一次客户现场沟通，建联、组件团队，确认项目交付任务；/);
    assert.match(documentXml, /2、确认项目主计划及启动会时间；/);
    assert.match(documentXml, /3、销售岳文昊2026-08-15收取首付款，安排资源进场开始调研；/);
    assert.match(documentXml, /4、项目初步预计2026-10-31完成整体交付；/);
    assert.match(documentXml, /1、采用标准业务包引导客户业务，实现快速交付的目标；/);
    assert.match(documentXml, /2、修改内容计入客开人天，商务配合谈追加费用，控制修改成本；/);
    assert.doesNotMatch(documentXml, /旧策略不应覆盖/);
    assert.match(documentXml, /☑\s*销售合同/);
    assert.match(documentXml, /☑\s*售前方案/);
    assert.match(documentXml, /☑\s*招投标文件/);
    assert.match(documentXml, /☑\s*前期POC环境、业务包/);
    assert.match(documentXml, /1\.项目经理，信息部，信息部经理，王涛，支持，尽快完工/);
    assert.match(documentXml, /岳文昊/);
    assert.match(documentXml, /戚二康/);
    assert.match(documentXml, /宋汉望/);
    assert.match(documentXml, /☑远程|☑ 远程/, '会议方式/交付方式应保留单选格式并勾选远程');
    assert.match(documentXml, /☑\s*否/, '是否类字段应保留单选格式并勾选否');
    assert.match(documentXml, /☑\s*是/, '是否类字段应保留单选格式并勾选是');
    assert.match(documentXml, /☑\s*致远/, '交付主体应保留单选格式并勾选致远');
    assert.doesNotMatch(documentXml, /需手动完善/, '网页未读取到的字段不应再写入“需手动完善”');
    assert.doesNotMatch(documentXml, /实施顾问A|客开工程师C|售前顾问B/, '会议人员应从项目组成员或项目承接信息取值，售前无人时留空');
    assert.match(documentXml, /1\.客开资源需要提前协调/);
    assert.doesNotMatch(documentXml, /解决策略：提前锁定客开资源/);
    assert.match(documentXml, /1\.项目经理：宋汉望，客开顾问/);
    assert.match(documentXml, /2\.实施顾问：戚二康，实施顾问/);
    assert.doesNotMatch(documentXml, /顾问名称：宋汉望|顾问姓名：宋汉望|项目角色：项目经理/);
    assert.match(documentXml, /1\.首付款2026-08-1530%/);
    assert.match(documentXml, /1\.完成电子签章接口开发/);
    assert.doesNotMatch(documentXml, /任务目标：完成电子签章接口开发/, '需要开发内容应只写编号清单，不写整行字段名汇总');
    assert.doesNotMatch(documentXml, /付款阶段：首付款/, '回款进度应只写编号清单，不写整行字段名汇总');
    assert.doesNotMatch(documentXml, /电子签章接口及档案归档接口/, '需要开发内容应由客开任务目标明细覆盖普通字段');

    await page.evaluate(() => {
      const setByLabel = (label, value) => {
        const cell = Array.from(document.querySelectorAll('#project-form td')).find((node) => node.textContent.trim() === label);
        const target = cell && cell.nextElementSibling && cell.nextElementSibling.querySelector('textarea,input');
        if (target) target.value = value;
      };
      setByLabel('项目安排', '只有一条安排');
      setByLabel('交付策略', '只有一条策略');
      setByLabel('交付物', '无法匹配的交付材料');
    });
    await panel.locator('#ph-reread').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    const preservedRemarksDownloadPromise = page.waitForEvent('download');
    await panel.locator('#ph-generate').click();
    const preservedRemarksDownload = await preservedRemarksDownloadPromise;
    const preservedRemarksPath = path.join(outputDir, `preserved-remarks-${preservedRemarksDownload.suggestedFilename()}`);
    await preservedRemarksDownload.saveAs(preservedRemarksPath);
    const preservedRemarksZip = await JSZip.loadAsync(fs.readFileSync(preservedRemarksPath));
    const preservedRemarksXml = await preservedRemarksZip.file('word/document.xml').async('string');
    assert.match(preservedRemarksXml, /XXXX第一次客户现场沟通/, '项目安排无法组装清单时应保留模板原文');
    assert.match(preservedRemarksXml, /采用标准业务包引导客户业务，实现快速交付的目标/, '主要策略无法组装清单时应保留模板原文');
    assert.match(preservedRemarksXml, /销售合同/, '交付物无法匹配时应保留模板原文');
    assert.doesNotMatch(preservedRemarksXml, /只有一条安排|只有一条策略|无法匹配的交付材料/);

    await page.evaluate(() => {
      const riskRows = Array.from(document.querySelectorAll('#project-form tr'));
      const headerRow = riskRows.find((row) => row.textContent.includes('风险描述') && row.textContent.includes('解决策略'));
      const riskRow = headerRow && headerRow.nextElementSibling;
      if (riskRow && riskRow.children[4]) riskRow.children[4].textContent = '';
    });
    await panel.locator('#ph-reread').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    const emptyRiskDownloadPromise = page.waitForEvent('download');
    await panel.locator('#ph-generate').click();
    const emptyRiskDownload = await emptyRiskDownloadPromise;
    const emptyRiskPath = path.join(outputDir, `empty-risk-${emptyRiskDownload.suggestedFilename()}`);
    await emptyRiskDownload.saveAs(emptyRiskPath);
    const emptyRiskZip = await JSZip.loadAsync(fs.readFileSync(emptyRiskPath));
    const emptyRiskXml = await emptyRiskZip.file('word/document.xml').async('string');
    assert.doesNotMatch(emptyRiskXml, /风险等级：|新增时间：|风险类别：|风险描述：\(空\)|解决策略：\(空\)/, '风险描述为空时不应回退整行风险汇总');

    await page.evaluate(() => {
      const memberRow = Array.from(document.querySelectorAll('#project-form tr')).find((row) => row.textContent.includes('客开顾问'));
      if (memberRow) memberRow.remove();
      const responsibilityLabel = Array.from(document.querySelectorAll('#project-form td')).find((cell) => cell.textContent.trim() === '客开责任人');
      const input = responsibilityLabel && responsibilityLabel.nextElementSibling && responsibilityLabel.nextElementSibling.querySelector('input');
      if (input) input.value = '承接兜底人员';
    });
    await panel.locator('#ph-reread').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-fields')?.textContent.includes('承接兜底人员'));
    assert.match(await panel.locator('#ph-fields').innerText(), /客开人员\s+承接兜底人员/, '项目组无客开顾问时应回退项目承接信息的客开责任人');

    await page.locator('#delivery-content').fill('');
    assert.strictEqual(await page.locator('#delivery-content').inputValue(), '', '测试页控件应已清空');
    await panel.locator('#ph-reread').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    const deliveryRow = panel.locator('#ph-fields tr').filter({ hasText: '交付内容' });
    assert.match(await deliveryRow.innerText(), /\(空\)/, '清空控件后重新读取不应回退旧 textContent');

    await page.setViewportSize({ width: 1280, height: 900 });
    await page.evaluate(() => {
      const oldPanel = document.getElementById('project-handover-panel');
      const oldButton = document.querySelector('#project-handover-panel #ph-generate');
      oldButton.replaceWith(oldButton.cloneNode(true));
      oldPanel.style.display = 'none';
    });
    await page.addScriptTag({ url: `http://127.0.0.1:${address.port}/zjai-browser-plugin/project-handover/content.js?reload=1` });
    const reloadedLauncher = page.locator('#project-handover-fab');
    await reloadedLauncher.locator('#ball').click();
    await reloadedLauncher.locator('#open').click();
    const reloadedPanel = page.locator('#project-handover-panel');
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    assert.match(await reloadedPanel.locator('#ph-status').innerText(), /已读取/);
    await reloadedPanel.locator('#ph-generate').click();
    await reloadedPanel.locator('#ph-status').waitFor({ state: 'visible' });
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已生成会议纪要'), null, { timeout: 1500 });

    await page.goto(`http://127.0.0.1:${address.port}/zjai-browser-plugin/project-handover/fixture.html`);
    await page.evaluate(() => document.querySelectorAll('.section-title').forEach((row) => row.remove()));
    const fallbackLauncher = page.locator('#project-handover-fab');
    await fallbackLauncher.locator('#ball').click();
    await fallbackLauncher.locator('#open').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    const fallbackText = await page.locator('#project-handover-panel').innerText();
    assert.doesNotMatch(fallbackText, /已读取 0 个区块、4 个字段、0 条明细/, '无区块标题时不应退化为只读取标题字段');
    assert.match(fallbackText, /项目基本信息/);
    assert.match(fallbackText, /合同编号\s+HTSP202607003568/);
    assert.match(fallbackText, /项目交接信息/);
    assert.match(fallbackText, /交付策略\s+采用标准业务包引导客户业务/);
    assert.match(fallbackText, /项目组成员/);
    assert.match(fallbackText, /宋汉望/);
    const fallbackBasicSection = await page.locator('#project-handover-panel section').filter({ hasText: '项目基本信息' }).innerText();
    assert.doesNotMatch(fallbackBasicSection, /\n1\s+宋汉望/);
    assert.doesNotMatch(fallbackBasicSection, /\n2\s+戚二康/);
    await page.screenshot({ path: path.join(outputDir, 'project-handover-fallback-fields.png'), fullPage: true });

    await page.goto(`http://127.0.0.1:${address.port}/zjai-browser-plugin/project-handover/cap4-fixture.html`);
    const cap4Launcher = page.locator('#project-handover-fab');
    await cap4Launcher.locator('#ball').click();
    await cap4Launcher.locator('#open').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    const cap4PanelText = await page.locator('#project-handover-panel').innerText();
    assert.doesNotMatch(cap4PanelText, /已读取 0 个区块、4 个字段、0 条明细/, 'CAP4 真实结构不应只读取标题字段');
    assert.match(cap4PanelText, /项目基本信息/);
    assert.match(cap4PanelText, /业务线\s+企业/);
    assert.match(cap4PanelText, /签约年度\s+2026/);
    assert.match(cap4PanelText, /合同编号\s+HTSP202607003568/);
    assert.match(cap4PanelText, /项目付款阶段/);
    assert.match(cap4PanelText, /首付款/);
    assert.match(cap4PanelText, /客开任务目标/);
    assert.match(cap4PanelText, /完成电子签章接口开发/);
    const cap4BasicSection = await page.locator('#project-handover-panel section').filter({ hasText: '项目基本信息' }).innerText();
    assert.doesNotMatch(cap4BasicSection, /\n1\s+宋汉望/);
    assert.doesNotMatch(cap4BasicSection, /\n2\s+戚二康/);
    await page.screenshot({ path: path.join(outputDir, 'project-handover-cap4-fields.png'), fullPage: true });

    await page.locator('#subject').evaluate((node) => { node.value = '普通流程'; });
    await page.locator('h1').evaluate((node) => { node.textContent = '普通流程'; });
    await page.evaluate(() => { document.title = '普通流程'; });
    await page.waitForTimeout(1700);
    assert.strictEqual(await page.locator('#project-handover-fab').count(), 0, '非目标页面应清理入口');
    await page.evaluate(() => {
      const pendingItem = document.createElement('div');
      pendingItem.textContent = '(自动发起)【浙江大区】-{HTSP202607003568-紫软（苏州）信息科技有限公司}-18000.00项目移交';
      document.body.appendChild(pendingItem);
    });
    await page.waitForTimeout(1700);
    assert.strictEqual(await page.locator('#project-handover-fab').count(), 0, '待办列表中出现项目移交标题时不应显示入口');
    await page.screenshot({ path: path.join(outputDir, 'project-handover-non-target-list.png'), fullPage: true });
    await page.goto(`http://127.0.0.1:${address.port}/zjai-browser-plugin/project-handover/frame-host-fixture.html`);
    const frameOnlyLauncher = page.locator('#project-handover-fab');
    await frameOnlyLauncher.waitFor({ state: 'visible' });
    await frameOnlyLauncher.locator('#ball').click();
    await frameOnlyLauncher.locator('#open').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-fields')?.textContent.includes('跨框测试公司'));
    assert.match(await page.locator('#project-handover-panel #ph-status').innerText(), /已读取 1 个区块、/);
    assert.match(await page.locator('#project-handover-panel #ph-fields').innerText(), /客户IT环境\s+iframe 内国产化环境/);
    await page.screenshot({ path: path.join(outputDir, 'project-handover-frame-only.png'), fullPage: true });
    console.log(JSON.stringify({ acceptanceLabelCount: acceptanceLabels.length, outputDir, docxPath, screenshot: path.join(outputDir, 'project-handover-panel.png'), taskScreenshot: path.join(outputDir, 'project-handover-task-tabs.png'), responsiveScreenshots: [768, 375].map((width) => path.join(outputDir, `project-handover-panel-${width}.png`)), nonTargetScreenshot: path.join(outputDir, 'project-handover-non-target-list.png'), frameOnlyScreenshot: path.join(outputDir, 'project-handover-frame-only.png') }));
  } finally {
    await closeBrowser(browser);
    await new Promise((resolve) => server.close(resolve));
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
