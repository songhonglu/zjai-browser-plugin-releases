# Project Handover Overlay Design

## 1. Direction

OA 内部工具风格，沿用 `project-check` 的紧凑蓝色操作面板；视觉优先级是字段可核对、按钮明确、长文本可读。

## 2. Tokens

- Accent: `#2563eb`; header: `#1d4ed8`; success: `#15803d`; danger: `#b91c1c`.
- Surface: `#ffffff`; muted surface: `#eff6ff`; border: `#bfdbfe`; text: `#1f2937`; muted text: `#64748b`.
- Spacing: 4px 基准；常用 8/12/16px。
- Radius: 面板 12px；按钮和信息块 8px。
- Typography: `system-ui,-apple-system,"Microsoft YaHei",sans-serif`; 12/13/14px。

## 3. Layout

- 42px 独立悬浮入口，默认位于右侧中部，可拖动。
- 480px 弹框，最大宽度 `calc(100vw - 32px)`，最大高度 `80vh`，标题栏作为拖动手柄。
- 字段列表使用两列键值表；长值自动换行，不横向滚动。

## 4. Components and States

- Launcher: default / dragging / menu-open。
- Panel: hidden / ready / error / generating。
- Button: default / hover / disabled；必须支持键盘焦点。
- Field row: label + wrapped value；空值显示 `(空)`。

## 5. Accessibility

- 入口和按钮使用真实 `button`，提供 `aria-label`。
- 关闭、重新读取、写入会议纪要均可键盘触发。
- 不依赖颜色表达状态；状态同时提供文字。
- 动效仅使用 transform/opacity，尊重 `prefers-reduced-motion`。

## 6. Accepted Debt

- 弹框运行在客户 OA 页面，无法进行独立 Lighthouse SEO 审计；使用本地真实 Chromium 交互与截图 QA 替代。
- 现场 DOM 未提供固定字段 ID 时，首版使用精确 label + 控件值读取；真实 OA 回归后可补稳定 ID 映射。
