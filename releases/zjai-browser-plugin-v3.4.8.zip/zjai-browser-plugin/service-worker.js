// =============================================================================
// 统一 Service Worker 入口（MV3, type:"module"）
// 由 manifest.json → background.service_worker 指向本文件。
//
// 本扩展后台承载两组功能，各自注册 chrome.runtime.onMessage 监听器，按消息字段分流：
//   ① 致远网页辅助工具原有功能（工时签卡 + CTP-Studio 代码合规扫描）
//      —— 消息带 { action } 字段；见 ./background.js
//   ② 客开冲突雷达（V5 源码冲突检测）
//      —— 消息带 { type } / { replyTo } 字段；见 ./conflict-radar/bg/service-worker.js
// 两组字段不重叠：background.js 的监听器已加守卫「仅处理带 action 字段的消息」，
// 冲突雷达监听器只认 type/replyTo，互不干扰、不交叉响应、不污染彼此日志。
//
// 说明：原 background.js 为「经典脚本」，本入口改为 ES module。作为 module 整体 import
// 时，其顶层代码（注册监听、初始化日志）照常执行；其内部函数互调都在同一模块作用域，
// 不受影响。冲突雷达 bg 为原生 ES module，整目录原样迁入，import 相对路径不变。
// =============================================================================

// ① 原致远网页辅助工具后台（工时签卡 + 代码合规）
import './background.js';

// ② 客开冲突雷达后台
import './conflict-radar/bg/service-worker.js';
