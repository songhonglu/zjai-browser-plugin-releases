(function () {
  const form = document.getElementById('form');
  const description = document.getElementById('description');
  const docUrl = document.getElementById('docUrl');
  const nameInput = document.getElementById('name');
  const contact = document.getElementById('contact');
  const msg = document.getElementById('msg');
  let msgTimer = null;

  function normalize(value) {
    return String(value || '').trim();
  }

  function setMsg(text, autoClear) {
    msg.textContent = text || '';
    if (msgTimer) clearTimeout(msgTimer);
    if (autoClear) {
      msgTimer = setTimeout(() => { msg.textContent = ''; }, 5000);
    }
  }

  async function submitToDingTalk(event) {
    event.preventDefault();
    const record = {
      description: normalize(description.value),
      docUrl: normalize(docUrl.value),
      name: normalize(nameInput.value),
      contact: normalize(contact.value),
      createdAt: new Date().toLocaleString('zh-CN', { hour12: false })
    };
    if (!record.description || !record.name || !record.contact) {
      setMsg('需求描述、姓名、联系方式不能为空');
      return;
    }
    setMsg('正在提交到钉钉...');
    try {
      const result = await chrome.runtime.sendMessage({ action: 'submitRequirementToDingTalk', params: record });
      if (!result || !result.success) {
        setMsg('钉钉提交失败：' + ((result && result.error) || '后台处理失败'));
        return;
      }
    } catch (error) {
      setMsg('钉钉提交失败：' + (error && error.message ? error.message : '后台不可用'));
      return;
    }
    description.value = '';
    docUrl.value = '';
    setMsg('已提交到钉钉机器人', true);
  }

  document.getElementById('clear-form').addEventListener('click', () => {
    form.reset();
    setMsg('');
  });
  form.addEventListener('submit', submitToDingTalk);
  try {
    chrome.runtime.sendMessage({ action: 'getRequirementCurrentUser' }, (result) => {
      if (!result || !result.success || !result.data) return;
      if (result.data.name) nameInput.value = result.data.name;
      if (result.data.contact) contact.value = result.data.contact;
    });
  } catch (_) {}
})();
