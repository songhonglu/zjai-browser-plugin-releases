// =============================================================================
// build-download main-world.js
// 以 "world": "MAIN" 注入（manifest content_scripts），不受页面 CSP 限制。
// 功能：patch window.open + HTMLIFrameElement.src setter，
//       拦到 minio/devops/build-manager URL 时改写成 about:blank，
//       并通过 document.documentElement[data-bd-url] 通知 ISOLATED world。
// =============================================================================
(function () {
  'use strict';
  if (window.__bd_main_injected) return;
  window.__bd_main_injected = true;

  function isMinio(u) {
    try { return /minio|devops|build-manager/i.test(String(u)); } catch (e) { return false; }
  }
  function signal(url) {
    try {
      document.documentElement.setAttribute('data-bd-url', String(url));
    } catch (e) {}
  }

  // patch window.open
  var _open = window.open;
  window.open = function (url) {
    if (isMinio(url)) {
      signal(url);
      return null;
    }
    return _open.apply(window, arguments);
  };

  // patch HTMLIFrameElement.src setter
  var d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src');
  if (d && d.set) {
    Object.defineProperty(HTMLIFrameElement.prototype, 'src', {
      configurable: true,
      enumerable: true,
      get: function () { return d.get ? d.get.call(this) : ''; },
      set: function (v) {
        if (isMinio(v)) {
          signal(v);
          v = 'about:blank';
        }
        return d.set.call(this, v);
      }
    });
  }
})();
