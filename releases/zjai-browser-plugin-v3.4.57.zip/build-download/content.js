// =============================================================================
// build-download v13 —— CTP-Studio「下载时只生成 1 个 构建备注.zip」
// 运行在 http://studio.kk.seeyon.com/* （manifest content_scripts, all_frames）。
//
// 方案：
//   1. main-world patch iframe.src setter + window.open，截获 minio URL，
//      把 src 改写成 about:blank / open 返回 null → 原生 CP_ 下载不发生。
//   2. content(isolated) 读「构建备注」列，发 buildDownloadDnr { name, url } 给后台。
//   3. 后台 SW fetch(url, credentials, 重试) → base64 返回 content。
//   4. content 用 Blob + <a download="备注.zip"> 触发下载（文件名 100% 生效）。
//   结果：下载目录只有 1 个「构建备注.zip」，无 CP_，不弹窗。
//
// 无常驻角标、无刷屏日志；仅在实际异常时打印一条 warn。
// =============================================================================
(function () {
  'use strict';
  if (window.__build_download_injected_v13) return;
  window.__build_download_injected_v13 = true;

  function warn(msg) { console.warn('[build-download]', msg); }
  function textOf(el) { return String(el && el.textContent || '').replace(/\s+/g, ' ').trim(); }

  // 清洗文件名（白名单）：去控制字符；非白名单字符（Windows 非法字符、全角标点、emoji 等）→ "-"；
  // 折叠连续 - 与空白，去首尾 -/. /空格，超长截断。与后台 sanitizeDownloadName 保持一致。
  function cleanName(raw, maxLen) {
    var s = String(raw || '');
    s = s.replace(/[\u0000-\u001F\u007F]/g, '');
    s = s.replace(/[^\u4e00-\u9fffa-zA-Z0-9.\-_ ]/g, '-');
    s = s.replace(/-+/g, '-');
    s = s.replace(/\s+/g, ' ').trim();
    s = s.replace(/^[-.\s]+|[-.\s]+$/g, '');
    var limit = maxLen || 80;
    if (s.length > limit) s = s.slice(0, limit).replace(/[-.\s]+$/g, '');
    return s;
  }
  function isMinioUrl(u) { return /minio|devops|build-manager/i.test(String(u || '')); }

  function isDownloadControl(el) {
    if (!el || !el.nodeType) return false;
    var t = textOf(el);
    if (t === '下载') return true;
    if (el.tagName === 'BUTTON' || el.tagName === 'A' || el.getAttribute('role') === 'button') {
      var title = (el.getAttribute && el.getAttribute('title')) || el.title || el.getAttribute('aria-label') || '';
      if (title === '下载' || (title.length <= 8 && title.indexOf('下载') >= 0)) return true;
      if (t.length <= 8 && t.indexOf('下载') >= 0) return true;
    }
    return false;
  }

  // ---------- 通过表头定位"构建备注"列 ----------
  function readRemarkByHeader(ctrl) {
    var tr = ctrl.closest ? ctrl.closest('tr') : null;
    if (!tr) return '';
    var table = tr.closest ? tr.closest('table') : null;
    if (!table) {
      var p = tr.parentElement;
      if (p && p.tagName === 'TBODY') table = p.parentElement;
      else if (p && p.tagName === 'TABLE') table = p;
      else {
        var allTables = document.querySelectorAll('table');
        for (var k = 0; k < allTables.length; k++) {
          if (textOf(allTables[k]).indexOf('构建备注') >= 0) { table = allTables[k]; break; }
        }
      }
    }
    if (!table) return '';
    var headerRow = null;
    var thead = table.querySelector('thead');
    if (thead) headerRow = thead.querySelector('tr');
    if (!headerRow) {
      var firstRow = table.querySelector('tr');
      if (firstRow && firstRow !== tr && firstRow.querySelectorAll('th').length > 0) headerRow = firstRow;
    }
    var remarkColIndex = -1;
    if (headerRow) {
      var ths = headerRow.querySelectorAll('th, td');
      for (var j = 0; j < ths.length; j++) {
        var ht = textOf(ths[j]);
        if (ht.indexOf('构建备注') >= 0 || (ht.indexOf('备注') >= 0 && ht.length <= 6)) {
          remarkColIndex = j; break;
        }
      }
    }
    if (remarkColIndex >= 0) {
      var tds = tr.querySelectorAll('td');
      if (tds[remarkColIndex]) { var val = textOf(tds[remarkColIndex]); if (val) return val; }
    }
    var best = '';
    tr.querySelectorAll('td').forEach(function (td) {
      var t = textOf(td);
      if (t.length < 10) return;
      if (t.indexOf('下载') >= 0 || t.indexOf('发布') >= 0) return;
      if (t.indexOf('复制提交SHA') >= 0) return;
      if (/^[\d.,\s]*(秒|分|时|ms|s|m|h)$/i.test(t)) return;
      if (/^\d{4}-\d{2}-\d{2}/.test(t)) return;
      if (/^CP[_-]/i.test(t)) return;
      if (t.indexOf('http') >= 0) return;
      if (t.length > best.length) best = t;
    });
    return best;
  }

  // ---------- 顶部客户名（如"财通证券股份有限公司"） ----------
  // 多项目同时打开时，"当前项目"由选中页签 .menuTab.active 决定；
  // #customerName 用 getElementById 只取文档里第一个会错乱，故 active tab 文本作首选。
  function readCustomerName() {
    var cName = '';
    // 1. 首选：当前选中页签 .menuTab.active 的文本（跨 frame；去掉关闭图标取纯文本）
    function readActiveTab(doc) {
      if (!doc || cName) return;
      var tab;
      try { tab = doc.querySelector('.menuTab.active') || doc.querySelector('.active.menuTab'); } catch (e) { return; }
      if (!tab) return;
      var clone = tab.cloneNode(true);
      try {
        var rm = clone.querySelectorAll('i, .fa, .fa-times-circle, .close');
        for (var k = 0; k < rm.length; k++) rm[k].remove();
      } catch (e) {}
      var t = textOf(clone);
      if (t) cName = t;
    }
    readActiveTab(document);
    if (!cName) {
      try {
        var topWin = window.top;
        readActiveTab(topWin && topWin.document);
        var topFrames = topWin && topWin.frames;
        if (topFrames) for (var tf = 0; tf < topFrames.length; tf++) { readActiveTab(topFrames[tf] && topFrames[tf].document); if (cName) break; }
      } catch (e) {}
    }
    if (!cName) {
      try { for (var mf2 = 0; mf2 < window.frames.length; mf2++) { readActiveTab(window.frames[mf2] && window.frames[mf2].document); if (cName) break; } } catch (e) {}
    }
    if (cName) return cName;

    // 2. 精确 id="customerName"（input 值在 value 属性；跨 frame）——active tab 未命中时兜底
    var cName2 = '';
    function findCustomer(doc) {
      if (!doc || cName2) return;
      var n;
      try { n = doc.getElementById('customerName'); } catch (e) { return; }
      if (n) { var v = (n.value && String(n.value).trim()) || textOf(n); if (v) cName2 = v; }
    }
    findCustomer(document);
    if (!cName2) {
      try {
        var tw2 = window.top;
        findCustomer(tw2 && tw2.document);
        var tf2 = tw2 && tw2.frames;
        if (tf2) for (var q = 0; q < tf2.length; q++) { findCustomer(tf2[q] && tf2[q].document); if (cName2) break; }
      } catch (e) {}
    }
    if (cName2) return cName2;
    // 2. 模糊匹配兜底：顶部 250px 内，找含组织词的最短文本
    var best = '';
    var els = document.querySelectorAll('div,span,a,label,li,p,h1,h2,h3,h4,h5,h6,b,strong,header,section,td');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var t = textOf(el);
      if (t.length < 4 || t.length > 50) continue;
      var r = el.getBoundingClientRect();
      if (!r || r.top > 250 || r.width < 20) continue;
      // 必须含组织名称关键词
      if (!/公司|有限|银行|证券|集团|研究院|事务所|基金/.test(t)) continue;
      // 排除导航/菜单/功能按钮文字
      if (/下载|发布|刷新|复制|构建|管理|扫描|记录|基本|仓库|升级|权限|源码|日志|策略|增量/.test(t)) continue;
      // 取最短（最精确的叶子节点）
      if (t.length < best.length || !best) best = t;
    }
    if (best) return best;
    // 兜底：从页面 title 取
    var title = (document.title || '').replace(/[-|].*$/, '').trim();
    if (title.length >= 4 && /公司|有限|银行|证券|集团/.test(title)) return title;
    return '';
  }

  // ---------- 该行"构建时间"取 YYYYMMDD ----------
  function readBuildDate(ctrl) {
    var tr = ctrl.closest ? ctrl.closest('tr') : null;
    if (!tr) return '';
    var d = '';
    tr.querySelectorAll('td').forEach(function (td) {
      if (d) return;
      // 完整时间戳 2026-11-19 19:13:13；没有时分秒则退回纯日期
      var m = textOf(td).match(/(\d{4}-\d{2}-\d{2})[ T]?((\d{2}:\d{2}:\d{2})|\d{2}:\d{2})?/);
      if (m) d = (m[1] + ' ' + (m[3] || m[2] || '')).trim();
    });
    if (!d) return '';
    // 去掉 - 空格 : → 2026-11-19 19:13:13 → 20261119191313；纯日期 → 20261119
    return d.replace(/[-:\s]/g, '');
  }

  // ---------- 监听 main-world.js 写入的 data-bd-url 属性 ----------
  // main-world.js（manifest 声明 MAIN world）patch window.open + iframe.src，
  // 拦到 minio URL 时改写为 about:blank 并通过 documentElement[data-bd-url] 通知。
  var lastBdUrl = '';
  var bdUrlObserver = new MutationObserver(function (mutations) {
    mutations.forEach(function (m) {
      if (m.type === 'attributes' && m.attributeName === 'data-bd-url') {
        var url = document.documentElement.getAttribute('data-bd-url') || '';
        if (url && url !== lastBdUrl) {
          lastBdUrl = url;
          lastUrl = url;
          try { document.documentElement.removeAttribute('data-bd-url'); } catch (e) {}
          if (pending.name) sendToBg(url);
        }
      }
    });
  });
  bdUrlObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-bd-url'] });

  // ---------- 状态 ----------
  var pending = { name: '', at: 0 };
  var lastUrl = '';
  var sentFlag = null; // 防止同一次点击触发多次下载

  function sendToBg(url) {
    var name = pending.name;
    if (!name) return;
    if (sentFlag === name) return; // 本次已发过，跳过
    sentFlag = name;
    var targetName = /\.zip$/i.test(name) ? name : name + '.zip';
    try {
      chrome.runtime.sendMessage({
        action: 'buildDownloadDnr',
        params: { name: targetName, url: url || '' }
      }, function (resp) {
        if (chrome.runtime.lastError) return;
        var data = resp && resp.data;
        if (data && data.fetched && data.base64) downloadViaBlob(data.base64, data.targetName);
      });
    } catch (e) { /* 静默 */ }
  }

  // base64 → Blob → <a download> 触发下载。blob: 是安全上下文，download 文件名 100% 生效。
  function downloadViaBlob(base64, targetName) {
    try {
      var bin = atob(base64);
      var len = bin.length;
      var bytes = new Uint8Array(len);
      for (var i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
      var blob = new Blob([bytes], { type: 'application/zip' });
      var blobUrl = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = blobUrl;
      a.download = targetName;
      a.style.display = 'none';
      document.documentElement.appendChild(a);
      a.click();
      setTimeout(function () {
        try { URL.revokeObjectURL(blobUrl); } catch (_) {}
        if (a.parentNode) a.parentNode.removeChild(a);
      }, 2000);
    } catch (e) {
      warn('Blob 下载异常：' + (e && e.message));
    }
  }

  // MutationObserver 兜底（若 main-world hook 未生效）+ 删除 minio iframe 阻止 CP_
  var io = new MutationObserver(function (mutations) {
    if (!pending.name || Date.now() - pending.at > 30000) return;
    mutations.forEach(function (m) {
      m.addedNodes.forEach(function (node) {
        if (node.nodeType !== 1) return;
        var check = function (iframe) {
          var src = iframe.src || iframe.getAttribute('src') || '';
          if (isMinioUrl(src)) {
            lastUrl = src;
            try { iframe.remove(); } catch (_) {}
            sendToBg(src);
          }
        };
        if (node.tagName === 'IFRAME') check(node);
        if (node.querySelectorAll) node.querySelectorAll('iframe').forEach(check);
      });
    });
  });
  io.observe(document.documentElement, { childList: true, subtree: true });

  // src 属性变化也监听（CTP 可能先建 iframe 再设 src）
  var attrIO = new MutationObserver(function (mutations) {
    if (!pending.name || Date.now() - pending.at > 30000) return;
    mutations.forEach(function (m) {
      if (m.type === 'attributes' && m.attributeName === 'src' && m.target.tagName === 'IFRAME') {
        var src = m.target.src || m.target.getAttribute('src') || '';
        if (isMinioUrl(src)) {
          lastUrl = src;
          try { m.target.remove(); } catch (_) {}
          sendToBg(src);
        }
      }
    });
  });
  attrIO.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });

  // ---------- 点击「下载」处理 ----------
  document.addEventListener('click', function (ev) {
    var target = ev.target;
    if (!target || !target.nodeType) return;
    var ctrl = target.closest ? target.closest('button,a,[role="button"]') : null;
    if (!(isDownloadControl(target) || (ctrl && isDownloadControl(ctrl)))) return;

    var ctrlEl = ctrl || target;
    var remark = readRemarkByHeader(ctrlEl);
    var remarkName = cleanName(remark, 40);           // 备注限 40，给客户名+日期留空间
    if (!remarkName) return;

    var customer = cleanName(readCustomerName(), 20);   // 客户名限 20
    var date = readBuildDate(ctrlEl);                  // YYYYMMDD
    if (!customer) {
      // 仅客户名缺失时打一条诊断（正常不打印），帮助一次定位 #customerName 在哪个 frame
      try {
        var diag = { self: !!document.getElementById('customerName') };
        try { diag.top = !!(window.top && window.top.document.getElementById('customerName')); } catch (e) { diag.top = 'blocked'; }
        var sub = 0;
        try { for (var d = 0; d < window.frames.length; d++) { if (window.frames[d].document.getElementById('customerName')) sub++; } } catch (e) {}
        diag.sub = sub;
        console.warn('[build-download] 未取到客户名。#customerName 探测：', JSON.stringify(diag),
          '本frame URL=', location.href.slice(0, 60));
      } catch (e) {}
    }

    var parts = [];
    if (customer) parts.push(customer);
    parts.push(remarkName);
    if (date) parts.push(date);
    var targetName = parts.join('_') + '.zip';

    pending = { name: targetName, at: Date.now() };
    sentFlag = null; // 允许本次点击重新发送一次；本次内的重复触发被 sendToBg 守卫拦住

    // 10s 内若 main-world 没拦到 URL，超时后仍发一次（后台可无 URL 时兜底）
    setTimeout(function () {
      if (pending.name === targetName && !lastUrl) sendToBg('');
      pending.name = '';
    }, 10000);

    // 30s 清 pending
    setTimeout(function () { pending.name = ''; }, 30000);
  }, true);
})();
