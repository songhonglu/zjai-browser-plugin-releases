// =============================================================================
// build-download v13 —— CTP-Studio「下载时只生成 1 个 构建备注.zip」
// 运行在 http://studio.kk.seeyon.com/* （manifest content_scripts, all_frames）。
//
// 方案：
//   1. main-world patch iframe.src setter + window.open，截获 minio URL，
//      把 src 改写成 about:blank / open 返回 null → 原生 CP_ 下载不发生。
//   2. content(isolated) 读「构建备注」列，发 buildDownloadDnr { name, url } 给后台。
//   3. 后台 SW fetch(url, credentials, 重试) → base64 返回 content。
//   4. content 用 Blob + <a download="备注.zip"> 触发下载（文件名 100% 生效）。
//   结果：下载目录只有 1 个「构建备注.zip」，无 CP_，不弹窗。
//
// 无常驻角标、无刷屏日志；仅在实际异常时打印一条 warn。
// =============================================================================
(function () {
  'use strict';
  if (window.__build_download_injected_v13) return;
  window.__build_download_injected_v13 = true;

  function warn(msg) { console.warn('[build-download]', msg); }
  function textOf(el) { return String(el && el.textContent || '').replace(/\s+/g, ' ').trim(); }

  // 清洗文件名（白名单）：去控制字符；非白名单字符（Windows 非法字符、全角标点、emoji 等）→ "-"；
  // 折叠连续 - 与空白，去首尾 -/. /空格，超长截断。与后台 sanitizeDownloadName 保持一致。
  function cleanName(raw) {
    var s = String(raw || '');
    s = s.replace(/[\u0000-\u001F\u007F]/g, '');
    s = s.replace(/[^\u4e00-\u9fffa-zA-Z0-9.\-_ ]/g, '-');
    s = s.replace(/-+/g, '-');
    s = s.replace(/\s+/g, ' ').trim();
    s = s.replace(/^[-.\s]+|[-.\s]+$/g, '');
    if (s.length > 80) s = s.slice(0, 80).replace(/[-.\s]+$/g, '');
    return s;
  }
  function isMinioUrl(u) { return /minio|devops|build-manager/i.test(String(u || '')); }

  function isDownloadControl(el) {
    if (!el || !el.nodeType) return false;
    var t = textOf(el);
    if (t === '下载') return true;
    if (el.tagName === 'BUTTON' || el.tagName === 'A' || el.getAttribute('role') === 'button') {
      var title = (el.getAttribute && el.getAttribute('title')) || el.title || el.getAttribute('aria-label') || '';
      if (title === '下载' || (title.length <= 8 && title.indexOf('下载') >= 0)) return true;
      if (t.length <= 8 && t.indexOf('下载') >= 0) return true;
    }
    return false;
  }

  // ---------- 通过表头定位"构建备注"列 ----------
  function readRemarkByHeader(ctrl) {
    var tr = ctrl.closest ? ctrl.closest('tr') : null;
    if (!tr) return '';
    var table = tr.closest ? tr.closest('table') : null;
    if (!table) {
      var p = tr.parentElement;
      if (p && p.tagName === 'TBODY') table = p.parentElement;
      else if (p && p.tagName === 'TABLE') table = p;
      else {
        var allTables = document.querySelectorAll('table');
        for (var k = 0; k < allTables.length; k++) {
          if (textOf(allTables[k]).indexOf('构建备注') >= 0) { table = allTables[k]; break; }
        }
      }
    }
    if (!table) return '';
    var headerRow = null;
    var thead = table.querySelector('thead');
    if (thead) headerRow = thead.querySelector('tr');
    if (!headerRow) {
      var firstRow = table.querySelector('tr');
      if (firstRow && firstRow !== tr && firstRow.querySelectorAll('th').length > 0) headerRow = firstRow;
    }
    var remarkColIndex = -1;
    if (headerRow) {
      var ths = headerRow.querySelectorAll('th, td');
      for (var j = 0; j < ths.length; j++) {
        var ht = textOf(ths[j]);
        if (ht.indexOf('构建备注') >= 0 || (ht.indexOf('备注') >= 0 && ht.length <= 6)) {
          remarkColIndex = j; break;
        }
      }
    }
    if (remarkColIndex >= 0) {
      var tds = tr.querySelectorAll('td');
      if (tds[remarkColIndex]) { var val = textOf(tds[remarkColIndex]); if (val) return val; }
    }
    var best = '';
    tr.querySelectorAll('td').forEach(function (td) {
      var t = textOf(td);
      if (t.length < 10) return;
      if (t.indexOf('下载') >= 0 || t.indexOf('发布') >= 0) return;
      if (t.indexOf('复制提交SHA') >= 0) return;
      if (/^[\d.,\s]*(秒|分|时|ms|s|m|h)$/i.test(t)) return;
      if (/^\d{4}-\d{2}-\d{2}/.test(t)) return;
      if (/^CP[_-]/i.test(t)) return;
      if (t.indexOf('http') >= 0) return;
      if (t.length > best.length) best = t;
    });
    return best;
  }

  // ---------- 注入 main world：patch iframe.src setter + window.open ----------
  // 拦在"赋值那一刻"，把 minio URL 改写为 about:blank / 返回 null，CP_ 请求发不出去。
  (function injectMainWorld() {
    var code = [
      '(function(){',
      '  if (window.__bd_main_v13) return; window.__bd_main_v13 = true;',
      '  function hit(u){ try{ return /minio|devops|build-manager/i.test(String(u)); }catch(e){ return false; } }',
      '  var _open = window.open;',
      '  window.open = function(url){',
      '    if (hit(url)) {',
      "      try { window.dispatchEvent(new CustomEvent('__bd_url__', { detail: { url: String(url), kind: 'open' } })); } catch(e){}",
      '      return null;',
      '    }',
      '    return _open.apply(window, arguments);',
      '  };',
      '  var d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "src");',
      '  if (d && d.set) {',
      '    Object.defineProperty(HTMLIFrameElement.prototype, "src", {',
      '      configurable: true, enumerable: true,',
      '      get: function(){ return d.get ? d.get.call(this) : ""; },',
      '      set: function(v){',
      '        if (hit(v)) {',
      "          try { window.dispatchEvent(new CustomEvent('__bd_url__', { detail: { url: String(v), kind: 'iframe' } })); } catch(e){}",
      '          v = "about:blank";',
      '        }',
      '        return d.set.call(this, v);',
      '      }',
      '    });',
      '  }',
      '})();'
    ].join('\n');
    var s = document.createElement('script');
    s.textContent = code;
    (document.head || document.documentElement).appendChild(s);
    s.remove();
  })();

  // ---------- 状态 ----------
  var pending = { name: '', at: 0 };
  var lastUrl = '';

  function sendToBg(url) {
    var name = pending.name;
    if (!name) return;
    var targetName = name + '.zip';
    try {
      chrome.runtime.sendMessage({
        action: 'buildDownloadDnr',
        params: { name: targetName, url: url || '' }
      }, function (resp) {
        if (chrome.runtime.lastError) return;
        var data = resp && resp.data;
        if (data && data.fetched && data.base64) downloadViaBlob(data.base64, data.targetName);
      });
    } catch (e) { /* 静默 */ }
  }

  // base64 → Blob → <a download> 触发下载。blob: 是安全上下文，download 文件名 100% 生效。
  function downloadViaBlob(base64, targetName) {
    try {
      var bin = atob(base64);
      var len = bin.length;
      var bytes = new Uint8Array(len);
      for (var i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
      var blob = new Blob([bytes], { type: 'application/zip' });
      var blobUrl = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = blobUrl;
      a.download = targetName;
      a.style.display = 'none';
      document.documentElement.appendChild(a);
      a.click();
      setTimeout(function () {
        try { URL.revokeObjectURL(blobUrl); } catch (_) {}
        if (a.parentNode) a.parentNode.removeChild(a);
      }, 2000);
    } catch (e) {
      warn('Blob 下载异常：' + (e && e.message));
    }
  }

  // main world 拦到 minio URL 后回调
  window.addEventListener('__bd_url__', function (e) {
    var url = e.detail && e.detail.url;
    if (!url) return;
    lastUrl = url;
    if (pending.name) sendToBg(url);
  });

  // MutationObserver 兜底（若 main-world hook 未生效）+ 删除 minio iframe 阻止 CP_
  var io = new MutationObserver(function (mutations) {
    if (!pending.name || Date.now() - pending.at > 30000) return;
    mutations.forEach(function (m) {
      m.addedNodes.forEach(function (node) {
        if (node.nodeType !== 1) return;
        var check = function (iframe) {
          var src = iframe.src || iframe.getAttribute('src') || '';
          if (isMinioUrl(src)) {
            lastUrl = src;
            try { iframe.remove(); } catch (_) {}
            sendToBg(src);
          }
        };
        if (node.tagName === 'IFRAME') check(node);
        if (node.querySelectorAll) node.querySelectorAll('iframe').forEach(check);
      });
    });
  });
  io.observe(document.documentElement, { childList: true, subtree: true });

  // src 属性变化也监听（CTP 可能先建 iframe 再设 src）
  var attrIO = new MutationObserver(function (mutations) {
    if (!pending.name || Date.now() - pending.at > 30000) return;
    mutations.forEach(function (m) {
      if (m.type === 'attributes' && m.attributeName === 'src' && m.target.tagName === 'IFRAME') {
        var src = m.target.src || m.target.getAttribute('src') || '';
        if (isMinioUrl(src)) {
          lastUrl = src;
          try { m.target.remove(); } catch (_) {}
          sendToBg(src);
        }
      }
    });
  });
  attrIO.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });

  // ---------- 点击「下载」处理 ----------
  document.addEventListener('click', function (ev) {
    var target = ev.target;
    if (!target || !target.nodeType) return;
    var ctrl = target.closest ? target.closest('button,a,[role="button"]') : null;
    if (!(isDownloadControl(target) || (ctrl && isDownloadControl(ctrl)))) return;

    var remark = readRemarkByHeader(ctrl || target);
    var name = cleanName(remark);
    if (!name) return;

    pending = { name: name, at: Date.now() };

    // 10s 内若 main-world 没拦到 URL，超时后仍发一次（后台可无 URL 时兜底）
    setTimeout(function () {
      if (pending.name === name && !lastUrl) sendToBg('');
      pending.name = '';
    }, 10000);

    // 30s 清 pending
    setTimeout(function () { pending.name = ''; }, 30000);
  }, true);
})();
