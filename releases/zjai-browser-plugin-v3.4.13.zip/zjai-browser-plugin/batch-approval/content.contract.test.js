const assert = require('assert');
const fs = require('fs');
const path = require('path');

const modulePath = path.join(__dirname, 'content.js');
const manifestPath = path.join(__dirname, '..', 'manifest.json');
const backgroundPath = path.join(__dirname, '..', 'background.js');
const requestHtmlPath = path.join(__dirname, '..', 'requirement', 'request.html');
const requestJsPath = path.join(__dirname, '..', 'requirement', 'request.js');

const api = require(modulePath);
const source = fs.readFileSync(modulePath, 'utf8');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const backgroundSource = fs.readFileSync(backgroundPath, 'utf8');
const requestHtmlSource = fs.readFileSync(requestHtmlPath, 'utf8');
const requestJsSource = fs.readFileSync(requestJsPath, 'utf8');

assert.strictEqual(api.matchApprovalType('交付序列周计划-浙江项目交付三部-黄米-2026年-8月-第1周'), '周计划');
assert.strictEqual(api.matchApprovalType('交付序列周计划-浙江客开二部-宋汉望-2026年-8月-第1周'), '周计划');
assert.strictEqual(api.matchApprovalType('交付序列周计划-浙江客开二部-陈培托-2026年-8月-第1周(由陈培托原发)'), '周计划');
assert.strictEqual(api.matchApprovalType('【浙江大区】SAP集成项目-2026-08-03项目周报'), '项目周报');
assert.strictEqual(api.matchApprovalType('【浙江军团】预算管理项目-2026年8月3日项目周报'), '项目周报');
assert.strictEqual(api.matchApprovalType('【江浙大区】SAP集成项目-2026-08-10项目周报'), '项目周报');
assert.strictEqual(api.matchApprovalType('【杭州】浙江省国际贸易集团有限公司-V8信创项目-2026-8-4项目周报'), '项目周报');
assert.strictEqual(api.matchApprovalType('【杭州区】财通证券股份有限公司-合同管理项目-2026-8-4项目周报'), '项目周报');
assert.strictEqual(api.matchApprovalType('【其他区域】预算管理项目-2026-08-03项目周报'), '');
assert.strictEqual(api.matchApprovalType('交付月度绩效考核-宋汉望-浙江客开二部-2026年度-8月度'), '绩效考核');
assert.strictEqual(api.matchApprovalType('交付月度绩效考核-宋汉望-浙江客开二部-2026年-8月'), '绩效考核');
assert.strictEqual(api.matchApprovalType('交付月度绩效考核-戴恩法-浙江客开二部-2026-7'), '绩效考核');
assert.strictEqual(api.matchApprovalType('(自动发起)交付月度绩效考核-宋汉望-浙江客开一部-2026-08'), '绩效考核');
assert.strictEqual(api.matchApprovalType('月度绩效考核-宋汉望-浙江客开二部-2026-8'), '');
assert.strictEqual(api.matchApprovalType('交付报价前置评估_浙江省机电产品质量检测所有限公司--集成项目'), '前置评估');
assert.strictEqual(api.matchApprovalType('交付报价前置评估变更_浙江省机电设计研究院有限公司--下属单位合同集成--26年预埋'), '前置评估');
assert.strictEqual(api.matchApprovalType('交付报价前置评估_'), '');
assert.strictEqual(api.matchApprovalType('【杭州区】交付作业申请：【乾元国家实验室-乾元国家实验室--OA项目】(￥200000.00)_PMP-KKZY-2026-5999_2026-08-11 09:16'), '客开作业单');
assert.strictEqual(api.matchApprovalType('【浙江区】交付作业申请：【客户A-客户B】(￥1.00)_PMP-KKZY-1_2026-08-11 09:16'), '客开作业单');
assert.strictEqual(api.matchApprovalType('【杭州区】交付作业申请：【乾元国家实验室】(￥200000.00)_PMP-KKZY-2026-5999_2026-08-11 09:16'), '');
assert.strictEqual(api.matchApprovalType('顾问工时登记-浙江大区-宋汉望-2026-07-30'), '工时单');
assert.strictEqual(api.matchApprovalType('顾问工时登记-浙江军团-宋汉望-2026-07-30'), '工时单');
assert.strictEqual(api.matchApprovalType('顾问工时登记-江浙大区-#张嘉荣-2026-08-10'), '工时单');
assert.strictEqual(api.matchApprovalType('顾问工时登记-浙江大区-#张嘉荣-2026-08-03(由#张嘉荣原发)'), '工时单');
assert.strictEqual(api.matchApprovalType('顾问工时登记 – 浙江大区 – #张嘉荣 – 2026-08-03(由#张嘉荣原发)'), '工时单');
assert.strictEqual(api.matchApprovalType('【补录】顾问工时登记-浙江军团-宋汉望-2026-01-26'), '工时单');
assert.strictEqual(api.matchApprovalType('【补录】顾问工时登记-江浙大区-#张嘉荣-2026-08-10'), '工时单');
assert.strictEqual(api.matchApprovalType('【补录】顾问工时登记-浙江军团-#张嘉荣-2026-01-26(由#张嘉荣原发)'), '工时单');
assert.strictEqual(api.matchApprovalType('运维顾问工时登记-江浙大区-张嘉荣-2026-08-10'), '工时单');
assert.strictEqual(api.matchApprovalType('【流程】运维顾问工时补录(张嘉荣 2026-08-13 09:30)'), '工时单');
assert.strictEqual(api.matchApprovalType('运维顾问工时登记-江浙大区-张嘉荣'), '');
assert.strictEqual(api.matchApprovalType('【流程】运维顾问工时补录()'), '');
assert.strictEqual(api.matchApprovalType('顾问工时登记-其他区域-宋汉望-2026-07-30'), '');
assert.ok(api.DEFAULT_PHRASES.includes('同意，按规定办理'), '应内置截图中的审批意见');
assert.ok(api.DEFAULT_PHRASES.includes('保留意见'), '应内置保留意见');

const filtered = api.filterApprovalItems([
  { affairId: '1', subject: '顾问工时登记-浙江大区-宋汉望-2026-07-30', receiveTime: '2026-07-30' },
  { affairId: '2', subject: '普通流程' },
  { affairId: '1', subject: '顾问工时登记-浙江大区-宋汉望-2026-07-30' },
  { affairId: '3', subject: '交付序列周计划-浙江客开二部-宋汉望-2026年-8月-第1周' },
  { affairId: '4', subject: '交付序列周计划-浙江客开二部-陈培托-2026年-8月-第1周(由陈培托原发)' },
  { affairId: '5', subject: '【浙江大区】SAP集成项目-2026-08-03项目周报' },
  { affairId: '6', subject: '交付月度绩效考核-宋汉望-浙江客开二部-2026年度-8月度' },
  { affairId: '7', subject: '顾问工时登记-浙江大区-#张嘉荣-2026-08-03(由#张嘉荣原发)' },
  { affairId: '8', subject: '交付报价前置评估_浙江省机电产品质量检测所有限公司--集成项目' },
  { affairId: '9', subject: '【杭州区】交付作业申请：【乾元国家实验室-乾元国家实验室--OA项目】(￥200000.00)_PMP-KKZY-2026-5999_2026-08-11 09:16' },
  { affairId: '10', subject: '运维顾问工时登记-江浙大区-张嘉荣-2026-08-10' },
  { affairId: '11', subject: '【流程】运维顾问工时补录(张嘉荣 2026-08-13 09:30)' },
  { affairId: '12', subject: '【杭州】浙江省国际贸易集团有限公司-V8信创项目-2026-8-4项目周报' },
  { affairId: '13', subject: '【杭州区】财通证券股份有限公司-合同管理项目-2026-8-4项目周报' }
]);
assert.deepStrictEqual(filtered.map((item) => item.affairId), ['1', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13']);
assert.match(api.buildDetailUrl('123'), /openFrom=listPending&affairId=123/);

assert.match(source, /id="ball"[\s\S]*aria-label="ZJAI"/, '应先显示圆形入口按钮');
assert.match(source, /id="open-batch"[\s\S]*批量处理/, '圆形入口菜单应包含“批量处理”');
assert.match(source, /id="open-work-hours"[\s\S]*工时签卡/, '圆形入口菜单应包含“工时签卡”');
assert.match(source, /openWorkHours\.addEventListener\('click', \(\) => \{\s*menu\.classList\.remove\('show'\);\s*document\.dispatchEvent\(new CustomEvent\('seeyon-helper:work-hours-open'\)\);/, '工时签卡入口应关闭菜单后通知既有工时模块打开弹窗');
assert.match(source, /id="open-request"[\s\S]*提需求/, '圆形入口菜单应包含“提需求”');
assert.match(source, /const REQUIREMENT_PAGE_URL = runtimeUrl\('requirement\/request\.html'\)/, '提需求入口应在上下文有效时缓存扩展页面 URL');
assert.match(source, /function openRequirementPage\(\)/, '提需求入口应使用普通链接打开需求页');
assert.match(source, /插件刚刚更新，请刷新 OA 页面后再点击提需求/, '扩展上下文失效时应提示刷新页面');
assert.doesNotMatch(source, /action: 'openRequirementPage'/, '提需求入口不应在点击时调用 chrome.runtime.sendMessage，避免扩展上下文失效报错');
assert.match(source, /#open-batch b\{display:block;font-size:13px;color:#dc2626\}/, '菜单项主文字应参考 project-check 使用红色强调');
assert.match(source, /function bindBallDrag\(/, '圆形入口应支持拖动');
assert.match(source, /seeyon-batch-approval-pos/, '圆形入口拖动位置应保存');
assert.match(source, /document\.addEventListener\('pointermove', move, true\)/, '圆形入口拖动应使用 document 级 pointermove，避免 OA 页面抢事件后拖不动');
assert.match(source, /#\$\{PANEL_ID\}\{position:fixed;right:72px;top:48px/, '弹框初始位置应在可视区内，并给列表留出更多高度');
assert.match(source, /待办批量处理/, '弹框标题应为待办批量处理');
assert.match(source, /function bindDrag\(/, '弹框应支持拖动');
assert.match(source, /table\{[^}]*table-layout:fixed/, '待办列表应使用固定表格布局，避免刷新后列宽变化');
assert.match(source, /\.list\{[^}]*max-height:520px/, '待办列表高度应支持最多约 20 条数据展示');
assert.match(source, /list\.style\.height = listHeight\(\);/, '待办列表高度应固定按 10 行显示');
assert.match(source, /function listHeight\(\)/, '应有列表高度计算函数');
assert.match(source, /th,td\{[^}]*padding:5px 8px/, '表格行距应适当收紧，提升单屏可见行数');
assert.match(source, /th,td\{[^}]*white-space:nowrap[^}]*text-overflow:ellipsis/, '表格单元格应单行省略，避免类型/时间/状态换行');
assert.match(source, /td\.subject\{max-width:none;word-break:normal\}/, '标题列不应按内容换行撑开布局');
assert.match(source, /<a class="detail-link" href="' \+ buildDetailUrl\(item\.affairId\) \+ '" target="_blank" rel="noopener noreferrer"/, '点击标题应以新页签打开待办详情');
assert.match(source, /\.detail-link\{[^}]*text-decoration:none/, '标题详情链接应保持列表样式');
assert.match(source, /function startSilentRunner\(/, '批量处理应通过隐藏 iframe 静默运行');
assert.match(source, /id = RUNNER_ID|frame\.id = RUNNER_ID/, '静默处理 iframe 应使用固定 RUNNER_ID');
assert.doesNotMatch(source, /window\.open\(/, '开始批量处理不应打开新网页');
assert.match(source, /const PAGE_SIZE_OPTIONS = \[5, 10, 20, 30\]/, '列表分页应支持每页 5/10/20/30 行');
assert.match(source, /const DEFAULT_PAGE_SIZE = 10/, '待办列表默认每页应为 10 条');
assert.match(source, /let pageSize = DEFAULT_PAGE_SIZE/, '首次打开默认每页条数应为 10');
assert.match(source, /const RUN_TIMEOUT_MS = 30000/, '静默批量处理应有超时出口，避免页面卡死后一直处理中');
assert.match(source, /const RUN_HANDOFF_DELAY_MS = 5000/, '多条批量处理应延迟接力下一条，避免打断上一条提交');
assert.match(source, /seeyon-batch-approval-page-size/, '每页行数设置应持久化保存');
assert.match(source, /id="page-size"/, '分页组件应包含每页行数下拉');
assert.match(source, /async function loadPageSize\(/, '打开插件时应读取用户保存的每页行数');
assert.match(source, /PAGE_SIZE_OPTIONS\.includes\(saved\) \? saved : DEFAULT_PAGE_SIZE/, '无有效保存配置时应回退到默认 10 条');
assert.match(source, /PAGE_SIZE_OPTIONS\.includes\(value\) \? value : DEFAULT_PAGE_SIZE/, '用户选择无效时应回退到默认 10 条');
assert.match(source, /return 10 \* 29 \+ 31 \+ 'px';/, '不管用户选择每页多少条，列表高度都应按 10 行显示');
assert.match(source, /let selectedIds = new Set\(\)/, '跨页选择状态应独立保存，不能只依赖当前页 DOM');
assert.match(source, /items = filterApprovalItems\(raw\);\s*selectedIds = new Set\(\);/, '首次加载或刷新待办后默认不应选中任何数据');
assert.match(source, /if \(!run \|\| !run\.active\) await chromeSet\(\{ \[STORAGE_RUN\]: null \}\);/, '刷新待办时应清理已结束批次状态，避免旧状态覆盖新列表');
assert.doesNotMatch(source, /class=\\"row-box\\"[^>]* checked/, '行复选框模板不应写死 checked');
assert.match(source, /function syncSelectedWithTypes\(\)|const syncSelectedWithTypes = \(\) =>/, '类型筛选变化应联动选择集合');
assert.doesNotMatch(source, /const syncSelectedWithTypes = \(\) => \{[\s\S]{0,260}selectedIds\.add/, '类型筛选不应把可见数据重新自动选中');
assert.match(source, /syncSelectedWithTypes\(\);\s*pageIndex = 0;\s*renderList\(\);/, '点击周计划/工时单筛选后应立即刷新列表和选择状态');
assert.match(source, /data-type="项目周报" checked>项目周报/, '类型筛选应包含项目周报');
assert.match(source, /data-type="绩效考核" checked>绩效考核/, '类型筛选应包含绩效考核');
assert.match(source, /data-type="前置评估" checked>前置评估/, '类型筛选应包含前置评估');
assert.match(source, /data-type="客开作业单" checked>客开作业单/, '类型筛选应包含客开作业单');
assert.doesNotMatch(source, /id="select-all"|id="select-none"|>全选<|>全不选</, '顶部不应再显示全选/全不选按钮');
assert.match(source, /id="all-box"/, '应保留表头复选框用于当前页选择');
assert.match(source, /上一页[\s\S]*下一页/, '分页控件应包含上一页和下一页');
assert.match(source, /function startSilentRunner\([\s\S]*iframe/, '静默处理应创建 iframe runner');
assert.match(source, /处理超时，仍在待办/, '静默处理超时后应把未完成数据标记为仍在待办');
assert.match(source, /function resumeProcessingItem\(/, '首页应负责接力启动队列中下一条处理中待办');
assert.match(source, /resumeProcessingItem\(run\);/, '同步队列状态时应检查并接力下一条');
assert.match(source, /startSilentRunner\(current\.affairId\)/, '接力时应重新指向当前处理中待办详情');
assert.match(source, /async function dismissRecoveryPrompt\(/, '静默打开待办时应自动处理恢复提示');
assert.match(source, /不恢复/, '有未保存数据提示应自动选择“不恢复”');
assert.match(source, /await dismissRecoveryPrompt\(\);[\s\S]*waitAndFillOpinion/, '应先关闭恢复提示，再填写审批意见');
assert.match(source, /function verifyQueueStatus\(/, '提交后应回查待办列表确认真实状态');
assert.match(source, /clicked \? '已提交'/, '点击提交成功后应直接显示已提交');
assert.match(source, /回查失败，请刷新待办/, '待办回查失败时应提示用户刷新确认');
assert.match(source, /仍在待办/, '回查后仍存在的待办应显示仍在待办');
assert.match(source, /已办结/, '回查后消失的待办才允许显示已办结');
assert.doesNotMatch(source, /已点击提交/, '不能把点击提交按钮误当成处理结果');
assert.doesNotMatch(source, /已提交，回查中/, '不应使用“回查中”展示状态');
assert.doesNotMatch(source, /已触发提交，待复核/, '不应继续使用“待复核”作为提交后的展示状态');
assert.match(source, /let detailAutoSubmitStarted = false/, '详情页自动提交应有单次执行锁，避免 DOMContentLoaded/load 重复触发');
assert.match(source, /if \(detailAutoSubmitStarted\) return;\s*detailAutoSubmitStarted = true;/, '自动提交前应先加锁');
assert.match(source, /\^\(确定\|继续提交\)\$/, '二次确认只应点击确认类按钮');
assert.doesNotMatch(source, /clickConfirmButtons[\s\S]{0,260}\|提交/, '二次确认不能再次点击普通提交按钮');
assert.match(source, /closePanel\(\)/, '关闭按钮应调用 closePanel');
assert.match(source, /id="phrase-toggle"[\s\S]*常用语/, '常用语入口应在审批意见输入框右侧');
assert.match(source, /id="phrase-panel"/, '常用语应使用弹层展示');
assert.match(source, /\.phrase-panel\{[^}]*position:absolute/, '常用语弹层应浮在输入区上方，不占用列表空间');
assert.match(source, /\.phrase-panel\{[^}]*width:360px/, '常用语弹层宽度应紧凑');
assert.match(source, /\.phrase-list\{[^}]*max-height:88px/, '常用语列表高度应进一步收紧，避免弹层过高');
assert.match(source, /\.phrase-item\{[^}]*padding:2px 4px/, '常用语列表项应使用紧凑行距');
assert.match(source, /\.phrase-item\{[^}]*border:none/, '常用语列表项不应显示边框');
assert.match(source, /\.approval button:not\(\.phrase-item\),\.custom button/, '常用语列表项应排除通用按钮边框样式');
assert.match(source, /id="phrase-list"/, '常用语弹层应渲染常用语列表');
assert.match(source, /新增\/编辑/, '常用语弹层应提供新增编辑入口');
assert.match(source, /审批意见不能为空/, '审批意见不能为空时应阻止提交');
assert.match(source, /chrome\.storage\.local/, '自定义常用语应保存到 chrome.storage.local');
assert.match(source, /batchApprovalGetPending/, '内容脚本应通过独立 action 查询批量待办');
assert.doesNotMatch(source, /weeklyPlanAiSummarize/, '批量处理插件不应依赖 weekly-plan 功能');
assert.doesNotMatch(requestHtmlSource, /id="webhook"|id="secret"|Webhook|加签密钥/, '普通用户不应填写钉钉机器人配置');
assert.match(requestHtmlSource, /<textarea id="description" required/, '需求页应要求填写需求描述');
assert.match(requestHtmlSource, /<input id="name" required placeholder="自动读取当前登录人"/, '需求页姓名应默认读取当前登录人');
assert.match(requestHtmlSource, /<input id="contact" required placeholder="自动读取手机号/, '需求页联系方式应默认读取手机号');
assert.match(requestHtmlSource, /<input id="docUrl" type="url"/, '需求页应提供在线文档链接输入');
assert.match(requestHtmlSource, /提交到钉钉/, '需求页应直接提交到钉钉机器人');
assert.doesNotMatch(requestHtmlSource, /导出记录/, '需求页不应再提供本地记录导出');
assert.doesNotMatch(requestHtmlSource, /id="reset"/, '需求页不能用 reset 作为表单内控件 id，避免遮蔽 form.reset()');
assert.match(requestJsSource, /submitRequirementToDingTalk/, '需求页应通过后台 action 提交到钉钉');
assert.match(requestJsSource, /getRequirementCurrentUser/, '需求页打开时应请求后台读取当前登录人资料');
assert.doesNotMatch(requestJsSource, /debugRequirementPersonalInfoFrame|\[ZJAI\]\[personalInfoFrame\]\[request-page\]|console\.log\('html:'/, '需求页不应保留 personalInfoFrame 临时调试输出');
assert.match(requestJsSource, /result\.data\.name[\s\S]*nameInput\.value = result\.data\.name/, '读取到姓名后应自动填入姓名字段');
assert.match(requestJsSource, /result\.data\.contact[\s\S]*contact\.value = result\.data\.contact/, '读取到手机号后应自动填入联系方式字段');
assert.match(requestJsSource, /function setMsg\(text, autoClear\)/, '需求页应统一管理提示文案');
assert.match(requestJsSource, /setTimeout\(\(\) => \{ msg\.textContent = ''; \}, 5000\)/, '提交成功提示应 5 秒后自动消失');
assert.match(requestJsSource, /description\.value = '';\s*docUrl\.value = '';\s*setMsg\('已提交到钉钉机器人', true\);/, '提交成功后应只清空需求和在线文档，并保留姓名联系方式');
assert.doesNotMatch(requestJsSource, /form\.reset\(\);\s*setMsg\('已提交到钉钉机器人'/, '提交成功后不应 reset 整个表单，避免清空姓名联系方式');
assert.doesNotMatch(requestJsSource, /oapi\.dingtalk\.com|access_token|SEC|fetch\(|crypto\.subtle|seeyon-requirement-dingtalk/, '需求页脚本不应包含或处理钉钉机器人配置');
assert.doesNotMatch(requestJsSource, /seeyon-requirement-requests|records\.push|JSON\.stringify\(records, null, 2\)/, '需求内容不应再保存为本地记录或导出 JSON');
assert.doesNotMatch(requestHtmlSource + requestJsSource + JSON.stringify(manifest), /qyapi\.weixin\.qq\.com/, '需求页不应残留旧机器人域名配置');

const resources = manifest.web_accessible_resources.flatMap((item) => item.resources || []);
assert.ok(resources.includes('requirement/request.html'), 'manifest 应开放需求收集页面');
assert.ok(resources.includes('requirement/request.js'), 'manifest 应开放需求收集脚本');
assert.ok(manifest.host_permissions.includes('https://oapi.dingtalk.com/*'), 'manifest 应允许请求钉钉机器人 Webhook');
assert.ok(!manifest.permissions.includes('tabs'), '静默 iframe 读取 personalInfoFrame 后不应再申请 tabs 权限');

const batchScript = manifest.content_scripts.find((item) => item.js && item.js.includes('batch-approval/content.js'));
assert.ok(batchScript, 'manifest 应注入 batch-approval/content.js');
assert.strictEqual(batchScript.all_frames, true);
assert.match(backgroundSource, /case 'batchApprovalGetPending':/, 'background 应处理批量待办查询 action');
assert.doesNotMatch(backgroundSource, /case 'openRequirementPage':/, 'background 不应保留已废弃的提需求打开 action');
assert.ok(backgroundSource.includes("case 'submitRequirementToDingTalk':"), 'background 应处理需求提交到钉钉 action');
assert.ok(backgroundSource.includes("case 'getRequirementCurrentUser':"), 'background 应处理当前登录人资料读取 action');
assert.ok(backgroundSource.includes("case 'getCurrentUserProfile':"), 'background 应提供公共当前登录人资料 action，供其他插件复用');
assert.ok(backgroundSource.includes('chrome.tabs.query'), 'background 应从已打开 OA 标签页读取当前登录人');
assert.match(backgroundSource, /const runtimeOnMessage = globalThis\.chrome && chrome\.runtime && chrome\.runtime\.onMessage/, 'background 注册消息监听前应判断 chrome.runtime.onMessage 是否可用');
assert.match(backgroundSource, /runtimeOnMessage\.addListener/, 'background 应通过受保护的 runtimeOnMessage 注册消息监听');
assert.doesNotMatch(backgroundSource, /chrome\.runtime\.onMessage\.addListener/, 'background 不应裸调用 chrome.runtime.onMessage.addListener，避免启动时报错');
assert.match(backgroundSource, /function normalizeRequirementMobile\(value\)/, 'background 应规范化并校验手机号');
assert.match(backgroundSource, /\^1\[3-9\]\\d\{9\}\$/.source ? /\^1\[3-9\]\\d\{9\}\$/ : /1\[3-9\]/, 'background 应只接受 11 位中国手机号');
assert.doesNotMatch(backgroundSource, /REQUIREMENT_CURRENT_USER_CACHE_MS|requirementCurrentUserCache/, '当前登录人姓名手机号不应缓存，避免共享电脑切换账号后显示上一个人信息');
assert.match(backgroundSource, /userId: String\(userId \|\| ''\)/, 'background 应从 OA 当前用户对象返回 userId');
assert.match(backgroundSource, /async function getCurrentUserProfile\(sender\)/, 'background 应将当前登录人资料读取抽成公共函数');
assert.match(backgroundSource, /department:[\s\S]*email:[\s\S]*mobile:/, '公共当前登录人资料应包含部门、邮箱和手机号字段');
assert.match(backgroundSource, /readInputValueAfterLabel\(html, '电子邮件'\)/, 'background 应从 personalInfoFrame 的“电子邮件”字段解析邮箱');
assert.match(backgroundSource, /doc\.querySelector\('#email'\)/, 'OA 页面上下文应优先读取 personalInfoFrame 的 #email');
assert.match(backgroundSource, /getRequirementCurrentUser\(sender\) \{[\s\S]*getCurrentUserProfile\(sender\)/, '提需求当前用户读取应复用公共当前登录人资料函数');
assert.doesNotMatch(backgroundSource, /fetchRequirementMemberById|\/seeyon\/rest\/orgMember|\[requirement\]\[orgMember\]|member\.telNumber/, 'OA REST 需要 token，当前不应再走 orgMember REST 获取手机号');
assert.match(backgroundSource, /personalInfoFrame&path=\/personalAffair\.do\?method=personalInfo/, 'background 应使用 OA 可直接访问的 personalInfoFrame 页面作为兜底来源');
assert.match(backgroundSource, /readInputValueAfterLabel\(html, '手机号码'\)/, 'background 应从 personalInfoFrame 的“手机号码”字段解析手机号');
assert.match(backgroundSource, /readInputValueAfterLabel\(html, '姓名'\)/, 'background 应从 personalInfoFrame 的“姓名”字段解析姓名');
assert.match(backgroundSource, /async function PAGE_PERSONAL_INFO_FUNC\(\)/, 'background 应能在 OA 页面上下文读取 personalInfoFrame');
assert.match(backgroundSource, /doc\.querySelector\('#telNumber'\)/, 'OA 页面上下文应优先读取 personalInfoFrame 的 #telNumber');
assert.match(backgroundSource, /doc\.querySelector\('#content_div'\)/, 'personalInfoFrame 外层页签应读取 #content_div iframe 内的真实个人信息表单');
assert.match(backgroundSource, /document\.createElement\('iframe'\)/, 'background 应通过 OA 页面隐藏 iframe 静默加载 personalInfoFrame');
assert.match(backgroundSource, /ownedFrame\.style\.cssText = 'position:absolute;width:1px;height:1px;left:-9999px/, '隐藏 iframe 不应被用户看到');
assert.match(backgroundSource, /ownedFrame\.parentNode\.removeChild\(ownedFrame\)/, '读取完成后应移除隐藏 iframe');
assert.match(backgroundSource, /tabProfile = await getPersonalInfoFrameFromTab\(tab\.id\)/, '读取当前用户时应在已打开 OA 标签页中静默补充 personalInfoFrame 手机号');
assert.match(backgroundSource, /if \(!combined\.name \|\| !combined\.contact \|\| !combined\.email\) \{[\s\S]*fetchCurrentUserProfileFromPersonalInfo\(\)/, '只有姓名、手机号或邮箱缺失时才执行旧 personalInfo fallback');
assert.doesNotMatch(backgroundSource, /chrome\.tabs\.create|chrome\.tabs\.remove|readPersonalInfoFromNewTab/, 'background 不应再以可见新页签方式打开 personalInfoFrame');
assert.doesNotMatch(backgroundSource, /debugRequirementPersonalInfoFrame|\[ZJAI\]\[personalInfoFrame\]|console\.groupCollapsed|console\.log\('html:'|html: html/, 'background 不应保留 personalInfoFrame 临时调试输出');
assert.doesNotMatch(backgroundSource, /loginAccount\)\)/, 'background 不应把 loginAccount 或人员 ID 当联系方式预填');
assert.ok(backgroundSource.includes('fetchCurrentUserProfileFromPersonalInfo'), 'background 应通过 personalInfo 兜底读取当前用户资料');
assert.ok(backgroundSource.includes('REQUIREMENT_DINGTALK_WEBHOOK'), 'background 应集中持有钉钉机器人 Webhook 配置');
assert.ok(backgroundSource.includes('REQUIREMENT_DINGTALK_SECRET'), 'background 应集中持有钉钉机器人加签密钥配置');
assert.ok(backgroundSource.includes('crypto.subtle.importKey'), 'background 应使用 Web Crypto 计算钉钉签名');
assert.ok(backgroundSource.includes("msgtype: 'markdown'"), 'background 应发送钉钉 markdown 消息');
assert.ok(backgroundSource.includes('result.errcode !== 0'), 'background 应处理钉钉非 0 返回');
assert.match(backgroundSource, /getBatchApprovalPending/, 'background 应提供批量待办查询函数');
assert.match(backgroundSource, /'江浙大区'/, '后台工时部门别名应兼容江浙大区');
assert.match(backgroundSource, /subject: '工时登记'/, 'background 应使用工时登记关键字兜底查询工时待办');
assert.match(backgroundSource, /subject: '项目周报'/, 'background 应查询项目周报待办');
assert.match(backgroundSource, /subject: '交付月度绩效考核'/, 'background 应查询交付月度绩效考核待办');
assert.match(backgroundSource, /subject: '交付报价前置评估'/, 'background 应查询交付报价前置评估待办');
assert.match(backgroundSource, /subject: '交付作业申请'/, 'background 应查询交付作业申请待办');

console.log('batch approval contract checks passed');
