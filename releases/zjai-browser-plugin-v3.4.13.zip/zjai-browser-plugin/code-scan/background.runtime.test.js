const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'background.js'), 'utf8');

function createSandbox() {
    const sandbox = {
        console,
        setTimeout,
        clearTimeout,
        fetch: async () => ({ ok: true, json: async () => ({}), text: async () => '' }),
        chrome: {
            cookies: { getAll: async () => [] },
            runtime: { onMessage: { addListener: () => {} } },
            scripting: { executeScript: async () => [] },
            storage: {
                local: {
                    set: (_obj, cb) => { cb && cb(); },
                    get: (_keys, cb) => { cb({}); }
                }
            }
        }
    };
    vm.createContext(sandbox);
    vm.runInContext(source, sandbox);
    return sandbox;
}

async function sleep(ms) {
    await new Promise((resolve) => setTimeout(resolve, ms));
}

async function main() {
    const sandbox = createSandbox();
    sandbox.getCodeStudioCookies = async () => 'cookie=test';
    sandbox.codeScanGetCurrentUserName = async () => '宋汉望';
    const allowedAreas = new Set(['浙江军团', '浙江大区', '江浙大区']);
    let state = null;

    sandbox.codeScanSaveState = async (nextState) => {
        const snapshot = JSON.parse(JSON.stringify(nextState));
        if (snapshot?.progress?.phase === 'projects' && snapshot.progress.current === 4) {
            await sleep(80);
        }
        state = snapshot;
    };
    sandbox.codeScanLoadState = async () => state;

    sandbox.codeStudioPost = async (_url, bodyParams) => {
        if (String(_url).includes('/system/customizationInfo/list')) {
            return {
                code: 0,
                total: 200,
                rows: [
                    { area: '浙江军团', dogNum: `dog-zj-${bodyParams.pageNum}`, buildid: `build-zj-${bodyParams.pageNum}`, projectAlias: '浙江军团项目', creator: '张三' },
                    { area: '浙江大区', dogNum: `dog-zd-${bodyParams.pageNum}`, buildid: `build-zd-${bodyParams.pageNum}`, projectAlias: '浙江大区项目', creator: '李四' },
                    { area: '江浙大区', dogNum: `dog-jz-${bodyParams.pageNum}`, buildid: `build-jz-${bodyParams.pageNum}`, projectAlias: '江浙大区项目', creator: '王五' },
                    { area: '上海军团直客中心', dogNum: `dog-sh-${bodyParams.pageNum}`, buildid: `build-sh-${bodyParams.pageNum}`, projectAlias: '上海军团项目', creator: '赵六' }
                ]
            };
        }
        throw new Error('不应直接走到这里');
    };

    const projects = await sandbox.codeScanGetAllProjects('cookie=test');
    assert.deepEqual(
        [...new Set(Array.from(projects, (project) => project.area))].sort(),
        [...allowedAreas].sort(),
        '仅保留浙江军团、浙江大区和江浙大区项目'
    );
    assert.equal(
        projects.some((project) => project.area === '上海军团直客中心'),
        false,
        '上海军团项目不得进入扫描'
    );

    const never = new Promise(() => {});
    sandbox.codeScanGetSourceRows = async () => never;

    const executePromise = sandbox.codeScanExecute();
    await sleep(120);

    const currentState = await sandbox.codeScanLoadState();
    assert.equal(currentState.status, 'scanning', '扫描未结束时状态应保持 scanning');
    assert.equal(currentState.progress.phase, 'scanning', '进入项目扫描后不应再被旧的 projects 进度覆盖');
    assert.equal(currentState.progress.current, 1, '开始扫描首个项目时 current 应为 1');
    assert.equal(currentState.progress.total, 12, '目标项目总数应保留为过滤后的项目数量');
    assert.equal(currentState.progress.percent, 8, '首个项目开始扫描时 percent 应反映真实进度');

    executePromise.catch(() => {});
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
