(function () {
  const STORAGE_KEY = 'seeyon:custom-icon';
  const HISTORY_KEY = 'seeyon:custom-icon-history';
  const ICON_SIZE = 84;
  const MIN_CROP_SIZE = 36;
  const fileInput = document.getElementById('icon-file');
  const previewCanvas = document.getElementById('preview');
  const previewLabel = document.getElementById('preview-label');
  const cropEditor = document.getElementById('crop-editor');
  const editorZone = document.getElementById('editor-zone');
  const cropCanvas = document.getElementById('crop-canvas');
  const resetButton = document.getElementById('reset');
  const confirmButton = document.getElementById('confirm-crop');
  const cancelButton = document.getElementById('cancel-crop');
  const status = document.getElementById('status');
  const recentIcons = document.getElementById('recent-icons');
  const previewContext = previewCanvas.getContext('2d');
  const cropContext = cropCanvas.getContext('2d');
  let cropImage = null;
  let imageBounds = null;
  let crop = null;
  let pointerAction = null;

  function setStatus(message, kind) {
    status.textContent = message || '';
    status.className = kind || '';
  }

  function storageGet(key) {
    return new Promise((resolve) => chrome.storage.local.get(key, resolve));
  }

  function storageSet(value) {
    return new Promise((resolve) => chrome.storage.local.set({ [STORAGE_KEY]: value }, resolve));
  }

  function historyGet() {
    return storageGet(HISTORY_KEY).then((result) => Array.isArray(result && result[HISTORY_KEY]) ? result[HISTORY_KEY] : []);
  }

  function historySet(history) {
    return new Promise((resolve) => chrome.storage.local.set({ [HISTORY_KEY]: history.slice(0, 5) }, resolve));
  }

  function formatHistoryDate(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '自定义图标' : `${date.getMonth() + 1}/${date.getDate()} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  }

  function drawPreview(dataUrl, label) {
    const image = new Image();
    image.onload = () => {
      previewContext.clearRect(0, 0, ICON_SIZE, ICON_SIZE);
      previewContext.drawImage(image, 0, 0, ICON_SIZE, ICON_SIZE);
      previewLabel.textContent = label;
    };
    image.onerror = () => setStatus('图片读取失败，请换一张 PNG、JPG 或 WebP 图片。', 'error');
    image.src = dataUrl;
  }

  function loadCurrent() {
    storageGet(STORAGE_KEY).then((result) => {
      const value = result && result[STORAGE_KEY];
      drawPreview(SeeyonIcon.isCustomIconDataUrl(value) ? value : SeeyonIcon.runtimeUrl('icons/fab-84.png'), SeeyonIcon.isCustomIconDataUrl(value) ? '当前使用自定义图标' : '当前使用内置图标');
    });
  }

  function renderHistory() {
    historyGet().then((history) => {
      recentIcons.innerHTML = '';
      if (!history.length) {
        recentIcons.innerHTML = '<div class="recent-empty">保存过的图标会显示在这里</div>';
        return;
      }
      history.forEach((item, index) => {
        if (!item || !SeeyonIcon.isCustomIconDataUrl(item.dataUrl)) return;
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'history-item';
        button.title = '切换到此图标';
        button.innerHTML = `<img alt="最近使用的图标 ${index + 1}"><span>${formatHistoryDate(item.createdAt)}</span>`;
        button.querySelector('img').src = item.dataUrl;
        button.addEventListener('click', async () => {
          await storageSet(item.dataUrl);
          closeCropEditor();
          drawPreview(item.dataUrl, '当前使用自定义图标');
          setStatus('已切换到最近使用的图标。', 'success');
        });
        recentIcons.appendChild(button);
      });
    });
  }

  async function rememberIcon(dataUrl) {
    const history = await historyGet();
    await historySet([{ dataUrl, createdAt: Date.now() }, ...history.filter((item) => item && item.dataUrl !== dataUrl)]);
    renderHistory();
  }

  function clampCrop(next) {
    const maxSize = Math.min(imageBounds.width, imageBounds.height);
    const size = Math.max(MIN_CROP_SIZE, Math.min(maxSize, next.size));
    return {
      x: Math.max(imageBounds.x, Math.min(imageBounds.x + imageBounds.width - size, next.x)),
      y: Math.max(imageBounds.y, Math.min(imageBounds.y + imageBounds.height - size, next.y)),
      size
    };
  }

  function setImageBounds() {
    const scale = Math.min(cropCanvas.width / cropImage.naturalWidth, cropCanvas.height / cropImage.naturalHeight);
    const width = cropImage.naturalWidth * scale;
    const height = cropImage.naturalHeight * scale;
    imageBounds = { x: (cropCanvas.width - width) / 2, y: (cropCanvas.height - height) / 2, width, height, scale };
    const size = Math.min(width, height) * 0.72;
    crop = { x: imageBounds.x + (width - size) / 2, y: imageBounds.y + (height - size) / 2, size };
  }

  function renderCrop() {
    if (!cropImage || !imageBounds || !crop) return;
    cropContext.fillStyle = '#0f172a';
    cropContext.fillRect(0, 0, cropCanvas.width, cropCanvas.height);
    cropContext.drawImage(cropImage, imageBounds.x, imageBounds.y, imageBounds.width, imageBounds.height);
    cropContext.fillStyle = 'rgba(15,23,42,.56)';
    cropContext.fillRect(0, 0, cropCanvas.width, cropCanvas.height);
    cropContext.save();
    cropContext.beginPath();
    cropContext.arc(crop.x + crop.size / 2, crop.y + crop.size / 2, crop.size / 2, 0, Math.PI * 2);
    cropContext.clip();
    cropContext.drawImage(cropImage, imageBounds.x, imageBounds.y, imageBounds.width, imageBounds.height);
    cropContext.restore();
    cropContext.strokeStyle = '#38bdf8';
    cropContext.lineWidth = 2;
    cropContext.beginPath();
    cropContext.arc(crop.x + crop.size / 2, crop.y + crop.size / 2, crop.size / 2, 0, Math.PI * 2);
    cropContext.stroke();
    cropContext.fillStyle = '#fff';
    cropContext.strokeStyle = '#0ea5e9';
    cropContext.lineWidth = 1;
    cropContext.fillRect(crop.x + crop.size - 7, crop.y + crop.size - 7, 14, 14);
    cropContext.strokeRect(crop.x + crop.size - 7, crop.y + crop.size - 7, 14, 14);
  }

  function canvasPoint(event) {
    const rect = cropCanvas.getBoundingClientRect();
    return { x: (event.clientX - rect.left) * cropCanvas.width / rect.width, y: (event.clientY - rect.top) * cropCanvas.height / rect.height };
  }

  function isResizeHandle(point) {
    return Math.abs(point.x - (crop.x + crop.size)) <= 12 && Math.abs(point.y - (crop.y + crop.size)) <= 12;
  }

  function closeCropEditor() {
    cropEditor.hidden = true;
    editorZone.classList.remove('cropping');
    cropImage = null;
    imageBounds = null;
    crop = null;
    pointerAction = null;
    fileInput.value = '';
  }

  function openCropEditor(dataUrl) {
    const image = new Image();
    image.onload = () => {
      cropImage = image;
      setImageBounds();
      cropEditor.hidden = false;
      editorZone.classList.add('cropping');
      renderCrop();
      setStatus('拖动蓝色圆形裁剪框选取图标内容，完成后点击“确定”。');
    };
    image.onerror = () => setStatus('图片读取失败，请换一张 PNG、JPG 或 WebP 图片。', 'error');
    image.src = dataUrl;
  }

  async function confirmCrop() {
    if (!cropImage || !imageBounds || !crop) return;
    const sourceX = (crop.x - imageBounds.x) / imageBounds.scale;
    const sourceY = (crop.y - imageBounds.y) / imageBounds.scale;
    const sourceSize = crop.size / imageBounds.scale;
    previewContext.clearRect(0, 0, ICON_SIZE, ICON_SIZE);
    previewContext.save();
    previewContext.beginPath();
    previewContext.arc(ICON_SIZE / 2, ICON_SIZE / 2, ICON_SIZE / 2, 0, Math.PI * 2);
    previewContext.clip();
    previewContext.drawImage(cropImage, sourceX, sourceY, sourceSize, sourceSize, 0, 0, ICON_SIZE, ICON_SIZE);
    previewContext.restore();
    const dataUrl = previewCanvas.toDataURL('image/png');
    await storageSet(dataUrl);
    await rememberIcon(dataUrl);
    closeCropEditor();
    previewLabel.textContent = '当前使用自定义图标';
    setStatus('已保存图标。刷新 OA 页面后，所有圆形入口都会使用新图标。', 'success');
  }

  cropCanvas.addEventListener('pointerdown', (event) => {
    if (!crop) return;
    const point = canvasPoint(event);
    const insideCrop = Math.hypot(point.x - (crop.x + crop.size / 2), point.y - (crop.y + crop.size / 2)) <= crop.size / 2;
    if (!insideCrop && !isResizeHandle(point)) return;
    pointerAction = { type: isResizeHandle(point) ? 'resize' : 'move', pointerId: event.pointerId, start: point, crop: { ...crop } };
    cropCanvas.setPointerCapture(event.pointerId);
    event.preventDefault();
  });

  cropCanvas.addEventListener('pointermove', (event) => {
    const point = canvasPoint(event);
    if (!pointerAction || pointerAction.pointerId !== event.pointerId) {
      cropCanvas.style.cursor = crop && isResizeHandle(point) ? 'nwse-resize' : 'move';
      return;
    }
    const dx = point.x - pointerAction.start.x;
    const dy = point.y - pointerAction.start.y;
    if (pointerAction.type === 'move') crop = clampCrop({ x: pointerAction.crop.x + dx, y: pointerAction.crop.y + dy, size: pointerAction.crop.size });
    else crop = clampCrop({ x: pointerAction.crop.x, y: pointerAction.crop.y, size: pointerAction.crop.size + Math.max(dx, dy) });
    renderCrop();
    event.preventDefault();
  });

  const endPointerAction = (event) => {
    if (!pointerAction || pointerAction.pointerId !== event.pointerId) return;
    try { cropCanvas.releasePointerCapture(event.pointerId); } catch (_) {}
    pointerAction = null;
  };
  cropCanvas.addEventListener('pointerup', endPointerAction);
  cropCanvas.addEventListener('pointercancel', endPointerAction);

  fileInput.addEventListener('change', () => {
    const file = fileInput.files && fileInput.files[0];
    if (!file) return;
    if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 10 * 1024 * 1024) {
      fileInput.value = '';
      setStatus('只支持不超过 10MB 的 PNG、JPG 或 WebP 图片。', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => openCropEditor(reader.result);
    reader.onerror = () => setStatus('图片读取失败，请重试。', 'error');
    reader.readAsDataURL(file);
  });

  confirmButton.addEventListener('click', confirmCrop);
  cancelButton.addEventListener('click', () => { closeCropEditor(); setStatus('已取消本次裁剪，当前图标未改变。'); });
  resetButton.addEventListener('click', async () => { await storageSet(''); closeCropEditor(); loadCurrent(); setStatus('已恢复默认图标。', 'success'); });

  loadCurrent();
  renderHistory();
})();
