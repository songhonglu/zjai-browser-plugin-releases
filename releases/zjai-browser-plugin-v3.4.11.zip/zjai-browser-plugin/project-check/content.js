(function () {
  if (window.__project_check_injected) return;
  window.__project_check_injected = true;

  const LOG_PREFIX = '[kk-helper:project-check]';
  const FAB_ID = 'pc-check-fab';
  const MENU_ID = 'pc-check-menu';
  const PANEL_ID = 'pc-check-panel';
  const PANEL_POS_KEY = 'project-check:panel-pos';
  const PROJECT_CHECK_PAGE_TITLES = Object.freeze([
    '项目盘点底表',
    '区域项目档案'
  ]);
  const CHECK_RULES = Object.freeze({
    'inventory-info': '盘点验收时间、保底/争取、按期验收率、当前项目进度、下一步安排不允许为空',
    'project-plan': '项目主计划、主计划锁定不允许全部为空',
    'kk-base': '客开负责人、客开启动时间、客开进度、Ctp-Studio仓库地址不允许为空',
    'implement-detail': '至少存在一行“序号、任务目标”都有值的实施任务明细',
    'implement-business': '至少存在一行“序号、业务应用类型、业务模块、业务名称”都有值的实施业务应用明细',
    'kk-detail': '至少存在一行“序号、任务目标”都有值的客开任务分解明细',
    'kk-integration': '至少存在一行“序号、客开集成类型、客开集成系统、客开集成内容”都有值的客开集成复用明细',
    'phase-deliver': '至少存在一行“序号、文档阶段、阶段交付物”都有值的阶段交付物明细',
    'project-put': '至少存在一行“序号、顾问名称、顾问类型、项目角色”都有值的项目投放明细'
  });
  const FIELD_ID_MAP = Object.freeze({
    '是否延期': 'field0421_id',
    '是否提前进场': 'field0064_id',
    '项目状态': 'field0062_id',
    '项目阶段': 'field0050_id',
    '项目类型': 'field0046_id',
    '项目类别': 'field0046_id',
    '客户经理': 'field0049_id',
    '项目经理': 'field0048_id',
    '内部项目经理': 'field0180_id',
    '交付类型': 'field0063_id',
    '合同编号': 'field0041_id',
    '客户名称': 'field0042_id',
    '项目名称': 'field0045_id',
    '项目编号': 'field0044_id',
    '盘点验收时间': 'field0106_id',
    '保底/争取': 'field0427_id',
    '按期验收率': 'field0108_id',
    '按期验收概率': 'field0108_id',
    '暗器验收概率': 'field0108_id',
    '当前项目进度': 'field0097_id',
    '下一步安排': 'field0098_id',
    '项目主计划': 'field0499_id',
    '主计划锁定': 'field1598_id',
    '客开负责人': 'field0255_id',
    '客开启动时间': 'field0256_id',
    '客开进度': 'field0257_id',
    'Ctp-Studio仓库地址': 'field0325_id',
    'Ctp-Studio仓库地址址': 'field0325_id'
  });
  const DETAIL_FIELD_MAP = Object.freeze({
    implementTask: Object.freeze({ formsonPrefix: 'formson_72103_', fields: Object.freeze({ seq: 'field0363', goal: 'field0364', start: 'field0365' }) }),
    implementBusiness: Object.freeze({ formsonPrefix: 'formson_64139_', fields: Object.freeze({ seq: 'field0110', type: 'field0212', module: 'field0114', name: 'field0306' }) }),
    kkTask: Object.freeze({ formsonPrefix: 'formson_72138_', fields: Object.freeze({ seq: 'field0398', goal: 'field0400', start: 'field0401' }) }),
    kkIntegrationReuse: Object.freeze({ formsonPrefix: 'formson_64140_', fields: Object.freeze({ seq: 'field0111', type: 'field0210', system: 'field0119', content: 'field0120' }) }),
    phaseDeliver: Object.freeze({ formsonPrefix: 'formson_64851_', fields: Object.freeze({ seq: 'field0166', documentPhase: 'field0167', completionTime: 'field0169', deliverable: 'field0168' }) }),
    projectPut: Object.freeze({ formsonPrefix: 'formson_61125_', fields: Object.freeze({ seq: 'field0086', consultantName: 'field0087', consultantType: 'field0260', projectRole: 'field0312' }) })
  });
  const DETAIL_LABEL_MAP = Object.freeze({
    implementTask: Object.freeze({ seq: '序号', goal: '任务目标', start: '开始时间' }),
    implementBusiness: Object.freeze({ seq: '序号', type: '业务应用类型', module: '业务模块', name: '业务名称' }),
    kkTask: Object.freeze({ seq: '序号', goal: '任务目标', start: '开始时间' }),
    kkIntegrationReuse: Object.freeze({ seq: '序号', type: '客开集成类型', system: '客开集成系统', content: '客开集成内容' }),
    phaseDeliver: Object.freeze({ seq: '序号', documentPhase: '文档阶段', completionTime: '完成时间', deliverable: '阶段交付物' }),
    projectPut: Object.freeze({ seq: '序号', consultantName: '顾问名称', consultantType: '顾问类型', projectRole: '项目角色' })
  });
  const TAB_SELECTOR_MAP = Object.freeze({
    '实施任务': 'div#tab-clientId1894-0',
    '客开任务': 'div#tab-clientId1894-1',
    '阶段交付物': 'div#tab-clientId2089-0',
    '项目投放': 'div#tab-clientId2089-1',
    '项目投放明细': 'div#tab-clientId2089-1'
  });
  const DETAIL_TAB_MAP = Object.freeze({
    implementTask: '实施任务',
    implementBusiness: '实施任务',
    kkTask: '客开任务',
    kkIntegrationReuse: '客开任务',
    phaseDeliver: '阶段交付物',
    projectPut: '项目投放'
  });
  const MULTI_HEADER_DETAIL_KEYS = new Set(['implementTask', 'kkTask']);
  const PLACEHOLDER_TEXTS = Object.freeze([
    '项目当前进展描述',
    '项目下一步的策略及推动动作'
  ]);
  const FIELD_ANCHOR_ALIASES = {
    '是否提前进场': ['是否提前进场', '提前进场'],
    '项目类型': ['项目类型', '项目类别'],
    '项目类别': ['项目类型', '项目类别'],
    '客开负责人': ['客开负责人', '客开责任人'],
    '客开启动时间': ['客开启动时间'],
    '客开进度': ['客开进度'],
    'Ctp-Studio仓库地址': ['Ctp-Studio仓库地址', 'Ctp-Studio仓库地址址'],
    'Ctp-Studio仓库地址址': ['Ctp-Studio仓库地址', 'Ctp-Studio仓库地址址'],
    '盘点验收时间': ['盘点验收时间'],
    '当前项目进度': ['当前项目进度'],
    '下一步安排': ['下一步安排'],
    '项目主计划': ['项目主计划'],
    '主计划锁定': ['主计划锁定']
  };
  let checkRunning = false;
  let docsCache = null;
  let sectionCache = new Map();
  let sectionTablesCache = new Map();
  let sectionRootsCache = new Map();
  let sectionPrimaryTableCache = new Map();
  let tabNodeCache = new Map();
  let tabbedAreaCache = null;
  let deliveryAreaCache = null;
  let tableResolveCache = new Map();
  let navAutoCheckTimer = null;
  let navAutoCheckObservers = [];
  let navAutoCheckBound = false;
  let navAutoCheckBoundDocs = new WeakSet();
  let pendingAutoCheck = false;
  let lastRenderedSignature = '';
  let panelSignatureWatchTimer = null;

  const Log = {
    info: (...args) => console.log(LOG_PREFIX, ...args),
    warn: (...args) => console.warn(LOG_PREFIX, ...args),
    debug: (...args) => console.debug(LOG_PREFIX, ...args)
  };

  function normalizeText(text) {
    return String(text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function preserveText(text) {
    return String(text || '').replace(/\u00a0/g, ' ').replace(/\r\n?/g, '\n').trim();
  }

  function isInsidePlugin(node) {
    if (!node || !node.closest) return false;
    return !!node.closest(`#${FAB_ID}, #${PANEL_ID}`);
  }

  function isLikelyLabelText(text) {
    const value = normalizeText(text);
    return [
      '盘点验收时间', '当前项目进度', '下一步安排', '保底/争取', '按期验收率', '按期验收概率', '暗器验收概率', '跟进次数',
      '项目类别', '客开负责人', '客开启动时间', '客开进度', 'Ctp-Studio仓库地址',
      '项目主计划', '主计划锁定', '项目主计划确认时间', '阶段交付物', '项目投放'
    ].includes(value);
  }

  function isInvalidValueText(text) {
    const value = normalizeText(text);
    return [
      '',
      '项目盘点底表',
      '项目盘点信息',
      '项目交付内容',
      '交付物及成本',
      '项目计划',
      '区域盘点记录',
      '变更次数',
      ...PLACEHOLDER_TEXTS
    ].includes(value);
  }

  function titleMatches(text, expected) {
    const a = normalizeText(text).replace(/\.{3,}|…/g, '');
    const b = normalizeText(expected).replace(/\.{3,}|…/g, '');
    return a === b || a.startsWith(b) || b.startsWith(a);
  }

  function fieldLabelMatches(text, expected) {
    const a = normalizeFieldLabel(text);
    const b = normalizeFieldLabel(expected);
    return a === b;
  }

  function normalizeFieldLabel(text) {
    return normalizeText(text)
      .replace(/\.{3,}|…/g, '')
      .replace(/[：:]/g, '')
      .replace(/\*/g, '')
      .replace(/\s+/g, '');
  }

  function escapeRegExp(text) {
    return String(text || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function firstUrl(text) {
    const match = normalizeText(text).match(/https?:\/\/[^\s<>"']+/);
    return match ? match[0] : '';
  }

  function absoluteHttpUrl(url) {
    try {
      const value = String(url || '').trim();
      if (!value || value === '#' || /^javascript:/i.test(value)) return '';
      const absolute = new URL(value, window.location.href).href;
      return /^https?:\/\//i.test(absolute) ? absolute : '';
    } catch (_) {
      return '';
    }
  }

  function pickField(obj, names) {
    if (!obj || typeof obj !== 'object') return '';
    const lowerNames = names.map((name) => name.toLowerCase());
    for (const key of Object.keys(obj)) {
      if (!lowerNames.includes(key.toLowerCase())) continue;
      const value = obj[key];
      if (value != null && typeof value !== 'object' && typeof value !== 'function') return value;
    }
    return '';
  }

  function parseAttachmentName(text) {
    return normalizeText(text).replace(/^全部下载\s*/, '').replace(/\s*\([^)]*\)\s*$/, '').trim();
  }

  function findVueInstance(rootEl) {
    const start = rootEl && (rootEl.querySelector && rootEl.querySelector('.cap4-attach') || rootEl);
    let cur = start;
    for (let depth = 0; cur && depth < 12; depth++) {
      if (cur.__vue__) return cur.__vue__;
      if (cur.__vueParentComponent) return cur.__vueParentComponent;
      cur = cur.parentElement;
    }
    return null;
  }

  function vueDataObjects(inst) {
    if (!inst) return [];
    return [inst.$data, inst.data, inst.setupState, inst.proxy && inst.proxy.$data, inst.proxy, inst.$props, inst.props, inst.ctx]
      .filter((obj) => obj && typeof obj === 'object');
  }

  function findVueAttachments(rootEl) {
    const inst = findVueInstance(rootEl);
    const attachments = [];
    const seen = new WeakSet();
    const walk = (obj, depth) => {
      if (!obj || typeof obj !== 'object' || typeof obj.nodeType === 'number' || depth > 6 || seen.has(obj)) return;
      seen.add(obj);
      if (!Array.isArray(obj) && pickField(obj, ['fileId', 'fileid'])) {
        attachments.push(obj);
        return;
      }
      if (Array.isArray(obj)) obj.slice(0, 300).forEach((item) => walk(item, depth + 1));
      else Object.keys(obj).forEach((key) => { if (key[0] !== '_') walk(obj[key], depth + 1); });
    };
    vueDataObjects(inst).forEach((obj) => walk(obj, 0));
    return attachments;
  }

  function buildAttachmentDownloadUrl(att) {
    const fileId = pickField(att, ['fileId', 'fileid']);
    if (!fileId) return '';
    const params = new URLSearchParams();
    params.set('method', 'doDownload');
    const filename = pickField(att, ['filename', 'filenameStr', 'name']);
    const v = pickField(att, ['v', 'token']);
    const createDate = pickField(att, ['createDate', 'creationDate', 'createdate']);
    if (filename) params.set('filename', String(filename));
    if (v) params.set('v', String(v));
    params.set('fileId', String(fileId));
    if (createDate) params.set('createDate', String(createDate));
    return absoluteHttpUrl(`/seeyon/fileDownload.do?${params.toString()}`);
  }

  function readAttachmentLinks(node) {
    if (!node || !node.querySelector) return '';
    const rows = Array.from(node.querySelectorAll('.cap4-attach__att, .cap4-attach__aright span, .cap4-attach__aright'));
    const names = rows.map((el) => parseAttachmentName(el.textContent))
      .filter((name) => name && name !== '全部下载' && !/^全部下载\s*$/.test(name));
    const attachments = findVueAttachments(node);
    const links = uniqueJoin(attachments.map((att, index) => {
      const name = normalizeText(pickField(att, ['filename', 'filenameStr', 'name'])) || names[index] || '';
      const url = buildAttachmentDownloadUrl(att);
      return uniqueJoin([name, url]);
    }).filter(Boolean));
    return links || uniqueJoin(names);
  }

  function cleanFieldDisplayValue(label, value) {
    const shouldPreserveLayout = ['当前项目进度', '下一步安排'].includes(label);
    const cleanValue = (input) => shouldPreserveLayout ? preserveText(input) : normalizeText(input);
    const text = cleanValue(value);
    if (!text) return '';
    if (label === '主计划锁定') return text.replace(/^全部下载\s*/, '');
    const labels = [label, ...((FIELD_ANCHOR_ALIASES && FIELD_ANCHOR_ALIASES[label]) || [])];
    let cleaned = text;
    labels.filter(Boolean).forEach((name) => {
      cleaned = cleanValue(cleaned.replace(new RegExp(`^${escapeRegExp(name)}[：:\\s]*`), ''));
    });
    cleaned = cleanValue(cleaned.replace(/^预测维度[：:\s]*/, ''));
    if (labels.some((name) => normalizeText(cleaned) === normalizeText(name))) return '';
    if (PLACEHOLDER_TEXTS.includes(normalizeText(cleaned))) return '';
    if (['按期验收率', '按期验收概率', '暗器验收概率'].includes(label)) {
      const percent = cleaned.match(/\d+(?:\.\d+)?%/);
      return percent ? percent[0] : '';
    }
    if (label === '项目主计划') return firstUrl(cleaned) || cleaned;
    if (['Ctp-Studio仓库地址', 'Ctp-Studio仓库地址址'].includes(label)) return firstUrl(cleaned);
    return cleaned;
  }

  function isLikelyActionText(text) {
    const value = normalizeText(text);
    if (!value) return false;
    if (value === '变更次数') return true;
    if (value.length > 12) return false;
    return /查询|确认|发起|新增|删除|导入|导出|复制|锁定/.test(value);
  }

  function textFromNode(node) {
    return readBusinessValue(node);
  }

  function readValueCell(node) {
    return readBusinessValue(node);
  }

  function readValueCellMeta(node) {
    return readFieldNodeMeta(node);
  }

  function emptyMeta(source) {
    return { value: '', source: source || 'empty', control: '', text: '', scope: '', label: '' };
  }

  function uniqueJoin(values) {
    return values.filter(Boolean).filter((value, index, arr) => arr.indexOf(value) === index).join(' / ');
  }

  function readControlValue(node) {
    if (!node) return '';
    const values = [];
    const controls = [];
    if (node.matches && node.matches('input, textarea, select, [contenteditable="true"]')) controls.push(node);
    if (node.querySelectorAll) controls.push(...Array.from(node.querySelectorAll('input, textarea, select, [contenteditable="true"]')));
    controls.forEach((el) => {
      if (!el || !isVisible(el)) return;
      if (el.matches && el.matches('input[type="hidden"]')) return;
      if (el.matches && el.matches('input[type="radio"], input[type="checkbox"]') && !el.checked) return;
      let value = '';
      if (el.matches && el.matches('select')) {
        const selected = el.selectedOptions && el.selectedOptions.length ? Array.from(el.selectedOptions).map((opt) => normalizeText(opt.textContent || opt.value)).filter(Boolean) : [];
        value = selected.join(' / ') || normalizeText(el.value);
      } else {
        const propertyValue = preserveText('value' in el ? el.value : '');
        const attributeValue = preserveText(el.getAttribute ? el.getAttribute('value') : '');
        value = propertyValue || attributeValue || preserveText(el.textContent);
      }
      if (value && !values.includes(value)) values.push(value);
    });
    return values.join(' / ');
  }

  function hasEditableControls(node) {
    if (!node) return false;
    try {
      const controls = [];
      if (node.matches && node.matches('input, textarea, select, [contenteditable="true"]')) controls.push(node);
      if (node.querySelectorAll) controls.push(...Array.from(node.querySelectorAll('input, textarea, select, [contenteditable="true"]')));
      return controls.some((el) => {
        if (!el || !isVisible(el)) return false;
        if (el.matches && el.matches('input[type="hidden"]')) return false;
        return true;
      });
    } catch (_) {
      return false;
    }
  }

  function readVisibleValue(node) {
    if (!node) return '';
    if (!node.cloneNode) return preserveText(node.innerText || node.textContent);
    const clone = node.cloneNode(true);
    clone.querySelectorAll('script, style, button, svg, img, input, textarea, select, [role=\"button\"], [aria-hidden=\"true\"], .icon, [class*=\"icon\"], [class*=\"Icon\"], [class*=\"layui-icon\"]').forEach((el) => el.remove());
    return preserveText(clone.innerText || clone.textContent);
  }

  function readLinkText(node) {
    if (!node || !node.querySelectorAll) return '';
    const attachmentLinks = readAttachmentLinks(node);
    if (attachmentLinks) return attachmentLinks;
    const texts = Array.from(node.querySelectorAll('a'))
      .filter((el) => isVisible(el))
      .map((el) => uniqueJoin([
        normalizeText(el.innerText || el.textContent),
        absoluteHttpUrl(el.getAttribute('href'))
      ]))
      .filter(Boolean);
    return uniqueJoin(texts);
  }

  function readBusinessValue(node) {
    return readValueCellMeta(node).value;
  }

  function readDirectCellText(node) {
    if (!node) return '';
    const texts = [];
    for (const child of Array.from(node.childNodes || [])) {
      if (child.nodeType === 3) {
        const text = normalizeText(child.textContent);
        if (text) texts.push(text);
        continue;
      }
      if (child.nodeType !== 1) continue;
      const el = child;
      if (['TABLE', 'TBODY', 'TR', 'TD', 'TH', 'BUTTON', 'SVG', 'IMG'].includes(el.tagName)) continue;
      if (el.matches && el.matches('input, textarea, select, [contenteditable="true"], [role="button"], .icon, [class*="icon"], [class*="Icon"], [class*="layui-icon"]')) continue;
      if (el.querySelector && el.querySelector('table')) continue;
      const text = normalizeText(el.innerText || el.textContent);
      if (text) texts.push(text);
    }
    return texts.join(' / ');
  }

  function readDirectValueCellMeta(node) {
    return readFieldNodeMeta(node, { directOnly: true });
  }

  function readFieldNodeMeta(node, options) {
    if (!node) return emptyMeta();
    const directOnly = !!(options && options.directOnly);
    const editable = hasEditableControls(node);
    const controlValue = readControlValue(node);
    const textValue = normalizeText(directOnly ? readDirectCellText(node) : readVisibleValue(node));
    const linkValue = readLinkText(node);

    if (editable) {
      if (controlValue) return { value: controlValue, source: 'control', control: controlValue, text: '', scope: '', label: '' };
      return emptyMeta('editable-empty');
    }

    const readonlyValue = linkValue || textValue;
    if (readonlyValue && !isLikelyLabelText(readonlyValue) && !isInvalidValueText(readonlyValue) && !isLikelyActionText(readonlyValue)) {
      return { value: readonlyValue, source: linkValue ? 'readonly-link-text' : (directOnly ? 'direct-text' : 'text'), control: '', text: readonlyValue, scope: '', label: '' };
    }
    return emptyMeta();
  }

  function readFieldByIdMeta(label) {
    const id = FIELD_ID_MAP[label];
    if (!id) return withMetaContext(emptyMeta('id-unmapped'), { scope: 'id-map', label });
    for (const doc of allDocs()) {
      const node = doc.getElementById ? doc.getElementById(id) : null;
      if (!node || isInsidePlugin(node) || !isVisible(node)) continue;
      const candidates = uniqueNodes([
        node,
        node.closest && node.closest('.cap-field-content'),
        node.closest && node.closest('.field-content__view'),
        node.parentElement,
        node.closest && node.closest('td')
      ]);
      for (const candidate of candidates) {
        const meta = readFieldNodeMeta(candidate);
        if (meta.value) {
          return withMetaContext({ ...meta, source: `id:${id}/${meta.source}` }, { scope: `#${id}`, label });
        }
        if (hasEditableControls(candidate)) continue;
        const visibleText = uniqueJoin([readLinkText(candidate), readVisibleValue(candidate)]);
        if (visibleText && !isLikelyLabelText(visibleText) && !isInvalidValueText(visibleText) && !isLikelyActionText(visibleText)) {
          return withMetaContext({ value: visibleText, source: `id:${id}/id-visible-text`, control: '', text: visibleText }, { scope: `#${id}`, label });
        }
      }
      return withMetaContext(emptyMeta('id-empty'), { scope: `#${id}`, label });
    }
    return withMetaContext(emptyMeta('id-miss'), { scope: `#${id}`, label });
  }

  function withMetaContext(meta, extras) {
    const base = meta && typeof meta === 'object' ? meta : emptyMeta();
    return {
      value: base.value || '',
      source: base.source || 'empty',
      control: base.control || '',
      text: base.text || '',
      scope: (extras && extras.scope) || base.scope || '',
      label: (extras && extras.label) || base.label || ''
    };
  }

  function isVisible(node) {
    if (!node || !node.ownerDocument || !node.getBoundingClientRect) return true;
    try {
      const style = node.ownerDocument.defaultView.getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
      const rect = node.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    } catch (_) {
      return true;
    }
  }

  function allDocs() {
    if (docsCache) return docsCache;
    const docs = [];
    const seen = new Set();
    const docScore = (doc) => {
      try {
        const frame = doc.defaultView && doc.defaultView.frameElement;
        if (!frame) return Number.MAX_SAFE_INTEGER;
        if (!isVisible(frame)) return -1;
        const rect = frame.getBoundingClientRect();
        return rect.width * rect.height;
      } catch (_) {
        return 0;
      }
    };
    const push = (doc) => {
      if (!doc || seen.has(doc)) return;
      seen.add(doc);
      docs.push(doc);
      let frames = [];
      try {
        frames = Array.from(doc.querySelectorAll('iframe')).map((iframe) => {
          try { return iframe.contentDocument; } catch (_) { return null; }
        }).filter(Boolean);
      } catch (_) {}
      frames.forEach(push);
    };
    push(document);
    try {
      if (window.top && window.top.document) push(window.top.document);
    } catch (_) {}
    docs.sort((a, b) => docScore(b) - docScore(a));
    docsCache = docs;
    return docs;
  }

  function pageIdentityText(doc) {
    if (!doc) return '';
    const title = doc.title || '';
    const body = doc.body ? doc.body.innerText || doc.body.textContent : '';
    return normalizeText(`${title} ${body}`);
  }

  function isTargetDocument(doc) {
    const text = pageIdentityText(doc);
    return PROJECT_CHECK_PAGE_TITLES.some((title) => text.includes(title));
  }

  function isTargetPage() {
    return allDocs().some(isTargetDocument);
  }

  function isTopWindow() {
    try { return window.top === window; } catch (_) { return true; }
  }

  function isUiHostWindow() {
    return isTopWindow() || isTargetDocument(document);
  }

  function removeProjectCheckUiInDoc(doc) {
    const host = doc.getElementById(FAB_ID);
    const panel = doc.getElementById(PANEL_ID);
    if (host) host.remove();
    if (panel) panel.remove();
  }

  function removeProjectCheckUi() {
    allDocs().forEach(removeProjectCheckUiInDoc);
  }

  function resetReadCaches() {
    docsCache = null;
    sectionCache = new Map();
    sectionTablesCache = new Map();
    sectionRootsCache = new Map();
    sectionPrimaryTableCache = new Map();
    tabNodeCache = new Map();
    tabbedAreaCache = null;
    deliveryAreaCache = null;
    tableResolveCache = new Map();
  }

  function isProjectDataReady() {
    return !!projectDataSignature();
  }

  function projectDataSignature() {
    resetReadCaches();
    return ['项目编号', '合同编号', '客户经理', '项目经理']
      .map((label) => cleanFieldDisplayValue(label, readFieldByIdMeta(label).value))
      .filter(Boolean)
      .join('|');
  }

  function startPanelSignatureWatch() {
    if (panelSignatureWatchTimer) return;
    panelSignatureWatchTimer = setInterval(() => {
      if (!isUiHostWindow()) return;
      const panel = document.getElementById(PANEL_ID);
      if (!panel || panel.style.display === 'none') return;
      if (!isTargetPage() || checkRunning || navAutoCheckTimer || isProjectPageLoading()) return;
      const signature = projectDataSignature();
      if (!signature || !lastRenderedSignature || signature === lastRenderedSignature) return;
      Log.info('auto check signature changed', `before=${lastRenderedSignature}`, `current=${signature}`);
      scheduleAutoCheckAfterNavigation('signature-watch');
    }, 1000);
  }

  function isProjectPageLoading() {
    const loadingTexts = /加载中|保存中|处理中|请稍候|正在加载|正在保存/;
    const loadingSelectors = [
      '.el-loading-mask',
      '.ant-spin',
      '.ui-loading',
      '.cap-loading',
      '.cap4-loading',
      '.ui-message',
      '.el-message',
      '.ant-message'
    ];
    return allDocs().some((doc) => {
      const nodes = [];
      loadingSelectors.forEach((selector) => {
        try { nodes.push(...Array.from(doc.querySelectorAll(selector))); } catch (_) {}
      });
      return nodes.some((node) => {
        if (isInsidePlugin(node) || !isVisible(node)) return false;
        const text = normalizeText(node.innerText || node.textContent);
        return !text || loadingTexts.test(text);
      });
    });
  }

  function hasTopHost() {
    return allDocs().some((doc) => !!doc.getElementById(FAB_ID));
  }

  function findLabeledValueInRoots(label, roots) {
    const docs = Array.isArray(roots) ? roots.filter(Boolean) : [];
    for (const doc of docs) {
      const cells = Array.from(doc.querySelectorAll ? doc.querySelectorAll('td, th, div, span, label') : []);
      for (const cell of cells) {
        if (!isVisible(cell)) continue;
        if (isInsidePlugin(cell)) continue;
        if (!titleMatches(cell.textContent, label)) continue;
        const row = cell.closest('tr');
        if (row) {
          const rowCells = Array.from(row.children);
          const idx = rowCells.indexOf(cell);
          const nextCell = idx >= 0 ? rowCells[idx + 1] : null;
          if (nextCell && !isInsidePlugin(nextCell)) {
            const txt = textFromNode(nextCell);
            if (txt && !isLikelyLabelText(txt) && txt !== label) return txt;
          }
          continue;
        }
        const sib = cell.nextElementSibling;
        if (sib && !isInsidePlugin(sib)) {
          const txt = textFromNode(sib);
          if (txt && !isLikelyLabelText(txt) && txt !== label) return txt;
        }
      }
    }
    return '';
  }

  function findStrictRowValue(label, roots) {
    const docs = Array.isArray(roots) ? roots.filter(Boolean) : [];
    for (const doc of docs) {
      const cells = Array.from(doc.querySelectorAll ? doc.querySelectorAll('td, th') : []);
      for (const cell of cells) {
        if (!isVisible(cell)) continue;
        if (isInsidePlugin(cell)) continue;
        if (!titleMatches(cell.textContent, label)) continue;
        const row = cell.closest('tr');
        if (!row) continue;
        const rowCells = Array.from(row.children);
        const idx = rowCells.indexOf(cell);
        const nextCell = idx >= 0 ? rowCells[idx + 1] : null;
        if (!nextCell || isInsidePlugin(nextCell)) continue;
        const value = normalizeText(readValueCell(nextCell));
        if (value) return value;
      }
    }
    return '';
  }

  function findStrictRowMeta(label, roots) {
    return findRowMetaInRoots(label, roots);
  }

  function findRowValueMeta(rowCells, labelIndex) {
    if (!Array.isArray(rowCells) || labelIndex < 0) return emptyMeta('row-miss');
    for (let i = labelIndex + 1; i < rowCells.length; i++) {
      const valueCell = rowCells[i];
      if (!valueCell || isInsidePlugin(valueCell)) continue;
      const cellText = normalizeText(valueCell.textContent);
      if (i > labelIndex + 1 && (isLikelyLabelText(cellText) || isLikelyActionText(cellText))) break;
      const meta = readDirectValueCellMeta(valueCell);
      if (isLikelyActionText(meta.value)) continue;
      if (meta.value && !isLikelyLabelText(meta.value) && !isInvalidValueText(meta.value)) return meta;
    }
    return emptyMeta('row-empty');
  }

  function uniqueNodes(nodes) {
    return nodes.filter(Boolean).filter((node, index, arr) => arr.indexOf(node) === index);
  }

  function collectRootsBySectionTitles(sectionTitles) {
    const roots = [];
    for (const title of Array.isArray(sectionTitles) ? sectionTitles : []) {
      findSectionTables(title).forEach((table) => roots.push(table));
      getSectionRoots(title).forEach((root) => roots.push(root));
    }
    return uniqueNodes(roots);
  }

  function rowMatchesPeers(row, peerLabels) {
    const peers = Array.isArray(peerLabels) ? peerLabels.filter(Boolean) : [];
    if (!peers.length) return true;
    const rowText = normalizeText(row.innerText || row.textContent);
    return peers.every((peer) => rowText.includes(peer));
  }

  function findRowMetaInRoots(label, roots, options) {
    const docs = Array.isArray(roots) ? roots.filter(Boolean) : [];
    const peerLabels = options && options.peerLabels;
    const scope = options && options.scope;
    for (const root of docs) {
      const rows = Array.from(root.querySelectorAll ? root.querySelectorAll('tr') : []);
      for (const row of rows) {
        if (!isVisible(row) || isInsidePlugin(row)) continue;
        if (!rowMatchesPeers(row, peerLabels)) continue;
        const cells = Array.from(row.cells || row.children || []);
        for (let i = 0; i < cells.length; i++) {
          const cell = cells[i];
          if (!cell || !isVisible(cell) || isInsidePlugin(cell)) continue;
          if (!fieldLabelMatches(cell.textContent, label)) continue;
          const meta = findRowValueMeta(cells, i);
          if (meta.value) return withMetaContext(meta, { scope, label });
        }
      }
    }
    return withMetaContext(emptyMeta(peerLabels && peerLabels.length ? 'peer-row-miss' : 'row-miss'), { scope, label });
  }

  function findTopFormFieldMeta(label, peerLabels) {
    const scopedRoots = collectRootsBySectionTitles(['项目盘点信息', '区域盘点记录']);
    const scopedMeta = findRowMetaInRoots(label, scopedRoots, { peerLabels, scope: '项目盘点信息/区域盘点记录' });
    if (scopedMeta.value) return scopedMeta;
    return findRowMetaInRoots(label, allDocs(), { peerLabels, scope: 'allDocs' });
  }

  function readAdjacentValueMeta(rowCells, labelIndex) {
    if (!Array.isArray(rowCells) || labelIndex < 0) return emptyMeta('anchor-row-miss');
    const valueCell = rowCells[labelIndex + 1];
    if (!valueCell || isInsidePlugin(valueCell)) return emptyMeta('anchor-next-cell-miss');
    const meta = readDirectValueCellMeta(valueCell);
    if (!meta.value || isLikelyLabelText(meta.value) || isInvalidValueText(meta.value) || isLikelyActionText(meta.value)) {
      return emptyMeta('anchor-empty');
    }
    return meta;
  }

  function findExactAdjacentMeta(label, roots, options) {
    const docs = Array.isArray(roots) ? roots.filter(Boolean) : [];
    const scope = options && options.scope;
    const aliases = FIELD_ANCHOR_ALIASES[label] || [label];
    for (const root of docs) {
      const rows = Array.from(root.querySelectorAll ? root.querySelectorAll('tr') : []);
      for (const row of rows) {
        if (!isVisible(row) || isInsidePlugin(row)) continue;
        const cells = Array.from(row.cells || row.children || []);
        for (let i = 0; i < cells.length; i++) {
          const cell = cells[i];
          if (!cell || !isVisible(cell) || isInsidePlugin(cell)) continue;
          if (!aliases.some((alias) => fieldLabelMatches(cell.textContent, alias))) continue;
          return withMetaContext(readAdjacentValueMeta(cells, i), { scope, label });
        }
      }
    }
    return withMetaContext(emptyMeta('anchor-label-miss'), { scope, label });
  }

  function getAnchorRootsByKey(key) {
    switch (key) {
      case '盘点验收时间':
      case '当前项目进度':
      case '下一步安排':
        return collectRootsBySectionTitles(['区域盘点记录']);
      case '客开负责人':
      case '客开启动时间':
      case '客开进度':
      case 'Ctp-Studio仓库地址':
      case 'Ctp-Studio仓库地址址':
        return uniqueNodes([getExplicitKkBaseTable(), findFieldTableAfterTab('客开任务'), findDeliveryAreaRoot(), findSectionByTitle('客开任务')]);
      case '项目主计划':
      case '主计划锁定':
        return collectRootsBySectionTitles(['项目计划']);
      default:
        return [];
    }
  }

  function getExplicitFieldMeta(label) {
    if (FIELD_ID_MAP[label]) return readFieldByIdMeta(label);
    const roots = getAnchorRootsByKey(label);
    const scope = roots.length ? `anchor:${label}` : `anchor-missing:${label}`;
    return findExactAdjacentMeta(label, roots, { scope });
  }

  function findTablesByHeaders(headers, scopeEl) {
    const roots = scopeEl ? [scopeEl] : allDocs();
    const matches = [];
    for (const root of roots) {
      const tables = root.querySelectorAll ? Array.from(root.querySelectorAll('table')) : [];
      for (const table of tables) {
        if (isInsidePlugin(table) || !isVisible(table)) continue;
        const text = normalizeText(table.innerText || table.textContent);
        if (headers.every((header) => text.includes(header))) matches.push(table);
      }
    }
    return uniqueNodes(matches);
  }

  function detailFieldSelector(config, fieldClass) {
    return `[class*="${config.formsonPrefix}"][class~="${fieldClass}"]`;
  }

  function readDetailFieldValue(row, config, fieldClass) {
    const node = row && row.querySelector ? row.querySelector(detailFieldSelector(config, fieldClass)) : null;
    if (!node) return '';
    const direct = readFieldNodeMeta(node).value;
    if (direct) return direct;
    const cell = node.closest && node.closest('td');
    return cell ? readFieldNodeMeta(cell).value : '';
  }

  function expandedCells(row) {
    const cells = [];
    Array.from(row && row.cells || []).forEach((cell) => {
      const span = Math.max(1, Number(cell.colSpan) || 1);
      for (let i = 0; i < span; i++) cells.push(cell);
    });
    return cells;
  }

  function detailHeaderIndexes(table, labels, multiHeader) {
    const indexes = {};
    let headerEndIndex = -1;
    const rows = Array.from(table.rows || []);
    for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
      const row = rows[rowIndex];
      const cells = multiHeader ? expandedCells(row) : Array.from(row.cells || []);
      const texts = cells.map((cell) => normalizeText(cell.innerText || cell.textContent));
      labels.forEach((label) => {
        if (!label || indexes[label] != null) return;
        const index = texts.findIndex((text) => text === label || text.includes(label));
        if (index >= 0) {
          indexes[label] = index;
          headerEndIndex = Math.max(headerEndIndex, rowIndex);
        }
      });
      if (labels.every((label) => indexes[label] != null)) break;
    }
    if (multiHeader) {
      while (rows[headerEndIndex + 1] && isDetailHeaderLikeRow(rows[headerEndIndex + 1], labels)) headerEndIndex += 1;
    }
    return { indexes, headerEndIndex };
  }

  function readDetailCellByHeader(row, index, multiHeader) {
    const cells = multiHeader ? expandedCells(row) : Array.from(row && row.cells || []);
    const cell = index != null ? cells[index] : null;
    return cell ? readFieldNodeMeta(cell).value : '';
  }

  function cleanDetailValue(value, label) {
    const text = normalizeText(value);
    if (!label || !text) return text;
    const normalizedValue = normalizeFieldLabel(text);
    const normalizedLabel = normalizeFieldLabel(label);
    if (!normalizedLabel) return text;
    if (normalizedValue === normalizedLabel) return '';
    const stripped = normalizeText(text.replace(new RegExp(`^${escapeRegExp(label)}[：:\\s\\-_]*`), ''));
    if (stripped && stripped !== text) return stripped;
    if (/[-_]/.test(text) && normalizedValue.endsWith(normalizedLabel)) return '';
    return text;
  }

  function isDetailHeaderLikeRow(row, labels) {
    const headerWords = new Set([...(labels || []), '开始', '确认']);
    const texts = Array.from(row && row.cells || []).map((cell) => normalizeText(cell.innerText || cell.textContent)).filter(Boolean);
    return texts.length > 0 && texts.every((text) => headerWords.has(text));
  }

  function countDetailRowsInTable(table, config, requiredFields) {
    return detailRowsStatsInTable(table, config, requiredFields).validRows;
  }

  function detailRowsStatsInTable(table, config, requiredFields, labels, multiHeader) {
    if (!table || !config) return { valueRows: 0, validRows: 0 };
    const headerLabels = labels || [];
    const headerInfo = headerLabels.length ? detailHeaderIndexes(table, headerLabels, !!multiHeader) : { indexes: {}, headerEndIndex: -1 };
    const indexes = headerInfo.indexes;
    let valueRows = 0;
    let validRows = 0;
    const rows = Array.from(table.rows || []);
    for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
      const row = rows[rowIndex];
      if (rowIndex <= headerInfo.headerEndIndex) continue;
      if (!isVisible(row) || isInsidePlugin(row)) continue;
      const text = normalizeText(row.innerText || row.textContent);
      if (!text || /合计|总计|其中/.test(text)) continue;
      if (multiHeader && headerLabels.length && isDetailHeaderLikeRow(row, headerLabels)) continue;
      const values = requiredFields.map((name, index) => {
        const label = headerLabels[index];
        const hasHeaderIndex = indexes[label] != null;
        const value = hasHeaderIndex ? readDetailCellByHeader(row, indexes[label], !!multiHeader) : readDetailFieldValue(row, config, config.fields[name]);
        return cleanDetailValue(value, label);
      });
      if (headerLabels.length && values.every((value, index) => !value || value === headerLabels[index])) continue;
      const businessValues = values.filter((_, index) => requiredFields[index] !== 'seq');
      if ((businessValues.length ? businessValues : values).some(Boolean)) valueRows += 1;
      if (values.every(Boolean)) validRows += 1;
    }
    return { valueRows, validRows };
  }

  function getDetailTableByKey(key) {
    const config = DETAIL_FIELD_MAP[key];
    if (!config) return null;
    const fieldClasses = Object.values(config.fields);
    const candidates = [];
    for (const doc of allDocs()) {
      const tables = doc.querySelectorAll ? Array.from(doc.querySelectorAll('table')) : [];
      for (const table of tables) {
        if (!isVisible(table) || isInsidePlugin(table)) continue;
        if (fieldClasses.every((fieldClass) => table.querySelector(detailFieldSelector(config, fieldClass)))) candidates.push(table);
      }
    }
    let best = null;
    let bestScore = -1;
    const requiredFields = Object.keys(config.fields);
    for (const table of uniqueNodes(candidates)) {
      const score = countDetailRowsInTable(table, config, requiredFields);
      const bestSize = best ? normalizeText(best.innerText || best.textContent).length : Infinity;
      const tableSize = normalizeText(table.innerText || table.textContent).length;
      if (score > bestScore || (score === bestScore && tableSize < bestSize)) {
        best = table;
        bestScore = score;
      }
    }
    if (best) return best;
    const labels = Object.values(DETAIL_LABEL_MAP[key] || {}).slice(0, 3);
    return labels.length ? findTableByHeaders(labels) : null;
  }

  function countDetailRowsByKey(key, requiredFields, table) {
    const config = DETAIL_FIELD_MAP[key];
    return countDetailRowsInTable(table || getDetailTableByKey(key), config, requiredFields);
  }

  function detailRowsStatsByKey(key, requiredFields, table) {
    const config = DETAIL_FIELD_MAP[key];
    const labels = requiredFields.map((name) => DETAIL_LABEL_MAP[key] && DETAIL_LABEL_MAP[key][name]).filter(Boolean);
    return detailRowsStatsInTable(table || getDetailTableByKey(key), config, requiredFields, labels, MULTI_HEADER_DETAIL_KEYS.has(key));
  }

  async function activateTabForRead(title) {
    const tab = findTabNode(title);
    if (!tab) return false;
    try { tab.click(); } catch (_) { return false; }
    resetReadCaches();
    await sleep(520);
    return true;
  }

  async function readDetailStateOnTab(key, requiredFields) {
    const read = async () => {
      const table = await waitForTable(() => getDetailTableByKey(key));
      return {
        table,
        stats: detailRowsStatsByKey(key, requiredFields, table)
      };
    };
    const tabTitle = DETAIL_TAB_MAP[key];
    const tab = tabTitle ? findTabNode(tabTitle) : null;
    if (!tabTitle || (tab && isTabActive(tab))) {
      const current = await read();
      if (current.table && (current.stats.valueRows > 0 || current.stats.validRows > 0)) return current;
    }
    if (tabTitle) await activateTabForRead(tabTitle);
    return read();
  }

  function getExplicitKkBaseTable() {
    const scopes = uniqueNodes([findDeliveryAreaRoot(), findSectionByTitle('客开任务'), findFieldTableAfterTab('客开任务')]);
    const candidates = [];
    scopes.forEach((scope) => {
      const tables = scope && scope.querySelectorAll ? Array.from(scope.querySelectorAll('table')) : [];
      tables.forEach((table) => {
        if (isInsidePlugin(table) || !isVisible(table)) return;
        const text = normalizeText(table.innerText || table.textContent);
        const hitCount = [
          /客开负责人|客开责任人/.test(text),
          text.includes('客开启动时间'),
          text.includes('客开进度'),
          /Ctp-Studio仓库地址/.test(text)
        ].filter(Boolean).length;
        if (hitCount >= 3) candidates.push(table);
      });
    });
    let best = null;
    let bestScore = -1;
    for (const table of uniqueNodes(candidates)) {
      const text = normalizeText(table.innerText || table.textContent);
      const score = [
        /客开负责人|客开责任人/.test(text),
        text.includes('客开启动时间'),
        text.includes('客开进度'),
        /Ctp-Studio仓库地址/.test(text)
      ].filter(Boolean).length;
      if (score > bestScore) {
        best = table;
        bestScore = score;
      }
    }
    return best;
  }

  function findDeliveryFieldValue(label) {
    return findDeliveryFieldMeta(label).value;
  }

  function findFieldTableAfterTab(title) {
    const tab = findTabNode(title);
    if (!tab) return null;
    let cur = tab.closest('div, table, section') || tab.parentElement;
    for (let depth = 0; cur && depth < 8; depth++, cur = cur.parentElement) {
      const tables = cur.querySelectorAll ? Array.from(cur.querySelectorAll('table')) : [];
      const ordered = tables.slice().sort((a, b) => Number(isVisible(b)) - Number(isVisible(a)));
      for (const table of ordered) {
        if (isInsidePlugin(table)) continue;
        const txt = normalizeText(table.innerText || table.textContent);
        if (txt.includes('客开负责人') || txt.includes('客开启动时间') || txt.includes('客开进度') || txt.includes('Ctp-Studio仓库地址')) {
          return table;
        }
      }
    }
    return null;
  }

  function findDeliveryFieldMeta(label) {
    const roots = [];
    const fieldTable = findFieldTableAfterTab('客开任务');
    if (fieldTable) roots.push(fieldTable);
    const area = findDeliveryAreaRoot();
    if (area && !roots.includes(area)) roots.push(area);
    const scopedMeta = findRowMetaInRoots(label, roots, { scope: '客开任务区域' });
    if (scopedMeta.value) return scopedMeta;
    const fallbackRoots = allDocs().filter((doc) => !roots.includes(doc));
    return findRowMetaInRoots(label, fallbackRoots, { scope: 'allDocs' });
  }

  function findSectionByTitle(title) {
    if (sectionCache.has(title)) return sectionCache.get(title);
    for (const doc of allDocs()) {
      const nodes = Array.from(doc.querySelectorAll('td, th, div, span, a'));
      for (const node of nodes) {
        if (isInsidePlugin(node)) continue;
        if (!titleMatches(node.textContent, title)) continue;
        let cur = node.closest('div, table, section') || node.parentElement;
        for (let depth = 0; cur && depth < 8; depth++, cur = cur.parentElement) {
          const text = normalizeText(cur.innerText || cur.textContent);
          if (text.includes(title)) {
            sectionCache.set(title, cur);
            return cur;
          }
        }
      }
    }
    sectionCache.set(title, null);
    return null;
  }

  function findSectionTables(title) {
    if (sectionTablesCache.has(title)) return sectionTablesCache.get(title);
    const primary = findSectionPrimaryTable(title);
    if (primary) {
      const only = [primary];
      sectionTablesCache.set(title, only);
      return only;
    }
    const tables = [];
    for (const doc of allDocs()) {
      const nodes = Array.from(doc.querySelectorAll('td, th, div, span, a'));
      for (const node of nodes) {
        if (isInsidePlugin(node)) continue;
        if (!titleMatches(node.textContent, title)) continue;
        let cur = node.parentElement;
        for (let depth = 0; cur && depth < 6; depth++, cur = cur.parentElement) {
          const found = cur.querySelectorAll ? Array.from(cur.querySelectorAll('table')) : [];
          if (found.length) {
            found.forEach((table) => {
              if (!isInsidePlugin(table) && !tables.includes(table)) tables.push(table);
            });
            if (tables.length) {
              sectionTablesCache.set(title, tables);
              return tables;
            }
          }
        }
      }
    }
    sectionTablesCache.set(title, tables);
    return tables;
  }

  function findSectionPrimaryTable(title) {
    if (sectionPrimaryTableCache.has(title)) return sectionPrimaryTableCache.get(title);
    for (const doc of allDocs()) {
      const nodes = Array.from(doc.querySelectorAll('td, th, div, span, a'));
      for (const node of nodes) {
        if (isInsidePlugin(node)) continue;
        if (!titleMatches(node.textContent, title)) continue;
        let cur = node.closest('tr, div, section, table') || node.parentElement;
        for (let depth = 0; cur && depth < 6; depth++, cur = cur.parentElement) {
          let sib = cur.nextElementSibling;
          while (sib) {
            if (isInsidePlugin(sib)) { sib = sib.nextElementSibling; continue; }
            if (sib.tagName === 'TABLE' && isVisible(sib)) {
              sectionPrimaryTableCache.set(title, sib);
              return sib;
            }
            const innerTable = sib.querySelector && sib.querySelector('table');
            if (innerTable && isVisible(innerTable)) {
              sectionPrimaryTableCache.set(title, innerTable);
              return innerTable;
            }
            const text = normalizeText(sib.innerText || sib.textContent);
            if (text && !titleMatches(text, title) && /项目盘点信息|区域盘点记录|项目计划|项目交付内容|交付物及成本|确权信息/.test(text)) break;
            sib = sib.nextElementSibling;
          }
        }
      }
    }
    sectionPrimaryTableCache.set(title, null);
    return null;
  }

  function getSectionRoots(title) {
    if (sectionRootsCache.has(title)) return sectionRootsCache.get(title);
    const section = findSectionByTitle(title);
    const roots = section ? [section] : allDocs();
    sectionRootsCache.set(title, roots);
    return roots;
  }

  function findSectionRowValue(sectionTitle, label) {
    const meta = findSectionRowMeta(sectionTitle, label);
    return meta.value;
  }

  function findSectionRowMeta(sectionTitle, label) {
    const tables = findSectionTables(sectionTitle);
    for (const table of tables) {
      const meta = findRowMetaInRoots(label, [table], { scope: `section:${sectionTitle}` });
      if (meta.value) return meta;
    }
    return withMetaContext(emptyMeta(), { scope: `section:${sectionTitle}`, label });
  }

  function getSectionFieldValue(sectionTitle, label) {
    return findSectionRowValue(sectionTitle, label);
  }

  function getSectionFieldMeta(sectionTitle, label) {
    const sectionMeta = findSectionRowMeta(sectionTitle, label);
    if (sectionMeta.value) return sectionMeta;
    return withMetaContext(findStrictRowMeta(label, getSectionRoots(sectionTitle)), { scope: `section-roots:${sectionTitle}`, label });
  }

  function findRowValueByPeerLabels(label, peerLabels) {
    return findTopFormFieldMeta(label, peerLabels);
  }

  function findTabbedAreaRoot() {
    if (tabbedAreaCache !== null) return tabbedAreaCache;
    const titles = ['阶段交付物', '项目投放', '项目周报', '项目人天', '外包记录', '项目核算', '项目成本'];
    for (const doc of allDocs()) {
      const text = normalizeText(doc.body ? doc.body.innerText || doc.body.textContent : '');
      if (!titles.every((title) => text.includes(title))) continue;
      const nodes = Array.from(doc.querySelectorAll('td, th, div, span, a'));
      for (const node of nodes) {
        if (isInsidePlugin(node)) continue;
        if (!titleMatches(node.textContent, '阶段交付物')) continue;
        let cur = node.closest('div, table, section') || node.parentElement;
        for (let depth = 0; cur && depth < 10; depth++, cur = cur.parentElement) {
          const areaText = normalizeText(cur.innerText || cur.textContent);
          if (titles.filter((title) => areaText.includes(title)).length >= 4) {
            tabbedAreaCache = cur;
            return cur;
          }
        }
      }
    }
    tabbedAreaCache = null;
    return null;
  }

  function findDeliveryAreaRoot() {
    if (deliveryAreaCache !== null) return deliveryAreaCache;
    const titles = ['实施任务', '客开任务'];
    for (const doc of allDocs()) {
      const text = normalizeText(doc.body ? doc.body.innerText || doc.body.textContent : '');
      if (!titles.every((title) => text.includes(title)) || !text.includes('项目交付内容')) continue;
      const nodes = Array.from(doc.querySelectorAll('td, th, div, span, a'));
      for (const node of nodes) {
        if (isInsidePlugin(node)) continue;
        if (!titleMatches(node.textContent, '项目交付内容')) continue;
        let cur = node.closest('div, table, section') || node.parentElement;
        for (let depth = 0; cur && depth < 10; depth++, cur = cur.parentElement) {
          const areaText = normalizeText(cur.innerText || cur.textContent);
          if (titles.filter((title) => areaText.includes(title)).length >= 2) {
            deliveryAreaCache = cur;
            return cur;
          }
        }
      }
    }
    deliveryAreaCache = null;
    return null;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function yieldToUi() {
    return new Promise((resolve) => setTimeout(resolve, 0));
  }

  function findTableByHeaders(headers, scopeEl) {
    const roots = scopeEl ? [scopeEl] : allDocs();
    const matches = [];
    for (const root of roots) {
      const tables = root.querySelectorAll ? Array.from(root.querySelectorAll('table')) : [];
      for (const table of tables) {
        if (isInsidePlugin(table)) continue;
        if (!isVisible(table)) continue;
        const headText = normalizeText(table.innerText || table.textContent);
        if (!headers.every((header) => headText.includes(header))) continue;
        matches.push({ table, score: headText.length });
      }
    }
    matches.sort((a, b) => a.score - b.score);
    return matches.length ? matches[0].table : null;
  }

  async function waitForTable(resolveFn, timeoutMs = 1600, intervalMs = 120) {
    const endAt = Date.now() + timeoutMs;
    while (Date.now() < endAt) {
      resetReadCaches();
      const table = resolveFn();
      if (table) return table;
      await sleep(intervalMs);
    }
    resetReadCaches();
    return resolveFn();
  }

  function cacheKey(prefix, title, headers) {
    return `${prefix}::${title || ''}::${(headers || []).join('|')}`;
  }

  function findTableInTabbedArea(headers) {
    const area = findTabbedAreaRoot();
    if (!area) return null;
    return findTableByHeaders(headers, area);
  }

  function findTableInDeliveryArea(headers) {
    const area = findDeliveryAreaRoot();
    if (!area) return null;
    return findTableByHeaders(headers, area);
  }

  function resolveDeliveryTable(tabTitle, headers) {
    const key = cacheKey('delivery', tabTitle, headers);
    if (tableResolveCache.has(key)) return tableResolveCache.get(key);
    const table = findTableNearTab(tabTitle, headers) ||
      findTableInDeliveryArea(headers) ||
      findTableByHeaders(headers, findSectionByTitle(tabTitle)) ||
      findTableByHeaders(headers, findDeliveryAreaRoot()) ||
      findTableByHeaders(headers);
    tableResolveCache.set(key, table || null);
    return table;
  }

  function resolveTabbedTable(tabTitle, headers) {
    const key = cacheKey('tabbed', tabTitle, headers);
    if (tableResolveCache.has(key)) return tableResolveCache.get(key);
    const table = findTableNearTab(tabTitle, headers) ||
      findTableByHeaders(headers, findTabbedAreaRoot()) ||
      findTableInTabbedArea(headers) ||
      findTableByHeaders(headers);
    tableResolveCache.set(key, table || null);
    return table;
  }

  function findTableNearTab(title, headers) {
    for (const doc of allDocs()) {
      const tabs = Array.from(doc.querySelectorAll('td, th, div, span, a'));
      for (const tab of tabs) {
        if (isInsidePlugin(tab)) continue;
        if (!titleMatches(tab.textContent, title)) continue;
        let cur = tab.closest('div, table, section') || tab.parentElement;
        for (let depth = 0; cur && depth < 8; depth++, cur = cur.parentElement) {
          const tables = cur.querySelectorAll ? Array.from(cur.querySelectorAll('table')) : [];
          const ordered = tables.slice().sort((a, b) => Number(isVisible(b)) - Number(isVisible(a)));
          for (const table of ordered) {
            if (isInsidePlugin(table)) continue;
            if (!isVisible(table)) continue;
            const txt = normalizeText(table.innerText || table.textContent);
            if (headers.every((header) => txt.includes(header))) return table;
          }
        }
      }
    }
    return null;
  }

  function findTabNode(title) {
    if (tabNodeCache.has(title)) return tabNodeCache.get(title);
    const selector = TAB_SELECTOR_MAP[title];
    if (selector) {
      for (const doc of allDocs()) {
        const tab = doc.querySelector(selector);
        if (tab && !isInsidePlugin(tab)) {
          tabNodeCache.set(title, tab);
          return tab;
        }
      }
    }
    for (const doc of allDocs()) {
      const tabs = Array.from(doc.querySelectorAll('td, th, div, span, a, button'));
      for (const tab of tabs) {
        if (isInsidePlugin(tab)) continue;
        if (!titleMatches(tab.textContent, title)) continue;
        if (tab.closest && tab.closest('[style*="display: none"]')) continue;
        tabNodeCache.set(title, tab);
        return tab;
      }
    }
    tabNodeCache.set(title, null);
    return null;
  }

  function isTabActive(node) {
    if (!node) return false;
    const text = normalizeText((node.className || '') + ' ' + (node.getAttribute && node.getAttribute('style') || ''));
    return /active|cur|selected|current|red|color:\s*red/.test(text) || /rgb\(255,\s*0,\s*0\)|#f00|#ff0000/i.test(text);
  }

  async function withTabActivated(title, fn) {
    const tab = findTabNode(title);
    if (!tab) return fn();

    const allTitles = ['阶段交付物', '项目投放', '项目周报', '项目人天', '外包记录', '项目核算', '项目成本', '实施任务', '客开任务'];
    let active = null;
    for (const name of allTitles) {
      const node = findTabNode(name);
      if (node && isTabActive(node)) {
        active = node;
        break;
      }
    }
    const targetWasActive = tab === active || isTabActive(tab);
    if (!targetWasActive) {
      try { tab.click(); } catch (_) {}
      resetReadCaches();
      await sleep(520);
    }
    try {
      return await fn();
    } finally {
      if (!targetWasActive && active) {
        try { active.click(); } catch (_) {}
        resetReadCaches();
        await sleep(180);
      }
    }
  }

  async function withTabGroup(titles, runner) {
    let active = null;
    let originalActive = null;
    for (const name of titles) {
      const node = findTabNode(name);
      if (node && isTabActive(node)) {
        active = node;
        originalActive = node;
        break;
      }
    }
    const activate = async (title) => {
      const tab = findTabNode(title);
      if (!tab) return false;
      if (tab === active || isTabActive(tab)) {
        active = tab;
        return true;
      }
      try { tab.click(); } catch (_) { return false; }
      resetReadCaches();
      await sleep(220);
      active = tab;
      return true;
    };
    try {
      return await runner(activate);
    } finally {
      if (originalActive && originalActive !== active) {
        try { originalActive.click(); } catch (_) {}
        await sleep(120);
      }
    }
  }

  function parseMoneyLikeNumber(text) {
    const cleaned = String(text || '').replace(/,/g, '').match(/-?\d+(?:\.\d+)?/);
    return cleaned ? Number(cleaned[0]) : 0;
  }

  function describeTable(table) {
    if (!table) return '(未定位到表格)';
    const rows = Array.from(table.rows || []);
    const header = rows.length ? normalizeText(rows[0].innerText || rows[0].textContent) : '';
    return `表头=${header || '(空)'}；总行数=${rows.length}`;
  }

  function activeTabTitle(titles) {
    for (const title of titles) {
      const node = findTabNode(title);
      if (node && isTabActive(node)) return title;
    }
    return '';
  }

  function createResult(key, title, ok, detail, raw) {
    return { key, title, ok, detail, rule: CHECK_RULES[key] || '', raw: normalizeText(raw || '') };
  }

  function createDetailCheckResult(key, title, stats, table, tabTitle, validText, partialText, emptyText, options) {
    const emptyAsWarn = !!(options && options.emptyAsWarn);
    const status = stats.validRows <= 0 ? (emptyAsWarn ? 'warn' : 'fail') : (stats.valueRows > stats.validRows ? 'warn' : 'ok');
    const detail = status === 'ok' ? validText : (status === 'warn' ? partialText : emptyText);
    const traceParts = [`当前页签=${tabTitle}`, describeTable(table), `有值行数=${stats.valueRows}`, `合规行数=${stats.validRows}`];
    return {
      ...createResult(
        key,
        title,
        status === 'ok',
        detail,
        buildTrace(traceParts)
      ),
      status
    };
  }

  function createTableResult(key, title, rows) {
    return { key, title, kind: 'table', rows };
  }

  function createRequiredFieldsResult(key, title, labels) {
    const entries = labels.map((label) => {
      const meta = readFieldByIdMeta(label);
      return { label, meta: { ...meta, value: cleanFieldDisplayValue(label, meta.value) } };
    });
    const missing = entries.filter((entry) => !entry.meta.value).map((entry) => entry.label);
    return {
      ...createResult(
      key,
      title,
      missing.length === 0,
      missing.length ? `不允许为空：${missing.join('、')}` : `已填写${entries.length}个字段`,
      buildTrace(entries.map((entry) => `${entry.label}: ${describeMeta(entry.meta)}`))
      ),
      kind: 'check-table',
      rows: entries.map((entry) => ({ label: entry.label, value: entry.meta.value }))
    };
  }

  function createAnyFieldResult(key, title, labels) {
    const entries = labels.map((label) => {
      const meta = readFieldByIdMeta(label);
      return { label, meta: { ...meta, value: cleanFieldDisplayValue(label, meta.value) } };
    });
    const filled = entries.filter((entry) => entry.meta.value);
    return {
      ...createResult(
      key,
      title,
      filled.length > 0,
      filled.length ? `已填写${filled.length}个字段` : `不允许全部为空：${labels.join('、')}`,
      buildTrace(entries.map((entry) => `${entry.label}: ${describeMeta(entry.meta)}`))
      ),
      kind: 'check-table',
      rows: entries.map((entry) => ({ label: entry.label, value: entry.meta.value }))
    };
  }

  function withLen(label, value) {
    const text = normalizeText(value || '');
    return `${label}=${text || '(空)'} (len=${text.length})`;
  }

  function buildTrace(parts) {
    return parts
      .map((part) => normalizeText(part))
      .filter((part) => part.length > 0)
      .join('；');
  }

  function describeMeta(meta) {
    return buildTrace([
      `label=${meta.label || '(未知)'}`,
      `scope=${meta.scope || '(未标记)'}`,
      `source=${meta.source || '(未知)'}`,
      withLen('value', meta.value || ''),
      meta.control ? withLen('control', meta.control) : '',
      meta.text ? withLen('text', meta.text) : ''
    ]);
  }

  function updatePanelSummary(panel, results, running) {
    panel.__pcResults = results.slice();
    const checks = results.filter((result) => result.kind !== 'table');
    const passCount = checks.filter((item) => item.ok).length;
    const warnCount = checks.filter((item) => item.status === 'warn').length;
    const failCount = checks.filter((item) => !item.ok && item.status !== 'warn').length;
    const dataCount = results.length - checks.length;
    const summary = panel.querySelector('#pc-summary');
    const jumpStyle = 'cursor:pointer;text-decoration:underline;text-underline-offset:2px;';
    const num = (count, color, target) => {
      const attrs = count > 0 ? `data-pc-summary-target="${target}" title="跳转查看"` : '';
      const style = count > 0 ? jumpStyle : '';
      return `<span ${attrs} style="color:${color};font-size:15px;font-weight:900;${style}">${count}</span>`;
    };
    const failNum = num(failCount, failCount > 0 ? '#dc2626' : '#2563eb', 'fail');
    const parts = [
      running ? `检查中：已完成${num(results.length, '#1d4ed8', 'any')}项` : '检查结果：',
      `通过${num(passCount, '#16a34a', 'ok')}项`,
      `不通过${failNum}项`
    ];
    if (warnCount) parts.push(`待完善${num(warnCount, '#d97706', 'warn')}项`);
    if (dataCount) parts.push(`数据表${num(dataCount, '#2563eb', 'table')}项`);
    summary.innerHTML = `${parts.join('，')}。`;
  }

  function appendPanelResult(panel, result) {
    const list = panel.querySelector('#pc-list');
    const wrap = document.createElement('div');
    wrap.innerHTML = renderItem(result);
    list.appendChild(wrap.firstElementChild);
  }

  function scrollToFirstSummaryTarget(panel, target) {
    const selector = target === 'any' ? '[data-pc-status]' : `[data-pc-status="${target}"]`;
    const node = panel.querySelector(selector);
    if (!node) return;
    node.scrollIntoView({ behavior: 'smooth', block: 'start' });
    node.style.boxShadow = '0 0 0 3px rgba(37,99,235,.28)';
    setTimeout(() => { node.style.boxShadow = ''; }, 1400);
  }

  function resultStatusText(result) {
    if (result.kind === 'table') return '数据';
    if (result.status === 'warn') return '待完善';
    return result.ok ? '通过' : '不通过';
  }

  function formatResultForCopy(result) {
    const lines = [`【${resultStatusText(result)}】${result.title}`];
    if (result.rule) lines.push(`校验规则：${result.rule}`);
    if (result.detail) lines.push(`结果：${result.detail}`);
    if (result.rows && result.rows.length) {
      result.rows.forEach((row) => lines.push(`${row.label}：${preserveText(row.value) || '(空)'}`));
    }
    if (result.raw && !['kk-base', 'inventory-info', 'project-plan'].includes(result.key)) lines.push(`读取值：${result.raw}`);
    return lines.join('\n');
  }

  async function copyPanelResults(panel) {
    const results = panel.__pcResults || [];
    const text = results.length ? results.map(formatResultForCopy).join('\n\n') : '暂无检查结果';
    await navigator.clipboard.writeText(text);
    const tip = panel.querySelector('#pc-copy-tip');
    if (tip) {
      tip.textContent = '复制成功';
      setTimeout(() => { tip.textContent = ''; }, 1800);
    }
  }

  function bindPanelDownload(panel) {
    if (panel.dataset.pcDownloadBound === '1') return;
    panel.dataset.pcDownloadBound = '1';
    panel.addEventListener('click', (event) => {
      const link = event.target && event.target.closest && event.target.closest('[data-pc-download-name]');
      if (!link) return;
      event.preventDefault();
      clickOriginalAttachmentDownload('field1598_id', link.getAttribute('data-pc-download-name'));
    });
  }

  function clickOriginalAttachmentDownload(fieldId, fileName) {
    const expectedName = parseAttachmentName(fileName);
    for (const doc of allDocs()) {
      const root = doc.getElementById && doc.getElementById(fieldId);
      if (!root || isInsidePlugin(root)) continue;
      const rows = Array.from(root.querySelectorAll('.cap4-attach__att, .cap4-attach'));
      for (const row of rows) {
        const rowName = parseAttachmentName(row.textContent);
        if (expectedName && rowName && rowName !== expectedName) continue;
        const icon = row.querySelector('.cap-icon-download, .cap4-attach__download, .icon.CAP.cap-icon-download');
        if (icon) { icon.click(); return true; }
      }
      const icons = root.querySelectorAll('.cap-icon-download, .cap4-attach__download, .icon.CAP.cap-icon-download');
      if (icons.length === 1) { icons[0].click(); return true; }
    }
    return false;
  }

  function openPanel() {
    const panel = ensurePanel();
    bindPanelDownload(panel);
    startPanelSignatureWatch();
    panel.querySelector('#pc-list').innerHTML = '';
    panel.style.display = 'flex';
    updatePanelSummary(panel, [], true);
    return panel;
  }

  async function runChecksStream() {
    if (checkRunning) {
      pendingAutoCheck = true;
      Log.info('auto check queued: check is running');
      return;
    }
    if (!isUiHostWindow()) return;
    if (!isTargetPage()) {
      removeProjectCheckUi();
      return;
    }
    checkRunning = true;
    resetReadCaches();
    const panel = openPanel();
    const results = [];
    const push = (result) => {
      results.push(result);
      appendPanelResult(panel, result);
      updatePanelSummary(panel, results, true);
    };
    const pushAndYield = async (result) => {
      push(result);
      await yieldToUi();
    };

    try {
      const projectInfoLabels = [
        '是否延期', '是否提前进场', '项目状态', '项目阶段', '项目类型', '客户经理',
        '项目经理', '内部项目经理', '交付类型', '合同编号', '客户名称', '项目名称', '项目编号'
      ];
      const projectInfoRows = projectInfoLabels.map((label) => ({
        label,
        value: cleanFieldDisplayValue(label, readFieldByIdMeta(label).value)
      }));
      await pushAndYield(createTableResult('project-info', '项目信息', projectInfoRows));

      await pushAndYield(createRequiredFieldsResult('inventory-info', '项目盘点信息', [
        '盘点验收时间', '保底/争取', '按期验收率', '当前项目进度', '下一步安排'
      ]));

      await pushAndYield(createAnyFieldResult('project-plan', '项目计划', ['项目主计划', '主计划锁定']));

      const projectCategory = readFieldByIdMeta('项目类型').value;
      const kkAmount = parseMoneyLikeNumber(getSectionFieldValue('项目信息', '客开金额'));
      const needKk = /实施客开|客开/.test(projectCategory) || kkAmount > 0 || !!findTabNode('客开任务');
      let kkState = null;
      let kkBaseResult = null;
      if (needKk) {
        const kkTask = await readDetailStateOnTab('kkTask', ['seq', 'goal']);
        const kkIntegration = await readDetailStateOnTab('kkIntegrationReuse', ['seq', 'type', 'system', 'content']);
        const leader = getExplicitFieldMeta('客开负责人');
        const start = getExplicitFieldMeta('客开启动时间');
        const progress = getExplicitFieldMeta('客开进度');
        const repo = (() => {
          const primary = getExplicitFieldMeta('Ctp-Studio仓库地址');
          return primary.value ? primary : getExplicitFieldMeta('Ctp-Studio仓库地址址');
        })();
        kkState = {
          leader: { ...leader, value: cleanFieldDisplayValue('客开负责人', leader.value) },
          start: { ...start, value: cleanFieldDisplayValue('客开启动时间', start.value) },
          progress: { ...progress, value: cleanFieldDisplayValue('客开进度', progress.value) },
          repo: { ...repo, value: cleanFieldDisplayValue('Ctp-Studio仓库地址', repo.value) },
          taskTable: kkTask.table,
          integrationTable: kkIntegration.table,
          taskStats: kkTask.stats,
          integrationStats: kkIntegration.stats
        };

        const kkBaseRows = [
          { label: '客开负责人', value: kkState.leader.value },
          { label: '客开启动时间', value: kkState.start.value },
          { label: '客开进度', value: kkState.progress.value },
          { label: 'Ctp-Studio仓库地址', value: kkState.repo.value }
        ];
        const missingKkBase = kkBaseRows.filter((row) => !row.value).map((row) => row.label);
        kkBaseResult = {
          ...createResult(
          'kk-base',
          '客开基础信息',
          missingKkBase.length === 0,
          missingKkBase.length ? `不允许为空：${missingKkBase.join('、')}` : `已填写${kkBaseRows.length}个字段`,
          buildTrace([
            `客开负责人: ${describeMeta(kkState.leader)}`,
            `客开启动时间: ${describeMeta(kkState.start)}`,
            `客开进度: ${describeMeta(kkState.progress)}`,
            `Ctp-Studio仓库地址: ${describeMeta(kkState.repo)}`
          ])
          ),
          kind: 'check-table',
          rows: kkBaseRows
        };
      }

      const needImplement = /实施客开|实施|运维/.test(projectCategory) || !!findTabNode('实施任务');
      if (needImplement) {
        const task = await readDetailStateOnTab('implementTask', ['seq', 'goal']);
        const business = await readDetailStateOnTab('implementBusiness', ['seq', 'type', 'module', 'name']);
        const implementState = {
          taskTable: task.table,
          businessTable: business.table,
          taskStats: task.stats,
          businessStats: business.stats
        };
        await pushAndYield(createDetailCheckResult('implement-detail', '实施任务分解', implementState.taskStats, implementState.taskTable, '实施任务', '实施任务分解存在合规明细行', '实施任务分解已有明细值，但必须至少存在一行“序号+任务目标”都有值的明细', '实施任务分解明细表不允许为空'));
        await pushAndYield(createDetailCheckResult('implement-business', '实施业务应用', implementState.businessStats, implementState.businessTable, '实施任务', '实施业务应用存在合规明细行', '实施业务应用未发现合规明细行', '实施业务应用未发现合规明细行', { emptyAsWarn: true }));
      }

      if (kkBaseResult) {
        await pushAndYield(kkBaseResult);
      }

      if (needKk && kkState) {
        await pushAndYield(createDetailCheckResult('kk-detail', '客开任务分解', kkState.taskStats, kkState.taskTable, '客开任务', '客开任务分解存在合规明细行', '客开任务分解已有明细值，但必须至少存在一行“序号+任务目标”都有值的明细', '客开任务分解明细表不允许为空'));
        await pushAndYield(createDetailCheckResult('kk-integration', '客开集成复用明细', kkState.integrationStats, kkState.integrationTable, '客开任务', '客开集成复用存在合规明细行', '客开集成复用未发现合规明细行', '客开集成复用未发现合规明细行', { emptyAsWarn: true }));
      }

      const phaseDeliver = await readDetailStateOnTab('phaseDeliver', ['seq', 'documentPhase', 'deliverable']);
      await pushAndYield(createDetailCheckResult('phase-deliver', '阶段交付物明细表', phaseDeliver.stats, phaseDeliver.table, '阶段交付物', '阶段交付物存在合规明细行', '阶段交付物已有明细值，但必须至少存在一行“序号+文档阶段+阶段交付物”都有值的明细', '阶段交付物明细表不允许为空'));

      const projectStaff = await readDetailStateOnTab('projectPut', ['seq', 'consultantName', 'consultantType', 'projectRole']);
      await pushAndYield(createDetailCheckResult('project-put', '项目投放明细', projectStaff.stats, projectStaff.table, '项目投放', '项目投放存在合规明细行', '项目投放已有明细值，但必须至少存在一行“序号+顾问名称+顾问类型+项目角色”都有值的明细', '项目投放明细表不允许为空'));

      updatePanelSummary(panel, results, false);
      lastRenderedSignature = projectDataSignature();
      return results;
    } catch (error) {
      const list = panel.querySelector('#pc-list');
      const wrap = document.createElement('div');
      wrap.innerHTML = renderItem(createResult('runtime-error', '检查执行异常', false, String((error && error.message) || error)));
      list.appendChild(wrap.firstElementChild);
      updatePanelSummary(panel, results, false);
      return results;
    } finally {
      checkRunning = false;
      if (pendingAutoCheck) {
        pendingAutoCheck = false;
        setTimeout(runChecksStream, 0);
      }
    }
  }

  function autoCheckTriggerType(target) {
    if (!target || !target.closest) return '';
    if (target.closest(`#${FAB_ID}, #${PANEL_ID}`)) return '';
    if (target.closest('.cap-icon-zuojiantou, .cap-icon-youjiantou, .cap-icon-save-and-modify-next')) return 'record-change';
    if (target.closest('.cap-icon-baocun')) return 'save';
    const clickable = target.closest('.cap4-headers__btn, button, a, span, div');
    if (!clickable || !clickable.querySelector) return '';
    if (clickable.querySelector('.cap-icon-zuojiantou, .cap-icon-youjiantou, .cap-icon-save-and-modify-next')) return 'record-change';
    if (clickable.querySelector('.cap-icon-baocun')) return 'save';
    const text = normalizeText(clickable.innerText || clickable.textContent);
    if (text === '保存并修改下一条') return 'record-change';
    if (text === '保存') return 'save';
    return '';
  }

  function scheduleAutoCheckAfterNavigation(triggerType) {
    if (!isUiHostWindow()) return;
    if (!isTargetPage()) return;
    if (navAutoCheckTimer) clearTimeout(navAutoCheckTimer);
    navAutoCheckObservers.forEach((observer) => observer.disconnect());
    navAutoCheckObservers = [];
    const beforeSignature = projectDataSignature();
    const needsRecordChange = triggerType === 'record-change';
    const startedAt = Date.now();
    let lastSignature = '';
    let stableSince = 0;
    let lastLogAt = 0;
    Log.info('auto check scheduled', `trigger=${triggerType}`, `before=${beforeSignature || '(empty)'}`);
    const waitAndRun = () => {
      navAutoCheckTimer = null;
      if (checkRunning) {
        Log.info('auto check waiting: check is running');
        navAutoCheckTimer = setTimeout(waitAndRun, 300);
        return;
      }
      const signature = projectDataSignature();
      const ready = !!signature;
      const changed = !needsRecordChange || !beforeSignature || (signature && signature !== beforeSignature);
      const loading = isProjectPageLoading();
      if (signature && signature === lastSignature) {
        stableSince = stableSince || Date.now();
      } else {
        lastSignature = signature;
        stableSince = 0;
      }
      const stable = stableSince && Date.now() - stableSince >= 200;
      if (Date.now() - lastLogAt > 1500) {
        lastLogAt = Date.now();
        Log.info('auto check waiting', `trigger=${triggerType}`, `ready=${ready}`, `changed=${!!changed}`, `loading=${loading}`, `stable=${!!stable}`, `signature=${signature || '(empty)'}`);
      }
      const timedOut = Date.now() - startedAt >= 30000;
      if (!(ready && changed && !loading && stable) && !timedOut) {
        navAutoCheckTimer = setTimeout(waitAndRun, 300);
        return;
      }
      Log.info('auto check rerun', `trigger=${triggerType}`, `ready=${ready}`, `changed=${!!changed}`, `loading=${loading}`, `stable=${!!stable}`, `elapsed=${Date.now() - startedAt}ms`);
      navAutoCheckObservers.forEach((observer) => observer.disconnect());
      navAutoCheckObservers = [];
      if (!isTargetPage()) {
        Log.info('auto check skipped: not target page');
        removeProjectCheckUi();
        return;
      }
      runChecksStream();
    };
    allDocs().forEach((doc) => {
      if (!doc.body || typeof MutationObserver === 'undefined') return;
      const observer = new MutationObserver(() => {
        docsCache = null;
        bindRecordNavigationAutoCheck();
        if (navAutoCheckTimer) clearTimeout(navAutoCheckTimer);
        navAutoCheckTimer = setTimeout(waitAndRun, 50);
      });
      observer.observe(doc.body, { childList: true, subtree: true, characterData: true, attributes: true });
      navAutoCheckObservers.push(observer);
    });
    navAutoCheckTimer = setTimeout(waitAndRun, 100);
  }

  function bindRecordNavigationAutoCheck() {
    navAutoCheckBound = true;
    const handler = (event) => {
      const triggerType = autoCheckTriggerType(event.target);
      if (triggerType) {
        Log.info('auto check trigger captured', `event=${event.type}`, `trigger=${triggerType}`);
        scheduleAutoCheckAfterNavigation(triggerType);
      }
    };
    allDocs().forEach((doc) => {
      if (!doc || navAutoCheckBoundDocs.has(doc)) return;
      navAutoCheckBoundDocs.add(doc);
      ['pointerup', 'mouseup', 'click'].forEach((eventName) => {
        doc.addEventListener(eventName, handler, true);
      });
    });
  }

  function ensureUi() {
    if (!document.body) return null;
    let host = document.getElementById(FAB_ID);
    if (host) return host;
    host = document.createElement('div');
    host.id = FAB_ID;
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        #ball{width:42px;height:42px;border-radius:50%;background:#fff;border:2px solid #fff;box-shadow:0 4px 14px rgba(56,189,248,.45);cursor:grab;display:flex;align-items:center;justify-content:center;overflow:hidden}
        #ball img{width:42px;height:42px;display:block;object-fit:cover}
        .menu{position:absolute;right:64px;top:0;min-width:220px;background:#fff;border-radius:10px;padding:6px;box-shadow:0 8px 30px rgba(0,0,0,.18);display:none;font-family:"Microsoft YaHei",sans-serif}
        .menu.show{display:block}
        .item{display:flex;align-items:center;gap:10px;width:100%;padding:10px 12px;border:none;background:transparent;cursor:pointer;border-radius:8px;font-size:13px;color:#1f2937;text-align:left}
        .item:hover{background:#eff6ff}
        .item .ico{font-size:16px}
        .item .main b{display:block;font-size:13px}
        .item .main span{display:block;font-size:11px;color:#6b7280}
      </style>
      <div class="menu" id="${MENU_ID}">
        <button class="item" id="check-item">
          <span class="ico">🧾</span>
          <span class="main"><b>台账检查</b><span>检查关键字段是否完整</span></span>
        </button>
      </div>
      <button id="ball" title="项目台账检查" aria-label="项目台账检查"><img id="logo" alt=""></button>
    `;
    document.documentElement.appendChild(host);
    bindRecordNavigationAutoCheck();
    const logo = shadow.getElementById('logo');
    try { SeeyonIcon.applyToImage(logo, 'icons/fab-84.png'); } catch (_) {}

    const menu = shadow.getElementById(MENU_ID);
    const ball = shadow.getElementById('ball');
    const item = shadow.getElementById('check-item');

    const SIZE = 42;
    const setPos = (left, top) => {
      left = Math.max(0, Math.min(window.innerWidth - SIZE, left));
      top = Math.max(0, Math.min(window.innerHeight - SIZE, top));
      host.style.left = left + 'px';
      host.style.top = top + 'px';
    };
    setPos(window.innerWidth - SIZE - 18, window.innerHeight / 2 + 120);
    window.addEventListener('resize', () => setPos(parseFloat(host.style.left) || 0, parseFloat(host.style.top) || 0));

    let pressing = false, moved = false, sx = 0, sy = 0, offX = 0, offY = 0;
    ball.addEventListener('pointerdown', (e) => {
      pressing = true; moved = false; sx = e.clientX; sy = e.clientY;
      const r = host.getBoundingClientRect();
      offX = e.clientX - r.left; offY = e.clientY - r.top;
      try { ball.setPointerCapture(e.pointerId); } catch (_) {}
    });
    ball.addEventListener('pointermove', (e) => {
      if (!pressing) return;
      if (!moved && Math.hypot(e.clientX - sx, e.clientY - sy) > 5) moved = true;
      if (moved) setPos(e.clientX - offX, e.clientY - offY);
    });
    const end = (e) => {
      if (!pressing) return;
      pressing = false;
      try { ball.releasePointerCapture(e.pointerId); } catch (_) {}
      if (!moved) menu.classList.toggle('show');
    };
    ball.addEventListener('pointerup', end);
    ball.addEventListener('pointercancel', end);

    document.addEventListener('pointerdown', (e) => {
      if (!menu.classList.contains('show')) return;
      const path = typeof e.composedPath === 'function' ? e.composedPath() : [];
      if (path.includes(host) || path.includes(shadow)) return;
      menu.classList.remove('show');
    });

    item.addEventListener('click', () => {
      menu.classList.remove('show');
      runChecksStream();
    });

    return host;
  }

  function bindPanelDrag(panel) {
    const header = panel.querySelector('#pc-panel-header');
    if (!header || panel.dataset.pcDragBound === '1') return;
    panel.dataset.pcDragBound = '1';
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const moveTo = (left, top) => {
      const maxLeft = Math.max(0, window.innerWidth - panel.offsetWidth);
      const maxTop = Math.max(0, window.innerHeight - panel.offsetHeight);
      panel.style.left = `${clamp(left, 0, maxLeft)}px`;
      panel.style.top = `${clamp(top, 0, maxTop)}px`;
      panel.style.right = 'auto';
    };
    const saved = (() => {
      try { return JSON.parse(localStorage.getItem(PANEL_POS_KEY) || 'null'); } catch (_) { return null; }
    })();
    if (saved && typeof saved.left === 'number' && typeof saved.top === 'number') moveTo(saved.left, saved.top);
    header.addEventListener('pointerdown', (event) => {
      if (event.target && event.target.closest && event.target.closest('button')) return;
      dragging = true;
      const rect = panel.getBoundingClientRect();
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      try { header.setPointerCapture(event.pointerId); } catch (_) {}
    });
    header.addEventListener('pointermove', (event) => {
      if (!dragging) return;
      moveTo(event.clientX - offsetX, event.clientY - offsetY);
    });
    const stop = (event) => {
      if (!dragging) return;
      dragging = false;
      try { header.releasePointerCapture(event.pointerId); } catch (_) {}
      try {
        const rect = panel.getBoundingClientRect();
        localStorage.setItem(PANEL_POS_KEY, JSON.stringify({ left: rect.left, top: rect.top }));
      } catch (_) {}
    };
    header.addEventListener('pointerup', stop);
    header.addEventListener('pointercancel', stop);
    window.addEventListener('resize', () => {
      const rect = panel.getBoundingClientRect();
      moveTo(rect.left, rect.top);
    });
  }

  function ensurePanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.style.cssText = [
      'position:fixed',
      'top:80px',
      'right:16px',
      'width:440px',
      'max-width:calc(100vw - 32px)',
      'max-height:80vh',
      'display:none',
      'flex-direction:column',
      'background:#fff',
      'border-radius:12px',
      'box-shadow:0 10px 40px rgba(0,0,0,.28)',
      'z-index:2147483647',
      'font:13px/1.55 system-ui,-apple-system,"Microsoft YaHei",sans-serif',
      'overflow:hidden'
    ].join(';');
    panel.innerHTML = `
      <div id="pc-panel-header" style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#1d4ed8;color:#fff;cursor:move;user-select:none">
        <b style="font-size:14px">项目台账检查</b>
        <button id="pc-close" style="cursor:pointer;border:none;background:rgba(255,255,255,.2);color:#fff;width:24px;height:24px;border-radius:6px;font-size:15px;line-height:1">×</button>
      </div>
      <div style="padding:12px 14px;overflow:auto">
        <div id="pc-summary" style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:10px 12px;color:#1d4ed8;font-weight:700"></div>
        <div id="pc-list" style="margin-top:12px"></div>
        <div style="display:flex;gap:8px;margin-top:14px">
          <button id="pc-rerun" style="cursor:pointer;border:none;border-radius:8px;padding:7px 14px;font-size:13px;background:#2563eb;color:#fff">重新检查</button>
          <button id="pc-copy" style="cursor:pointer;border:none;border-radius:8px;padding:7px 14px;font-size:13px;background:#0f766e;color:#fff">复制检查结果</button>
          <span id="pc-copy-tip" style="align-self:center;color:#16a34a;font-size:12px;font-weight:700"></span>
        </div>
      </div>
    `;
    document.documentElement.appendChild(panel);
    bindPanelDrag(panel);
    panel.querySelector('#pc-close').addEventListener('click', () => { panel.style.display = 'none'; });
    panel.querySelector('#pc-rerun').addEventListener('click', () => {
      runChecksStream();
    });
    panel.querySelector('#pc-summary').addEventListener('click', (event) => {
      const target = event.target && event.target.closest && event.target.closest('[data-pc-summary-target]');
      if (target) scrollToFirstSummaryTarget(panel, target.getAttribute('data-pc-summary-target'));
    });
    panel.querySelector('#pc-copy').addEventListener('click', () => {
      copyPanelResults(panel).catch((error) => {
        const tip = panel.querySelector('#pc-copy-tip');
        if (tip) tip.textContent = `复制失败：${(error && error.message) || error}`;
      });
    });
    return panel;
  }

  function renderItem(result) {
    if (result.kind === 'table' || result.kind === 'check-table') {
      const rows = result.rows.map((row) => `<tr>
        <td style="padding:6px 8px;border:1px solid #dbeafe;background:#f8fafc;width:38%;font-weight:600">${escapeHtml(row.label)}</td>
        <td style="padding:6px 8px;border:1px solid #dbeafe;word-break:break-all;overflow-wrap:anywhere;white-space:normal">${renderTableValue(row)}</td>
      </tr>`).join('');
      if (result.kind === 'check-table') {
        const showRaw = !['kk-base', 'inventory-info', 'project-plan'].includes(result.key);
        const okStyle = result.ok
          ? 'background:#f0fdf4;border:1px solid #bbf7d0;color:#166534'
          : 'background:#fef2f2;border:1px solid #fecaca;color:#991b1b';
        const icon = result.ok ? '✅' : '❌';
        return `<div data-pc-status="${result.ok ? 'ok' : 'fail'}" style="${okStyle};border-radius:10px;padding:10px 12px;margin-bottom:10px">
          <div style="font-weight:700">${icon} ${escapeHtml(result.title)}</div>
          <div style="margin-top:4px;font-size:12px;line-height:1.6;font-weight:600">校验规则：${escapeHtml(result.rule)}</div>
          <table style="width:100%;table-layout:fixed;border-collapse:collapse;margin-top:8px;font-size:12px;color:#334155;background:#fff">${rows}</table>
          <div style="margin-top:6px;font-size:12px;line-height:1.6">${escapeHtml(result.detail)}</div>
          ${showRaw && result.raw ? `<div style="margin-top:6px;font-size:11px;line-height:1.5;color:#64748b">读取值：${escapeHtml(result.raw)}</div>` : ''}
        </div>`;
      }
      return `<div data-pc-status="table" style="background:#fff;border:1px solid #bfdbfe;border-radius:10px;padding:10px 12px;margin-bottom:10px;color:#1e3a8a">
        <div style="font-weight:700;margin-bottom:8px">${escapeHtml(result.title)}</div>
        <table style="width:100%;table-layout:fixed;border-collapse:collapse;font-size:12px;color:#334155">${rows}</table>
      </div>`;
    }
    const status = result.status || (result.ok ? 'ok' : 'fail');
    const okStyle = status === 'ok'
      ? 'background:#f0fdf4;border:1px solid #bbf7d0;color:#166534'
      : (status === 'warn'
        ? 'background:#fffbeb;border:1px solid #fde68a;color:#92400e'
        : 'background:#fef2f2;border:1px solid #fecaca;color:#991b1b');
    const icon = status === 'ok' ? '✅' : (status === 'warn' ? '⚠️' : '❌');
    return `<div data-pc-status="${status}" style="${okStyle};border-radius:10px;padding:10px 12px;margin-bottom:10px">
      <div style="font-weight:700">${icon} ${result.title}</div>
      ${result.rule ? `<div style="margin-top:4px;font-size:12px;line-height:1.6;font-weight:600">校验规则：${result.rule}</div>` : ''}
      <div style="margin-top:4px;font-size:12px;line-height:1.6">${result.detail}</div>
      ${result.raw ? `<div style="margin-top:6px;font-size:11px;line-height:1.5;color:#64748b">读取值：${result.raw}</div>` : ''}
    </div>`;
  }

  function renderTableValue(row) {
    const value = preserveText(row && row.value);
    if (!value) return '(空)';
    if (!['项目主计划', '主计划锁定', 'Ctp-Studio仓库地址'].includes(row && row.label)) return `<span style="white-space:pre-wrap">${escapeHtml(value)}</span>`;
    if ((row && row.label) === '主计划锁定') return renderNamedLink(value);
    return linkifyHttpUrls(value);
  }

  function renderNamedLink(value) {
    const text = String(value || '');
    const url = firstUrl(text);
    const name = url ? normalizeText(text.slice(0, text.indexOf(url)).replace(/[\/\s]+$/g, '')) : normalizeText(text.replace(/^全部下载\s*/, ''));
    const label = name || '下载附件';
    return `<a href="#" data-pc-download-name="${escapeHtml(label)}" style="color:#2563eb;text-decoration:underline">${escapeHtml(label)}</a>`;
  }

  function linkifyHttpUrls(value) {
    return String(value || '').split(/(https?:\/\/[^\s<>"']+)/g).map((part) => {
      if (!/^https?:\/\//i.test(part)) return escapeHtml(part);
      const url = escapeHtml(part);
      return `<a href="${url}" target="_blank" rel="noopener noreferrer" style="color:#2563eb;text-decoration:underline;overflow-wrap:anywhere;word-break:break-all">${url}</a>`;
    }).join('');
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function bootstrap() {
    if (!document.body) return;
    if (!isUiHostWindow()) {
      removeProjectCheckUiInDoc(document);
      return;
    }
    bindRecordNavigationAutoCheck();
    if (!isTargetPage()) {
      removeProjectCheckUi();
      return;
    }
    if (hasTopHost()) return;
    ensureUi();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
  } else {
    bootstrap();
  }
  window.addEventListener('load', bootstrap, { once: true });
  setTimeout(bootstrap, 1200);
  setTimeout(bootstrap, 3000);
})();
