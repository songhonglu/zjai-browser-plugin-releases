const assert = require('assert');
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const modulePath = path.join(__dirname, 'content.js');
const manifestPath = path.join(__dirname, '..', 'manifest.json');
const templatePath = path.join(__dirname, 'assets', '项目交接会议纪要模板.docx');
const backgroundPath = path.join(__dirname, '..', 'background.js');

const api = require(modulePath);
const source = fs.readFileSync(modulePath, 'utf8');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const backgroundSource = fs.readFileSync(backgroundPath, 'utf8');

const parsed = api.parseHandoverTitle('(自动发起)【浙江大区】-{HTSP202607003568-紫软（苏州）信息科技有限公司}-18000.00项目移交');
assert.deepStrictEqual(parsed, {
  region: '浙江大区',
  contractNo: 'HTSP202607003568',
  company: '紫软（苏州）信息科技有限公司',
  amount: '18000.00',
  rawTitle: '(自动发起)【浙江大区】-{HTSP202607003568-紫软（苏州）信息科技有限公司}-18000.00项目移交'
});
assert.strictEqual(api.parseHandoverTitle('普通流程'), null);
assert.strictEqual(api.buildOutputFileName('紫软/苏州', new Date('2026-07-29T00:00:00+08:00')), '项目交接会议纪要-紫软_苏州-2026-07-29.docx');
assert.strictEqual(api.sanitizeFilePart('公司\u202Ecod.exe'), '公司cod.exe');
assert.strictEqual(api.sanitizeFilePart('A\u061c\u2060\u00adB'), 'AB');
assert.ok(Buffer.byteLength(api.buildOutputFileName('甲'.repeat(200), new Date('2026-07-29T00:00:00+08:00')), 'utf8') <= 240, '完整文件名应保留文件系统字节余量');
assert.strictEqual(api.templateLabelFor('合同编号'), '合同编号');
assert.strictEqual(api.templateLabelFor('客户名称'), '签约单位');

assert.match(source, /function collectPageFields\(/, '应采集页面字段');
assert.match(source, /function bindDrag\(/, '入口和弹框应支持拖动');
assert.match(source, /runtimeUrl\('icons\/fab-42\.png'\)/, '项目移交入口应统一使用插件图标');
assert.match(source, /chrome\.runtime\.getURL\(path\)/, '扩展环境应通过 chrome.runtime.getURL 读取插件图标');
assert.doesNotMatch(source, />移<\/button>/, '项目移交入口不应显示文字“移”');
assert.match(source, /clickedButton && clickedButton !== handle/, '入口图标作为按钮子元素时仍应允许拖动');
assert.match(source, /id="ph-reread"/, '弹框应包含重新读取按钮');
assert.match(source, /id="ph-generate"/, '弹框应包含写入会议纪要按钮');
assert.match(source, /word\/document\.xml/, '应修改 DOCX document.xml');
assert.match(source, /projectHandoverGetTemplate/, '真实扩展环境应通过后台读取模板，避免页面直接加载扩展 DOCX');
assert.match(source, /response\.data && response\.data\.base64/, '后台模板应使用可序列化 base64 返回');
assert.match(source, /模板读取超时/, '模板后台请求应有超时反馈，避免点击后无反应');
assert.match(source, /chrome\.runtime\.getURL\('project-handover\/assets\/项目交接会议纪要模板\.docx'\)/, '应读取内置模板');
assert.match(backgroundSource, /case 'projectHandoverGetTemplate':/, 'background 应处理项目移交模板读取消息');
assert.match(backgroundSource, /getProjectHandoverTemplate/, 'background 应提供项目移交模板读取函数');
assert.match(backgroundSource, /base64: btoa/, 'background 应返回 base64，避免 Chrome 消息传 ArrayBuffer 不稳定');

const handoverScript = manifest.content_scripts.find((item) => item.js && item.js.includes('project-handover/content.js'));
assert.ok(handoverScript, 'manifest 应注入项目移交 content script');
assert.deepStrictEqual(handoverScript.js, ['shared/icon.js', 'project-handover/lib/jszip.min.js', 'project-handover/content.js']);
assert.strictEqual(handoverScript.all_frames, true);

const templateResource = manifest.web_accessible_resources.some((item) => item.resources && item.resources.includes('project-handover/assets/项目交接会议纪要模板.docx'));
assert.ok(templateResource, '模板应配置为 web accessible resource');
assert.ok(fs.existsSync(templatePath), '源码目录应包含项目交接会议纪要模板');

const packagePath = path.join(__dirname, '..', '..', 'pak', `zjai-browser-plugin-v${manifest.version}.zip`);
if (fs.existsSync(packagePath)) {
  const packageHasTemplate = execFileSync('python3', ['-c', [
    'from zipfile import ZipFile',
    'import sys',
    'name="zjai-browser-plugin/project-handover/assets/项目交接会议纪要模板.docx"',
    'print(name in ZipFile(sys.argv[1]).namelist())'
  ].join(';'), packagePath], { encoding: 'utf8' }).trim();
  assert.strictEqual(packageHasTemplate, 'True', '当前版本 zip 包应包含项目交接会议纪要模板');
}

console.log('project handover contract checks passed');
