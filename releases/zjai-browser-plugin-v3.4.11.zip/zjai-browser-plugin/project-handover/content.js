(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else api.bootstrap();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const FAB_ID = 'project-handover-fab';
  const PANEL_ID = 'project-handover-panel';
  const FAB_POS_KEY = 'project-handover:fab-pos';
  const PANEL_POS_KEY = 'project-handover:panel-pos';
  const TEMPLATE_PATH = 'project-handover/assets/项目交接会议纪要模板.docx';
  const WORD_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  const FRAME_CHANNEL = 'project-handover-frame-sections';
  const OWNER_ID = (() => {
    try { return chrome && chrome.runtime && chrome.runtime.id ? chrome.runtime.id : 'project-handover-local'; } catch (_) { return 'project-handover-local'; }
  })();
  const SECTION_TITLES = Object.freeze(['项目基本信息', '客户干系人', '客户关键人', '项目组成员', '项目交接信息', '项目承接信息', '项目预计风险', '项目任务', '交接结论', '补充信息']);
  const SECTION_TABS = Object.freeze({
    '项目交接信息': Object.freeze(['项目交接信息', '项目付款阶段']),
    '项目承接信息': Object.freeze(['项目交接信息', '项目付款阶段']),
    '项目任务': Object.freeze(['实施任务目标', '客开任务目标'])
  });
  const LABEL_ALIASES = Object.freeze({
    '大区': '大区名称',
    '区域': '大区名称',
    '合同号': '合同编号',
    '交接时间': '会议时间',
    '销售经理': '销售人员',
    '客户名称': '签约单位',
    '签约客户': '签约单位',
    '合同客户': '签约单位',
    '客户单位': '签约单位',
    '最终客户': '实际用户',
    '最终用户': '实际用户',
    '项目客户': '实际用户',
    '是否招标': '是否招标项目',
    '是否有合同': '是否签订合同',
    '是否提前入场': '是否提前进场',
    '签约时间': '合同签订时间',
    '合同时间': '合同签订时间',
    '产品': '交付产品',
    '插件': '交付插件',
    '实施人天': '实施合同人天',
    '客开人天': '客开合同人天',
    '客户环境': '客户IT环境',
    '项目实施范围': '实施范围',
    '项目范围': '实施范围',
    '合同交付内容': '交付内容',
    '客户关键需求': '最核心需求',
    '核心需求': '最核心需求',
    '开发内容': '需要开发内容',
    '项目预计风险': '风险和其他说明',
    '特殊条款': '特殊的条款',
    '非合同内承诺': '客户要求和口头承诺',
    '口头承诺': '客户要求和口头承诺',
    '项目风险': '风险和其他说明',
    '风险说明': '风险和其他说明',
    '指派内部项目经理': '项目经理',
    '进场日期': '进场时间',
    '报价实施评估人天': '实施进场评估人天',
    '实施评估人天': '实施进场评估人天',
    '报价客开评估人天': '客开进场评估人天',
    '客开评估人天': '客开进场评估人天',
    '是否召开启动会': '是否有启动会',
    '启动会召开时间': '预计召开时间',
    '交付策略': '主要策略',
    '计划安排': '项目安排'
  });
  const TEMPLATE_FIELD_LABELS = new Set([
    '会议方式', '会议时间', '销售人员', '售前顾问', '实施人员', '客开人员', '其他与会人员',
    '签约单位', '实际用户', '是否合作项目', '合作性质', '是否招标项目', '招投标文档是否交接',
    '是否签订合同', '是否提前进场', '合同签订时间', '预计合同签订时间', '合同编号', '交付产品',
    '交付插件', '是否有代采', '代采内容', '代采是否交付', '交付主体', '实施合同人天', '客开合同人天',
    '是否有启动会', '预计召开时间', '客户IT环境', '实施地点', '地点类型', '实施范围', '交付内容',
    '最核心需求', '需要开发内容', '特殊的条款', '客户要求和口头承诺', '回款进度', '客户关键人员',
    '风险和其他说明', '项目经理', '进场时间', '实施进场评估人天', '客开进场评估人天', '是否外包',
    '外包类型', '外包伙伴', '预计人天', '项目组成员', '交付方式', '是否在线交付', '项目安排',
    '主要策略', '预计外包内容', '其他事项', '交付物'
  ]);
  const PREFERRED_SOURCE_LABELS = new Set([
    '交接时间', '销售经理', '最终客户', '签约时间', '项目实施范围', '是否召开启动会', '启动会召开时间',
    '客户关键需求', '非合同内承诺', '指派内部项目经理', '报价实施评估人天', '报价客开评估人天', '交付策略'
  ]);
  const PRESERVE_TEMPLATE_WHEN_UNASSEMBLED = new Set(['项目安排', '主要策略', '交付物']);
  const FALLBACK_SECTION_FIELDS = Object.freeze({
    '项目基本信息': Object.freeze([
      '大区名称', '合同编号', '签约单位', '签约客户', '漏斗编号', '项目编号', '项目名称', '所属战区', '所属区域', '最终客户', '所属行业',
      '合同金额', '产品金额', '实施金额', '客开金额', '基础运维金额', '拓展运维金额', '升级升迁金额', '代采金额',
      '销售经理', '销售组织', '产品系列', '项目状态', '业务线', '联营合同', '纳税人识别号', '是否新签', '客户联系人', '联系电话',
      '公司职务', '客户地址', '是否AI', '是否集约交付', '是否信创', '是否使用协同云', '是否需要结项', '是否CAP交付',
      '是否购买分析云', '是否购买薪事力', '是否为V8项目', '交付主体'
    ]),
    '客户干系人': Object.freeze(['客户负责人', '客户关键人员', '职务', '部门', '支持态度', '项目角色', '项目期望点', '干系人备注']),
    '项目交接信息': Object.freeze([
      '客户关键需求', '项目实施范围', '非合同内承诺', '商务风险提醒', '项目前期方案', '指派内部项目经理', '指派现场项目经理',
      '客开责任人', '项目类别', '交付类型', '交付分层', '是否召开启动会', '启动会召开时间', '进场时间', '预计建设完工时间',
      '预计上线时间', '预计验收时间', '合同实施人天', '合同客开人天', '报价实施评估人天', '报价客开评估人天', '交付策略',
      '交接评估意见', '项目安排'
    ]),
    '交接结论': Object.freeze(['项目经理', '实施进场评估人天', '客开进场评估人天', '是否外包', '外包类型', '外包伙伴', '预计人天', '交付方式', '是否在线交付', '主要策略', '预计外包内容', '交付物', '其他事项'])
  });

  let currentSnapshot = null;
  let monitorTimer = 0;
  let launcherButton = null;
  let frameBridgeBound = false;

  function normalizeText(value) {
    return String(value == null ? '' : value).replace(/[\u200b-\u200f\ufeff]/g, '').replace(/\s+/g, ' ').trim();
  }

  function normalizeLabel(value) {
    return normalizeText(value).replace(/[：:*＊\s]+$/g, '').replace(/\s+/g, '');
  }

  function parseHandoverTitle(text) {
    const normalized = normalizeText(text);
    const match = normalized.match(/\(自动发起\)\s*【([^】]+)】\s*-\s*\{([^{}]+?)-([^{}]+)\}\s*-\s*([\d,]+(?:\.\d+)?)\s*项目移交/);
    if (!match) return null;
    return {
      region: normalizeText(match[1]),
      contractNo: normalizeText(match[2]),
      company: normalizeText(match[3]),
      amount: normalizeText(match[4]).replace(/,/g, ''),
      rawTitle: normalizeText(match[0])
    };
  }

  function sanitizeFilePart(value) {
    const cleaned = normalizeText(value)
      .replace(/[\p{Cc}\p{Cf}]/gu, '')
      .replace(/[\\/:*?"<>|]/g, '_')
      .replace(/[.\s]+$/g, '');
    const source = cleaned || '未命名单位';
    const encoder = new TextEncoder();
    let result = '';
    let bytes = 0;
    for (const char of source) {
      const size = encoder.encode(char).length;
      if (bytes + size > 160) break;
      result += char;
      bytes += size;
    }
    return result || '未命名单位';
  }

  function buildOutputFileName(company, date) {
    const value = date instanceof Date ? date : new Date(date);
    const yyyy = value.getFullYear();
    const mm = String(value.getMonth() + 1).padStart(2, '0');
    const dd = String(value.getDate()).padStart(2, '0');
    return `项目交接会议纪要-${sanitizeFilePart(company)}-${yyyy}-${mm}-${dd}.docx`;
  }

  function templateLabelFor(label) {
    const normalized = normalizeLabel(label);
    return LABEL_ALIASES[normalized] || normalized;
  }

  function isVisible(node) {
    if (!node || !node.ownerDocument || !node.getBoundingClientRect) return true;
    try {
      const style = node.ownerDocument.defaultView.getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden') return false;
      const rect = node.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    } catch (_) {
      return true;
    }
  }

  function allDocs() {
    const docs = [];
    const seen = new Set();
    const visit = (doc) => {
      if (!doc || seen.has(doc)) return;
      seen.add(doc);
      docs.push(doc);
      try {
        doc.querySelectorAll('iframe').forEach((frame) => {
          try { visit(frame.contentDocument); } catch (_) {}
        });
      } catch (_) {}
    };
    visit(document);
    try { if (window.top && window.top.document !== document) visit(window.top.document); } catch (_) {}
    return docs;
  }

  function bindFrameBridge() {
    if (frameBridgeBound) return;
    frameBridgeBound = true;
    window.addEventListener('message', async (event) => {
      const message = event.data;
      if (isTopWindow() || event.source !== window.top || !message || message.channel !== FRAME_CHANNEL || message.type !== 'request') return;
      const sections = await collectPageSections();
      window.top.postMessage({ channel: FRAME_CHANNEL, type: 'response', requestId: message.requestId, sections }, '*');
    });
  }

  function requestFrameSections() {
    if (!isTopWindow()) return Promise.resolve([]);
    const targets = Array.from(new Set(allDocs().flatMap((doc) => Array.from(doc.querySelectorAll('iframe')).map((frame) => {
      try {
        if (frame.contentDocument && frame.contentDocument.documentElement) return null;
      } catch (_) {}
      return frame.contentWindow;
    }).filter(Boolean))));
    if (!targets.length) return Promise.resolve([]);
    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve) => {
      const sections = [];
      const pending = new Set(targets);
      const finish = () => {
        window.removeEventListener('message', onMessage);
        clearTimeout(timer);
        resolve(sections);
      };
      const onMessage = (event) => {
        const message = event.data;
        if (!pending.has(event.source) || !message || message.channel !== FRAME_CHANNEL || message.type !== 'response' || message.requestId !== requestId) return;
        pending.delete(event.source);
        if (Array.isArray(message.sections)) sections.push(...message.sections);
        if (!pending.size) finish();
      };
      const timer = setTimeout(finish, 2200);
      window.addEventListener('message', onMessage);
      targets.forEach((target) => target.postMessage({ channel: FRAME_CHANNEL, type: 'request', requestId }, '*'));
    });
  }

  function controlValue(control) {
    if (!control || control.disabled || !isVisible(control)) return '';
    const tag = String(control.tagName || '').toLowerCase();
    const type = String(control.type || '').toLowerCase();
    if ((type === 'checkbox' || type === 'radio')) return control.checked ? normalizeText(control.value || '是') : '';
    if (tag === 'select') {
      const option = control.options && control.options[control.selectedIndex];
      return normalizeText(option ? option.textContent : control.value);
    }
    return normalizeText(control.value != null ? control.value : control.getAttribute('value'));
  }

  function cellValue(cell) {
    if (!cell) return '';
    const cap4Fields = Array.from(cell.querySelectorAll('.cap-field')).filter((field) => !isAuxiliaryCap4Field(field));
    const cap4Values = cap4Fields.map(cap4FieldValue).filter(Boolean);
    if (cap4Values.length) return Array.from(new Set(cap4Values)).join('、');
    const controls = Array.from(cell.querySelectorAll('input,select,textarea'));
    const values = controls.map(controlValue).filter(Boolean);
    if (controls.length) return Array.from(new Set(values)).join('、');
    return normalizeText(cell.innerText || cell.textContent);
  }

  function cleanSectionTitleText(value) {
    return normalizeText(value).replace(/^[■█▌▊▍▪●]+\s*/u, '');
  }

  function isAuxiliaryCap4Field(field) {
    const value = `${field.id || ''} ${field.className || ''}`;
    return /auxiliary/i.test(value);
  }

  function isDetailCap4Field(field) {
    const value = `${field.className || ''}`;
    return /formson_/i.test(value) || Boolean(field.closest('.formson,.cap-formson,[id^="tableName-front_formson_"]'));
  }

  function cap4FieldLabel(field) {
    const node = field && field.querySelector('.cap4-ctrl__label .label-margin,.cap4-ctrl__label,label,[class*="label"]');
    return normalizeText(node && node.textContent);
  }

  function cap4FieldValue(field) {
    if (!field) return '';
    const view = field.querySelector('.field-content__view,.field__right,.cap4-ctrl__browse__content,.cap4-browse_content');
    const root = view || field;
    const controls = Array.from(root.querySelectorAll('input,select,textarea'));
    const controlValues = controls.map(controlValue).filter(Boolean);
    if (controlValues.length) return Array.from(new Set(controlValues)).join('、');
    return normalizeText(root.innerText || root.textContent);
  }

  function labelForControl(control) {
    const explicit = normalizeText(control.getAttribute('aria-label') || control.getAttribute('data-label') || control.placeholder);
    if (explicit && explicit.length <= 40) return explicit;
    const id = control.id;
    if (id) {
      try {
        const label = control.ownerDocument.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (label) return normalizeText(label.textContent);
      } catch (_) {}
    }
    const cell = control.closest('td,th');
    if (cell) {
      let previous = cell.previousElementSibling;
      while (previous) {
        const value = normalizeText(previous.innerText || previous.textContent);
        if (value && value.length <= 40) return value;
        previous = previous.previousElementSibling;
      }
    }
    const group = control.closest('.cap4-field,.form-group,.el-form-item,[class*="field"]');
    if (group) {
      const label = group.querySelector('label,.cap4-label,.el-form-item__label,[class*="label"]');
      if (label) return normalizeText(label.textContent);
    }
    return '';
  }

  function looksLikeLabel(text) {
    const value = normalizeLabel(text);
    return value.length > 0 && value.length <= 24 && !/^[-+]?\d+(?:\.\d+)?%?$/.test(value) && !/^https?:\/\//i.test(value);
  }

  function looksLikeValueCell(cell) {
    if (!cell || !isVisible(cell)) return false;
    const text = normalizeText(cell.innerText || cell.textContent);
    if (cell.querySelector('input,select,textarea')) return true;
    return Boolean(text) && !looksLikeLabel(text);
  }

  function nextFieldValueCell(cells, labelIndex) {
    for (let index = labelIndex + 1; index < cells.length; index += 1) {
      if (looksLikeValueCell(cells[index])) return cells[index];
      if (looksLikeLabel(cells[index].innerText || cells[index].textContent)) return null;
    }
    return null;
  }

  function collectPageFields() {
    const fields = new Map();
    const put = (label, value, source) => {
      const cleanLabel = normalizeLabel(label);
      const cleanValue = normalizeText(value);
      if (!cleanLabel || cleanLabel.length > 40) return;
      const key = templateLabelFor(cleanLabel);
      const existing = fields.get(key);
      const priority = source === 'control' || source === 'cap4' ? 2 : 1;
      const existingPriority = existing && (existing.source === 'control' || existing.source === 'cap4') ? 2 : 1;
      if (!existing || priority > existingPriority || (!existing.value && cleanValue)) {
        fields.set(key, { label: key, originalLabel: cleanLabel, value: cleanValue, source });
      }
    };

    allDocs().forEach((doc) => {
      doc.querySelectorAll('.cap-field').forEach((field) => {
        if (field.closest(`#${FAB_ID},#${PANEL_ID}`) || isAuxiliaryCap4Field(field) || isDetailCap4Field(field)) return;
        put(cap4FieldLabel(field), cap4FieldValue(field), 'cap4');
      });
      doc.querySelectorAll('input,select,textarea').forEach((control) => {
        if (control.closest(`#${FAB_ID},#${PANEL_ID}`)) return;
        if (control.closest('.cap-field')) return;
        put(labelForControl(control), controlValue(control), 'control');
      });
      let inDetailTable = false;
      doc.querySelectorAll('tr').forEach((row) => {
        if (!isVisible(row) || row.closest(`#${FAB_ID},#${PANEL_ID}`)) return;
        if (row.querySelector('.cap-field')) return;
        const cells = Array.from(row.children).filter((node) => /^(TD|TH)$/.test(node.tagName));
        const headers = detailHeaders(cells);
        if (headers) {
          inDetailTable = true;
          return;
        }
        if (inDetailTable) {
          const firstValue = normalizeText(cellValue(cells[0]));
          if (/^\d+$/.test(firstValue)) return;
          inDetailTable = false;
        }
        for (let index = 0; index < cells.length - 1; index += 1) {
          const label = normalizeText(cells[index].innerText || cells[index].textContent);
          if (!looksLikeLabel(label)) continue;
          const valueCell = nextFieldValueCell(cells, index);
          if (valueCell) put(label, cellValue(valueCell), 'row');
        }
      });
    });
    return Array.from(fields.values()).sort((a, b) => a.label.localeCompare(b.label, 'zh-CN'));
  }

  function fallbackSectionForField(field) {
    const label = templateLabelFor(field.label || field.originalLabel);
    for (const [sectionTitle, labels] of Object.entries(FALLBACK_SECTION_FIELDS)) {
      if (labels.includes(label)) return sectionTitle;
    }
    return '项目基本信息';
  }

  function classifyTable(headers) {
    const text = headers.join(' ');
    if (/顾问名称|顾问姓名|成员姓名|人员姓名/.test(text) && /顾问类型|项目角色|岗位序列/.test(text)) return { section: '项目组成员' };
    if (/项目角色/.test(text) && /部门/.test(text) && /职务/.test(text) && /姓名/.test(text) && /支持态度|项目期望点/.test(text)) return { section: '客户干系人' };
    if (/风险等级|风险描述|解决策略/.test(text)) return { section: '项目预计风险' };
    if (/付款阶段|付款比例|回款|收款/.test(text)) return { section: '项目交接信息', tab: '项目付款阶段' };
    if (/任务目标|任务名称|任务内容/.test(text)) return { section: '项目任务', tab: '实施任务目标' };
    return null;
  }

  function collectPageTables() {
    const tables = [];
    allDocs().forEach((doc) => {
      let current = null;
      doc.querySelectorAll('tr').forEach((row) => {
        if (!isVisible(row) || row.closest(`#${FAB_ID},#${PANEL_ID}`)) return;
        const cells = Array.from(row.children).filter((node) => /^(TD|TH)$/.test(node.tagName));
        if (!cells.length) return;
        const headers = detailHeaders(cells);
        if (headers) {
          const kind = classifyTable(headers);
          current = kind ? { headers, rows: [], kind } : null;
          if (current) tables.push(current);
          return;
        }
        if (current && cells.length >= current.headers.length) {
          const values = cells.slice(0, current.headers.length).map(cellValue);
          if (normalizeLabel(current.headers[0]) === '序号' && values[0] && !/^\d+$/.test(values[0])) {
            current = null;
            return;
          }
          if (values.slice(1).some(Boolean)) current.rows.push(values);
        }
      });
    });
    return tables.filter((table) => table.rows.length);
  }

  function hasSectionPayload(sections) {
    return sections.some((section) => section.fields.length || section.tables.length || section.tabs.some((tab) => tab.fields.length || tab.tables.length));
  }

  function collectFallbackSections() {
    const grouped = new Map();
    const ensure = (title) => {
      if (!grouped.has(title)) grouped.set(title, { title, fields: [], tables: [], tabs: [] });
      return grouped.get(title);
    };
    collectPageFields().forEach((field) => ensure(fallbackSectionForField(field)).fields.push(field));
    collectPageTables().forEach((table) => {
      const section = ensure(table.kind.section);
      const data = { headers: table.headers, rows: table.rows };
      if (!table.kind.tab) {
        section.tables.push(data);
        return;
      }
      let tab = section.tabs.find((item) => item.title === table.kind.tab);
      if (!tab) {
        tab = { title: table.kind.tab, fields: [], tables: [] };
        section.tabs.push(tab);
      }
      tab.tables.push(data);
    });
    return SECTION_TITLES.map((title) => grouped.get(title)).filter(Boolean);
  }

  function sectionTitleFromRow(row) {
    if (!row || !isVisible(row)) return '';
    const text = normalizeText(row.innerText || row.textContent);
    const markedTitle = /^[■█▌▊▍▪●]/u.test(text);
    const knownTitle = SECTION_TITLES.find((title) => text === title || (markedTitle && cleanSectionTitleText(text).startsWith(title)) || Array.from(row.querySelectorAll('td,th,div,span,b,strong,pre')).some((node) => cleanSectionTitleText(node.textContent) === title));
    if (knownTitle) return knownTitle;
    const cells = Array.from(row.children).filter((node) => /^(TD|TH)$/.test(node.tagName));
    if (cells.length !== 1 || Number(cells[0].colSpan || 1) < 2 || text.length > 30) return '';
    if (cells[0].querySelector('table,input,select,textarea,button,a')) return '';
    return text;
  }

  function findSectionRows(title) {
    for (const doc of allDocs()) {
      const rows = Array.from(doc.querySelectorAll('tr'));
      const start = rows.findIndex((row) => sectionTitleFromRow(row) === title);
      if (start < 0) continue;
      const result = [rows[start]];
      for (let index = start + 1; index < rows.length; index += 1) {
        if (sectionTitleFromRow(rows[index])) break;
        result.push(rows[index]);
      }
      return result;
    }
    return [];
  }

  function detailHeaders(cells) {
    const headers = cells.map((cell) => normalizeText(cell.innerText || cell.textContent));
    return headers.length >= 3 && headers.includes('序号') ? headers : null;
  }

  function collectSectionContent(title) {
    const fields = [];
    const tables = [];
    let currentTable = null;
    findSectionRows(title).forEach((row) => {
      if (!isVisible(row) || row.closest(`#${FAB_ID},#${PANEL_ID}`)) return;
      const cells = Array.from(row.children).filter((node) => /^(TD|TH)$/.test(node.tagName));
      if (!cells.length || (cells.length === 1 && cells[0].querySelector('table'))) return;
      const headers = detailHeaders(cells);
      if (headers) {
        currentTable = { headers, rows: [] };
        tables.push(currentTable);
        return;
      }
      if (currentTable && cells.length >= currentTable.headers.length) {
        const values = cells.slice(0, currentTable.headers.length).map(cellValue);
        if (values.slice(1).some(Boolean)) currentTable.rows.push(values);
        return;
      }
      const cap4Fields = Array.from(row.querySelectorAll('.cap-field')).filter((field) => !isAuxiliaryCap4Field(field) && !isDetailCap4Field(field));
      if (cap4Fields.length) {
        cap4Fields.forEach((field) => {
          const label = cap4FieldLabel(field);
          if (label) fields.push({ label: templateLabelFor(label), originalLabel: normalizeLabel(label), value: cap4FieldValue(field), source: 'cap4' });
        });
        currentTable = null;
        return;
      }
      currentTable = null;
      for (let index = 0; index < cells.length - 1; index += 1) {
        const label = normalizeText(cells[index].innerText || cells[index].textContent);
        if (!looksLikeLabel(label)) continue;
        const valueCell = nextFieldValueCell(cells, index);
        if (valueCell) fields.push({ label: templateLabelFor(label), originalLabel: label, value: cellValue(valueCell), source: 'section' });
      }
    });
    return { fields, tables: tables.filter((table) => table.rows.length) };
  }

  function findTabNode(title) {
    for (const doc of allDocs()) {
      const preferred = Array.from(doc.querySelectorAll('[role="tab"],button,a')).find((node) => isVisible(node) && normalizeText(node.textContent) === title);
      if (preferred) return preferred;
      const fallback = Array.from(doc.querySelectorAll('div,span,td,th')).find((node) => isVisible(node) && normalizeText(node.textContent) === title && !sectionTitleFromRow(node.closest('tr')));
      if (fallback) return fallback;
    }
    return null;
  }

  function isTabActive(node) {
    if (!node) return false;
    const state = `${node.className || ''} ${node.getAttribute('style') || ''}`;
    return node.getAttribute('aria-selected') === 'true' || /active|selected|current|\bcur\b/i.test(state);
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function collectPageSections() {
    const found = [];
    allDocs().forEach((doc) => {
      doc.querySelectorAll('tr').forEach((row) => {
        const title = sectionTitleFromRow(row);
        if (title && !found.includes(title)) found.push(title);
      });
    });
    const sections = [];
    for (const title of found) {
      const tabTitles = SECTION_TABS[title] || [];
      if (!tabTitles.length) {
        sections.push({ title, ...collectSectionContent(title), tabs: [] });
        continue;
      }
      const activeTitle = tabTitles.find((tabTitle) => isTabActive(findTabNode(tabTitle)));
      const tabs = [];
      for (const tabTitle of tabTitles) {
        const tab = findTabNode(tabTitle);
        if (!tab) {
          tabs.push({ title: tabTitle, fields: [], tables: [], error: '未找到页签' });
          continue;
        }
        if (!isTabActive(tab)) {
          tab.click();
          await sleep(350);
        }
        tabs.push({ title: tabTitle, ...collectSectionContent(title) });
      }
      if (activeTitle) {
        const original = findTabNode(activeTitle);
        if (original && !isTabActive(original)) {
          original.click();
          await sleep(150);
        }
      }
      sections.push({ title, fields: [], tables: [], tabs });
    }
    return sections;
  }

  function tableSummary(table) {
    return table.rows.map((row) => row.map((value, index) => `${table.headers[index]}：${value || '(空)'}`).join('，')).join('\n');
  }

  function numberedColumnSummary(table, patterns) {
    const columnIndex = table.headers.findIndex((header) => patterns.some((pattern) => pattern.test(normalizeText(header))));
    if (columnIndex < 0) return '';
    return table.rows.map((row) => normalizeText(row[columnIndex])).filter((value) => value && value !== '(空)').map((value, index) => `${index + 1}.${value}`).join('\n');
  }

  function columnValue(table, row, patterns) {
    const index = table.headers.findIndex((header) => patterns.some((pattern) => pattern.test(normalizeText(header))));
    return index >= 0 ? normalizeText(row[index]) : '';
  }

  function projectMemberSummary(table) {
    return table.rows.map((row, index) => {
      const role = columnValue(table, row, [/项目角色/]);
      const type = columnValue(table, row, [/顾问类型/]);
      const name = columnValue(table, row, [/顾问名称/, /顾问姓名/, /成员姓名/, /人员姓名/, /^姓名$/]);
      const text = [role && name ? `${role}：${name}` : role || name, type].filter(Boolean).join('，');
      return text ? `${index + 1}.${text}` : '';
    }).filter(Boolean).join('\n');
  }

  function stakeholderSummary(table) {
    return table.rows.map((row, index) => {
      const values = [
        columnValue(table, row, [/项目角色/]),
        columnValue(table, row, [/部门/]),
        columnValue(table, row, [/职务/]),
        columnValue(table, row, [/姓名/, /客户负责人/]),
        columnValue(table, row, [/支持态度/]),
        columnValue(table, row, [/项目期望点/])
      ].filter(Boolean);
      return values.length ? `${index + 1}.${values.join('，')}` : '';
    }).filter(Boolean).join('\n');
  }

  function riskDescriptionSummary(table) {
    return numberedColumnSummary(table, [/风险描述/]);
  }

  function paymentProgressSummary(table) {
    return table.rows.map((row, index) => {
      const node = columnValue(table, row, [/收款节点/, /付款阶段/, /阶段名称/]);
      const cycle = columnValue(table, row, [/周期/, /预计付款时间/, /付款时间/]);
      const unit = columnValue(table, row, [/单位/]);
      const ratio = columnValue(table, row, [/收款比例/, /付款比例/]);
      const amount = columnValue(table, row, [/收款金额/, /付款金额/]);
      const text = `${node}${cycle}${unit}${ratio}${amount ? ` ${amount}` : ''}`;
      return text ? `${index + 1}.${text}` : '';
    }).filter(Boolean).join('\n');
  }

  function flattenSections(sections) {
    const fields = new Map();
    const put = (field) => {
      const label = templateLabelFor(field.label);
      const preferred = PREFERRED_SOURCE_LABELS.has(normalizeLabel(field.originalLabel || field.label));
      const existing = fields.get(label);
      if (field.force || preferred || !existing || (!existing.value && field.value)) {
        fields.set(label, { ...field, label });
      } else if (field.source === 'detail' && field.value && !existing.value.includes(field.value)) {
        existing.value = `${existing.value}\n${field.value}`;
      }
    };
    sections.forEach((section) => {
      section.fields.forEach(put);
      section.tabs.forEach((tab) => tab.fields.forEach(put));
      const groups = [{ title: section.title, tables: section.tables }, ...section.tabs.map((tab) => ({ title: tab.title, tables: tab.tables }))];
      groups.forEach((group) => group.tables.forEach((table) => {
        const summary = tableSummary(table);
        if (group.title === '项目付款阶段') put({ label: '回款进度', originalLabel: group.title, value: paymentProgressSummary(table) || summary, source: 'detail', force: true });
        if (group.title === '实施任务目标') put({ label: '项目安排', originalLabel: group.title, value: '', source: 'detail' });
        if (group.title === '客开任务目标') put({ label: '需要开发内容', originalLabel: group.title, value: numberedColumnSummary(table, [/客开任务目标/, /任务目标/]) || summary, source: 'detail', force: true });
        if (group.title === '项目预计风险') put({ label: '风险和其他说明', originalLabel: group.title, value: riskDescriptionSummary(table), source: 'detail', force: true });
        if (group.title === '项目组成员') put({ label: '项目组成员', originalLabel: group.title, value: projectMemberSummary(table) || summary, source: 'detail' });
        if (group.title === '客户干系人') put({ label: '客户关键人员', originalLabel: group.title, value: stakeholderSummary(table), source: 'detail', force: true });
      }));
    });
    return Array.from(fields.values());
  }

  function applyMeetingParticipants(sections) {
    const memberSection = sections.find((section) => section.title === '项目组成员');
    const people = { presales: [], implementation: [], customization: [] };
    (memberSection ? memberSection.tables : []).forEach((table) => {
      const nameIndex = table.headers.findIndex((header) => /^(顾问名称|顾问姓名|成员姓名|人员姓名|姓名)$/.test(normalizeText(header)));
      const roleIndexes = table.headers.map((header, index) => (/顾问类型|项目角色|岗位序列|人员性质|人员属性/.test(normalizeText(header)) ? index : -1)).filter((index) => index >= 0);
      if (nameIndex < 0) return;
      table.rows.forEach((row) => {
        const name = normalizeText(row[nameIndex]);
        const role = roleIndexes.map((index) => normalizeText(row[index])).join(' ');
        if (!name) return;
        if (/售前/.test(role)) people.presales.push(name);
        else if (/客开|开发顾问/.test(role)) people.customization.push(name);
        else if (/实施/.test(role)) people.implementation.push(name);
      });
    });
    const handoverSections = sections.filter((section) => /项目交接信息|项目承接信息/.test(section.title));
    const handoverFields = handoverSections.flatMap((section) => section.fields.concat(section.tabs.flatMap((tab) => tab.fields)));
    const handoverValue = (labels) => {
      const field = handoverFields.find((item) => labels.includes(normalizeLabel(item.originalLabel || item.label)) && item.value);
      return field ? field.value : '';
    };
    const values = {
      '售前顾问': Array.from(new Set(people.presales)).join('、') || handoverValue(['售前顾问']),
      '实施人员': Array.from(new Set(people.implementation)).join('、') || handoverValue(['实施人员', '指派现场项目经理', '指派内部项目经理', '项目经理']),
      '客开人员': Array.from(new Set(people.customization)).join('、') || handoverValue(['客开人员', '客开责任人'])
    };
    const basicSection = sections.find((section) => section.title === '项目基本信息');
    if (!basicSection) return;
    Object.entries(values).forEach(([label, value]) => {
      const field = basicSection.fields.find((item) => templateLabelFor(item.label) === label);
      if (field) field.value = value;
      else basicSection.fields.push({ label, originalLabel: label, value, source: 'derived' });
    });
  }

  function findPageTitle() {
    for (const doc of allDocs()) {
      try {
        const frame = doc.defaultView && doc.defaultView.frameElement;
        if (frame && !isVisible(frame)) continue;
      } catch (_) {}
      const subject = doc.getElementById && doc.getElementById('subject');
      for (const candidate of [subject && subject.value, subject && subject.textContent, doc.title]) {
        const parsed = parseHandoverTitle(candidate);
        if (parsed) return parsed;
      }
      const markerTexts = Array.from(doc.querySelectorAll('a,button,div,span,li')).map((node) => normalizeText(node.textContent));
      const isDetailPage = markerTexts.includes('商务实施移交单') || (markerTexts.includes('表单') && markerTexts.includes('流程'));
      if (!isDetailPage) continue;
      const titleNodes = Array.from(doc.querySelectorAll('h1,h2,h3,[class*="subject"],[class*="title"]'));
      for (const node of titleNodes) {
        const parsed = parseHandoverTitle(node.textContent);
        if (parsed) return parsed;
      }
    }
    return null;
  }

  async function readSnapshot() {
    const title = findPageTitle();
    if (!title) return null;
    const sections = await collectPageSections();
    const needsLocalFallback = !hasSectionPayload(sections);
    sections.push(...await requestFrameSections());
    if (needsLocalFallback) sections.push(...collectFallbackSections());
    applyMeetingParticipants(sections);
    const fields = flattenSections(sections);
    const values = new Map(fields.map((field) => [field.label, field.value]));
    const titleFields = [
      ['大区名称', title.region],
      ['合同编号', title.contractNo],
      ['签约单位', title.company],
      ['合同金额', title.amount]
    ];
    titleFields.forEach(([label, value]) => {
      values.set(label, value);
      const existing = fields.find((field) => field.label === label);
      if (existing) existing.value = value;
      else fields.unshift({ label, originalLabel: label, value, source: 'title' });
    });
    if (values.get('合同签订时间')) {
      values.set('是否签订合同', '是');
      const existing = fields.find((field) => field.label === '是否签订合同');
      if (existing) existing.value = '是';
      else fields.push({ label: '是否签订合同', originalLabel: '签约时间', value: '是', source: 'derived' });
    }
    return { title, sections, fields, values, readAt: new Date() };
  }

  function bindDrag(handle, target, storageKey) {
    if (!handle || !target || handle.dataset.dragBound === '1') return;
    handle.dataset.dragBound = '1';
    let active = false;
    let moved = false;
    let startX = 0;
    let startY = 0;
    let offsetX = 0;
    let offsetY = 0;
    const moveTo = (left, top) => {
      const maxLeft = Math.max(0, window.innerWidth - target.offsetWidth);
      const maxTop = Math.max(0, window.innerHeight - target.offsetHeight);
      target.style.left = `${Math.max(0, Math.min(maxLeft, left))}px`;
      target.style.top = `${Math.max(0, Math.min(maxTop, top))}px`;
      target.style.right = 'auto';
    };
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
      if (saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) moveTo(saved.left, saved.top);
    } catch (_) {}
    handle.addEventListener('pointerdown', (event) => {
      const clickedButton = event.target && event.target.closest && event.target.closest('button');
      if (clickedButton && clickedButton !== handle) return;
      const rect = target.getBoundingClientRect();
      active = true;
      moved = false;
      startX = event.clientX;
      startY = event.clientY;
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      try { handle.setPointerCapture(event.pointerId); } catch (_) {}
    });
    handle.addEventListener('pointermove', (event) => {
      if (!active) return;
      if (!moved && Math.hypot(event.clientX - startX, event.clientY - startY) > 5) moved = true;
      if (moved) moveTo(event.clientX - offsetX, event.clientY - offsetY);
    });
    const stop = (event) => {
      if (!active) return;
      active = false;
      try { handle.releasePointerCapture(event.pointerId); } catch (_) {}
      if (!moved) return;
      target.dataset.draggedAt = String(Date.now());
      const rect = target.getBoundingClientRect();
      try { localStorage.setItem(storageKey, JSON.stringify({ left: rect.left, top: rect.top })); } catch (_) {}
    };
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
    window.addEventListener('resize', () => {
      const rect = target.getBoundingClientRect();
      moveTo(rect.left, rect.top);
    });
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function isCurrentUi(node) {
    return node && node.dataset.projectHandoverOwner === OWNER_ID && node.dataset.projectHandoverBound === '1';
  }

  function markCurrentUi(node) {
    node.dataset.projectHandoverOwner = OWNER_ID;
    node.dataset.projectHandoverBound = '1';
  }

  function ensurePanel() {
    let panel = document.getElementById(PANEL_ID);
    if (isCurrentUi(panel)) return panel;
    if (panel) panel.remove();
    panel = document.createElement('section');
    panel.id = PANEL_ID;
    markCurrentUi(panel);
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'false');
    panel.setAttribute('aria-label', '项目移交会议纪要');
    panel.style.cssText = 'position:fixed;top:72px;right:16px;width:720px;max-width:calc(100vw - 32px);max-height:80vh;display:none;flex-direction:column;background:#fff;border:1px solid #bfdbfe;border-radius:12px;box-shadow:0 12px 40px rgba(30,64,175,.24);z-index:2147483647;font:13px/1.5 system-ui,-apple-system,"Microsoft YaHei",sans-serif;color:#1f2937;overflow:hidden';
    panel.innerHTML = `
      <style>
        #${PANEL_ID} button:hover:not(:disabled){filter:brightness(.94)}
        #${PANEL_ID} button:focus-visible{outline:2px solid #f59e0b;outline-offset:2px}
      </style>
      <header id="ph-header" style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#1d4ed8;color:#fff;cursor:move;user-select:none">
        <b style="font-size:14px">项目移交会议纪要</b>
        <button id="ph-close" type="button" aria-label="关闭" style="width:28px;height:28px;border:0;border-radius:8px;background:rgba(255,255,255,.18);color:#fff;font-size:18px;cursor:pointer">×</button>
      </header>
      <div style="padding:12px 16px;overflow:auto">
        <div id="ph-status" role="status" style="padding:8px 12px;border:1px solid #bfdbfe;border-radius:8px;background:#eff6ff;color:#1d4ed8;font-weight:600"></div>
        <div id="ph-fields" style="margin-top:12px"></div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px">
          <button id="ph-reread" type="button" aria-label="重新读取网页字段" style="padding:8px 14px;border:0;border-radius:8px;background:#0f766e;color:#fff;cursor:pointer">重新读取</button>
          <button id="ph-generate" type="button" aria-label="写入并下载会议纪要" style="padding:8px 14px;border:0;border-radius:8px;background:#2563eb;color:#fff;cursor:pointer">写入会议纪要</button>
        </div>
      </div>`;
    document.documentElement.appendChild(panel);
    bindDrag(panel.querySelector('#ph-header'), panel, PANEL_POS_KEY);
    panel.querySelector('#ph-close').addEventListener('click', () => {
      panel.style.display = 'none';
      if (launcherButton) launcherButton.focus();
    });
    panel.querySelector('#ph-reread').addEventListener('click', async () => {
      const status = panel.querySelector('#ph-status');
      status.textContent = '正在重新读取网页区块和页签…';
      renderPanel(await readSnapshot());
    });
    panel.querySelector('#ph-generate').addEventListener('click', async () => {
      const button = panel.querySelector('#ph-generate');
      const status = panel.querySelector('#ph-status');
      const oldText = button.textContent;
      button.disabled = true;
      button.style.opacity = '.65';
      button.textContent = '生成中…';
      status.textContent = '正在生成会议纪要…';
      try {
        if (!currentSnapshot) throw new Error('未识别到项目移交流程标题');
        const result = await generateMinutes(currentSnapshot);
        status.textContent = '已生成会议纪要，文件已开始下载。';
        status.title = result.fileName;
        button.textContent = '已生成';
      } catch (error) {
        status.textContent = `生成失败：${error && error.message ? error.message : error}`;
        status.style.color = '#b91c1c';
        button.textContent = '生成失败';
      } finally {
        button.disabled = false;
        button.style.opacity = '1';
        setTimeout(() => {
          button.textContent = oldText;
        }, 800);
      }
    });
    return panel;
  }

  function renderDataTable(table) {
    const head = table.headers.map((header) => `<th style="padding:6px 8px;border:1px solid #dbeafe;background:#eff6ff;text-align:left;word-break:break-word">${escapeHtml(header)}</th>`).join('');
    const body = table.rows.map((row) => `<tr>${row.map((value) => `<td style="padding:6px 8px;border:1px solid #dbeafe;white-space:pre-wrap;word-break:break-word">${escapeHtml(value || '(空)')}</td>`).join('')}</tr>`).join('');
    return `<div style="overflow:auto;margin-top:8px"><table style="width:100%;border-collapse:collapse;font-size:12px;color:#334155"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  }

  function renderFields(fields) {
    if (!fields.length) return '';
    const rows = fields.map((field) => `<tr>
      <th scope="row" style="width:34%;padding:7px 8px;border:1px solid #dbeafe;background:#f8fafc;text-align:left;vertical-align:top;word-break:break-word">${escapeHtml(field.originalLabel || field.label)}</th>
      <td style="padding:7px 8px;border:1px solid #dbeafe;vertical-align:top;white-space:pre-wrap;word-break:break-word">${escapeHtml(field.value || '(空)')}</td>
    </tr>`).join('');
    return `<table style="width:100%;table-layout:fixed;border-collapse:collapse;font-size:12px;color:#334155"><tbody>${rows}</tbody></table>`;
  }

  function taskGoals(tab) {
    const values = [];
    tab.tables.forEach((table) => {
      const targetIndex = table.headers.findIndex((header) => header === tab.title || header.includes(tab.title) || /任务目标/.test(header));
      if (targetIndex < 0) return;
      table.rows.forEach((row) => {
        const value = String(row[targetIndex] || '').trim();
        if (value && value !== '(空)') values.push(value);
      });
    });
    return values;
  }

  function renderTaskTab(tab) {
    const goals = taskGoals(tab);
    const items = goals.length ? goals.map((value, index) => `<div style="margin-top:4px;color:#334155">${index + 1}.${escapeHtml(value)}</div>`).join('') : '<div style="margin-top:4px;color:#64748b">(空)</div>';
    return `<div data-ph-task-tab="${escapeHtml(tab.title)}" style="margin-top:10px">
      <div style="font-weight:700;color:#1d4ed8">${escapeHtml(tab.title)}</div>
      <div style="padding:8px 10px;border:1px solid #dbeafe;border-radius:8px;background:#fff">${items}</div>
    </div>`;
  }

  function renderTab(tab, compact) {
    if (compact) return renderTaskTab(tab);
    const body = tab.error ? `<div style="margin-top:6px;color:#b91c1c">${escapeHtml(tab.error)}</div>` : `${renderFields(tab.fields)}${tab.tables.map(renderDataTable).join('')}`;
    return `<div data-ph-tab-card="${escapeHtml(tab.title)}" style="margin-top:10px;padding:9px 10px;border:1px solid #dbeafe;border-radius:8px;background:#f8fafc">
      <div style="font-weight:700;color:#1d4ed8">${escapeHtml(tab.title)}</div>
      ${body}
    </div>`;
  }

  function renderSection(section) {
    const compactTask = section.title === '项目任务';
    const tabs = section.tabs.map((tab) => renderTab(tab, compactTask)).join('');
    return `<section style="background:#fff;border:1px solid #bfdbfe;border-radius:10px;padding:10px 12px;margin-bottom:10px;color:#1e3a8a">
      <div style="font-weight:700;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid #dbeafe">${escapeHtml(section.title)}</div>
      ${compactTask ? '' : `${renderFields(section.fields)}${section.tables.map(renderDataTable).join('')}`}${tabs}
    </section>`;
  }

  function renderPanel(snapshot) {
    const panel = ensurePanel();
    currentSnapshot = snapshot;
    panel.style.display = 'flex';
    const status = panel.querySelector('#ph-status');
    const fieldsHost = panel.querySelector('#ph-fields');
    status.style.color = '#1d4ed8';
    if (!snapshot) {
      status.textContent = '未识别到项目移交流程，请确认当前页面标题。';
      fieldsHost.innerHTML = '';
      return;
    }
    const detailRows = snapshot.sections.reduce((count, section) => count + section.tables.reduce((sum, table) => sum + table.rows.length, 0) + section.tabs.reduce((sum, tab) => sum + tab.tables.reduce((rows, table) => rows + table.rows.length, 0), 0), 0);
    status.textContent = `已读取 ${snapshot.sections.length} 个区块、${snapshot.fields.length} 个字段、${detailRows} 条明细；网页修改后可点击“重新读取”。`;
    fieldsHost.innerHTML = snapshot.sections.map(renderSection).join('');
  }

  function ensureLauncher() {
    let host = document.getElementById(FAB_ID);
    if (isCurrentUi(host)) return host;
    if (host) host.remove();
    host = document.createElement('div');
    host.id = FAB_ID;
    markCurrentUi(host);
    host.style.cssText = 'position:fixed;right:18px;top:55%;z-index:2147483646;font-family:system-ui,-apple-system,"Microsoft YaHei",sans-serif';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>
      button{font:inherit}#ball{width:42px;height:42px;padding:0;border:0;border-radius:50%;background:transparent;cursor:grab;box-shadow:0 4px 14px rgba(37,99,235,.28);overflow:hidden}
      #ball img{display:block;width:42px;height:42px}
      #menu{position:absolute;right:54px;top:0;width:220px;display:none;padding:6px;background:#fff;border:1px solid #bfdbfe;border-radius:10px;box-shadow:0 10px 30px rgba(30,64,175,.2)}
      #menu.open{display:block}#open{width:100%;padding:10px 12px;border:0;border-radius:8px;background:#fff;color:#1f2937;text-align:left;cursor:pointer}#open:hover,#open:focus-visible{background:#eff6ff;outline:2px solid #2563eb;outline-offset:1px}
      #ball:focus-visible{outline:2px solid #f59e0b;outline-offset:3px}
      #open b{display:block;font-size:13px}#open span{display:block;margin-top:2px;font-size:11px;color:#64748b}
      @media (prefers-reduced-motion:no-preference){#ball{transition:transform .15s ease}#ball:hover{transform:scale(1.05)}}
    </style><div id="menu"><button id="open" type="button"><b>项目移交会议纪要</b><span>读取网页并生成 DOCX</span></button></div><button id="ball" type="button" aria-label="打开项目移交工具"><img alt=""></button>`;
    document.documentElement.appendChild(host);
    const ball = shadow.getElementById('ball');
    const iconImage = ball.querySelector('img');
    try {
      iconImage.src = runtimeUrl('icons/fab-42.png');
      SeeyonIcon.applyToImage(iconImage, 'icons/fab-42.png');
    } catch (_) {}
    launcherButton = ball;
    const menu = shadow.getElementById('menu');
    bindDrag(ball, host, FAB_POS_KEY);
    ball.setAttribute('aria-expanded', 'false');
    ball.addEventListener('click', () => {
      if (Date.now() - Number(host.dataset.draggedAt || 0) < 250) return;
      menu.classList.toggle('open');
      ball.setAttribute('aria-expanded', menu.classList.contains('open') ? 'true' : 'false');
    });
    shadow.getElementById('open').addEventListener('click', async () => {
      menu.classList.remove('open');
      ball.setAttribute('aria-expanded', 'false');
      const panel = ensurePanel();
      panel.style.display = 'flex';
      panel.querySelector('#ph-status').textContent = '正在读取网页区块和页签…';
      panel.querySelector('#ph-fields').innerHTML = '';
      renderPanel(await readSnapshot());
      const closeButton = document.querySelector(`#${PANEL_ID} #ph-close`);
      if (closeButton) closeButton.focus();
    });
    return host;
  }

  function replaceCellText(cell, value) {
    const oldParagraph = cell.getElementsByTagNameNS(WORD_NS, 'p')[0];
    const oldRun = cell.getElementsByTagNameNS(WORD_NS, 'r')[0];
    const cellProperties = cell.getElementsByTagNameNS(WORD_NS, 'tcPr')[0];
    Array.from(cell.childNodes).forEach((node) => { if (node !== cellProperties) cell.removeChild(node); });
    const paragraph = cell.ownerDocument.createElementNS(WORD_NS, 'w:p');
    const paragraphProperties = oldParagraph && oldParagraph.getElementsByTagNameNS(WORD_NS, 'pPr')[0];
    if (paragraphProperties) paragraph.appendChild(paragraphProperties.cloneNode(true));
    const run = cell.ownerDocument.createElementNS(WORD_NS, 'w:r');
    const runProperties = oldRun && oldRun.getElementsByTagNameNS(WORD_NS, 'rPr')[0];
    if (runProperties) run.appendChild(runProperties.cloneNode(true));
    const text = cell.ownerDocument.createElementNS(WORD_NS, 'w:t');
    text.setAttribute('xml:space', 'preserve');
    text.textContent = String(value || '');
    run.appendChild(text);
    paragraph.appendChild(run);
    cell.appendChild(paragraph);
  }

  function cellText(cell) {
    return normalizeText(Array.from(cell.getElementsByTagNameNS(WORD_NS, 't')).map((node) => node.textContent).join(''));
  }

  function remarkList(value) {
    const items = String(value || '').split(/[\n\r]+|[；;]/).map((item) => normalizeText(item).replace(/^\d+[、.．]\s*/, '')).filter(Boolean);
    if (items.length < 2) return '';
    return items.map((item, index) => `${index + 1}、${item.replace(/[；;]$/, '')}；`).join('\n');
  }

  function optionMatches(selected, option) {
    if (!option) return false;
    if (selected === option || selected.includes(option) || option.includes(selected)) return true;
    return /前期POC环境、业务包/.test(option) && /前期方案/.test(selected);
  }

  function valueForTemplateCell(templateText, value, preserveOnNoMatch) {
    const rawValue = String(value || '');
    if (!rawValue) return /[☐☑]/.test(templateText) ? templateText : '';
    if (!/[☐☑]/.test(templateText)) return rawValue;
    const selected = normalizeText(rawValue);
    if (/^是\s*[☐☑]\s*否$/.test(templateText)) {
      if (selected === '是') return '☑是 ☐否';
      if (selected === '否') return '☐是 ☑否';
    }
    let matched = false;
    const marked = templateText.replace(/[☐☑]\s*([^☐☑]+)/g, (part, optionText) => {
      const option = normalizeText(optionText).replace(/[，,;；|]/g, '');
      const checked = optionMatches(selected, option);
      if (checked) matched = true;
      return `${checked ? '☑' : '☐'}${optionText}`;
    });
    return matched ? marked : (preserveOnNoMatch ? '' : `${marked} ${rawValue}`);
  }

  function fillDocumentXml(xml, snapshot) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xml, 'application/xml');
    if (doc.getElementsByTagName('parsererror').length) throw new Error('会议纪要模板 XML 无法解析');
    const values = snapshot.values || new Map(snapshot.fields.map((field) => [field.label, field.value]));
    const rows = Array.from(doc.getElementsByTagNameNS(WORD_NS, 'tr'));
    rows.forEach((row) => {
      const cells = Array.from(row.getElementsByTagNameNS(WORD_NS, 'tc')).filter((cell) => cell.parentNode === row);
      cells.forEach((cell, index) => {
        const label = normalizeLabel(cellText(cell));
        if (label.includes('项目交接会议纪要')) {
          replaceCellText(cell, `${snapshot.title.company}项目交接会议纪要`);
          return;
        }
        const targetLabel = templateLabelFor(label);
        if (!TEMPLATE_FIELD_LABELS.has(targetLabel) || index + 1 >= cells.length) return;
        const valueCell = cells[index + 1];
        let value = values.get(targetLabel) || '';
        if (targetLabel === '项目安排' || targetLabel === '主要策略') value = remarkList(value);
        if (PRESERVE_TEMPLATE_WHEN_UNASSEMBLED.has(targetLabel) && !value) return;
        const output = valueForTemplateCell(cellText(valueCell), value, targetLabel === '交付物');
        if (PRESERVE_TEMPLATE_WHEN_UNASSEMBLED.has(targetLabel) && !output) return;
        replaceCellText(valueCell, output);
      });
    });
    return new XMLSerializer().serializeToString(doc);
  }

  function requestTemplateBuffer() {
    if (typeof chrome === 'undefined' || !chrome.runtime || typeof chrome.runtime.sendMessage !== 'function') return Promise.resolve(null);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('模板读取超时，请重新加载插件后再试')), 8000);
      chrome.runtime.sendMessage({ action: 'projectHandoverGetTemplate' }, (response) => {
        clearTimeout(timer);
        const runtimeError = chrome.runtime && chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message || '模板读取失败'));
          return;
        }
        if (!response || response.success === false) {
          reject(new Error(`模板读取失败：${(response && response.error) || '后台无响应'}`));
          return;
        }
        const base64 = response.data && response.data.base64;
        if (!base64) {
          reject(new Error('后台未返回会议纪要模板'));
          return;
        }
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
        resolve(bytes);
      });
    });
  }

  async function generateMinutes(snapshot) {
    if (typeof JSZip === 'undefined') throw new Error('JSZip 未加载');
    let templateBuffer = await requestTemplateBuffer();
    if (!templateBuffer) {
      const templateUrl = chrome.runtime.getURL('project-handover/assets/项目交接会议纪要模板.docx');
      let response;
      try {
        response = await fetch(templateUrl);
      } catch (_) {
        throw new Error('模板读取失败，请在扩展管理页重新加载插件并刷新当前页面');
      }
      if (!response.ok) throw new Error(`模板加载失败：HTTP ${response.status}`);
      templateBuffer = await response.arrayBuffer();
    }
    const zip = await JSZip.loadAsync(templateBuffer);
    const documentFile = zip.file('word/document.xml');
    if (!documentFile) throw new Error('模板缺少 word/document.xml');
    zip.file('word/document.xml', fillDocumentXml(await documentFile.async('string'), snapshot));
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
    const fileName = buildOutputFileName(snapshot.title.company, new Date());
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.style.display = 'none';
    document.documentElement.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    return { blob, fileName };
  }

  function removeUi() {
    const fab = document.getElementById(FAB_ID);
    const panel = document.getElementById(PANEL_ID);
    if (fab) fab.remove();
    if (panel) panel.remove();
  }

  function isTopWindow() {
    try { return window.top === window; } catch (_) { return true; }
  }

  function runtimeUrl(path) {
    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function') {
      return chrome.runtime.getURL(path);
    }
    return `../${path}`;
  }

  function refreshUi() {
    if (!isTopWindow() || !findPageTitle()) {
      removeUi();
      return;
    }
    ensureLauncher();
  }

  function bootstrap() {
    if (typeof document === 'undefined' || !document.documentElement) return;
    bindFrameBridge();
    removeUi();
    refreshUi();
    if (monitorTimer) clearInterval(monitorTimer);
    monitorTimer = setInterval(refreshUi, 1500);
  }

  return {
    parseHandoverTitle,
    sanitizeFilePart,
    buildOutputFileName,
    templateLabelFor,
    collectPageFields,
    fillDocumentXml,
    bootstrap
  };
});
