const assert = require('assert');
const fs = require('fs');
const path = require('path');

const iconPath = path.join(__dirname, 'icon.js');
const iconSource = fs.readFileSync(iconPath, 'utf8');
const api = require(iconPath);
const root = path.join(__dirname, '..');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const settingsHtmlPath = path.join(root, 'settings', 'icon.html');
const settingsJsPath = path.join(root, 'settings', 'icon.js');
const settingsHtmlSource = fs.readFileSync(settingsHtmlPath, 'utf8');
const settingsJsSource = fs.readFileSync(settingsJsPath, 'utf8');

assert.deepStrictEqual(api.centerCropRect(160, 80, 84), { sx: 40, sy: 0, size: 80 });
assert.deepStrictEqual(api.centerCropRect(80, 160, 84), { sx: 0, sy: 40, size: 80 });
assert.strictEqual(api.isCustomIconDataUrl('data:image/png;base64,abc'), true);
assert.strictEqual(api.isCustomIconDataUrl('https://example.com/icon.png'), false);
assert.strictEqual(api.isCustomIconDataUrl('data:text/html;base64,abc'), false);
assert.match(iconSource, /chrome\.storage\.local\.get/);
assert.match(iconSource, /chrome\.storage\.onChanged/);
assert.match(iconSource, /image\.dataset\.seeyonIconFallback = fallbackPath \|\| 'icons\/fab-84\.png';/);

assert.strictEqual(manifest.version, '3.4.11');
assert.strictEqual(manifest.options_page, 'settings/icon.html');
assert.strictEqual(manifest.action.default_popup, 'settings/icon.html');
assert.ok(manifest.permissions.includes('storage'));
assert.ok(fs.existsSync(settingsHtmlPath), '应提供自定义图标设置页');
assert.ok(fs.existsSync(settingsJsPath), '应提供自定义图标设置脚本');
assert.match(settingsJsSource, /previewCanvas\.toDataURL\('image\/png'\)/);
assert.match(settingsJsSource, /seeyon:custom-icon-history/);
assert.match(settingsJsSource, /slice\(0, 5\)/);
assert.match(settingsHtmlSource, /id="recent-icons"/);
assert.match(settingsHtmlSource, /\.history-item\{height:auto;/);
assert.match(settingsHtmlSource, /#reset\{white-space:nowrap;/);
assert.match(settingsHtmlSource, /id="crop-canvas"/);
assert.match(settingsHtmlSource, /id="confirm-crop"/);
assert.match(settingsHtmlSource, /id="cancel-crop"/);
assert.match(settingsJsSource, /function clampCrop\(/);
assert.match(settingsJsSource, /function confirmCrop\(/);
assert.match(settingsJsSource, /cropContext\.arc\(/);
assert.match(settingsJsSource, /previewContext\.arc\(/);
assert.match(settingsJsSource, /Math\.hypot\(/);
assert.match(settingsJsSource, /cropCanvas\.addEventListener\('pointerdown'/);
assert.match(settingsJsSource, /cropCanvas\.addEventListener\('pointermove'/);
assert.match(settingsJsSource, /cropCanvas\.addEventListener\('pointerup'/);
assert.match(settingsJsSource, /cropEditor\.hidden = false/);

const contentScripts = manifest.content_scripts.filter((item) => item.js && item.js.some((file) => file.endsWith('.js')));
assert.ok(contentScripts.length > 0);
for (const script of contentScripts) {
  assert.ok(script.js.includes('shared/icon.js'), `${script.js.join(',')} 应加载共享图标脚本`);
}

const entrySources = [
  'shared/launcher.js',
  'work-hours/content.js',
  'code-scan/content-code-scan.js',
  'bug-flow/bug-flow.js',
  'conflict-radar/content.js',
  'weekly-plan/content.js',
  'project-check/content.js',
  'batch-approval/content.js',
  'project-handover/content.js'
].map((file) => fs.readFileSync(path.join(root, file), 'utf8')).join('\n');
assert.match(entrySources, /SeeyonIcon\.applyToImage/);
assert.doesNotMatch(entrySources, /chrome\.runtime\.getURL\('icons\/fab-84\.png'\)/);

console.log('custom icon contract checks passed');
