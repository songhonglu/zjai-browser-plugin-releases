(function (root) {
  if (root.SeeyonIcon) return;

  const STORAGE_KEY = 'seeyon:custom-icon';
  const registeredImages = new Set();

  function runtimeUrl(path) {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function') {
        return chrome.runtime.getURL(path);
      }
    } catch (_) {}
    return path;
  }

  function isCustomIconDataUrl(value) {
    return /^data:image\/(?:png|jpeg|webp);base64,[a-z0-9+/=]+$/i.test(String(value || ''));
  }

  function centerCropRect(width, height, targetSize) {
    const size = Math.min(width, height);
    return {
      sx: Math.round((width - size) / 2),
      sy: Math.round((height - size) / 2),
      size
    };
  }

  function readCustomIcon(done) {
    try {
      chrome.storage.local.get(STORAGE_KEY, (result) => {
        const value = result && result[STORAGE_KEY];
        done(isCustomIconDataUrl(value) ? value : '');
      });
    } catch (_) {
      done('');
    }
  }

  function applyToImage(image, fallbackPath) {
    if (!image) return;
    registeredImages.add(image);
    image.dataset.seeyonIconFallback = fallbackPath || 'icons/fab-84.png';
    image.src = runtimeUrl(image.dataset.seeyonIconFallback);
    readCustomIcon((customIcon) => {
      if (customIcon && image.isConnected !== false) image.src = customIcon;
    });
  }

  function refreshAll() {
    readCustomIcon((customIcon) => {
      registeredImages.forEach((image) => {
        if (!image || image.isConnected === false) {
          registeredImages.delete(image);
          return;
        }
        image.src = customIcon || runtimeUrl(image.dataset.seeyonIconFallback || 'icons/fab-84.png');
      });
    });
  }

  root.SeeyonIcon = Object.freeze({
    STORAGE_KEY,
    applyToImage,
    centerCropRect,
    isCustomIconDataUrl,
    runtimeUrl
  });

  try {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local' && changes[STORAGE_KEY]) refreshAll();
    });
  } catch (_) {}

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { centerCropRect, isCustomIconDataUrl };
  }
})(typeof window !== 'undefined' ? window : globalThis);
