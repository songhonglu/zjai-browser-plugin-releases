// =============================================================================
// shared/launcher.js —— 统一悬浮球 + 菜单（方案 B：单球 + 菜单分流）
// =============================================================================
// 在 xt.seeyon.com 工单页注入，作为 ②冲突雷达 与 ③工单速配 的统一入口：
//   1. 隐藏 ②③ 各自的自带悬浮球（#v5cs-fab、#seeyon-bug-flow-host）；
//      ② 的结果面板 #v5cs-panel 保留，由菜单触发的 conflict-open 事件打开。
//   2. 轮询 <html> 上的 data-* 属性（由 ②③ 写入），据此显示菜单项：
//        data-seeyon-conflict = "1"           → 「🔧 代码冲突检测」
//        data-seeyon-engineer = "张三"(非空)   → 「👤 推荐工程师：张三」
//      至少有一项可用才显示统一球；菜单项按可用性动态显隐。
//   3. 菜单点击：
//        冲突检测 → dispatch CustomEvent('seeyon-helper:conflict-open')（②监听→打开面板）
//        推荐工程师 → 复制姓名到剪切板；附带「查看工单」链接（data-seeyon-engineer-affair）
//   4. 球可拖动，位置记忆（chrome.storage.local）。
//
// 用 <html> 上的 data 属性作 IPC，规避多脚本注入的时序问题（launcher 不必早于 ②③）。
// =============================================================================
(function () {
  if (window.__seeyon_launcher) return;              // 防重复注入（每框架独立 window）
  window.__seeyon_launcher = true;

  // ---- 隐藏 ②③ 自带球（保留 ② 面板 #v5cs-panel，由事件触发显示）----
  const hideStyle = document.createElement('style');
  hideStyle.textContent =
    '#v5cs-fab{display:none!important}' +
    '#seeyon-bug-flow-host{display:none!important}';
  (document.head || document.documentElement).appendChild(hideStyle);

  // ---- 日志（统一前缀 [kk-helper:launcher]，便于按模块排查）----
  const LOG = {
    info: (...a) => console.log('[kk-helper:launcher]', ...a),
    warn: (...a) => console.warn('[kk-helper:launcher]', ...a),
    debug: (...a) => console.debug('[kk-helper:launcher]', ...a),
  };
  LOG.info('loaded @ ' + location.href);

  // ---- 宿主 + Shadow DOM（样式隔离）----
  const host = document.createElement('div');
  host.id = 'seeyon-helper-launcher';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;';
  const shadow = host.attachShadow({ mode: 'open' });
  shadow.innerHTML = `
    <style>
      #ball {
        width:42px;height:42px;border-radius:50%;
        background:#fff;
        color:#fff;font-size:11px;font-weight:700;letter-spacing:.5px;line-height:1.15;
        display:flex;align-items:center;justify-content:center;text-align:center;
        cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;
        box-shadow:0 4px 14px rgba(56,189,248,.45);
        border:2px solid #fff;font-family:"Microsoft YaHei",sans-serif;
        overflow:hidden;
        transition:transform .15s ease;
      }
      #ball img { width:42px;height:42px;display:block;object-fit:cover;pointer-events:none; }
      #ball:hover { transform:scale(1.06); }
      #ball:active { cursor:grabbing; }
      #ball.has-conflict { box-shadow:0 4px 14px rgba(14,165,233,.55); }
      .menu {
        position:absolute;right:64px;top:0;min-width:230px;
        background:#fff;border-radius:10px;padding:6px;
        box-shadow:0 8px 30px rgba(0,0,0,.18);
        font-family:"Microsoft YaHei",sans-serif;
        display:none;
      }
      .menu.show { display:block; }
      .item {
        display:flex;align-items:center;gap:10px;width:100%;
        padding:10px 12px;border:none;background:transparent;cursor:pointer;
        border-radius:8px;font-size:13px;color:#1f2937;text-align:left;
      }
      .item:hover { background:#eff6ff; }
      .item .ico { font-size:16px; flex:none; }
      .item .main { flex:1; min-width:0; }
      .item .main b { display:block; font-weight:600; font-size:13px; }
      .item .main span { display:block; font-size:11px; color:#6b7280; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
      .link {
        display:block;padding:6px 12px;font-size:11px;color:#3b82f6;
        text-decoration:none;border-radius:6px;
      }
      .link:hover { background:#eff6ff; }
    </style>
    <div class="menu" id="menu">
      <button class="item" id="i-conflict" style="display:none">
        <span class="ico">🔧</span>
        <span class="main"><b>代码冲突检测</b><span>比对源码补丁与客开 V5 仓库</span></span>
      </button>
      <button class="item" id="i-engineer" style="display:none">
        <span class="ico">👤</span>
        <span class="main"><b>推荐工程师</b><span id="eng-name">—</span></span>
      </button>
      <a class="link" id="i-engineer-link" style="display:none" target="_blank" rel="noopener noreferrer">查看该历史工单 ↗</a>
    </div>
    <button id="ball" title="ZJAI" aria-label="ZJAI"><img id="ball-logo" alt=""></button>
  `;
  document.documentElement.appendChild(host);

  const ball = shadow.getElementById('ball');
  const ballLogo = shadow.getElementById('ball-logo');
  try { SeeyonIcon.applyToImage(ballLogo, 'icons/fab-84.png'); } catch (_) {}
  const menu = shadow.getElementById('menu');
  const iConflict = shadow.getElementById('i-conflict');
  const iEngineer = shadow.getElementById('i-engineer');
  const engName = shadow.getElementById('eng-name');
  const iEngLink = shadow.getElementById('i-engineer-link');

  // ---- 位置记忆 ----
  const POS_KEY = 'seeyonhelper:fabpos';
  const SIZE = 42;
  function setPos(left, top) {
    left = Math.max(0, Math.min(window.innerWidth - SIZE, left));
    top = Math.max(0, Math.min(window.innerHeight - SIZE, top));
    host.style.left = left + 'px';
    host.style.top = top + 'px';
  }
  function savePos() {
    try {
      chrome.storage.local.set({ [POS_KEY]: { left: parseFloat(host.style.left) || 0, top: parseFloat(host.style.top) || 0 } });
    } catch (_) {}
  }
  function initPos() {
    try {
      chrome.storage.local.get(POS_KEY, (res) => {
        const p = res && res[POS_KEY];
        if (p && typeof p.left === 'number') setPos(p.left, p.top);
        else setPos(window.innerWidth - SIZE - 24, window.innerHeight / 2 - SIZE / 2);
      });
    } catch (_) {
      setPos(window.innerWidth - SIZE - 24, window.innerHeight / 2 - SIZE / 2);
    }
  }
  window.addEventListener('resize', () => setPos(parseFloat(host.style.left) || 0, parseFloat(host.style.top) || 0));

  // ---- 拖动 + 点击（区分）----
  let pressing = false, moved = false, sx = 0, sy = 0, offX = 0, offY = 0;
  ball.addEventListener('pointerdown', (e) => {
    pressing = true; moved = false; sx = e.clientX; sy = e.clientY;
    const r = host.getBoundingClientRect();
    offX = e.clientX - r.left; offY = e.clientY - r.top;
    try { ball.setPointerCapture(e.pointerId); } catch (_) {}
  });
  ball.addEventListener('pointermove', (e) => {
    if (!pressing) return;
    if (!moved && Math.hypot(e.clientX - sx, e.clientY - sy) > 5) moved = true;
    if (moved) setPos(e.clientX - offX, e.clientY - offY);
  });
  const end = (e) => {
    if (!pressing) return;
    pressing = false;
    try { ball.releasePointerCapture(e.pointerId); } catch (_) {}
    if (moved) savePos();
    else toggleMenu();
  };
  ball.addEventListener('pointerup', end);
  ball.addEventListener('pointercancel', end);

  function toggleMenu() { menu.classList.toggle('show'); }

  // 点击页面空白处关闭菜单（shadow 内点击的 e.target 会 retarget 到 host）
  const isInsideLauncher = function (e) {
    if (!e) return false;
    const path = typeof e.composedPath === 'function' ? e.composedPath() : [];
    if (path && path.length) {
      return path.indexOf(host) >= 0 || path.indexOf(shadow) >= 0 || path.indexOf(menu) >= 0;
    }
    return e.target === host || host.contains(e.target) || host === e.target.getRootNode().host;
  };

  const stopClose = function (e) {
    e.stopPropagation();
  };
  ball.addEventListener('pointerdown', stopClose);
  menu.addEventListener('pointerdown', stopClose);
  iConflict.addEventListener('pointerdown', stopClose);
  iEngineer.addEventListener('pointerdown', stopClose);
  iEngLink.addEventListener('pointerdown', stopClose);

  document.addEventListener('pointerdown', (e) => {
    if (!menu.classList.contains('show')) return;
    if (isInsideLauncher(e)) return;
    menu.classList.remove('show');
  });

  // ---- 菜单项交互 ----
  iConflict.addEventListener('click', () => {
    menu.classList.remove('show');
    document.dispatchEvent(new CustomEvent('seeyon-helper:conflict-open'));
  });
  iEngineer.addEventListener('click', async () => {
    const name = document.documentElement.getAttribute('data-seeyon-engineer') || '';
    if (!name) return;
    menu.classList.remove('show');
    const ok = await copyText(name);
    flash(ok ? '已复制' : '复制失败');
  });

  async function copyText(t) {
    try { await navigator.clipboard.writeText(t); return true; } catch (_) {}
    try {
      const ta = document.createElement('textarea');
      ta.value = t; ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
      document.body.appendChild(ta); ta.focus(); ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (_) { return false; }
  }

  // 球上临时反馈
  let flashTimer = null;
  function flash(msg) {
    ballLogo.style.display = 'none';
    ball.textContent = msg;
    if (flashTimer) clearTimeout(flashTimer);
    flashTimer = setTimeout(() => { ballLogo.style.display = ''; ball.textContent = ''; ball.appendChild(ballLogo); }, 1500);
  }

  // ---- 读取 BUG 工单标题 subject ----
  // 1) 当前/同源 parent/top 文档的 #subject
  // 2) window.subject / window.top.subject
  // 3) 文档标题（新页面 subject 未落到 #subject 时）
  function readSubject() {
    const norm = (v) => String(v || '').replace(/^﻿+/, '').trim();
    const docs = [];
    const seen = new Set();
    const collectFrom = (doc) => {
      if (!doc || seen.has(doc)) return;
      seen.add(doc);
      docs.push(doc);

      let frames = [];
      try {
        frames = Array.from(doc.querySelectorAll('iframe')).map((iframe) => {
          try { return iframe.contentDocument; } catch (_) { return null; }
        }).filter(Boolean);
      } catch (_) {
        frames = [];
      }
      for (const f of frames) collectFrom(f);
    };

    // 先收集当前文档，再收集顶部文档（若同源且未重复）
    collectFrom(document);
    try {
      if (window.top && window.top.document && window.top.document !== document) {
        collectFrom(window.top.document);
      }
    } catch (_) {}

    for (const doc of docs) {
      try {
        const el = doc.querySelector('#subject');
        if (el) {
          const val = el.value != null ? el.value : (el.getAttribute('value') || '');
          const s = norm(val);
          if (s) return s;
        }
      } catch (_) {}
    }

    for (const doc of docs) {
      try {
        const win = doc.defaultView;
        if (win && typeof win.subject === 'string') {
          const s = norm(win.subject);
          if (s) return s;
        }
      } catch (_) {}
    }

    for (const doc of docs) {
      try {
        const s = norm(doc.title);
        if (s) return s;
      } catch (_) {}
    }

    return '';
  }

  function hasTopLauncherHost() {
    if (window.top === window) return false;
    try {
      return Boolean(window.top && window.top.document && window.top.document.getElementById('seeyon-helper-launcher'));
    } catch (_) {
      return false;
    }
  }

  // ---- 轮询 ②③ 状态（DOM 属性 IPC）----
  let lastVisible = null;
  let lastHiddenReason = '';
  function poll() {
    // 顶部已挂载统一入口时，子 frame 不再重复显示（避免阴影球重复出现）
    if (hasTopLauncherHost()) {
      host.style.display = 'none';
      menu.classList.remove('show');
      return;
    }

    const conflict = document.documentElement.getAttribute('data-seeyon-conflict') === '1';
    const engineer = document.documentElement.getAttribute('data-seeyon-engineer') || '';
    const affair = document.documentElement.getAttribute('data-seeyon-engineer-affair') || '';
    // ★ 仅 BUG 工单页（subject 含 _BUG20）才显示统一球
    const subject = readSubject();
    const subjectContainsBug20 = subject.indexOf('_BUG20') >= 0;
    const isBugPage = subjectContainsBug20;
    const hasConflictMenu = Boolean(conflict);
    const hasEngineerMenu = Boolean(engineer);
    const hasAnyMenuItem = hasConflictMenu || hasEngineerMenu;

    let any = false;
    // 冲突检测项
    iConflict.style.display = conflict ? 'flex' : 'none';
    if (conflict) any = true;
    // 工程师项
    if (engineer) {
      iEngineer.style.display = 'flex';
      engName.textContent = engineer + '（点击复制）';
      any = true;
      if (affair) {
        iEngLink.style.display = 'block';
        iEngLink.href = 'https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=listDone&affairId=' + encodeURIComponent(affair) + '&showTab=true';
      } else {
        iEngLink.style.display = 'none';
      }
    } else {
      iEngineer.style.display = 'none';
      iEngLink.style.display = 'none';
    }

    // 球的显隐：必须是 BUG 工单页，且至少有一项可用，才显示（避免空菜单 / 非 BUG 页打扰）
    if (isBugPage && any) {
      if (lastVisible !== true) LOG.info('[入口] 统一悬浮球显示', { conflict, engineer: engineer || '(无)', subject });
      lastVisible = true;
      lastHiddenReason = '';
      host.style.display = '';
      ball.classList.toggle('has-conflict', conflict && !engineer);
    } else {
      const reason = !isBugPage ? '非 BUG 工单页或未读取到 _BUG20 标题' : '没有可用菜单项（冲突检测/推荐工程师均未就绪）';
      const key = reason + '|subject=' + subject + '|conflict=' + conflict + '|engineer=' + Boolean(engineer);
      if (lastVisible !== false || lastHiddenReason !== key) {
        LOG.info('[入口] 统一悬浮球不显示：目标页/菜单条件未满足', {
          reason,
          url: location.href,
          bugPageRule: {
            subject: subject || '(空)',
            expectedSubjectContains: '_BUG20',
            subjectContainsBug20,
            isBugPage
          },
          menuRule: {
            conflictAttribute: document.documentElement.getAttribute('data-seeyon-conflict') || '(空)',
            hasConflictMenu,
            engineer: engineer || '(空)',
            hasEngineerMenu,
            hasAnyMenuItem
          }
        });
      }
      lastVisible = false;
      lastHiddenReason = key;
      host.style.display = 'none';
      menu.classList.remove('show');
    }
  }

  initPos();
  poll();
  setInterval(poll, 600);
})();
