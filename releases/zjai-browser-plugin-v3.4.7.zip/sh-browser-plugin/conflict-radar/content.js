// V5 源码冲突检测 —— content script（经典脚本，无 import/export）。
// 在 BUG 工单页所在框架运行（manifest all_frames）：注入悬浮球（右侧随机初始位置、可拖动、位置记忆）+ 结果面板；
// 负责 DOM 抽取（源码附件 / 表单参数）并响应 background 的 RPC。
(function () {
  if (window.__v5cs_injected) return;                // 防重复注入（每框架独立 window）
  window.__v5cs_injected = true;
  console.log('[kk-helper:conflict-radar] content loaded @ ' + location.href);

  // ---------- 工具 ----------
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
  }
  function getQueryParam(href, name) {
    try {
      const u = new URL(href);
      const l = name.toLowerCase();
      for (const [k, v] of u.searchParams) if (k.toLowerCase() === l) return v;
    } catch (_) { /* ignore */ }
    return '';
  }
  function normalizePath(p) {
    if (!p) return '';
    let s = String(p).replace(/\\/g, '/').trim();
    s = s.replace(/^\.\//, '').replace(/^\/+/, '').replace(/\/+$/, '');
    return s;
  }
  function basenameOf(p) {
    const n = normalizePath(p);
    if (!n) return '';
    const i = n.lastIndexOf('/');
    return i < 0 ? n : n.slice(i + 1);
  }
  function compactLogList(items, limit = 5) {
    if (!Array.isArray(items) || !items.length) return '(none)';
    const names = items.slice(0, limit).map((it) => it && (it.fileName || it.name) ? (it.fileName || it.name) : '(unnamed)');
    return names.join('、') + (items.length > limit ? `（共 ${items.length} 个，截断展示）` : `（共 ${items.length} 个）`);
  }
  function logCollectDebug(type, stage, result, details) {
    const count = result && Array.isArray(result.items) ? result.items.length : 0;
    const reason = result && result.reason ? result.reason : 'ok';
    const debug = result && result.debug ? result.debug : null;
    console.log('[kk-helper:conflict-radar][content-rpc]', '[COLLECT]', type, stage, 'reason=' + reason, 'items=' + count, 'detail=' + (details || '-'), debug ? ('debug=' + JSON.stringify(debug)) : '');
  }
  function logRpcTrace(msgType, id, status, payload, startTs) {
    const cost = typeof startTs === 'number' ? (Date.now() - startTs) : null;
    if (payload && payload.items) {
      const items = payload.items;
      const reason = payload.reason || 'ok';
      console.log('[kk-helper:conflict-radar][content-rpc]', '[RPC]', msgType + '#' + id, status, `reason=${reason}`, `items=${items.length}`, `cost=${cost != null ? cost + 'ms' : '-'}`, `names=${compactLogList(items)}`);
    } else {
      const reason = payload && payload.reason ? payload.reason : 'ok';
      console.log('[kk-helper:conflict-radar][content-rpc]', '[RPC]', msgType + '#' + id, status, `reason=${reason}`, `cost=${cost != null ? cost + 'ms' : '-'}`);
    }
  }
  function resolveContextHref(href) {
    try { return href ? new URL(href) : null; } catch (_) { return null; }
  }
  function readQueryFromHref(href, key) {
    const url = resolveContextHref(href);
    if (!url) return '';
    return url.searchParams.get(key) || '';
  }
  function collectQueryHints() {
    const hrefs = [];
    hrefs.push(location.href);
    try { if (window.top && window.top !== window && window.top.location) hrefs.push(window.top.location.href); } catch (_) {}
    try { if (window.parent && window.parent !== window && window.parent.location) hrefs.push(window.parent.location.href); } catch (_) {}
    let method = '';
    let affairId = '';
    for (const href of hrefs) {
      const vMethod = readQueryFromHref(href, 'method').toLowerCase();
      const vAffair = readQueryFromHref(href, 'affairId') || readQueryFromHref(href, 'affairid') || readQueryFromHref(href, 'objId');
      if (!method && vMethod) method = vMethod;
      if (!affairId && vAffair) affairId = vAffair;
      if (method && affairId) break;
    }
    return { method, affairId, byQuery: method === 'summary' && !!affairId };
  }
  function allDocs() {
    const docs = [document];
    const walk = (win) => {
      try {
        for (let i = 0; i < win.frames.length; i++) {
          const d = win.frames[i].document; // 跨域会抛错
          if (d) { docs.push(d); walk(win.frames[i]); }
        }
      } catch (_) { /* cross-origin iframe */ }
    };
    walk(window);
    return docs;
  }
  function findByIdDeep(id) {
    for (const d of allDocs()) {
      try { const el = d.getElementById(id); if (el) return el; } catch (_) { /* ignore */ }
    }
    return null;
  }

  // ---------- DOM 抽取 ----------
  // seeyon cap4 附件：文件下载由 `cap4-attach` Vue 组件在点击时用 JS 拼出
  //   /seeyon/fileDownload.do?method=doDownload&filename=..&v=..&fileId=..&createDate=..
  // 其中 v 为服务端下发的令牌（不可前端推算），存在于组件实例数据中、不在 HTML 里。
  // 故优先从 Vue 组件读附件元数据拼 URL；HTML 内若直接含 fileDownload.do 则兜底用之。
  // （HTML 里的 batchDownload「全部下载」直接 GET 会 404，一律跳过。）

  // 从对象上按字段名（大小写无关）取「标量」值
  function pickField(obj, names) {
    if (!obj || typeof obj !== 'object') return '';
    const lower = names.map((n) => n.toLowerCase());
    for (const k of Object.keys(obj)) {
      const i = lower.indexOf(k.toLowerCase());
      if (i >= 0 && obj[k] != null && typeof obj[k] !== 'object') return obj[k];
    }
    return '';
  }

  // 在 .cap4-attach 及其祖先上查找 Vue 实例句柄（Vue2: __vue__；Vue3: __vueParentComponent）
  function findVueInstance(rootEl) {
    const start = rootEl.querySelector('.cap4-attach') || rootEl;
    let cur = start, depth = 0;
    while (cur && depth < 12) {
      if (cur.__vue__) return { handle: '__vue__', inst: cur.__vue__ };
      if (cur.__vueParentComponent) return { handle: '__vueParentComponent__', inst: cur.__vueParentComponent };
      cur = cur.parentElement; depth++;
    }
    return null;
  }
  // 从实例收集候选数据对象（Vue2/Vue3 位置不同）
  function vueDataObjects(inst) {
    const out = [];
    const push = (o) => { if (o && typeof o === 'object') out.push(o); };
    push(inst.$data); push(inst.data); push(inst.setupState);
    if (inst.proxy) { push(inst.proxy.$data); push(inst.proxy); }
    push(inst.$props); push(inst.props); push(inst.ctx);
    return out;
  }
  // 扫描 Vue 实例数据，收集附件对象（含 fileId）
  function findVueAttachments(rootEl) {
    const found = findVueInstance(rootEl);
    if (!found) return { attachments: [], handle: null };
    const atts = [];
    const seen = new WeakSet();
    const looksLikeAtt = (o) =>
      o && typeof o === 'object' && !Array.isArray(o) && typeof o.nodeType !== 'number' &&
      String(pickField(o, ['fileId'])).length > 0;
    const walk = (o, d) => {
      if (d > 6 || o == null || typeof o !== 'object') return;
      if (typeof o.nodeType === 'number') return;
      if (seen.has(o)) return; seen.add(o);
      if (looksLikeAtt(o)) {
        const flat = {};
        Object.keys(o).forEach((k) => {
          const v = o[k];
          if (typeof v !== 'function' && !(v && typeof v === 'object')) flat[k] = v;
        });
        atts.push(flat);
      }
      if (Array.isArray(o)) { o.slice(0, 300).forEach((x) => walk(x, d + 1)); return; }
      Object.keys(o).forEach((k) => { if (k[0] === '_') return; try { walk(o[k], d + 1); } catch (_) { /* ignore */ } });
    };
    vueDataObjects(found.inst).forEach((o) => { try { walk(o, 0); } catch (_) { /* ignore */ } });
    return { attachments: atts, handle: found.handle };
  }

  function buildFileDownloadUrl(att) {
    const fileId = String(pickField(att, ['fileId', 'fileid']) || '');
    if (!fileId) return null;
    const p = new URLSearchParams();
    p.set('method', 'doDownload');
    const filename = pickField(att, ['filename', 'filenameStr', 'name']);
    const v = pickField(att, ['v', 'token']);
    const createDate = pickField(att, ['createDate', 'creationDate', 'createdate']);
    if (filename) p.set('filename', filename);
    if (v) p.set('v', String(v));
    p.set('fileId', fileId);
    if (createDate) p.set('createDate', createDate);
    return '/seeyon/fileDownload.do?' + p.toString();
  }

  // "OrgChangeEventImp.java (6KB)" -> "OrgChangeEventImp.java"
  function parseAttName(text) {
    let t = String(text || '').trim();
    t = t.replace(/\s*\([^)]*\)\s*$/, '').trim();
    return t;
  }
  // 可下载解压：zip 类 + tar + rar（下载后按内容识别 zip/tar/rar）；7z/gz 等暂不支持自动解压 -> 手工
  const ARCHIVE_DOWNLOADABLE = /\.(zip|jar|war|ear|tar|tgz|tar\.gz|rar)$/i;
  const PAK_RE = /\.pak$/i; // 致远补丁包：本质加密 zip，下载后读中央目录取 .class 文件名
  const OTHER_ARCHIVE = /\.(7z|gz|bz2|arj|lzh|cab)$/i;
  const isArchiveName = (n) => ARCHIVE_DOWNLOADABLE.test(n) || PAK_RE.test(n) || OTHER_ARCHIVE.test(n);

  // 尽力收集下载 URL（仅压缩包需要，用于解压取真实文件名）
  function collectDownloadUrls(rootEl, fieldId) {
    const urls = [];
    const seen = new Set();
    const push = (rawUrl, fileName) => {
      if (!rawUrl) return;
      const url = String(rawUrl).trim();
      if (!url || url === '#' || /^javascript:/i.test(url)) return;
      if (/\/batchDownload/i.test(url)) return; // 批量 zip 直接 GET 会 404，跳过
      let abs;
      try { abs = new URL(url, location.href).href; } catch (_) { return; }
      if (seen.has(abs)) return; seen.add(abs);
      urls.push({ url: abs, fileName: (getQueryParam(abs, 'filename') || fileName || '').trim() });
    };
    const html = rootEl.outerHTML || '';
    const re = /fileDownload\.do\?[^\s"'<>)}\]]+/gi;
    let m;
    while ((m = re.exec(html))) push(m[0]);
    if (!urls.length) {
      const r = findVueAttachments(rootEl);
      (r.attachments || []).forEach((att) => {
        const u = buildFileDownloadUrl(att);
        if (u) push(u, pickField(att, ['filename', 'name']));
      });
    }
    return urls;
  }

  // 点击「指定字段下、文件名匹配的单个附件」下载图标。
  // 关键：background 串行逐个点击+捕获，避免同时点击多个下载图标时 cap4 的单导航机制
  // （location.href 等）只真正发起一个下载、其余 URL 丢失。
  function clickOneDownload(fieldId, fileName) {
    const root = findByIdDeep(fieldId);
    if (!root) return { clicked: 0 };
    const icons = root.querySelectorAll('.cap4-attach__download');
    if (!icons.length) return { clicked: 0 };

    // 1) 按文件名定位：找展示名匹配的元素，在其共同祖先行内取下载图标
    let nameEls = root.querySelectorAll('.cap4-attach__aright span');
    if (!nameEls.length) nameEls = root.querySelectorAll('.cap4-attach__aright, .cap4-attach__att');
    for (const s of nameEls) {
      if (parseAttName(s.textContent) === fileName) {
        let row = s.parentElement;
        for (let i = 0; i < 6 && row; i++) {
          const ic = row.querySelector('.cap4-attach__download');
          if (ic) { try { ic.click(); } catch (_) { /* ignore */ } return { clicked: 1 }; }
          row = row.parentElement;
        }
      }
    }
    // 1.5) 如果文件名匹配失败，兜底用显示文本/行 data-name 对齐
    const fallbackName = String(fileName || '').trim();
    if (fallbackName) {
      const attRows = root.querySelectorAll('.cap4-attach__att');
      for (const row of attRows) {
        const txt = parseAttName(row.textContent);
        const dataName = String((row.dataset && row.dataset.name) || '').trim();
        if (txt === fallbackName || dataName === fallbackName) {
          const ic = row.querySelector('.cap4-attach__download');
          if (ic) { try { ic.click(); } catch (_) { /* ignore */ } return { clicked: 1 }; }
        }
      }
    }
    // 2) 兜底：该字段仅一个下载图标（一字段一附件的常见场景）→ 直接点
    if (icons.length === 1) { try { icons[0].click(); } catch (_) { /* ignore */ } return { clicked: 1 }; }
    // 3) 兜底：同字段多个图标时，选同容器里的第一个可用下载图标
    if (icons.length > 0) {
      const firstFieldIcon = Array.from(icons).find((ic) => {
        const parent = ic.closest('.cap4-attach');
        return !parent || parent.closest(`#${fieldId}`) !== null || (fieldId && parent.closest(`[id="${fieldId}"]`) !== null);
      });
      if (firstFieldIcon) { try { firstFieldIcon.click(); } catch (_) { /* ignore */ } return { clicked: 1 }; }
    }
    return { clicked: 0 };
  }

  function extractAttachments(rootEl, fieldId) {
    const items = [];
    const seenName = new Set();

    // 主要：从附件展示文本读文件名（单个源码文件无需下载，直接用于匹配）
    let nameEls = rootEl.querySelectorAll('.cap4-attach__aright span');
    if (!nameEls.length) nameEls = rootEl.querySelectorAll('.cap4-attach__aright');
    if (!nameEls.length) nameEls = rootEl.querySelectorAll('.cap4-attach__att');
    nameEls.forEach((el) => {
      const name = parseAttName(el.textContent);
      if (!name || seenName.has(name)) return;
      seenName.add(name);
      if (PAK_RE.test(name)) items.push({ fileName: name, needUrl: true, from: fieldId });                    // 补丁包：下载后按加密 zip 取文件名
      else if (ARCHIVE_DOWNLOADABLE.test(name)) items.push({ fileName: name, needUrl: true, from: fieldId }); // 下载后按内容识别 zip/tar/rar
      else if (OTHER_ARCHIVE.test(name)) items.push({ fileName: name, manual: true, from: fieldId }); // 不支持自动解压 -> 手工
      else items.push({ fileName: name, nameOnly: true, from: fieldId });                              // 单文件，无需下载
    });

    // zip 类：若 HTML 内能直接取到 fileDownload.do 则先用之，免点击；否则 needUrl 留待 background 经 chrome.downloads 捕获
    const zipItems = items.filter((it) => it.needUrl);
    if (zipItems.length) {
      const urls = collectDownloadUrls(rootEl, fieldId);
      urls.forEach((u) => {
        const exist = zipItems.find((it) => it.fileName === u.fileName);
        if (exist) { exist.url = u.url; delete exist.needUrl; }
        else items.push({ url: u.url, fileName: u.fileName, from: fieldId });
      });
    }
    // eslint-disable-next-line no-console
    if (!items.length) console.warn('[kk-helper:conflict-radar] field=' + fieldId + ' 未解析出附件（无展示文件名、无下载 URL）');
    return items;
  }

  function collectSource() {
    const ids = ['field1537_id', 'field1237_id'];
    const items = [];
    let foundAny = false;
    const trace = [];
    for (const id of ids) {
      const el = findByIdDeep(id);
      if (!el) { trace.push(id + ':no-node'); continue; }
      foundAny = true;
      const list = extractAttachments(el, id);
      trace.push(id + ':count=' + list.length + '|' + compactLogList(list));
      items.push(...list);
    }
    const result = !foundAny
      ? { items: [], reason: 'no-field' }
      : !items.length
        ? { items: [], reason: 'no-link' }
        : { items };
    logCollectDebug('source', 'collect', result, trace.join(' ; '));
    return result;
  }

  // 收集 field1244_id 下的 .pak 补丁包附件（needUrl：下载后读加密 zip 取文件名）
  function collectPak() {
    const id = 'field1244_id';
    const trace = [];
    const el = findByIdDeep(id);
    if (!el) {
      const result = { items: [], reason: 'no-field' };
      logCollectDebug('pak', 'collect', result, trace.join(' ; '));
      return result;
    }
    const raw = extractAttachments(el, id);
    const items = raw.filter((it) => PAK_RE.test(it.fileName));
    trace.push('raw=' + raw.length + ' pak=' + items.length);
    const result = !items.length
      ? { items: [], reason: 'no-pak' }
      : { items };
    logCollectDebug('pak', 'collect', result, trace.join(' ; '));
    return result;
  }

  function extractForm() {
    const sEl = findByIdDeep('summaryId');
    const moduleId = ((sEl && (sEl.value || sEl.getAttribute('value'))) || '').trim();
    let rightId = '';
    const scriptsText = allDocs().map(d => {
      try { return Array.from(d.scripts).map(s => s.textContent || '').join('\n'); } catch (_) { return ''; }
    }).join('\n');
    const m = scriptsText.match(/formViewOperation\s*=\s*['"]([^'"]+)['"]/);
    if (m) rightId = m[1].trim();
    // affairId 来源：当前框架 URL 优先；iframe 场景下当前框架 URL 可能不含 affairId，
    // 回退向上(父/顶层)与向下(同源子 iframe)各框架 URL 的查询参数。
    let affairId = getQueryParam(location.href, 'affairId')
      || getQueryParam(location.href, 'affairid')
      || getQueryParam(location.href, 'objId');
    if (!affairId) {
      const urls = [];
      try { if (window.parent && window.parent !== window) urls.push(window.parent.location.href); } catch (_) {}
      try { urls.push(window.top.location.href); } catch (_) {}
      try { allDocs().forEach(d => { try { if (d && d.URL) urls.push(d.URL); } catch (_) {} }); } catch (_) {}
      for (const u of urls) {
        const v = getQueryParam(u, 'affairId') || getQueryParam(u, 'affairid') || getQueryParam(u, 'objId');
        if (v) { affairId = v; break; }
      }
    }
    return { moduleId, rightId, affairId };
  }

  // ---------- UI ----------
  const FAB_W = 42, FAB_H = 42, MARGIN = 16;
  const SECTIONS = ['source', 'pak'];
  const STEP_KEYS = ['source', 'gitlab'];
  // 步骤标签：两区块仅保留各自差异步骤（识别 + 比对）；加密狗号/仓库信息提到顶部共享信息栏展示
  const STEP_LABELS = { gitlab: '冲突检测' };
  const stepLabel = (section, key) =>
    key === 'source' ? (section === 'pak' ? '识别补丁包' : '识别源码') : (STEP_LABELS[key] || key);
  // stepState[section][stepKey] = {status, message}；两区块各自独立，「加密狗/仓库/比对」共享进度时同步写入两份
  const stepState = { source: {}, pak: {} };
  const conflictCounts = { source: 0, pak: 0 };

  const fab = document.createElement('div');
  fab.id = 'v5cs-fab';
  fab.title = 'SHAI';
  fab.innerHTML = '<img alt=""><span class="v5cs-badge"></span>';
  try { fab.querySelector('img').src = chrome.runtime.getURL('icons/fab-84.png'); } catch (_) {}

  const panel = document.createElement('div');
  panel.id = 'v5cs-panel';
  panel.innerHTML =
    '<div class="v5cs-head"><b>V5 冲突检测</b>' +
    '<button class="v5cs-close" title="关闭">×</button></div>' +
    '<div class="v5cs-body">' +
    '<div class="v5cs-notice">⚠️ 本工具会读取当前工单的源码附件与<b>.pak 补丁包</b>，并与客开 GitLab「V5 目录」下<b>已提交</b>的代码进行路径/文件名比对；其中<b>文件名命中请重点核对</b>，未提交到仓库的改动无法检出。检测结果仅供参考，最终冲突判断请以人工核对为准。' +
    '<span class="v5cs-help" title="原理：取当前 BUG 单源码附件/补丁包与加密狗号；用加密狗号查 cTPStudio 客开项目/分支；再拉 GitLab V5 文件列表，与源码路径/文件名比对。补丁包为加密 zip，读其 .class 文件名推回源码名后参与比对。">?</span></div>' +
    '<div id="v5cs-shared" class="v5cs-shared"></div>' +
    '<section class="v5cs-block" data-section="source">' +
      '<div class="v5cs-block-h"><b>V5 源码冲突检测</b><span class="v5cs-block-sub">源码附件 ↔ 客开仓库</span></div>' +
      '<div class="v5cs-steps" data-section="source"></div>' +
      '<div class="v5cs-detail" data-section="source"></div>' +
    '</section>' +
    '<section class="v5cs-block" data-section="pak">' +
      '<div class="v5cs-block-h"><b>V5 补丁包冲突检测</b><span class="v5cs-block-sub">.pak 产物 ↔ 客开仓库</span></div>' +
      '<div class="v5cs-steps" data-section="pak"></div>' +
      '<div class="v5cs-detail" data-section="pak"></div>' +
    '</section>' +
    '<details class="v5cs-logwrap"><summary>运行日志</summary><pre id="v5cs-log" class="v5cs-log"></pre></details>' +
    '<div class="v5cs-btns">' +
    '<button class="v5cs-btn" id="v5cs-run">重新检测</button>' +
    '</div>' +
    '</div>';

  function mount() {
    if (fab.isConnected) {
      console.log('[kk-helper:conflict-radar]', '[入口] 冲突检测悬浮球已挂载，跳过重复挂载');
      return;
    }
    document.documentElement.appendChild(fab);
    document.documentElement.appendChild(panel);
    fab.querySelector('span'); // noop
    panel.querySelector('.v5cs-close').addEventListener('click', () => panel.classList.remove('v5cs-show'));
    panel.querySelector('#v5cs-run').addEventListener('click', startDetect);
    bindDrag();
    initPosition();
    window.addEventListener('resize', clampFab);
    // 通知统一启动器（shared/launcher.js）：冲突检测入口已就绪
    try { document.documentElement.setAttribute('data-seeyon-conflict', '1'); } catch (_) {}
  }

  // ---- 悬浮球位置：记忆优先，否则右侧随机 ----
  function setFabPos(left, top) {
    fab.style.left = clamp(left, 0, window.innerWidth - FAB_W) + 'px';
    fab.style.top = clamp(top, 0, window.innerHeight - FAB_H) + 'px';
  }
  function clampFab() {
    const l = parseFloat(fab.style.left) || 0;
    const t = parseFloat(fab.style.top) || 0;
    setFabPos(l, t);
  }
  function initPosition() {
    try {
      chrome.storage.local.get('v5cs:fabpos', (res) => {
        const pos = res && res['v5cs:fabpos'];
        if (pos && typeof pos.left === 'number' && typeof pos.top === 'number') {
          setFabPos(pos.left, pos.top);
        } else {
          // 右侧随机一个位置
          const top = 80 + Math.floor(Math.random() * Math.max(40, window.innerHeight - FAB_H - 160));
          setFabPos(window.innerWidth - FAB_W - MARGIN, top);
        }
      });
    } catch (_) {
      const top = 80 + Math.floor(Math.random() * Math.max(40, window.innerHeight - FAB_H - 160));
      setFabPos(window.innerWidth - FAB_W - MARGIN, top);
    }
  }
  function savePos() {
    try {
      chrome.storage.local.set({
        'v5cs:fabpos': { left: parseFloat(fab.style.left) || 0, top: parseFloat(fab.style.top) || 0 },
      });
    } catch (_) { /* ignore */ }
  }

  // ---- 拖动（pointer 事件，区分点击/拖动）----
  function bindDrag() {
    let pressing = false, moved = false, offX = 0, offY = 0, sx = 0, sy = 0;
    fab.addEventListener('pointerdown', (e) => {
      pressing = true; moved = false; sx = e.clientX; sy = e.clientY;
      const r = fab.getBoundingClientRect();
      offX = e.clientX - r.left; offY = e.clientY - r.top;
      try { fab.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
      fab.classList.add('v5cs-dragging');
    });
    fab.addEventListener('pointermove', (e) => {
      if (!pressing) return;
      if (!moved && Math.hypot(e.clientX - sx, e.clientY - sy) > 5) moved = true;
      if (moved) setFabPos(e.clientX - offX, e.clientY - offY);
    });
    const end = (e) => {
      if (!pressing) return;
      pressing = false;
      fab.classList.remove('v5cs-dragging');
      try { fab.releasePointerCapture(e.pointerId); } catch (_) { /* ignore */ }
      if (moved) savePos();
      else onFabClick();
    };
    fab.addEventListener('pointerup', end);
    fab.addEventListener('pointercancel', end);
  }

  function onFabClick() {
    panel.classList.add('v5cs-show');
    startDetect();
  }

  // 统一启动器菜单点击 → 打开冲突检测面板（自带悬浮球已由 launcher 隐藏，入口收敛到统一球）
  document.addEventListener('seeyon-helper:conflict-open', () => onFabClick());

  // ---------- 渲染 ----------
  const detailEl = (section) => panel.querySelector(`.v5cs-detail[data-section="${section}"]`);
  const stepsEl = (section) => panel.querySelector(`.v5cs-steps[data-section="${section}"]`);
  function setDetailHtml(section, html) { const el = detailEl(section); if (el) el.innerHTML = html; }
  function setSharedHtml(html) { const el = panel.querySelector('#v5cs-shared'); if (el) el.innerHTML = html; }

  function renderSharedInfo(payload) {
    setSharedHtml(
      `<div class="v5cs-project-title">客户信息</div>` +
      `<div class="v5cs-shared-grid">` +
      `<span>加密狗号：<b>${escapeHtml(payload.dongle || payload.dogNum || '')}</b></span>` +
      `<span>名称：<b>${escapeHtml(payload.customer || '')}</b></span>` +
      `<span>分支：<b>${escapeHtml(payload.branch || '')}</b></span>` +
      `</div>`);
  }

  function renderSteps() {
    for (const section of SECTIONS) {
      const el = stepsEl(section);
      if (!el) continue;
      el.innerHTML = STEP_KEYS.map((key) => {
        const label = stepLabel(section, key);
        const s = stepState[section][key];
        if (!s) return `<div class="v5cs-step"><span class="v5cs-ico">○</span><span class="v5cs-label">${label}</span><span class="v5cs-msg">—</span></div>`;
        const ico = s.status === 'done' ? '✓' : '⏳';
        const cls = s.status === 'done' ? 'v5cs-done' : 'v5cs-run';
        const spin = (s.status === 'run' || s.status === 'start') ? ' v5cs-spin' : '';
        return `<div class="v5cs-step ${cls}"><span class="v5cs-ico">${ico}</span><span class="v5cs-label">${label}</span><span class="v5cs-msg${spin}">${escapeHtml(s.message || '')}</span></div>`;
      }).join('');
    }
  }

  function setProgress(msg) {
    const { section, step, status, message } = msg;
    if (section === 'source' || section === 'pak') {
      stepState[section][step] = { status, message };
    } else {
      // 共享步骤（加密狗/仓库/比对）：两区块同步写入
      stepState.source[step] = { status, message };
      stepState.pak[step] = { status, message };
    }
    renderSteps();
  }

  function resetSteps() {
    stepState.source = {};
    stepState.pak = {};
    conflictCounts.source = 0;
    conflictCounts.pak = 0;
    setDetailHtml('source', '');
    setDetailHtml('pak', '');
    setSharedHtml('');
    const logEl = panel.querySelector('#v5cs-log');
    if (logEl) logEl.textContent = '';
    applyConflictHighlight(0);
    renderSteps();
  }

  /** 按冲突数切换高亮：FAB 红色角标 + 面板头变红（>0），或清除（0）。 */
  function applyConflictHighlight(count) {
    const badge = fab.querySelector('.v5cs-badge');
    if (count > 0) {
      if (badge) { badge.textContent = String(count); badge.classList.add('v5cs-show'); }
      panel.classList.add('v5cs-has-conflict');
    } else {
      if (badge) badge.classList.remove('v5cs-show');
      panel.classList.remove('v5cs-has-conflict');
    }
  }
  // 角标汇总两区块冲突数
  function refreshConflictBadge() {
    applyConflictHighlight((conflictCounts.source || 0) + (conflictCounts.pak || 0));
  }

  // section 缺省=全局（两区块同显）；bg 下发的硬错误多为全局
  function renderError(message, section) {
    const html = `<div class="v5cs-error">❌ ${escapeHtml(message)}</div>`;
    if (section === 'source' || section === 'pak') {
      conflictCounts[section] = 0;       // 该区块出错，其旧冲突数失效
      setDetailHtml(section, html);
      refreshConflictBadge();
    } else {
      conflictCounts.source = 0; conflictCounts.pak = 0;
      setDetailHtml('source', html);
      setDetailHtml('pak', html);
      refreshConflictBadge();
    }
  }

  function showNeedLogin(msg) {
    const map = { studio: 'ctpStudio', gitlab: 'GitLab' };
    const name = map[msg.target] || msg.target;
    const html = `<div class="v5cs-login">⚠️ 请先登录 <b>${escapeHtml(name)}</b>（已为您打开登录页）。` +
      `登录完成后点击「已登录，继续」。</div>`;
    setDetailHtml('source', html);
    setDetailHtml('pak', html);
    // 临时追加登录按钮（已登录，继续 / 打开登录页）
    ensureAuxBtn('v5cs-openlogin', '打开登录页', () => window.open(msg.url, '_blank'));
    ensureAuxBtn('v5cs-resume', '已登录，继续', startDetect);
    try { window.open(msg.url, '_blank'); } catch (_) { /* ignore */ }
  }

  function ensureAuxBtn(id, label, handler) {
    const btns = panel.querySelector('.v5cs-btns');
    let b = btns.querySelector('#' + id);
    if (b) return;
    b = document.createElement('button');
    b.id = id; b.className = 'v5cs-btn v5cs-ghost'; b.textContent = label;
    b.addEventListener('click', handler);
    btns.appendChild(b);
  }
  function clearAuxBtns() {
    panel.querySelectorAll('.v5cs-btns .v5cs-ghost').forEach(b => b.remove());
  }

  function renderChooser(rows, onPick) {
    setDetailHtml('source', '<div class="v5cs-login">查询到多个客开项目，请选择一个继续：</div>');
    // 选择按钮挂在源码区块（主区块）；补丁包区块只给指引，避免出现「请选择」却无按钮的悬空提示
    setDetailHtml('pak', '<div class="v5cs-login">查询到多个客开项目，请在上方「V5 源码冲突检测」区块选择（两检测共用同一客开项目）。</div>');
    const detail = detailEl('source');
    if (!detail) return;                 // 选择器失配守卫，避免 appendChild 崩溃卡死流水线
    const wrap = document.createElement('div');
    wrap.className = 'v5cs-chooser';
    rows.forEach((row, i) => {
      const b = document.createElement('button');
      b.className = 'v5cs-choice';
      const alias = escapeHtml(row.projectAlias || '(无名)');
      const dog = escapeHtml(row.dogNum || row.dognum || '');
      const repo = escapeHtml(typeof row.repositories === 'string' ? row.repositories : JSON.stringify(row.repositories || ''));
      b.innerHTML = `<b>${alias}</b>　狗号:${dog}　分支:${repo}`;
      b.addEventListener('click', () => onPick(row));
      wrap.appendChild(b);
    });
    detail.appendChild(wrap);
  }

  function renderResult(payload, section) {
    clearAuxBtns();
    const label = section === 'pak' ? '补丁包' : '源码';

    // 空区块：无附件 → 平静提示；有附件但全部解析失败 → 展示手工处理清单（不计冲突）
    if (payload && payload.empty) {
      conflictCounts[section] = 0;
      refreshConflictBadge();
      const manual = payload.manual || [];
      if (manual.length) {
        setDetailHtml(section,
          `<div class="v5cs-error">❌ ${label}附件无法自动解析/解压，请手工处理：</div>` +
          manual.map((m) => `<div class="v5cs-conflict"><span class="v5cs-pair"><b>${escapeHtml(m.name || '(未知)')}</b>：${escapeHtml(m.reason || '')}</span></div>`).join(''));
      } else {
        setDetailHtml(section, `<div class="v5cs-clean">${section === 'pak' ? '（无补丁包附件，跳过）' : '（无源码附件，跳过）'}</div>`);
      }
      return;
    }

    const r = payload.result || {};
    const conflictCount = (r.conflicts || []).length;
    conflictCounts[section] = conflictCount;
    refreshConflictBadge();

    // 顶部强提示横幅：有冲突=红色警告（闪烁数次引人注意），无冲突=绿色
    const banner = conflictCount > 0
      ? `<div class="v5cs-banner v5cs-banner-danger">🚨 发现 <b>${conflictCount}</b> 处冲突（路径 ${r.pathHits || 0} / 文件名 ${r.nameHits || 0}），请重点核对下方文件！</div>`
      : `<div class="v5cs-banner v5cs-banner-ok">✅ 未发现冲突：${label}文件均不在客开仓库中。</div>`;

    const conflictHtml = (r.conflicts || []).map(c => {
      const tag = c.kind === 'path'
        ? '<span class="v5cs-tag v5cs-tag-path">路径命中</span>'
        : '<span class="v5cs-tag v5cs-tag-name">文件名命中</span>';
      // 补丁包区块额外标注原始 .class 名做溯源
      const origLine = (section === 'pak' && c.orig)
        ? `<br><b>补丁包：</b>${escapeHtml(c.orig)}`
        : '';
      return `<div class="v5cs-conflict"><span class="v5cs-pair"><b>源码：</b>${escapeHtml(c.source)}<br><b>客开：</b>${escapeHtml(c.repo)}${origLine}</span>${tag}</div>`;
    }).join('') || '<div class="v5cs-clean">无</div>';

    const cleanCount = (r.clean || []).length;
    const cleanHtml = (r.clean || []).map(c => `<div class="v5cs-clean">${escapeHtml(c.source)}</div>`).join('');

    const manual = payload.manual || [];
    const manualHtml = manual.length
      ? `<div class="v5cs-section"><div class="v5cs-h">✋ 无法自动比对，需手工处理（${manual.length}）</div>` +
        manual.map((m) => `<div class="v5cs-conflict"><span class="v5cs-pair"><b>${escapeHtml(m.name || '(未知)')}</b>：${escapeHtml(m.reason || '')}</span></div>`).join('') +
        `</div>`
      : '';

    // 加密狗号 / 客户 / 分支为两检测共享信息，统一在顶部显示一次
    renderSharedInfo(payload);

    setDetailHtml(section,
      banner +
      `<div class="v5cs-section">` +
      `<div class="v5cs-h">⚠️ 冲突文件（${(r.conflicts || []).length}：路径 ${r.pathHits || 0} / 文件名 ${r.nameHits || 0}）</div>` +
      conflictHtml +
      `<details><summary>无冲突文件（${cleanCount}）</summary><div class="v5cs-cleanwrap">${cleanHtml || '<div class="v5cs-clean">无</div>'}</div></details>` +
      `<div class="v5cs-clean" style="margin-top:8px">${label} ${payload.sourceCount} 个 ↔ 客开 ${payload.repoCount} 个</div>` +
      `</div>` + manualHtml);
  }

  // 在工单主页框架响应的判定：#subject / 附件关键字段 任一命中即可兜底。
  function hasTicketContext() {
    const affairId = getQueryParam(location.href, 'affairId') || getQueryParam(location.href, 'affairid') || getQueryParam(location.href, 'objId');
    const method = String(getQueryParam(location.href, 'method') || '').toLowerCase();
    const byQuery = method === 'summary' && !!affairId;
    return byQuery
      || !!(document.querySelector('#subject')
      || findByIdDeep('summaryId')
      || findByIdDeep('field1537_id')
      || findByIdDeep('field1237_id')
      || findByIdDeep('field1244_id'));
  }

  function canHandleRpc(msg) {
    if (msg && msg.type === 'CHOOSE_PROJECT') return true;
    if (msg && msg.type === 'CLICK_ONE_DOWNLOAD') return !!findByIdDeep(msg.fieldId || 'field1244_id') || hasTicketContext();
    return hasTicketContext();
  }

  function sendRpcError(msgId, message) {
    try { chrome.runtime.sendMessage({ replyTo: msgId, error: String(message || 'unknown') }); } catch (_) { /* ignore */ }
  }

  // ---------- RPC 服务端（响应 background 的请求）+ 事件渲染 ----------
  function handleRpc(msg) {

    switch (msg.type) {
      case 'COLLECT_SOURCE': return Promise.resolve(collectSource());
      case 'COLLECT_PAK': return Promise.resolve(collectPak());
      case 'EXTRACT_FORM': return Promise.resolve(extractForm());
      case 'CLICK_ONE_DOWNLOAD': return Promise.resolve(clickOneDownload(msg.fieldId, msg.fileName));
      case 'CHOOSE_PROJECT':
        return new Promise(resolve => renderChooser(msg.rows || [], row => resolve({ row })));
      default: return Promise.reject(new Error('未知 RPC：' + msg.type));
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return false;
    if (msg.replyTo != null) return false; // 自身回复回环（忽略）
    if (msg.id != null) {
      // RPC 仅在能处理工单上下文/相关操作的 frame 中应答，避免无关 frame 无声超时。
      const reqType = msg.type || 'unknown';
      const startTs = Date.now();
      logRpcTrace(reqType, msg.id, 'recv', null, startTs);
      if (!canHandleRpc(msg)) {
        const reason = 'content 已就绪但未通过工单上下文判断（可能是非目标 frame / 非工单上下文）';
        logRpcTrace(reqType, msg.id, 'skip', { items: [{ fileName: 'SKIP' }], reason }, startTs);
        sendRpcError(msg.id, reason);
        return false;
      }
      logRpcTrace(reqType, msg.id, 'handle', { items: [{ fileName: 'GO' }] }, startTs);
      const task = handleRpc(msg);
      const handlerTimer = typeof withRpcTimeout === 'function'
        ? withRpcTimeout(task, reqType + '#id' + msg.id + '.collect')
        : new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error('CONTENT_RPC 超时：' + reqType + '#id' + msg.id + '（30000ms）'));
          }, 30000);
          Promise.resolve(task).then(
            (v) => { clearTimeout(timer); resolve(v); },
            (e) => { clearTimeout(timer); reject(e); }
          );
        });
      handlerTimer.then(
        (result) => {
          logRpcTrace(reqType, msg.id, 'reply', result, startTs);
          chrome.runtime.sendMessage({ replyTo: msg.id, result });
        },
        (err) => {
          const message = String((err && err.message) || err);
          logRpcTrace(reqType, msg.id, 'reply-err', { items: [{ fileName: 'ERR' }], reason: message }, startTs);
          chrome.runtime.sendMessage({ replyTo: msg.id, error: message });
        }
      );
      return false;
    }
    switch (msg.type) {
      case 'PROGRESS': setProgress(msg); break;
      case 'NEED_LOGIN': clearAuxBtns(); showNeedLogin(msg); break;
      case 'RESULT': renderResult(msg.payload || {}, msg.section === 'pak' ? 'pak' : 'source'); break;
      case 'ERROR': clearAuxBtns(); renderError(msg.message, msg.section); break;
      case 'LOG': pushLog(msg.message || ''); break;
    }
    return false;
  });


  // 把 background 转发来的日志显示到页面控制台 + 面板日志区
  function pushLog(message) {
    // eslint-disable-next-line no-console
    console.log('[kk-helper:conflict-radar][bg]', message);
    const el = panel.querySelector('#v5cs-log');
    if (!el) return;
    const line = (message || '').replace(/[<>&]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));
    el.textContent = el.textContent + line + '\n';
    el.scrollTop = el.scrollHeight;
    if (el.textContent.length > 20000) el.textContent = el.textContent.slice(-10000);
  }

  // 扩展上下文是否可用（扩展重载后旧 content script 会失效）
  function extContextOk() {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (_) { return false; }
  }

  function startDetect() {
    clearAuxBtns();
    resetSteps();
    panel.classList.add('v5cs-show');
    if (!extContextOk()) {
      renderError('扩展已重新加载，当前页面仍是旧实例。请刷新页面（Ctrl+Shift+R）后再点悬浮球。');
      return;
    }
    setProgress({ step: 'source', status: 'run', message: '准备中…' });
    try {
      chrome.runtime.sendMessage({ type: 'RUN_DETECT' });
    } catch (e) {
      renderError('扩展通信异常，请刷新页面后重试：' + (e && e.message));
    }
  }

  // ---------- 启动：判定工单页后注入 ----------
  function isTicketPage() {
    const hasField = !!(findByIdDeep('summaryId') || findByIdDeep('field1537_id') || findByIdDeep('field1237_id'));
    const method = String(getQueryParam(location.href, 'method') || '').toLowerCase();
    const affairId = getQueryParam(location.href, 'affairId') || getQueryParam(location.href, 'affairid') || getQueryParam(location.href, 'objId');
    const hasBugKeyword = (() => {
      const titles = new Set();
      titles.add(document && document.title ? String(document.title) : '');
      try {
        const topDoc = window.top && window.top.document;
        if (topDoc && topDoc.title) titles.add(String(topDoc.title));
      } catch (_) {}
      for (const t of titles) {
        if ((t || '').indexOf('BUG_') >= 0) return true;
      }
      return false;
    })();
    const byQuery = method === 'summary' && !!affairId;
    const result = hasField || (byQuery && hasBugKeyword);
    if (!result) {
      console.log('[kk-helper:conflict-radar]', '[入口] 冲突检测悬浮球不显示：未识别到工单页关键字段', location.href);
    }
    return result;
  }

  function tryInject(reason) {
    if (isTicketPage()) {
      console.log('[kk-helper:conflict-radar]', '[入口] 冲突检测入口就绪，挂载悬浮球/面板', reason || 'initial');
      mount();
      return true;
    }
    return false;
  }

  function waitForTicketPageAndInject() {
    if (tryInject('initial')) return;

    const timeoutMs = 4500;
    const intervalMs = 300;
    let checkCount = 0;
    const maxCount = Math.ceil(timeoutMs / intervalMs);

    const timer = setInterval(() => {
      checkCount++;
      if (isTicketPage()) {
        clearInterval(timer);
        console.log('[kk-helper:conflict-radar]', '[入口] 冲突检测轮询发现关键字段，挂载悬浮球/面板');
        mount();
        return;
      }

      if (checkCount >= maxCount) {
        clearInterval(timer);
        console.log('[kk-helper:conflict-radar]', '[入口] 4500ms 重试后仍不显示冲突检测悬浮球，停止重试');
      }
    }, intervalMs);
  }

  waitForTicketPageAndInject();
})();
