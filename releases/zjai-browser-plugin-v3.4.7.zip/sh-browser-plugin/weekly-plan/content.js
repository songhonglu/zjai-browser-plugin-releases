(function () {
  if (window.__seeyon_weekly_plan__) return;
  window.__seeyon_weekly_plan__ = true;

  const LOG_PREFIX = '[kk-helper:weekly-plan]';
  const TARGET_LABELS = ['上周总结', '上周工作明细', '关联上周计划'];
  const HEADER_ALIASES = {
    date: ['日期'],
    weekday: ['星期几', '星期'],
    project: ['项目名称'],
    currentStage: ['当前阶段'],
    targetStage: ['目标阶段'],
    priority: ['概率'],
    partner: ['伙伴名称', '协作人员', '伙伴人员'],
    content: ['事项内容'],
    feedback: ['完成反馈'],
  };
  const FAB_ID = 'seeyon-weekly-plan-fab';
  const GUIDE_ID = 'seeyon-weekly-plan-guide';
  let observer = null;
  let writeLock = false;
  let scheduleTimer = null;
  let heartbeatTimer = null;
  let activated = false;
  let aiBusy = false;
  const SUGGESTION_MAX_LEN = 300;

  const Log = {
    info: (...args) => console.log(LOG_PREFIX, ...args),
    warn: (...args) => console.warn(LOG_PREFIX, ...args),
    debug: (...args) => console.debug(LOG_PREFIX, ...args),
  };

  function normalizeText(text) {
    return String(text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function pageText() {
    return normalizeText(document.body ? document.body.innerText || document.body.textContent : '');
  }

  function isTargetPage() {
    const text = pageText();
    return TARGET_LABELS.every((label) => text.includes(label));
  }

  function hasRelatedLastWeekPlan() {
    const labels = Array.from(document.querySelectorAll('td, th, span, div, a'));
    for (const el of labels) {
      if (normalizeText(el.textContent) !== '关联上周计划') continue;
      const cell = el.closest('td, th') || el.parentElement;
      if (!cell) continue;
      let sib = cell.nextElementSibling;
      while (sib) {
        const text = normalizeText(sib.textContent);
        if (text && text !== '关联上周计划' && !/^单位[:：]?\s*元?$/.test(text)) {
          return /工作计划/.test(text) || text.length >= 6;
        }
        sib = sib.nextElementSibling;
      }
    }
    return Array.from(document.querySelectorAll('a'))
      .some((a) => /工作计划/.test(normalizeText(a.textContent)));
  }

  function isTableElement(node) {
    return node instanceof HTMLElement && Boolean(node.closest('table'));
  }

  function extractCellText(cell) {
    if (!cell) return '';

    const values = [];
    const push = (value) => {
      const text = normalizeText(value);
      if (text && !values.includes(text)) values.push(text);
    };

    cell.querySelectorAll('textarea, input, [contenteditable="true"]').forEach((el) => {
      push('value' in el ? el.value : el.textContent);
    });

    if (!values.length) {
      const clone = cell.cloneNode(true);
      clone.querySelectorAll('script, style, button, a, svg, img, input, textarea, select').forEach((el) => el.remove());
      push(clone.innerText || clone.textContent);
    }

    return values.join('\n');
  }

  function extractFeedbackStrictText(cell) {
    if (!cell) return '';

    const controls = Array.from(cell.querySelectorAll('textarea, input, [contenteditable="true"]'));
    if (controls.length) {
      const values = controls.map((el) => normalizeText('value' in el ? el.value : el.textContent)).filter(Boolean);
      return values.join('\n');
    }

    const clone = cell.cloneNode(true);
    clone.querySelectorAll('script, style, button, a, svg, img, input, textarea, select').forEach((el) => el.remove());
    return normalizeText(clone.innerText || clone.textContent);
  }

  function isFieldEditable(field) {
    if (!field || !(field instanceof HTMLElement)) return false;
    if (field.matches('textarea, input, select')) {
      return !field.disabled && !field.readOnly;
    }
    if (field.isContentEditable) return true;
    return false;
  }

  function findSummaryField() {
    const areas = Array.from(document.querySelectorAll('textarea, input[type="text"]'));
    let best = null;
    let bestScore = -1;

    for (const area of areas) {
      const box = area.closest('tr, table, td, section, div, li') || area.parentElement;
      const scopeText = normalizeText(box ? box.innerText || box.textContent : '');
      let score = 0;
      if (scopeText.includes('上周总结')) score += 10;
      if (scopeText.includes('实际上周') || scopeText.includes('实际完成')) score += 4;
      if (area.tagName === 'TEXTAREA') score += 2;
      score += Math.min((area.cols || 0) / 10, 3);
      score += Math.min((area.rows || 0) / 5, 3);
      if (score > bestScore) {
        best = area;
        bestScore = score;
      }
    }

    return best;
  }

  function hasEditableDetailControl(detail) {
    if (!detail || !detail.table) return false;
    return Array.from(detail.table.querySelectorAll('textarea, input, select, [contenteditable="true"]'))
      .some((el) => isFieldEditable(el));
  }

  function isEditableMode(detail) {
    const summaryField = findSummaryField();
    const summaryEditable = isFieldEditable(summaryField);
    const detailEditable = hasEditableDetailControl(detail);
    return summaryEditable || detailEditable;
  }

  function headerIndexMap(row) {
    const cells = Array.from(row.cells || row.querySelectorAll('th,td'));
    const map = {};
    cells.forEach((cell, index) => {
      const text = normalizeText(cell.innerText || cell.textContent);
      for (const [key, aliases] of Object.entries(HEADER_ALIASES)) {
        if (map[key] != null) continue;
        if (aliases.some((alias) => text.includes(alias))) map[key] = index;
      }
    });
    return map;
  }

  function hasRequiredIndexes(map) {
    return ['project', 'content', 'feedback'].every((key) => Number.isInteger(map[key]));
  }

  function findDetailTable() {
    const tables = Array.from(document.querySelectorAll('table'));
    for (const table of tables) {
      const text = normalizeText(table.innerText || table.textContent);
      if (!text.includes('上周工作明细')) continue;
      const rows = Array.from(table.rows || []);
      for (const row of rows) {
        const map = headerIndexMap(row);
        if (hasRequiredIndexes(map)) return { table, headerMap: map, headerRow: row };
      }
    }

    for (const table of tables) {
      const rows = Array.from(table.rows || []);
      for (const row of rows) {
        const map = headerIndexMap(row);
        if (hasRequiredIndexes(map)) return { table, headerMap: map, headerRow: row };
      }
    }

    return null;
  }

  function parseRows(detail) {
    if (!detail) return [];
    const rows = [];
    let passedHeader = false;

    for (const row of Array.from(detail.table.rows || [])) {
      if (row === detail.headerRow) {
        passedHeader = true;
        continue;
      }
      if (!passedHeader) continue;

      const cells = Array.from(row.cells || []);
      if (!cells.length) continue;

      const date = extractCellText(cells[detail.headerMap.date]);
      const weekday = extractCellText(cells[detail.headerMap.weekday]);
      const project = extractCellText(cells[detail.headerMap.project]);
      const currentStage = extractCellText(cells[detail.headerMap.currentStage]);
      const targetStage = extractCellText(cells[detail.headerMap.targetStage]);
      const priority = extractCellText(cells[detail.headerMap.priority]);
      const partner = extractCellText(cells[detail.headerMap.partner]);
      const content = extractCellText(cells[detail.headerMap.content]);
      const feedback = extractFeedbackStrictText(cells[detail.headerMap.feedback]);

      if (!project && !content && !feedback) continue;
      rows.push({
        date,
        weekday,
        project,
        currentStage,
        targetStage,
        priority,
        partner,
        content,
        feedback,
      });
    }

    return rows;
  }

  function hasIncompleteFeedback(rows) {
    return rows.some((row) => String(normalizeText(row.feedback)).length <= 0);
  }

  function splitLines(text) {
    return String(text || '')
      .replace(/[；;]/g, '\n')
      .split(/\n+/)
      .map((line) => normalizeText(line))
      .filter(Boolean);
  }

  function parsePercent(text) {
    const match = String(text || '').match(/(\d+(?:\.\d+)?)\s*%/);
    return match ? Number(match[1]) : null;
  }

  function stageCategory(row) {
    const text = [row.currentStage, row.targetStage].join(' ');
    if (text.includes('验收')) return '验收类';
    if (text.includes('蓝图')) return '蓝图类';
    return '开发类';
  }

  function uniquePush(list, value) {
    const text = normalizeText(value);
    if (text && !list.includes(text)) list.push(text);
  }

  function collectProjectSummaries(rows) {
    const map = new Map();
    rows.forEach((row) => {
      const key = normalizeText(row.project) || '未命名项目';
      if (!map.has(key)) {
        map.set(key, {
          project: key,
          weekday: [],
          currentStage: normalizeText(row.currentStage),
          targetStage: normalizeText(row.targetStage),
          priority: normalizeText(row.priority),
          category: stageCategory(row),
          contentLines: [],
          feedbackLines: [],
        });
      }
      const item = map.get(key);
      uniquePush(item.weekday, row.weekday);
      splitLines(row.content).forEach((line) => uniquePush(item.contentLines, line));
      splitLines(row.feedback).forEach((line) => uniquePush(item.feedbackLines, line));
      if (!item.currentStage) item.currentStage = normalizeText(row.currentStage);
      if (!item.targetStage) item.targetStage = normalizeText(row.targetStage);
      if (!item.priority) item.priority = normalizeText(row.priority);
    });
    return Array.from(map.values());
  }

  function workloadBalanceText(dayStats) {
    const counts = dayStats.map((item) => item.count);
    const max = Math.max.apply(null, counts);
    const min = Math.min.apply(null, counts);
    if (max === min) return '整体分布均衡';
    if (max - min <= 1) return '整体较为均衡';
    return '工作量存在明显波动，需关注高峰日资源安排';
  }

  function classifyWorkType(text) {
    const value = String(text || '');
    if (/(上线支持|升级支持|升级准备|切换支持)/.test(value)) return '升级支撑';
    if (/(升级|迁移|信创|切换)/.test(value)) return '升级支撑';
    if (/(对接|同步|接口|联调|集成)/.test(value)) return '集成';
    if (/(调研|需求|沟通|分析)/.test(value)) return '调研';
    if (/(运维|支持|保障|修复|排查|维护)/.test(value)) return '运维';
    if (/(开发|上线|优化|实现|改造|新增)/.test(value)) return '开发';
    return '其他';
  }

  function collectRiskText(projects) {
    const risks = [];
    projects.forEach((item) => {
      const currentPercent = parsePercent(item.currentStage);
      const targetPercent = parsePercent(item.targetStage);
      if (currentPercent != null && targetPercent != null && currentPercent < targetPercent) {
        risks.push(`${item.project}当前阶段${item.currentStage}，低于目标阶段${item.targetStage}`);
      }
      const joined = item.feedbackLines.concat(item.contentLines).join('；');
      if (/(待|持续|沟通中|协调|准备|未完成|未达|风险|问题|排查)/.test(joined)) {
        risks.push(`${item.project}存在“${joined.slice(0, 24)}${joined.length > 24 ? '...' : ''}”类持续跟进事项`);
      }
    });
    return risks.filter((value, index) => value && risks.indexOf(value) === index);
  }

  function buildCompactTime(rows) {
    const dayMap = new Map();
    rows.forEach((row) => {
      const weekday = normalizeText(row.weekday) || '未知';
      if (!dayMap.has(weekday)) dayMap.set(weekday, new Set());
      dayMap.get(weekday).add(normalizeText(row.project) || '未命名项目');
    });
    const stats = Array.from(dayMap.entries()).map(([weekday, set]) => ({ weekday, count: set.size }));
    if (!stats.length) return '时间：未提取';
    const peak = stats.slice().sort((a, b) => b.count - a.count)[0];
    return `时间：${stats.length}天，${peak.weekday}${peak.count}项最高`;
  }

  function buildCompactProject(projects) {
    const counts = { 验收类: 0, 开发类: 0, 蓝图类: 0 };
    projects.forEach((item) => { counts[item.category] = (counts[item.category] || 0) + 1; });
    return `项目：验收${counts['验收类'] || 0}、开发${counts['开发类'] || 0}、蓝图${counts['蓝图类'] || 0}`;
  }

  function buildCompactProgress(projects) {
    let lagging = 0;
    projects.forEach((item) => {
      const currentPercent = parsePercent(item.currentStage);
      const targetPercent = parsePercent(item.targetStage);
      if (currentPercent != null && targetPercent != null && currentPercent < targetPercent) lagging += 1;
    });
    return lagging ? `进度：${lagging}项未达目标` : '进度：整体达标';
  }

  function buildCompactWork(rows) {
    const countMap = new Map();
    rows.forEach((row) => {
      const type = classifyWorkType(row.content || row.feedback);
      countMap.set(type, (countMap.get(type) || 0) + 1);
    });
    const top = Array.from(countMap.entries()).sort((a, b) => b[1] - a[1]).slice(0, 2);
    if (!top.length) return '事项：未提取';
    return `事项：${top.map(([k, v]) => `${k}${v}项`).join('，')}`;
  }

  function buildCompactPriority(projects) {
    const guaranteed = projects.filter((item) => item.priority.includes('保底')).length;
    const striving = projects.filter((item) => item.priority.includes('争取')).length;
    const risks = collectRiskText(projects);
    return `优先级：保底${guaranteed}、争取${striving}${risks.length ? `；风险${Math.min(risks.length, 9)}项` : '；风险可控'}`;
  }

  function trimToLength(text, maxLen) {
    const value = normalizeText(text).replace(/\s+/g, '');
    return value.length <= maxLen ? value : value.slice(0, maxLen - 1) + '…';
  }

  function buildNextWeekSuggestion(projects, rows) {
    const laggingProjects = projects.filter((item) => {
      const currentPercent = parsePercent(item.currentStage);
      const targetPercent = parsePercent(item.targetStage);
      return currentPercent != null && targetPercent != null && currentPercent < targetPercent;
    });
    const hasStriving = projects.some((item) => item.priority.includes('争取'));
    const hasSupport = rows.some((row) => /(支持|排查|沟通|调研)/.test([row.content, row.feedback].join('；')));
    const upgradeProjects = projects.filter((item) => /(升级|信创|蓝图)/.test([item.project, item.currentStage, item.targetStage].join(' ')));
    let text = '下周计划建议：';
    if (laggingProjects.length) {
      text += `优先推动${laggingProjects.slice(0, 2).map((item) => item.project).join('、')}补齐阶段差距，`;
    } else if (hasStriving) {
      text += '优先推进争取类项目资源落实与关键事项闭环，';
    } else {
      text += '优先围绕核心项目阶段成果落地与交付节点推进，';
    }
    if (upgradeProjects.length) {
      text += `同步关注${upgradeProjects.slice(0, 2).map((item) => item.project).join('、')}的升级/蓝图事项，`;
    }
    text += hasSupport
      ? '继续收敛持续沟通、排查和支持类事项，形成可确认的阶段结果。'
      : '同步准备阶段性交付材料，确保重点任务按计划推进。';
    return trimToLength(text, SUGGESTION_MAX_LEN);
  }

  function buildTimeSection(rows) {
    const order = ['周一', '周二', '周三', '周四', '周五'];
    const dayMap = new Map(order.map((key) => [key, new Set()]));
    rows.forEach((row) => {
      const weekday = normalizeText(row.weekday);
      if (!dayMap.has(weekday)) dayMap.set(weekday, new Set());
      dayMap.get(weekday).add(normalizeText(row.project) || '未命名项目');
    });
    const stats = Array.from(dayMap.entries()).map(([weekday, projects]) => ({
      weekday,
      count: projects.size,
    })).filter((item) => item.count > 0);
    if (!stats.length) return '一、时间维度\n未提取到可统计的日期与星期信息。';
    const summary = stats.map((item) => `${item.weekday}承接${item.count}个项目`).join('，');
    return `一、时间维度\n本周上周工作明细共覆盖${stats.length}个工作日，${summary}；${workloadBalanceText(stats)}。`;
  }

  function buildProjectSection(projects) {
    const categories = ['验收类', '开发类', '蓝图类'];
    const lines = ['二、项目主体维度'];
    categories.forEach((category) => {
      const items = projects.filter((item) => item.category === category);
      if (!items.length) return;
      lines.push(`${category}项目共${items.length}个：`);
      items.forEach((item, index) => {
        const workText = item.contentLines.slice(0, 3).join('；') || '未提取到事项内容';
        const feedbackText = item.feedbackLines.slice(0, 3).join('；') || '未填写完成反馈';
        lines.push(`${index + 1}. ${item.project}：本周工作为${workText}；当前阶段${item.currentStage || '未提取'}，目标阶段${item.targetStage || '未提取'}；完成情况为${feedbackText}。`);
      });
    });
    return lines.join('\n');
  }

  function buildProgressSection(projects) {
    const lines = ['三、进度维度'];
    const lagging = [];
    projects.forEach((item) => {
      const currentPercent = parsePercent(item.currentStage);
      const targetPercent = parsePercent(item.targetStage);
      if (currentPercent != null && targetPercent != null) {
        if (currentPercent < targetPercent) lagging.push(`${item.project}（当前${item.currentStage}，目标${item.targetStage}）`);
      }
    });
    if (lagging.length) {
      lines.push(`已识别进度未达标项目${lagging.length}个：${lagging.join('；')}。`);
    } else {
      lines.push('表格内可识别项目的当前阶段与目标阶段整体一致，未发现明确的阶段性未达标项目。');
    }
    return lines.join('\n');
  }

  function buildWorkSection(rows) {
    const typeMap = new Map();
    rows.forEach((row) => {
      const type = classifyWorkType(row.content || row.feedback);
      if (!typeMap.has(type)) typeMap.set(type, { count: 0, projects: [] });
      const item = typeMap.get(type);
      item.count += 1;
      uniquePush(item.projects, normalizeText(row.project) || '未命名项目');
    });
    const order = ['开发', '调研', '运维', '集成', '升级支撑', '其他'];
    const lines = ['四、工作事项维度'];
    order.forEach((type) => {
      const item = typeMap.get(type);
      if (!item) return;
      lines.push(`${type}类工作共${item.count}项，涉及项目：${item.projects.join('、')}。`);
    });
    return lines.join('\n');
  }

  function buildPrioritySection(projects) {
    const guaranteed = projects.filter((item) => item.priority.includes('保底'));
    const striving = projects.filter((item) => item.priority.includes('争取'));
    const lines = ['五、优先级维度'];
    lines.push(`保底类项目${guaranteed.length}个，争取类项目${striving.length}个。`);
    const risks = collectRiskText(projects);
    if (risks.length) {
      lines.push(`当前需重点关注的风险与持续事项：${risks.slice(0, 5).join('；')}。`);
    } else {
      lines.push('当前未从表格原文中识别到明确的资源不足、进度滞后或持续运维风险描述。');
    }
    return lines.join('\n');
  }

  function buildFallbackSummary(rows) {
    const projects = collectProjectSummaries(rows);
    const parts = [
      buildTimeSection(rows),
      buildProjectSection(projects),
      buildProgressSection(projects),
      buildWorkSection(rows),
      buildPrioritySection(projects),
    ];
    const suggestion = buildNextWeekSuggestion(projects, rows);
    const body = parts.join('\n\n').trim();
    return `${body}\n${suggestion}`;
  }

  function buildAiPayload(rows) {
    const projects = collectProjectSummaries(rows);
    const sanitizePartner = function (value) {
      const text = normalizeText(value);
      if (!text) return '';
      if (/^(上周安排[-－]?伙伴|伙伴类型|伙伴名称|未填写|无|-)$/.test(text)) return '';
      return text;
    };
    return {
      draftSummary: buildFallbackSummary(rows),
      feedbackDigest: projects.map((item, index) => ({
        index: index + 1,
        project: item.project,
        currentStage: item.currentStage,
        targetStage: item.targetStage,
        priority: item.priority,
        contents: item.contentLines,
        feedbacks: item.feedbackLines
      })),
      rows: rows.map((row) => ({
        date: normalizeText(row.date),
        weekday: normalizeText(row.weekday),
        project: normalizeText(row.project),
        currentStage: normalizeText(row.currentStage),
        targetStage: normalizeText(row.targetStage),
        priority: normalizeText(row.priority),
        partner: sanitizePartner(row.partner),
        content: normalizeText(row.content),
        feedback: normalizeText(row.feedback),
      }))
    };
  }

  function requestAiSummary(rows) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action: 'weeklyPlanAiSummarize', params: buildAiPayload(rows) }, function(resp) {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || 'AI消息失败'));
          return;
        }
        if (!resp || !resp.success) {
          reject(new Error(resp && resp.error ? resp.error : 'AI汇总失败'));
          return;
        }
        resolve(String(resp.data || '').trim());
      });
    });
  }

  function dispatchFieldEvents(field) {
    ['input', 'change', 'blur'].forEach((type) => {
      field.dispatchEvent(new Event(type, { bubbles: true }));
    });
  }

  function writeSummary(text, reason) {
    const field = findSummaryField();
    if (!field) {
      Log.warn('未找到“上周总结”输入框');
      return { ok: false, reason: 'no-summary-field' };
    }
    if (!isFieldEditable(field)) {
      return { ok: false, reason: 'summary-readonly' };
    }
    if (document.activeElement === field && reason !== 'manual') {
      return { ok: false, reason: 'summary-focused' };
    }
    if (field.value === text) {
      return { ok: true, reason: 'unchanged' };
    }

    writeLock = true;
    field.value = text;
    field.dataset.seeyonWeeklyPlanGenerated = text;
    dispatchFieldEvents(field);
    writeLock = false;
    return { ok: true, reason: 'written' };
  }

  async function generateSummary(reason) {
    if (!isTargetPage()) return { ok: false, reason: 'not-target-page' };
    if (!hasRelatedLastWeekPlan()) {
      return { ok: false, reason: 'no-last-week-plan' };
    }

    const detail = findDetailTable();
    if (!detail) {
      Log.warn('未找到“上周工作明细”表格');
      return { ok: false, reason: 'no-detail-table' };
    }
    if (!isEditableMode(detail)) {
      return { ok: false, reason: 'readonly-page' };
    }

    const rows = parseRows(detail);
    if (!rows.length) {
      Log.warn('表格可汇总内容为空');
      return { ok: false, reason: 'empty-summary' };
    }
    if (hasIncompleteFeedback(rows)) {
      Log.info('完成反馈存在空行，暂不触发汇总');
      return { ok: false, reason: 'incomplete-feedback' };
    }
    let text = '';
    try {
      aiBusy = true;
      text = await requestAiSummary(rows);
      Log.info('AI二次提炼完成');
    } catch (error) {
      Log.warn('AI汇总失败，回退本地规则汇总:', error.message);
      text = buildFallbackSummary(rows);
    } finally {
      aiBusy = false;
    }
    if (!text) {
      Log.warn('表格可汇总内容为空');
      return { ok: false, reason: 'empty-summary' };
    }

    const result = writeSummary(text, reason);
    Log.info('汇总完成', { reason, rows: rows.length, status: result.reason });
    return result;
  }

  function ensureFab() {
    removeFab();
  }

  function removeFab() {
    const fab = document.getElementById(FAB_ID);
    if (fab && fab.parentNode) fab.parentNode.removeChild(fab);
    const guide = document.getElementById(GUIDE_ID);
    if (guide && guide.parentNode) guide.parentNode.removeChild(guide);
  }

  function scheduleGenerate(reason) {
    if (scheduleTimer) clearTimeout(scheduleTimer);
    scheduleTimer = setTimeout(async () => {
      if (!isTargetPage()) return;
      if (aiBusy) return;
      const result = await generateSummary(reason);
      if (result.reason === 'readonly-page') {
        Log.info('当前为只读周工作计划页，跳过自动汇总');
      } else if (result.reason === 'no-last-week-plan') {
        Log.info('尚未关联上周计划，跳过自动汇总');
      } else if (result.reason === 'incomplete-feedback') {
        Log.info('完成反馈未全部填写，跳过自动汇总');
      }
    }, 300);
  }

  function bindWatchers() {
    if (observer || !document.body) return;

    document.addEventListener('input', (event) => {
      if (writeLock) return;
      const target = event.target;
      if (!isTableElement(target) || target.closest('#' + FAB_ID)) return;
      scheduleGenerate('input');
    }, true);

    document.addEventListener('change', (event) => {
      if (writeLock) return;
      const target = event.target;
      if (!isTableElement(target) || target.closest('#' + FAB_ID)) return;
      scheduleGenerate('change');
    }, true);

    observer = new MutationObserver(() => {
      if (writeLock) return;
      if (!activated) {
        bootstrap('mutation');
        return;
      }
      scheduleGenerate('mutation');
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function startHeartbeat() {
    if (heartbeatTimer) return;
    heartbeatTimer = setInterval(() => {
      if (activated) {
        clearInterval(heartbeatTimer);
        heartbeatTimer = null;
        return;
      }
      bootstrap('heartbeat');
    }, 1000);
  }

  function bootstrap(reason) {
    if (!document.body) return;
    bindWatchers();
    if (!isTargetPage()) {
      Log.debug('周工作计划页特征未就绪', reason || 'bootstrap');
      return;
    }
    if (!hasRelatedLastWeekPlan()) {
      removeFab();
      Log.info('尚未关联上周计划，功能不执行');
      return;
    }
    const detail = findDetailTable();
    if (!isEditableMode(detail)) {
      removeFab();
      Log.info('检测到已发/已办只读周工作计划页，功能不执行');
      return;
    }
    activated = true;
    scheduleGenerate('bootstrap');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => bootstrap('domcontentloaded'), { once: true });
  } else {
    bootstrap('immediate');
  }
  window.addEventListener('load', () => bootstrap('load'), { once: true });
  setTimeout(() => bootstrap('delayed-1200'), 1200);
  setTimeout(() => bootstrap('delayed-3000'), 3000);
  startHeartbeat();
})();
