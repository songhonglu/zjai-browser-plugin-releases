/**
 * Seeyon工时签卡助手 - 内容脚本
 * 负责悬浮图标、弹窗展示和交互
 */

const LOG_PREFIX = '[kk-helper:work-hours]';
const DEBUG = true;

// 扩展ID，用于postMessage通信
const EXTENSION_ID = chrome.runtime.id;

const Logger = {
    info: (...args) => DEBUG && console.log(LOG_PREFIX + '[INFO]', ...args),
    warn: (...args) => DEBUG && console.warn(LOG_PREFIX + '[WARN]', ...args),
    error: (...args) => DEBUG && console.error(LOG_PREFIX + '[ERROR]', ...args),
    debug: (...args) => DEBUG && console.debug(LOG_PREFIX + '[DEBUG]', ...args)
};

// 监听来自iframe的消息（用于iframe内调用扩展API）
window.addEventListener('message', function(event) {
    // 验证消息类型：处理iframe发来的请求
    if (!event.data || event.data.source !== 'seeyon-iframe') return;

    Logger.info('收到iframe消息:', event.data.action);

    var data = event.data;

    if (data.action === 'getRecentData') {
        // 通过chrome.runtime发送请求
        chrome.runtime.sendMessage({ action: 'getRecentData' }, function(resp) {
            // 发送响应回iframe
            event.source.postMessage({
                source: 'seeyon-parent',
                action: 'getRecentData',
                success: resp && resp.success,
                data: resp ? resp.data : null,
                error: resp && !resp.success ? (resp.error || '请求失败') : null
            }, '*');
        });
    }
});

const TARGET_TEMPLATE_IDS = new Set([
    '5700157742072248618',
    '6405666956814665521',
]);

function normalizeTemplateId(templateId) {
    return String(templateId || '').replace(/^-/, '');
}

function normalizeWorkHourSubject(subject) {
    return String(subject || '').replace(/^.*?(顾问工时登记-)/, '$1').trim();
}

function isWorkHourSubject(subject) {
    return normalizeWorkHourSubject(subject).startsWith('顾问工时登记-');
}

function isSupplementWorkHour(subject) {
    return String(subject || '').includes('补录');
}

function isTargetPage(doc = document, context = '主入口') {
    const win = doc.defaultView || window;
    const location = win.location;
    const params = new URLSearchParams(location.search);
    const pageUrl = location.href || '';
    const isBlankPage = pageUrl === 'about:blank';

    const byTemplateId = pageUrl.includes('collaboration.do') &&
                         params.get('method') === 'newColl' &&
                         TARGET_TEMPLATE_IDS.has(normalizeTemplateId(params.get('templateId')));

    const urlStartsWith = pageUrl.startsWith('https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=');
    const subjectInput = doc.getElementById('subject');
    const subjectValue = subjectInput && subjectInput.value ? String(subjectInput.value) : '';
    let globalSubject = '';
    try {
        globalSubject = typeof win.subject === 'string' ? win.subject : '';
    } catch (e) {}

    // 某些新页面/弹窗在刚加载时 URL 为 about:blank，先靠页面标题兜底
    const docTitle = doc.title || '';
    const titleSubject = String(docTitle || '') || '';
    const subjectStartsWith =
        isWorkHourSubject(subjectValue) ||
        isWorkHourSubject(globalSubject) ||
        isWorkHourSubject(titleSubject);

    const bySubject = (urlStartsWith || isBlankPage) && subjectStartsWith;

    const result = byTemplateId || bySubject;
    Logger.debug('isTargetPage:', result, 'byTemplateId:', byTemplateId, 'bySubject:', bySubject, 'url:', pageUrl, 'subjectValue:', subjectValue, 'globalSubject:', globalSubject, 'titleSubject:', titleSubject);
    if (!result) {
        Logger.info('[入口] 当前上下文未匹配工时签卡目标页，不显示悬浮球（' + context + '）', pageUrl);
    }
    return result;
}

function createFAB() {
    if (document.getElementById('seeyon-fab')) {
        Logger.warn('FAB已存在');
        return;
    }
    if (!document.body) {
        Logger.warn('[入口] 工时签卡悬浮球不显示：document.body 尚未就绪');
        return;
    }

    var fab = document.createElement('div');
    fab.id = 'seeyon-fab';
    fab.className = 'seeyon-fab';
    fab.innerHTML = '<img alt="">';
    fab.title = 'SHAI';
    try { fab.querySelector('img').src = chrome.runtime.getURL('icons/fab-84.png'); } catch (e) {}

    // 拖动相关变量
    var isDragging = false;
    var hasMoved = false;
    var startX, startY;
    var startLeft, startBottom;
    var DRAG_THRESHOLD = 5; // 拖动阈值，小于此值视为点击

    fab.onmousedown = function(e) {
        e = e || window.event;
        e.preventDefault();
        
        isDragging = true;
        hasMoved = false;
        startX = e.clientX;
        startY = e.clientY;
        
        // 获取当前位置
        var rect = fab.getBoundingClientRect();
        startLeft = rect.left;
        startBottom = window.innerHeight - rect.bottom;
        
        fab.style.transition = 'none'; // 拖动时禁用过渡动画
    };

    document.addEventListener('mousemove', function(e) {
        if (!isDragging) return;
        
        var deltaX = e.clientX - startX;
        var deltaY = e.clientY - startY;
        
        // 检查是否超过拖动阈值
        if (Math.abs(deltaX) > DRAG_THRESHOLD || Math.abs(deltaY) > DRAG_THRESHOLD) {
            hasMoved = true;
        }
        
        if (hasMoved) {
            var newLeft = startLeft + deltaX;
            var newBottom = startBottom - deltaY;
            
            // 边界限制
            newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - fab.offsetWidth));
            newBottom = Math.max(0, Math.min(newBottom, window.innerHeight - fab.offsetHeight));
            
            fab.style.left = newLeft + 'px';
            fab.style.bottom = newBottom + 'px';
            fab.style.right = 'auto'; // 清除right定位
        }
    });

    document.addEventListener('mouseup', function() {
        if (isDragging) {
            isDragging = false;
            fab.style.transition = ''; // 恢复过渡动画
        }
    });

    fab.onclick = function(e) {
        e = e || window.event;
        if (e.stopPropagation) e.stopPropagation();
        e.cancelBubble = true;
        
        // 只有在没有拖动时才触发点击
        if (!hasMoved) {
            Logger.info('FAB点击');
            showModal();
        }
    };

    document.body.appendChild(fab);
    Logger.info('FAB已创建');
}

function showModal() {
    Logger.debug('showModal开始');

    var overlay = document.getElementById('seeyon-modal-overlay');
    var modal = document.getElementById('seeyon-modal');

    if (!overlay) {
        Logger.info('创建弹窗DOM');
        overlay = document.createElement('div');
        overlay.id = 'seeyon-modal-overlay';
        overlay.className = 'seeyon-modal-overlay';

        modal = document.createElement('div');
        modal.id = 'seeyon-modal';
        modal.className = 'seeyon-modal';
        modal.innerHTML = buildModalInnerHTML();

        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        document.getElementById('seeyon-close-btn').onclick = function(e) {
            e = e || window.event;
            if (e.stopPropagation) e.stopPropagation();
            hideModal();
        };

        overlay.onclick = function(e) {
            e = e || window.event;
            if (e.target === overlay) {
                hideModal();
            }
        };
    } else {
        // 复用弹窗：重置双栏状态与右栏内容
        if (modal) modal.classList.remove('dual');
        var right = modal && modal.querySelector('.seeyon-modal-right');
        if (right) { right.classList.remove('active'); right.style.maxHeight = ''; }
    }

    overlay.classList.add('active');
    Logger.info('弹窗已显示');
    openFlow(document);
}

function hideModal() {
    var overlay = document.getElementById('seeyon-modal-overlay');
    if (overlay) {
        overlay.classList.remove('active');
        Logger.info('弹窗已隐藏');
    }
}

var WEEK_DAYS_SHORT = ['日', '一', '二', '三', '四', '五', '六'];

/**
 * 获取中国法定节假日列表（当年及上一年，确保跨年场景覆盖）
 */
function getHolidays() {
    var year = new Date().getFullYear();
    var holidays = {};

    // 上一年节假日（用于30天窗口跨年场景）
    holidays[(year - 1) + '-01-01'] = '元旦';
    holidays[(year - 1) + '-05-01'] = '劳动节';
    holidays[(year - 1) + '-05-02'] = '劳动节';
    holidays[(year - 1) + '-05-03'] = '劳动节';
    holidays[(year - 1) + '-05-04'] = '劳动节';
    holidays[(year - 1) + '-05-05'] = '劳动节';
    holidays[(year - 1) + '-10-01'] = '国庆节';
    holidays[(year - 1) + '-10-02'] = '国庆节';
    holidays[(year - 1) + '-10-03'] = '国庆节';
    holidays[(year - 1) + '-10-04'] = '国庆节';
    holidays[(year - 1) + '-10-05'] = '国庆节';
    holidays[(year - 1) + '-10-06'] = '国庆节';
    holidays[(year - 1) + '-10-07'] = '国庆节';

    // 固定节假日
    holidays[year + '-01-01'] = '元旦';
    holidays[year + '-05-01'] = '劳动节';
    holidays[year + '-05-02'] = '劳动节';
    holidays[year + '-05-03'] = '劳动节';
    holidays[year + '-05-04'] = '劳动节';
    holidays[year + '-05-05'] = '劳动节';
    holidays[year + '-10-01'] = '国庆节';
    holidays[year + '-10-02'] = '国庆节';
    holidays[year + '-10-03'] = '国庆节';
    holidays[year + '-10-04'] = '国庆节';
    holidays[year + '-10-05'] = '国庆节';
    holidays[year + '-10-06'] = '国庆节';
    holidays[year + '-10-07'] = '国庆节';

    // 2026年春节
    holidays['2026-01-29'] = '春节';
    holidays['2026-01-30'] = '春节';
    holidays['2026-01-31'] = '春节';
    holidays['2026-02-01'] = '春节';
    holidays['2026-02-02'] = '春节';

    // 2026年清明节
    holidays['2026-04-04'] = '清明节';

    // 2026年端午节
    holidays['2026-06-19'] = '端午节';

    // 2026年中秋节
    holidays['2026-09-27'] = '中秋节';

    return holidays;
}

function formatLocalDate(date) {
    return date.getFullYear() + '-' +
        String(date.getMonth() + 1).padStart(2, '0') + '-' +
        String(date.getDate()).padStart(2, '0');
}

function getMonday(date) {
    var d = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0, 0);
    var dayOfWeek = d.getDay(); // 0=周日, 1=周一, ... 6=周六
    var daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    d.setDate(d.getDate() - daysToMonday);
    return d;
}

/**
 * 生成最近30天的日期数组（按周一到周日排列）
 * 从最近30天所在周的周一开始，到本周周日结束，确保包含今天所在周。
 * @returns {Array<{date: string, day: number, weekday: string}>}
 */
function generateLast30Days() {
    var result = [];
    var today = new Date();
    var todayDate = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 12, 0, 0, 0);
    
    // 获取节假日列表
    var holidays = getHolidays();

    Logger.info('今天:', formatLocalDate(todayDate));

    var startDate = new Date(todayDate);
    startDate.setDate(todayDate.getDate() - 29); // 包含今天共30天

    var startMonday = getMonday(startDate);
    var endSunday = getMonday(todayDate);
    endSunday.setDate(endSunday.getDate() + 6);

    var todayStr = formatLocalDate(todayDate);

    for (var d = new Date(startMonday); d <= endSunday; d.setDate(d.getDate() + 1)) {
        var dateStr = formatLocalDate(d);
        var dayOfWeek = d.getDay(); // 0=周日, 1=周一, ... 6=周六
        result.push({
            date: dateStr,
            day: d.getDate(),
            weekday: '周' + WEEK_DAYS_SHORT[dayOfWeek],
            isHoliday: holidays[dateStr] !== undefined,
            holidayName: holidays[dateStr] || null,
            isWeekend: dayOfWeek === 0 || dayOfWeek === 6, // 周日或周六
            isToday: dateStr === todayStr
        });
    }

    if (!result.some(function(day) { return day.date === todayStr; })) {
        var currentMonday = getMonday(todayDate);
        for (var j = 0; j < 7; j++) {
            var currentWeekDate = new Date(currentMonday);
            currentWeekDate.setDate(currentMonday.getDate() + j);
            var currentWeekDateStr = formatLocalDate(currentWeekDate);
            var currentWeekDayOfWeek = currentWeekDate.getDay();
            result.push({
                date: currentWeekDateStr,
                day: currentWeekDate.getDate(),
                weekday: '周' + WEEK_DAYS_SHORT[currentWeekDayOfWeek],
                isHoliday: holidays[currentWeekDateStr] !== undefined,
                holidayName: holidays[currentWeekDateStr] || null,
                isWeekend: currentWeekDayOfWeek === 0 || currentWeekDayOfWeek === 6,
                isToday: currentWeekDateStr === todayStr
            });
        }
    }

    Logger.info('生成' + result.length + '天日期（覆盖最近30天和本周）:', result.map(x => x.date + '(' + x.weekday + ')').join(', '));
    return result;
}

// URL模板
var DETAIL_URL_TEMPLATE = 'https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=listSent&affairId=';

function buildDetailUrl(itemOrAffairId) {
    var affairId = (typeof itemOrAffairId === 'object') ? itemOrAffairId.affairId : itemOrAffairId;
    var source = (typeof itemOrAffairId === 'object' && itemOrAffairId.source) ? itemOrAffairId.source : 'sent';
    var openFrom = source === 'done' ? 'listDone' : (source === 'pending' ? 'listPending' : 'listSent');
    return 'https://xt.seeyon.com/seeyon/collaboration/collaboration.do?method=summary&openFrom=' + openFrom + '&affairId=' + encodeURIComponent(affairId);
}

/**
 * 生成日历视图HTML
 * @param {Object} dateMap - 日期聚合数据 { "2026-05-26": { workHours: [{affairId, subject}, ...], signIn: [...], signOut: [...] }, ... }
 * @returns {string} HTML字符串
 */
function generateCalendarHTML(dateMap) {
    var days = generateLast30Days();

    var html = '<div class="seeyon-calendar">';

    // 日历网格 - 每行7天（周一到周日）
    html += '<div class="seeyon-calendar-grid">';

    // 星期头部
    html += '<div class="seeyon-calendar-header">';
    html += '<span>周一</span><span>周二</span><span>周三</span><span>周四</span><span>周五</span><span>周六</span><span>周日</span>';
    html += '</div>';

    var totalWeeks = Math.ceil(days.length / 7);
    for (var week = 0; week < totalWeeks; week++) {
        html += '<div class="seeyon-calendar-row">';

        for (var col = 0; col < 7; col++) {
            var idx = week * 7 + col;
            if (idx < days.length) {
                var dayInfo = days[idx];
                var dayData = dateMap[dayInfo.date] || { workHours: [], signIn: [], signOut: [] };

                var cellClass = '';
                if (dayInfo.isToday) {
                    cellClass += ' today';
                }
                if (dayInfo.isHoliday) {
                    cellClass += ' holiday';
                } else if (dayInfo.isWeekend) {
                    cellClass += ' weekend';
                }
                var cellTitle = dayInfo.isHoliday ? ' title="' + dayInfo.holidayName + '"' : '';
                html += '<div class="seeyon-calendar-cell' + cellClass + '" data-date="' + dayInfo.date + '"' + cellTitle + '>';
                html += '<div class="cell-date">' + dayInfo.day + '</div>';
                html += '<div class="cell-checks">';

                // 第一列：工时登记
                html += '<div class="col">';
                if (dayData.workHours && dayData.workHours.length > 0) {
                    dayData.workHours.forEach(function(item) {
                        var url = buildDetailUrl(item);
                        var checkClass = isSupplementWorkHour(item.subject) ? 'red' : 'green';
                        var checkLabel = isSupplementWorkHour(item.subject) ? '工时补录' : '工时登记';
                        html += '<a href="' + url + '" target="_blank" class="check ' + checkClass + '" title="' + checkLabel + ': ' + (item.subject || '') + '" rel="noopener noreferrer">✓</a>';
                    });
                }
                html += '</div>';

                // 第二列：签到和签退（上下排列）
                html += '<div class="col">';
                // 橙勾：签到
                if (dayData.signIn && dayData.signIn.length > 0) {
                    dayData.signIn.forEach(function(item) {
                        var url = buildDetailUrl(item);
                        html += '<a href="' + url + '" target="_blank" class="check orange" title="签到: ' + (item.subject || '') + '" rel="noopener noreferrer">✓</a>';
                    });
                }
                // 紫勾：签退
                if (dayData.signOut && dayData.signOut.length > 0) {
                    dayData.signOut.forEach(function(item) {
                        var url = buildDetailUrl(item);
                        html += '<a href="' + url + '" target="_blank" class="check purple" title="签退: ' + (item.subject || '') + '" rel="noopener noreferrer">✓</a>';
                    });
                }
                html += '</div>';

                html += '</div>';
                html += '</div>';
            }
        }

        html += '</div>';
    }

    html += '</div>'; // end grid

    // 说明（放在日历下方）
    html += '<div class="seeyon-calendar-note">';
    html += '<p><strong>说明：</strong></p>';
    html += '<p><span class="check green">✓</span> 正常工时：参考已发流程标题中的日期</p>';
    html += '<p><span class="check red">✓</span> 补录工时：参考已发流程标题中的日期</p>';
    html += '<p><span class="check orange">✓</span> 签到：参考已发流程的发起日期</p>';
    html += '<p><span class="check purple">✓</span> 签退：参考已发流程的发起日期</p>';
    html += '</div>';

    html += '</div>'; // end calendar

    return html;
}

async function loadCalendarInto(doc, action, params) {
    var body = doc.getElementById('seeyon-body');
    if (!body) {
        Logger.error('body不存在');
        return null;
    }
    body.innerHTML = '<div class="seeyon-loading">加载中...</div>';
    try {
        var requestAction = action || 'getRecentData';
        Logger.info('发送请求:', requestAction, params || '');
        var dateMap = params ? await sendMsgWithParams(requestAction, params) : await sendMsg(requestAction);
        Logger.info('请求成功');
        body.innerHTML = generateCalendarHTML(dateMap);
        return dateMap;
    } catch (err) {
        Logger.error('加载失败:', err.message || err);
        body.innerHTML = '<div class="seeyon-error">加载失败: ' + (err.message || '未知错误') + '</div>';
        return null;
    }
}

// 构建弹窗主体 HTML（左栏日历 + 右栏明细占位）
function buildModalInnerHTML() {
    return '<div class="seeyon-modal-header">' +
        '<h3 class="seeyon-modal-title">最近30天工时、签卡情况</h3>' +
        '<button id="seeyon-close-btn">X</button>' +
        '</div>' +
        '<div class="seeyon-modal-cols">' +
        '<div class="seeyon-modal-left"><div id="seeyon-body"><div class="seeyon-loading">加载中...</div></div></div>' +
        '<div class="seeyon-modal-right"><div id="seeyon-right-body"></div></div>' +
        '</div>';
}

// 弹窗打开主流程：读取标题人员 → 按自己/他人选择数据源 → 左栏月度视图 + 右栏明细
async function openFlow(doc) {
    var globals = await readPageGlobals(doc);
    Logger.info('页面变量 name/subject:', JSON.stringify(globals));

    var subjectInfo = parseWorkHourSubject(globals.subject);
    // 新建页标题常未生成姓名，当前人员展示需回退到 background.getPageGlobals 取到的登录人姓名
    var currentPersonName = subjectInfo.personName || extractPersonFromSubject(globals.subject) || globals.name;
    renderCurrentPerson(doc, currentPersonName);

    var judge = judgeOwnership(globals.name, globals.subject);
    var action = 'getRecentData';
    var params = null;
    if (!judge.show && subjectInfo.personName && subjectInfo.subjectPrefix) {
        Logger.info('按标题解析到的人员加载工时数据:', JSON.stringify(subjectInfo));
        action = 'getRecentDataForPerson';
        params = {
            subjectPrefix: subjectInfo.subjectPrefix,
            subjectPrefixes: subjectInfo.subjectPrefixes,
            personName: subjectInfo.personName,
            department: subjectInfo.department
        };
    } else if (!judge.show && judge.reason !== 'no_name') {
        Logger.warn('标题无法解析为他人工时单据，按当前登录人展示右侧明细');
        judge.show = true;
    } else if (!judge.show) {
        Logger.warn('非本人单据且无法解析目标人员，保持单栏');
    }

    var dateMap = await loadCalendarInto(doc, action, params);
    renderCurrentPerson(doc, currentPersonName);
    if (!dateMap) {
        Logger.warn('左栏数据缺失，右侧不加载');
        return;
    }
    if (!judge.show && action !== 'getRecentDataForPerson') return;

    activateRightPanel(doc);
    var rightBody = doc.getElementById('seeyon-right-body');
    if (!rightBody) return;
    rightBody.innerHTML = '<div class="seeyon-right-head">最近5天工时明细</div><div class="seeyon-right-loading">加载中...</div>';
    loadRightPanelAsync(doc, dateMap, rightBody).catch(function (e) {
        Logger.error('右栏加载异常', e);
        rightBody.innerHTML = '<div class="seeyon-right-head">最近5天工时明细</div><div class="seeyon-right-fail">加载失败: ' + (e.message || e) + '</div>';
    });
}

// 读取当前登录人员姓名与单据标题（background 注入 MAIN world 读取，DOM 兜底）
function readPageGlobals(doc) {
    return new Promise(function (resolve) {
        var done = false;
        var timer = setTimeout(function () {
            if (done) return;
            done = true;
            Logger.warn('getPageGlobals 超时，使用DOM兜底');
            resolve(withDomFallback({ name: '', subject: '' }));
        }, 3000);

        var finish = function (data) {
            if (done) return;
            done = true;
            clearTimeout(timer);
            resolve(withDomFallback(data || { name: '', subject: '' }));
        };

        var withDomFallback = function (data) {
            try {
                if (!data.subject) {
                    var el = doc.getElementById('subject');
                    if (el && el.value) data.subject = String(el.value);
                }
            } catch (e) {}
            return data;
        };
        var fallback = function () {
            finish({ name: '', subject: '' });
        };
        try {
            chrome.runtime.sendMessage({ action: 'getPageGlobals' }, function (resp) {
                if (chrome.runtime.lastError || !resp || !resp.success) {
                    Logger.warn('getPageGlobals 失败:', chrome.runtime.lastError && chrome.runtime.lastError.message);
                    fallback();
                    return;
                }
                var data = resp.data || { name: '', subject: '' };
                finish({ name: data.name || '', subject: data.subject || '' });
            });
        } catch (e) {
            Logger.warn('readPageGlobals 异常', e);
            fallback();
        }
    });
}

// 从标题解析当前工单信息：顾问工时登记-{部门}-{姓名}-YYYY-MM-DD
function parseWorkHourSubject(subject) {
    var result = { department: '', personName: '', date: '', subjectPrefix: '', subjectPrefixes: [] };
    if (!subject) return result;
    var normalizedSubject = normalizeWorkHourSubject(subject);
    var match = normalizedSubject.match(/^顾问工时登记-(.+?)-(.+?)-(\d{4}-\d{2}-\d{2})/);
    if (!match) return result;
    result.department = match[1].trim();
    var rawPersonName = match[2].trim();
    result.personName = rawPersonName.replace(/^#/, '');
    result.date = match[3];
    result.subjectPrefix = '顾问工时登记-' + result.department + '-' + rawPersonName;
    result.subjectPrefixes = [result.subjectPrefix];
    var normalizedPrefix = '顾问工时登记-' + result.department + '-' + result.personName;
    if (normalizedPrefix !== result.subjectPrefix) {
        result.subjectPrefixes.push(normalizedPrefix);
    }
    return result;
}

function extractPersonFromSubject(subject) {
    return parseWorkHourSubject(subject).personName;
}

function renderCurrentPerson(doc, personName) {
    var body = doc.getElementById('seeyon-body');
    if (!body) return;
    var old = doc.getElementById('seeyon-current-person');
    if (old && old.parentNode) old.parentNode.removeChild(old);
    var div = doc.createElement('div');
    div.id = 'seeyon-current-person';
    div.className = 'seeyon-current-person';
    var label = document.createElement('span');
    label.className = 'seeyon-current-label';
    label.textContent = '当前人员:';
    var name = document.createElement('span');
    name.className = 'seeyon-current-name';
    name.textContent = personName || '';
    div.appendChild(label);
    div.appendChild(name);
    body.insertBefore(div, body.firstChild);
}

// 判断当前单据是否自己的（决策表见 docs/update-gs.md 3.3）
function judgeOwnership(name, subject) {
    if (!name) {
        Logger.warn('未获取到当前登录人员姓名，右侧不展示');
        return { show: false, reason: 'no_name' };
    }
    if (!subject) {
        Logger.info('标题为空，视为自己的单据');
        return { show: true, reason: '' };
    }
    if (subject.indexOf(name) >= 0) {
        Logger.info('标题包含当前用户姓名，视为自己的单据:', name);
        return { show: true, reason: '' };
    }
    Logger.info('标题不含当前用户姓名，视为他人单据:', name);
    return { show: false, reason: 'not_self' };
}

// 切换为双栏（加宽 + 显示右栏），并锁定右栏高度=左栏高度
// 防止右栏明细加载后撑高整体：左栏日历保持初始高度，仅右栏内部滚动
function activateRightPanel(doc) {
    var modal = doc.getElementById('seeyon-modal');
    if (modal) modal.classList.add('dual');
    var left = doc.querySelector('.seeyon-modal-left');
    var right = doc.querySelector('.seeyon-modal-right');
    if (right) right.classList.add('active');
    if (left && right && left.offsetHeight > 0) {
        right.style.maxHeight = left.offsetHeight + 'px';
    }
}

// 从 dateMap 取最近5个有工时登记的不同日期（降序），每天含其全部 affairId
function pickRecent5Days(dateMap) {
    if (!dateMap) return [];
    var dates = Object.keys(dateMap).filter(function (d) {
        return dateMap[d] && dateMap[d].workHours && dateMap[d].workHours.length > 0;
    });
    dates.sort(function (a, b) { return a < b ? 1 : (a > b ? -1 : 0); });
    return dates.slice(0, 5).map(function (date) {
        return { date: date, affairs: dateMap[date].workHours.map(function (w) { return { affairId: w.affairId, source: w.source || 'sent' }; }) };
    });
}

// 从 baseInfo JSON 文本中抓 cap4 模块的字段，避免大整型被 JSON.parse 变成 Number 精度损失
function extractCap4FieldFromText(jsonText, fieldName) {
    if (typeof jsonText !== 'string' || !jsonText) return '';

    var cap4Start = jsonText.indexOf('"cap4"');
    if (cap4Start < 0) cap4Start = jsonText.indexOf('\\"cap4\\"');
    if (cap4Start < 0) return '';

    // 不再用花括号截取 cap4 对象：baseInfo 里可能有嵌套对象/字符串，简单括号计数容易截断。
    // 直接从 cap4 之后找字段名，读取冒号后的字符串或数字字面量，保留原始文本精度。
    var keys = ['"' + fieldName + '"', '\\"' + fieldName + '\\"'];
    var keyPos = -1;
    var keyLen = 0;
    for (var k = 0; k < keys.length; k++) {
        keyPos = jsonText.indexOf(keys[k], cap4Start);
        if (keyPos >= 0) {
            keyLen = keys[k].length;
            break;
        }
    }
    if (keyPos < 0) return '';

    var colon = jsonText.indexOf(':', keyPos + keyLen);
    if (colon < 0) return '';

    var i = colon + 1;
    while (i < jsonText.length && /\s/.test(jsonText.charAt(i))) i++;

    // 兼容普通 JSON 字符串 "..." 与被转义后嵌在字符串里的 \"...\"
    var escapedQuote = jsonText.charAt(i) === '\\' && jsonText.charAt(i + 1) === '"';
    if (jsonText.charAt(i) === '"' || escapedQuote) {
        if (escapedQuote) i++;
        i++; // skip opening quote
        var out = '';
        while (i < jsonText.length) {
            var ch = jsonText.charAt(i);
            if (ch === '\\') {
                var next = jsonText.charAt(i + 1);
                if (next === '"') break;
                out += next || '';
                i += 2;
                continue;
            }
            if (ch === '"') break;
            out += ch;
            i++;
        }
        return out;
    }

    var start = i;
    while (i < jsonText.length && /[-0-9.]/.test(jsonText.charAt(i))) i++;
    return jsonText.slice(start, i);
}

// 通过 affairId 调用 baseInfo 接口获取 rightId/moduleId/affairId，避免隐藏 iframe 加载详情页触发页面弹窗
async function fetchDetailParamsByAffairId(affairRef) {
    var affairId = (typeof affairRef === 'object') ? affairRef.affairId : affairRef;
    affairId = String(affairId || '');
    if (!affairId) {
        Logger.error('baseInfo 获取失败：缺少 affairId，原始入参=', affairRef);
        throw new Error('缺少 affairId');
    }

    var url = 'https://xt.seeyon.com/seeyon/rest/collaboration/v1/web/new/baseInfo' +
        '?method=summary&openFrom=listDone&affairId=' + encodeURIComponent(affairId) +
        '&showTab=true&templateId=&from=listDone&projectId=&summaryId=&baseObjectId=&baseApp=&cashId=&processId=&designId=&docId=&_r=';
    Logger.info('baseInfo 获取工时详情参数 affairId=' + affairId + ' url=' + url);

    var res;
    var text = '';
    try {
        res = await fetch(url, { method: 'GET', credentials: 'include' });
        text = await res.text();
    } catch (e) {
        Logger.error('baseInfo 请求异常 affairId=' + affairId, e && e.message ? e.message : e);
        throw e;
    }

    var json = null;
    try { json = JSON.parse(text); } catch (e2) {}
    Logger.info('baseInfo 响应 affairId=' + affairId + ' status=' + res.status + ' len=' + text.length);

    if (!res.ok) {
        Logger.error('baseInfo HTTP失败 affairId=' + affairId + ' status=' + res.status + ' body前500=' + text.slice(0, 500));
        throw new Error('baseInfo HTTP错误: ' + res.status);
    }
    if (!json) {
        Logger.error('baseInfo 非JSON affairId=' + affairId + ' body前500=' + text.slice(0, 500));
        throw new Error('baseInfo 响应非JSON');
    }

    var data = json && json.data;
    var cap4 = data && data.zwIframe && data.zwIframe.cap4;
    var rightId = cap4 && cap4.rightId;
    var moduleId = cap4 && cap4.moduleId;

    // 兜底：直接从原始 JSON 文本提取，规避超长数字被 JSON.parse 改写
    var rawModuleId = extractCap4FieldFromText(text, 'moduleId');
    var rawRightId = extractCap4FieldFromText(text, 'rightId');
    Logger.info('baseInfo 原始参数提取 affairId=' + affairId + ' rawModuleId=' + (rawModuleId || '(空)') + ' rawRightId=' + (rawRightId ? rawRightId.slice(0, 24) + '…' : '(空)'));
    // 必须优先使用原始文本值：moduleId/rightId 是超长 ID，JSON.parse 后即使有值也可能已精度丢失
    moduleId = rawModuleId || moduleId;
    rightId = rawRightId || rightId;

    if (!rightId || !moduleId) {
        Logger.error('baseInfo 缺少 moduleId/rightId affairId=' + affairId,
            'topKeys=' + Object.keys(json || {}).join(','),
            'dataKeys=' + (data && typeof data === 'object' ? Object.keys(data).join(',') : '(无data)'),
            'zwIframeKeys=' + (data && data.zwIframe && typeof data.zwIframe === 'object' ? Object.keys(data.zwIframe).join(',') : '(无zwIframe)'),
            'cap4=' + JSON.stringify(cap4 || null));
        throw new Error('baseInfo 未返回 moduleId/rightId');
    }

    rightId = String(rightId);
    moduleId = String(moduleId);

    Logger.info('baseInfo 参数获取成功 affairId=' + affairId + ' moduleId=' + moduleId + ' rightId=' + rightId.slice(0, 24) + '…');
    return { rightId: rightId, moduleId: moduleId, affairId: affairId };
}

// 简单并发池
function runPool(items, limit, worker) {
    var results = new Array(items.length);
    var idx = 0;
    function next() {
        return Promise.resolve().then(function () {
            if (idx >= items.length) return;
            var i = idx++;
            return Promise.resolve(worker(items[i], i)).then(function (r) {
                results[i] = r;
            }).catch(function (e) {
                results[i] = { __error: e };
            }).then(function () {
                return next();
            });
        });
    }
    var runners = [];
    for (var k = 0; k < Math.min(limit, items.length); k++) runners.push(next());
    return Promise.all(runners).then(function () { return results; });
}

function sendMsgWithParams(action, params) {
    return new Promise(function (resolve, reject) {
        var timeout = action === 'getWorkHourDetail' ? 60000 : 30000;
        var done = false;
        var timer = setTimeout(function () {
            if (done) return;
            done = true;
            reject(new Error(action + ' 请求超时(' + timeout + 'ms)'));
        }, timeout);
        try {
            chrome.runtime.sendMessage({ action: action, params: params }, function (resp) {
                if (done) return;
                done = true;
                clearTimeout(timer);
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message || '扩展通信失败'));
                    return;
                }
                if (resp && resp.success) {
                    resolve(resp.data);
                } else {
                    reject(new Error(resp ? resp.error : '请求失败'));
                }
            });
        } catch (e) {
            if (done) return;
            done = true;
            clearTimeout(timer);
            reject(e);
        }
    });
}

// 抓取单张工时单（一个 affairId）的明细行
async function fetchDayDetail(affairRef) {
    var params = await fetchDetailParamsByAffairId(affairRef);
    var expectedAffairId = (typeof affairRef === 'object') ? (affairRef && affairRef.affairId) : affairRef;
    if (params.affairId && String(params.affairId) !== String(expectedAffairId)) {
        Logger.warn('affairId 不一致 link=' + String(expectedAffairId) + ' baseInfo=' + params.affairId);
    }
    return await sendMsgWithParams('getWorkHourDetail', params);
}

// 右栏主加载：取最近5天 → 并发抓取 → 按天渲染
async function loadRightPanelAsync(doc, dateMap, rightBody) {
    var days = pickRecent5Days(dateMap);
    Logger.info('最近5天:', JSON.stringify(days));
    if (!days.length) {
        rightBody.innerHTML = '<div class="seeyon-right-head">最近5天工时明细</div><div class="seeyon-right-empty">暂无工时登记</div>';
        return;
    }

    // 骨架 loading
    rightBody.innerHTML = '<div class="seeyon-right-sticky">' +
        '<div class="seeyon-right-head">最近5天工时明细</div>' +
        DETAIL_HEAD_HTML +
        '</div>' +
        days.map(function (d) { return dayCardHTML(d.date, null, 'loading', d.affairs && d.affairs[0]); }).join('');

    // 展开所有 affairId 任务，记录所属天索引
    var tasks = [];
    var taskDay = [];
    days.forEach(function (d, di) {
        d.affairs.forEach(function (affairId) {
            tasks.push(affairId);
            taskDay.push(di);
        });
    });

    var results = await runPool(tasks, 3, function (affairId) {
        return fetchDayDetail(affairId).then(function (rows) {
            return { ok: true, rows: rows || [] };
        }).catch(function (e) {
            var failAffairId = (typeof affairId === 'object') ? affairId.affairId : affairId;
            Logger.warn('抓取明细失败 affairId=' + failAffairId, e.message || e);
            return { ok: false, error: e.message || String(e) };
        });
    });

    // 按天聚合
    var dayResults = days.map(function (d) {
        return { date: d.date, affairs: d.affairs, rows: [], allOk: true, anyOk: false };
    });
    results.forEach(function (r, i) {
        var di = taskDay[i];
        if (r && r.ok) {
            dayResults[di].rows.push.apply(dayResults[di].rows, r.rows || []);
            dayResults[di].anyOk = true;
        } else {
            dayResults[di].allOk = false;
        }
    });

    // 渲染（保留头部）
    var sample = '';
    dayResults.forEach(function (dr) {
        dr.rows.forEach(function (r) { if (!sample && r.content) sample = r.content; });
    });
    Logger.info('工作内容样本(原始前300字):', (sample || '(空)').slice(0, 300));
    var html = '<div class="seeyon-right-sticky">' +
        '<div class="seeyon-right-head">最近5天工时明细</div>' +
        DETAIL_HEAD_HTML +
        '</div>';
    html += dayResults.map(function (dr) {
        var status;
        if (!dr.allOk && !dr.anyOk) status = 'fail';
        else if (dr.rows.length === 0) status = 'empty';
        else status = 'ok';
        return dayCardHTML(dr.date, dr.rows, status, dr.affairs && dr.affairs[0]);
    }).join('');
    rightBody.innerHTML = html;
}

// YYYY-MM-DD -> 周X
function weekdayOf(dateStr) {
    try {
        var p = dateStr.split('-');
        var d = new Date(+p[0], +p[1] - 1, +p[2]);
        return '周' + WEEK_DAYS_SHORT[d.getDay()];
    } catch (e) {
        return '';
    }
}

function escapeHtml(str) {
    return String(str == null ? '' : str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// 解码 HTML 实体（致远富文本字段常以实体编码返回，需解码后才能作为 HTML 渲染）
function decodeHtmlEntities(str) {
    if (!str) return '';
    var el = document.createElement('textarea');
    var s = String(str);
    var i = 0;
    while (i < 3 && /&[a-zA-Z#0-9]+;/i.test(s)) {
        el.innerHTML = s;
        var next = el.value;
        if (next === s) break;
        s = next;
        i++;
    }
    return s;
}

// 富文本渲染：解码实体 + 去除脚本（数据来自内部表单接口，保留样式）
function renderRichText(content) {
    var html = decodeHtmlEntities(content || '');
    return html.replace(/<script[\s\S]*?<\/script>/gi, '');
}

// 右栏明细统一表头（各天卡片共用，避免每天重复 thead）
var DETAIL_HEAD_HTML = '<table class="seeyon-detail-table seeyon-detail-head"><thead><tr>' +
    '<th>工时类型</th><th>项目名称</th><th>工作内容</th><th>消耗工时</th>' +
    '</tr></thead></table>';

// 单天卡片 HTML（status: loading/fail/empty/ok；affairRef 可选，提供则日期标题可点击跳转详情页）
function dayCardHTML(date, rows, status, affairRef) {
    var body;
    if (status === 'loading') {
        body = '<div class="seeyon-right-loading">加载中...</div>';
    } else if (status === 'fail') {
        body = '<div class="seeyon-right-fail">该天明细加载失败</div>';
    } else if (status === 'empty' || !rows || !rows.length) {
        body = '<div class="seeyon-right-empty">当天无工时明细</div>';
    } else {
        body = '<table class="seeyon-detail-table"><tbody>';
        rows.forEach(function (r) {
            body += '<tr>' +
                '<td>' + escapeHtml(r.type) + '</td>' +
                '<td>' + escapeHtml(r.project) + '</td>' +
                '<td class="seeyon-detail-content">' + renderRichText(r.content) + '</td>' +
                '<td>' + escapeHtml(r.hours) + '</td>' +
                '</tr>';
        });
        body += '</tbody></table>';
    }
    // 日期标题：有 affairRef 时整体可点击，新标签打开该天工时登记详情页（与左栏日历勾一致）
    var head;
    if (affairRef) {
        head = '<div class="seeyon-day-head">' +
            '<a class="seeyon-day-link" href="' + buildDetailUrl(affairRef) + '" target="_blank" rel="noopener noreferrer" title="点击在新标签页打开该天工时登记详情">' +
            '<span class="seeyon-day-date">' + escapeHtml(date) + '</span>' +
            '<span class="seeyon-day-week">' + weekdayOf(date) + '</span>' +
            '</a></div>';
    } else {
        head = '<div class="seeyon-day-head"><span class="seeyon-day-date">' + escapeHtml(date) + '</span><span class="seeyon-day-week">' + weekdayOf(date) + '</span></div>';
    }
    return '<div class="seeyon-day-card">' + head + body + '</div>';
}

function sendMsg(action) {
    return new Promise(function(resolve, reject) {
        var done = false;
        var timer = setTimeout(function () {
            if (done) return;
            done = true;
            reject(new Error(action + ' 请求超时'));
        }, 20000);
        try {
            chrome.runtime.sendMessage({ action: action }, function(resp) {
                if (done) return;
                done = true;
                clearTimeout(timer);
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message || '扩展通信失败'));
                    return;
                }
                if (resp && resp.success) {
                    resolve(resp.data);
                } else {
                    reject(new Error(resp ? resp.error : '请求失败'));
                }
            });
        } catch (e) {
            if (done) return;
            done = true;
            clearTimeout(timer);
            reject(e);
        }
    });
}

function init() {
    Logger.info('init', window.location.href);
    if (isTargetPage(document, 'init')) {
        Logger.info('目标页面，创建UI');
        createFAB();
    } else {
        Logger.info('非目标页面，开始轮询检查...');
        // 检测iframe
        detectTargetIframes();
        // 开始轮询，等待页面元素加载完成
        let checkCount = 0;
        const maxCheckCount = 10;
        const pollInterval = setInterval(() => {
            checkCount++;
            Logger.debug(`轮询检查中 ${checkCount}/${maxCheckCount}`);
            if (isTargetPage(document, 'init轮询第' + checkCount + '次')) {
                Logger.info('轮询发现目标页面，创建UI');
                clearInterval(pollInterval);
                createFAB();
            } else if (checkCount >= maxCheckCount) {
                Logger.info('轮询超时，停止检查');
                clearInterval(pollInterval);
            }
        }, 200);
    }
}

// 检测并处理iframe - 提前定义，确保在init调用前已初始化
var observedIframes = new WeakSet();

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// SPA 路由监听
var lastHref = location.href;
setInterval(function() {
    if (location.href !== lastHref) {
        lastHref = location.href;
        Logger.info('URL变化:', location.href);
        if (isTargetPage(document, 'URL变化')) {
            if (!document.getElementById('seeyon-fab')) {
                createFAB();
            }
        }
    }
}, 1000);

function detectTargetIframes() {
    var iframes = document.querySelectorAll('iframe');
    if (iframes.length === 0) {
        Logger.info('[入口] 未发现 iframe，iframe 内工时签卡悬浮球不显示');
        return;
    }
    iframes.forEach(function(iframe) {
        if (observedIframes.has(iframe)) return;
        observedIframes.add(iframe);

        try {
            var iframeDoc = getIframeDocumentSafe(iframe);
            
            if (iframeDoc) {
                // 等待iframe加载完成后再检查
                const checkIframe = function() {
                    try {
                        var doc = getIframeDocumentSafe(iframe);
                        if (!doc) return;
                        
                        // 尝试检查iframe是否是目标页面
                        if (isTargetPage(doc, 'iframe加载检查')) {
                            Logger.info('检测到目标iframe');
                            checkAndCreateFABInIframe(iframe, doc);
                        } else {
                            // 如果不是，开始轮询等待subject输入框填充
                            Logger.info('开始轮询检查iframe...');
                            let checkCount = 0;
                            const maxCheckCount = 10;
                            const pollInterval = setInterval(() => {
                                checkCount++;
                                try {
                                    var currentDoc = getIframeDocumentSafe(iframe);
                                    if (!currentDoc) {
                                        Logger.debug('iframe文档暂不可用，继续等待...');
                                        if (checkCount >= maxCheckCount) clearInterval(pollInterval);
                                        return;
                                    }
                                    Logger.debug(`iframe轮询检查中 ${checkCount}/${maxCheckCount}`);
                                    if (isTargetPage(currentDoc, 'iframe轮询第' + checkCount + '次')) {
                                        Logger.info('iframe轮询发现目标页面');
                                        clearInterval(pollInterval);
                                        checkAndCreateFABInIframe(iframe, currentDoc);
                                    } else if (checkCount >= maxCheckCount) {
                                        Logger.info('iframe轮询超时');
                                        clearInterval(pollInterval);
                                    }
                                } catch (e) {
                                    Logger.warn('iframe轮询检查失败:', e.message);
                                    clearInterval(pollInterval);
                                }
                            }, 200);
                        }
                    } catch (e) {
                        Logger.warn('检查iframe失败:', e.message);
                    }
                };
                
                // 如果iframe已经加载完成，立即检查
                if (iframeDoc.readyState === 'complete') {
                    Logger.info('iframe已加载完成，立即检查');
                    checkIframe();
                } else {
                    // 否则等待加载完成
                    Logger.info('等待iframe加载完成...');
                    iframe.addEventListener('load', checkIframe);
                }
            }
        } catch (e) {
            // 跨域iframe无法访问，静默处理
        }
    });
}

function getIframeDocumentSafe(iframe) {
    if (!iframe) return null;
    try {
        if (iframe.contentDocument) return iframe.contentDocument;
        if (iframe.contentWindow && iframe.contentWindow.document) return iframe.contentWindow.document;
    } catch (e) {
        return null;
    }
    return null;
}

function checkAndCreateFABInIframe(iframe, iframeDoc) {
    if (!iframeDoc) {
        Logger.warn('[入口] iframe工时签卡悬浮球不显示：iframeDoc 为空');
        return;
    }
    if (!iframeDoc.body) {
        Logger.warn('[入口] iframe工时签卡悬浮球不显示：iframe body 尚未就绪');
        return;
    }

    // 检查是否是目标页面
    if (isTargetPage(iframeDoc, 'iframe创建前校验')) {
        // 避免重复创建
        if (iframeDoc.getElementById('seeyon-fab')) {
            Logger.warn('iframe中FAB已存在');
            return;
        }
        
        // 在iframe中注入FAB
        var fab = iframeDoc.createElement('div');
        fab.id = 'seeyon-fab';
        fab.className = 'seeyon-fab';
        fab.innerHTML = '<img alt="" style="width:42px;height:42px;display:block;object-fit:cover;pointer-events:none;">';
        fab.title = 'SHAI';
        fab.style.cssText = 'position:fixed !important;bottom:20px !important;right:20px !important;width:42px !important;height:42px !important;background:#fff !important;border-radius:50% !important;cursor:pointer !important;z-index:2147483647 !important;display:flex !important;align-items:center !important;justify-content:center !important;color:white !important;font-weight:bold !important;font-size:16px !important;box-shadow:0 2px 8px rgba(0,0,0,0.3) !important;border:2px solid #fff !important;overflow:hidden !important;';
        try { fab.querySelector('img').src = chrome.runtime.getURL('icons/fab-84.png'); } catch (e) {}
        fab.onclick = function(e) {
            e.stopPropagation();
            showModalInIframe(iframe, iframeDoc);
        };
        iframeDoc.body.appendChild(fab);
        Logger.info('iframe中FAB已创建, body已有子元素:', iframeDoc.body.children.length);
    } else {
        Logger.info('[入口] iframe未匹配工时签卡目标页，不显示悬浮球');
    }
}

// 日历样式（用于iframe中动态注入）
var CALENDAR_STYLES = `
.seeyon-calendar { font-size: 12px; }
.seeyon-calendar-grid { display: flex; flex-direction: column; gap: 8px; }
.seeyon-calendar-header { display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; text-align: center; font-size: 12px; color: #666; font-weight: bold; padding-bottom: 6px; border-bottom: 1px solid #e0e0e0; }
.seeyon-calendar-row { display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; }
.seeyon-calendar-cell { display: flex; flex-direction: column; align-items: center; padding: 8px 4px; background: #fafafa; border: 1px solid #e0e0e0; border-radius: 6px; min-height: 60px; }
.seeyon-calendar-cell:hover { background: #f0f7fc; border-color: #4a90e2; }
.seeyon-calendar-cell.today { border: 2px solid #4a90e2; box-shadow: 0 0 0 2px rgba(74,144,226,0.12); }
.seeyon-calendar-cell.holiday { background: #fff5f5; border-color: #ffccc7; }
.seeyon-calendar-cell.holiday .cell-date { color: #ff4d4f; }
.seeyon-calendar-cell.weekend { background: #e8e8e8; border-color: #d0d0d0; }
.seeyon-calendar-cell.weekend .cell-date { color: #666; }
.cell-date { font-size: 16px; font-weight: bold; color: #333; }
.cell-checks { display: flex; flex-direction: row; align-items: flex-start; gap: 8px; width: 100%; justify-content: center; }
.cell-checks .col { display: flex; flex-direction: column; align-items: center; gap: 3px; }
.check { font-size: 14px; font-weight: bold; text-decoration: none; cursor: pointer; }
.check:hover { text-decoration: underline; }
.check.green { color: #4caf50; }
.check.red { color: #e53935; }
.check.orange { color: #ff9800; }
.check.purple { color: #9c27b0; }
.seeyon-calendar-note { margin-top: 15px; padding: 10px; background: #f5f5f5; border-radius: 4px; font-size: 11px; color: #666; }
.seeyon-calendar-note p { margin: 4px 0; }
.seeyon-current-person { margin: 0 0 10px 0; padding: 8px 10px; background: #f0f7fc; border: 1px solid #c5e0f7; border-radius: 4px; color: #4a90e2; font-size: 12px; font-weight: bold; }
.seeyon-current-name { display: inline-block; color: #fff; background: linear-gradient(135deg, #4a90e2, #2c6fb0); padding: 2px 10px; margin-left: 6px; border-radius: 12px; font-size: 12px; font-weight: bold; box-shadow: 0 1px 3px rgba(74,144,226,0.4); }

/* 弹窗双栏 + 右栏明细样式（与 styles.css 保持一致） */
#seeyon-modal.dual { width: min(1200px, calc(100vw - 48px)) !important; max-height: calc(100vh - 48px) !important; }
.seeyon-modal-cols { display: flex; align-items: stretch; max-height: calc(100vh - 90px); min-height: 0; }
.seeyon-modal-left { flex: 9 1 0; min-width: 0; min-height: 0; overflow-y: auto; }
.seeyon-modal-right { flex: 11 1 0; min-width: 0; min-height: 0; overflow-y: auto; display: none; background: #fafafa; }
.seeyon-modal-right.active { display: block; }
.seeyon-right-head { font-size: 12px; color: #4a90e2; font-weight: bold; padding: 0 0 8px 0; }
.seeyon-right-sticky { position: sticky; top: 0; background: #fff; z-index: 2; margin-bottom: 8px; }
.seeyon-day-card { background: #fff; border: 1px solid #e0e0e0; border-radius: 6px; margin-bottom: 10px; overflow: hidden; }
.seeyon-day-head { display: flex; justify-content: space-between; align-items: center; padding: 6px 10px; background: #f0f7fc; color: #4a90e2; font-size: 12px; font-weight: bold; border-bottom: 1px solid #e0e0e0; }
.seeyon-day-week { color: #888; font-weight: normal; margin-left: 6px; }
.seeyon-day-link { display: flex; align-items: center; width: 100%; color: inherit; text-decoration: none; cursor: pointer; }
.seeyon-day-link:hover { text-decoration: underline; }
.seeyon-day-link:hover .seeyon-day-date { color: #2c6fb0; }
.seeyon-detail-table { width: 100%; border-collapse: collapse; font-size: 11px; table-layout: fixed; }
.seeyon-detail-table th { background: #fafafa; color: #555; text-align: left; padding: 5px 6px; border-bottom: 1px solid #eee; word-break: break-word; }
.seeyon-detail-table td { padding: 5px 6px; border-bottom: 1px solid #f0f0f0; vertical-align: top; word-break: break-word; }
.seeyon-detail-table th:nth-child(1), .seeyon-detail-table td:nth-child(1) { width: 13%; }
.seeyon-detail-table th:nth-child(2), .seeyon-detail-table td:nth-child(2) { width: 13%; }
.seeyon-detail-table th:nth-child(3), .seeyon-detail-table td:nth-child(3) { width: 61%; }
.seeyon-detail-table th:nth-child(4), .seeyon-detail-table td:nth-child(4) { width: 13%; }
.seeyon-detail-content img { max-width: 100%; }
.seeyon-right-loading, .seeyon-right-empty { text-align: center; color: #999; padding: 14px; font-size: 12px; }
.seeyon-right-fail { text-align: center; color: #e74c3c; padding: 14px; font-size: 12px; }
`;

function showModalInIframe(iframe, iframeDoc) {
    Logger.info('iframe中showModal');

    // 注入样式（如果不存在）
    if (!iframeDoc.getElementById('seeyon-styles')) {
        var styleEl = iframeDoc.createElement('style');
        styleEl.id = 'seeyon-styles';
        styleEl.textContent = CALENDAR_STYLES;
        iframeDoc.head.appendChild(styleEl);
        Logger.info('样式已注入iframe');
    }

    var overlay = iframeDoc.getElementById('seeyon-modal-overlay');
    var modal = iframeDoc.getElementById('seeyon-modal');

    if (!overlay) {
        overlay = iframeDoc.createElement('div');
        overlay.id = 'seeyon-modal-overlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:999998;display:none;align-items:center;justify-content:center;';

        modal = iframeDoc.createElement('div');
        modal.id = 'seeyon-modal';
        modal.style.cssText = 'width:600px;max-height:80vh;background:white;border-radius:8px;overflow:hidden;';
        modal.innerHTML =
            '<div style="background:#4a90e2;color:white;padding:10px 15px;display:flex;justify-content:space-between;align-items:center;">' +
            '<h3 style="margin:0;font-size:14px;">最近30天工时、签卡情况</h3>' +
            '<button id="seeyon-close-btn" style="background:rgba(255,255,255,0.3);border:none;color:white;width:24px;height:24px;border-radius:4px;cursor:pointer;font-size:16px;">X</button>' +
            '</div>' +
            '<div class="seeyon-modal-cols">' +
            '<div class="seeyon-modal-left"><div id="seeyon-body" style="padding:15px;"><div style="text-align:center;padding:30px;color:#666;">加载中...</div></div></div>' +
            '<div class="seeyon-modal-right"><div id="seeyon-right-body" style="padding:15px;"></div></div>' +
            '</div>';

        overlay.appendChild(modal);
        iframeDoc.body.appendChild(overlay);

        iframeDoc.getElementById('seeyon-close-btn').onclick = function() {
            overlay.style.display = 'none';
        };

        overlay.onclick = function(e) {
            if (e.target === overlay) {
                overlay.style.display = 'none';
            }
        };
    } else {
        // 复用弹窗：重置双栏状态
        if (modal) { modal.classList.remove('dual'); modal.style.width = '600px'; }
        var right = modal && modal.querySelector('.seeyon-modal-right');
        if (right) { right.classList.remove('active'); right.style.maxHeight = ''; }
    }

    overlay.style.display = 'flex';
    openFlow(iframeDoc);
}

// loadDataInIframe 已由 openFlow(iframeDoc) + loadCalendarInto 取代（双栏弹窗统一入口）

// 定期检测新增的iframe
setInterval(detectTargetIframes, 2000);

Logger.info('内容脚本加载完成');

// [已临时禁用] 百度统计埋点 - 通过后台脚本注入到主世界（恢复时同步放开 background.js + manifest 权限）
// chrome.runtime.sendMessage({ action: 'injectBaiduTongji' }, (response) => {
//     if (response && response.success) {
//         Logger.info('百度统计注入成功');
//     } else {
//         Logger.warn('百度统计注入失败:', response?.error);
//     }
// });
