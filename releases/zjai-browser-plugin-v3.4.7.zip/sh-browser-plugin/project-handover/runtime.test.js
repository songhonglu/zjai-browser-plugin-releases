const assert = require('assert');
const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');
const dependencyRoot = process.env.CODEX_NODE_MODULES || path.join(os.homedir(), '.cache', 'codex-runtimes', 'codex-primary-runtime', 'dependencies', 'node', 'node_modules');
const { chromium } = require(path.join(dependencyRoot, 'playwright'));
const JSZip = require(path.join(dependencyRoot, 'jszip'));

const workspaceRoot = path.resolve(__dirname, '..', '..');
const mimeTypes = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' };

function serveFile(request, response) {
  const pathname = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
  const filePath = path.join(workspaceRoot, pathname.replace(/^\//, ''));
  if (!filePath.startsWith(workspaceRoot) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    response.writeHead(404).end('not found');
    return;
  }
  response.writeHead(200, { 'content-type': mimeTypes[path.extname(filePath)] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(response);
}

(async () => {
  const server = http.createServer(serveFile);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  const outputDir = fs.mkdtempSync(path.join(os.tmpdir(), 'project-handover-qa-'));
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  try {
    await page.goto(`http://127.0.0.1:${address.port}/sh-browser-plugin/project-handover/fixture.html`);
    const launcher = page.locator('#project-handover-fab');
    await launcher.waitFor({ state: 'visible' });
    const launcherBefore = await launcher.boundingBox();
    const ballBox = await launcher.locator('#ball').boundingBox();
    await page.mouse.move(ballBox.x + 20, ballBox.y + 20);
    await page.mouse.down();
    await page.mouse.move(ballBox.x - 120, ballBox.y - 60, { steps: 5 });
    await page.mouse.up();
    const launcherAfter = await launcher.boundingBox();
    assert.notStrictEqual(Math.round(launcherAfter.x), Math.round(launcherBefore.x), '入口拖动后位置应变化');
    await page.waitForTimeout(300);
    await launcher.locator('#ball').click();
    await launcher.locator('#open').click();
    const panel = page.locator('#project-handover-panel');
    await panel.waitFor({ state: 'visible' });
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    const panelText = await panel.locator('#ph-fields').innerText();
    for (const expected of ['项目基本信息', '客户干系人', '项目组成员', '项目交接信息', '项目任务', '项目预计风险', '首付款', '王涛', '完成项目启动和蓝图确认', '完成电子签章接口开发']) {
      assert.match(panelText, new RegExp(expected), `弹框应按网页区块展示：${expected}`);
    }
    assert.strictEqual(await page.evaluate(() => document.activeElement && document.activeElement.id), 'ph-close', '打开弹框后焦点应进入关闭按钮');
    await panel.locator('#ph-close').click();
    assert.strictEqual(await launcher.evaluate((host) => host.shadowRoot.activeElement && host.shadowRoot.activeElement.id), 'ball', '关闭弹框后焦点应返回入口');
    await launcher.locator('#ball').click();
    await launcher.locator('#open').click();
    await panel.waitFor({ state: 'visible' });
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    assert.match(await panel.locator('#ph-fields').innerText(), /紫软（苏州）信息科技有限公司/);
    assert.match(await panel.locator('#ph-fields').innerText(), /国产化环境，麒麟系统/);
    assert.match(await panel.locator('#ph-fields').innerText(), /同源iframe补充/);
    assert.doesNotMatch(await panel.locator('#ph-fields').innerText(), /隐藏旧值|HIDDEN-OLD/);

    const header = panel.locator('#ph-header');
    const beforeDrag = await panel.boundingBox();
    const headerBox = await header.boundingBox();
    await page.mouse.move(headerBox.x + 120, headerBox.y + 16);
    await page.mouse.down();
    await page.mouse.move(headerBox.x - 80, headerBox.y + 70, { steps: 5 });
    await page.mouse.up();
    const afterDrag = await panel.boundingBox();
    assert.notStrictEqual(Math.round(afterDrag.x), Math.round(beforeDrag.x), '弹框拖动后位置应变化');

    await page.locator('#delivery-content').fill('合同管理、项目管理、电子签章');
    await panel.locator('#ph-reread').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-fields')?.textContent.includes('合同管理、项目管理、电子签章'));
    assert.match(await panel.locator('#ph-fields').innerText(), /合同管理、项目管理、电子签章/);

    const downloadPromise = page.waitForEvent('download');
    await panel.locator('#ph-generate').click();
    const download = await downloadPromise;
    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    assert.strictEqual(download.suggestedFilename(), `项目交接会议纪要-紫软（苏州）信息科技有限公司-${today}.docx`);
    const docxPath = path.join(outputDir, download.suggestedFilename());
    await download.saveAs(docxPath);
    await page.evaluate(() => {
      window.__projectHandoverGetURL = window.chrome.runtime.getURL;
      window.chrome.runtime.getURL = () => 'chrome-extension://invalid/template.docx';
    });
    await panel.locator('#ph-generate').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('生成失败'));
    assert.match(await panel.locator('#ph-status').innerText(), /重新加载插件/);
    await page.evaluate(() => { window.chrome.runtime.getURL = window.__projectHandoverGetURL; });
    await panel.locator('#ph-reread').focus();
    await page.keyboard.press('Tab');
    assert.strictEqual(await page.evaluate(() => document.activeElement && document.activeElement.id), 'ph-generate');
    const focusStyle = await panel.locator('#ph-generate').evaluate((node) => getComputedStyle(node).outlineStyle);
    assert.notStrictEqual(focusStyle, 'none', '键盘焦点应有可见轮廓');
    await page.screenshot({ path: path.join(outputDir, 'project-handover-panel.png'), fullPage: true });
    for (const width of [768, 375]) {
      await page.setViewportSize({ width, height: 900 });
      await page.evaluate(() => window.dispatchEvent(new Event('resize')));
      await page.waitForTimeout(100);
      const box = await panel.boundingBox();
      assert.ok(box.x >= 0 && box.x + box.width <= width + 1, `${width}px 下弹框不应横向溢出：${JSON.stringify(box)}`);
      assert.strictEqual(await panel.locator('#ph-fields').evaluate((node) => node.scrollWidth <= node.clientWidth), true, `${width}px 下字段区不应横向滚动`);
      await page.screenshot({ path: path.join(outputDir, `project-handover-panel-${width}.png`), fullPage: true });
    }

    const zip = await JSZip.loadAsync(fs.readFileSync(docxPath));
    const documentXml = await zip.file('word/document.xml').async('string');
    assert.match(documentXml, /紫软（苏州）信息科技有限公司项目交接会议纪要/);
    assert.match(documentXml, /合同管理、项目管理、电子签章/);
    assert.match(documentXml, /国产化环境，麒麟系统/);
    assert.match(documentXml, /客开资源需要提前协调/);
    assert.match(documentXml, /首付款/);
    assert.match(documentXml, /完成项目启动和蓝图确认/);
    assert.match(documentXml, /完成电子签章接口开发/);

    await page.locator('#delivery-content').fill('');
    assert.strictEqual(await page.locator('#delivery-content').inputValue(), '', '测试页控件应已清空');
    await panel.locator('#ph-reread').click();
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    const deliveryRow = panel.locator('#ph-fields tr').filter({ hasText: '交付内容' });
    assert.match(await deliveryRow.innerText(), /\(空\)/, '清空控件后重新读取不应回退旧 textContent');

    await page.setViewportSize({ width: 1280, height: 900 });
    await page.evaluate(() => {
      const oldPanel = document.getElementById('project-handover-panel');
      const oldButton = document.querySelector('#project-handover-panel #ph-generate');
      oldButton.replaceWith(oldButton.cloneNode(true));
      oldPanel.style.display = 'none';
    });
    await page.addScriptTag({ url: `http://127.0.0.1:${address.port}/sh-browser-plugin/project-handover/content.js?reload=1` });
    const reloadedLauncher = page.locator('#project-handover-fab');
    await reloadedLauncher.locator('#ball').click();
    await reloadedLauncher.locator('#open').click();
    const reloadedPanel = page.locator('#project-handover-panel');
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已读取'));
    assert.match(await reloadedPanel.locator('#ph-status').innerText(), /已读取/);
    await reloadedPanel.locator('#ph-generate').click();
    await reloadedPanel.locator('#ph-status').waitFor({ state: 'visible' });
    await page.waitForFunction(() => document.querySelector('#project-handover-panel #ph-status')?.textContent.includes('已生成会议纪要'), null, { timeout: 1500 });

    await page.locator('#subject').evaluate((node) => { node.value = '普通流程'; });
    await page.locator('h1').evaluate((node) => { node.textContent = '普通流程'; });
    await page.waitForTimeout(1700);
    assert.strictEqual(await page.locator('#project-handover-fab').count(), 0, '非目标页面应清理入口');
    console.log(JSON.stringify({ outputDir, docxPath, screenshot: path.join(outputDir, 'project-handover-panel.png'), responsiveScreenshots: [768, 375].map((width) => path.join(outputDir, `project-handover-panel-${width}.png`)) }));
  } finally {
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
