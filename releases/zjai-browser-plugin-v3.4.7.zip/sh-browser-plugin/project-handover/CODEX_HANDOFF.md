## 当前目标

为标题符合 `(自动发起)【大区名称】-{合同号-签约单位}-合同金额项目移交` 的 OA 页面提供独立项目移交入口，读取页面字段并生成自动填充的会议纪要 DOCX。

## 已完成事项

- 新增独立 `project-handover` 模块，不扩大 `project-check` 两页白名单。
- 内置 `项目交接会议纪要模板.docx` 与 JSZip 3.10.1。
- 实现标题解析：大区、合同编号、签约单位、合同金额。
- 实现当前页面及同源 iframe 的编辑态/只读态字段读取；隐藏行与插件自身弹框不会被重复采集。
- 实现可拖动“移”入口和可拖动弹框，位置记忆、重新读取、错误提示、键盘焦点与响应式布局。
- 实现浏览器端 OOXML 填充与下载，文件名为 `项目交接会议纪要-{签约单位}-{YYYY-MM-DD}.docx`。
- 文件名已过滤全部 Unicode `Cc/Cf` 控制与格式字符、系统保留字符，并按 UTF-8 160 字节限制单位名称片段，完整文件名保留在 240 字节以内。
- 本地真实 Chromium 已验证：入口/弹框拖动、字段展示、同源 iframe、隐藏字段排除、修改后重新读取、清空后不回退旧值、DOCX 下载、非目标页清理、375/768/1280px 布局。

## 修改过的文件

- `content.js`
- `content.contract.test.js`
- `runtime.test.js`
- `fixture.html`
- `DESIGN.md`
- `lib/jszip.min.js`
- `assets/项目交接会议纪要模板.docx`
- `../manifest.json`
- `../README.txt`
- `../../CODEX_HANDOFF.md`
- `../../docs/superpowers/specs/2026-07-29-project-handover-design.md`
- `../../docs/superpowers/plans/2026-07-29-project-handover.md`

## 关键决策

- 模板随插件内置，浏览器不直接读取 `/Users/...` 本地物理路径。
- 生成文件只下载到本地，不自动上传或替换 OA 流程附件。
- 字段映射优先使用网页 label 与模板 label；流程标题为签约单位、合同编号等核心字段提供兜底。
- 跨域 iframe 受浏览器同源策略限制；当前支持同源 iframe，符合现有 xt.seeyon.com 表单结构假设。

## 未解决问题

- 尚未在客户真实 OA 项目移交流程页回归固定字段 DOM；若现场 label 与模板名称差异较大，需要补充 `LABEL_ALIASES` 或稳定字段 ID。
- LibreOffice 渲染环境缺少模板使用的部分中文字体，结构与 OOXML 已验证，最终视觉需在 Word/WPS 打开复核。
- 本轮未实现生成后自动上传 OA 附件；如后续需要，必须另行确认附件控件 DOM 和替换规则。

## 下一步最小指令

浏览器扩展页加载 `sh-browser-plugin/` 或安装 `pak/sh-browser-plugin-v3.4.6.zip`，打开真实项目移交流程，点击右侧“移”球，核对字段并生成 DOCX；如有漏字段，提供该字段 DOM 或完整表单截图。

## 2026-07-29 最终加固

- 修复入口按钮无法拖动、清空字段后误读弹框旧值、窗口缩小时弹框横向溢出。
- 增加打开弹框后焦点进入、关闭后焦点返回入口，以及入口/按钮 `focus-visible`。
- 文件名增加 Unicode 控制字符清理和 UTF-8 字节限制。
- 安装包改用 UTF-8 ZIP 条目生成，中文模板路径已用 Python `zipfile` 精确校验。
- 已从解压后的 `pak/sh-browser-plugin-v3.4.6.zip` 直接运行合同测试和真实 Chromium 测试，均通过。
